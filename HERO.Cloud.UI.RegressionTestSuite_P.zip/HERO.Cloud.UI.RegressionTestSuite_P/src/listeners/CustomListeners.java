package listeners;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.util.IOUtils;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.SkipException;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import base.base;
import utilities.MonitoringMail;
import utilities.TestConfig;
import utilities.TestUtil;

public class CustomListeners extends base implements ITestListener,ISuiteListener {

	public 	String messageBody;
	
	public void onFinish(ITestContext arg0) {
		// TODO Auto-generated method stub
		
	}

	public void onStart(ITestContext arg0) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub
		
	}

	public void onTestFailure(ITestResult arg0) {

	//	System.setProperty("org.uncommons.reportng.escape-output","false");
		try {
			
			String testName=arg0.getTestClass().getName().replace("testRepository.", "");
			
			TestUtil.captureScreenshot(testName);
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String FailReason=arg0.getThrowable().getMessage();
		//String Formatted_FailReason=(FailReason).substring((FailReason).lastIndexOf(':') + 1);
		
		test.log(LogStatus.FAIL, "Test Failed"+ "::"+FailReason);
		
		test.log(LogStatus.FAIL, test.addScreenCapture(TestUtil.screenshotName));
		
		
		System.setProperty("org.uncommons.reportng.escape-output", "false");
		Reporter.log("Click to see Screenshot");
		Reporter.log("<a target=\"_blank\" href="+TestUtil.screenshotName+">Screenshot</a>");
		Reporter.log("<br>");
		Reporter.log("<br>");
		Reporter.log("<a target=\"_blank\" href="+TestUtil.screenshotName+"><img src="+TestUtil.screenshotName+" height=200 width=200></img></a>");
		
	rep.endTest(test);
		rep.flush();
		
	}

	public void onTestSkipped(ITestResult arg0) {


	test.log(LogStatus.SKIP, arg0.getName()+" Skipped the test ");
		rep.endTest(test);
		rep.flush();
		
	}


	public void onTestStart(ITestResult arg0) {
     
	
		String testName=arg0.getTestClass().getName().replace("testRepository.", "");
		
		test=rep.startTest((testName+"::"+arg0.getName()), arg0.getName());
		String Modulename=arg0.getTestClass().getName().substring(arg0.getTestClass().getName().indexOf('.')+1, arg0.getTestClass().getName().lastIndexOf('.'));
		System.out.println("Modulename->"+Modulename);
		test.assignCategory(Modulename.toUpperCase());
		test.assignAuthor("TCS");
		
	}

	public void onTestSuccess(ITestResult arg0) {

	try {
			
			String testName=arg0.getTestClass().getName().replace("testRepository.", "");
			
			TestUtil.captureScreenshot(testName);
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		test.log(LogStatus.PASS, arg0.getClass().getSimpleName()+ "::" +arg0.getName()+" PASS");
		
		test.log(LogStatus.PASS, test.addScreenCapture(TestUtil.screenshotName));
		
		rep.endTest(test);
		rep.flush();
		
	}

	public void onFinish(ISuite arg0) {
		
		MonitoringMail mail = new MonitoringMail();
		 
		
		
		String MessageBodyFilePath=System.getProperty("user.dir")+"/src/resources/emailContent/mail.html";
		
		 File file=new File(MessageBodyFilePath);
		try {
			messageBody = FileUtils.readFileToString(file, "UTF-8");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
				
	
		try {
			mail.sendMail(TestConfig.server, TestConfig.from, TestConfig.to, TestConfig.subject, messageBody);
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}

	public void onStart(ISuite arg0) {
		
		
		
	}

	

	
	

}
