package pages;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.asserts.SoftAssert;

import base.base;

public class bulkUpdatePage extends base
{
	By link_upload_SearchViewpage=By.xpath("//label[contains(text(),'UPLOAD')]");
	By link_CreateNewRequest=By.xpath("//app-search[1]/div[1]/div[1]/div[2]/div[1]/div[1]/button[1]/span[1]");
	By radiobutton_ViewType_Claims=By.xpath("//label[contains(text(),'Claims')]");
	By NextButton=By.xpath("//button[contains(text(),'Next')]");
	By InputColumn_value=By.xpath("//div[contains(text(),'isa_authorizationInformationQualifier_1')]");
	By rightChevron=By.xpath("//p-picklist/div/div[3]/button[1]/span[1]");
	By OutputColumn_value=By.xpath("//div[contains(text(),'isa_authorizationInformationQualifier_1')]");
	
	By span_Actions=By.xpath("//span[contains(text(),'ACTIONS')]");
	By downChevron_Actions=By.xpath("//p-splitbutton/div/button[2]/span[1]");
	By dropdownValues_Actions=By.xpath("//p-splitbutton/div/p-menu/div/ul");
	
	By RequestIdLink=By.xpath("/html/body/app-root/div/app-admin-layout/div/app-search/div[4]/p-table/div/div/div/div[2]/table/tbody/tr/td[1]/a");
	By Title_RequestWorkflow=By.xpath("//h1[contains(text(),'Request Work Flow')]");
	By Link_DownloadTemplate=By.xpath("//a[contains(text(),'Download Template')]");
	By Upload_File=By.xpath("//app-fields/div/div[2]/div[2]/div[1]/div[1]/input");
	By BulkUpdate_Actions=By.xpath("//span[contains(text(),'Bulk Update')]");
	By TextArea_BulkUpdate=By.xpath("//app-fields/div[2]/p-sidebar/div/div[2]/div/app-bulkupload/div/div[2]/div[3]/textarea");
	By Button_Submit=By.xpath("//app-bulkupload/div/div[2]/div[4]/div/button[1]");
	By CountMessage_FileUploadHistory=By.xpath("//span[contains(text(),'Total records showing -')]");
	By RequestType_FileUploadHistory=By.xpath("//tbody/tr[1]/td[2]/span[1]");
	By InputFileName_FileUploadHistory=By.xpath("//app-search/div[4]/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[3]/span/a");
	
	By SelectLoop=By.xpath("//app-bulkupload/div/div[2]/div[2]/table/tbody/tr/td[1]/div/p-dropdown/div/span");
	By FirstElement_LoopDropdown=By.xpath("//ul/p-dropdownitem[1]/li/span");
	
	By SelectSegment=By.xpath("//app-bulkupload/div/div[2]/div[2]/table/tbody/tr/td[2]/div/p-dropdown/div/span");
	By FirstElement_SegmentDropdown=By.xpath("//ul/p-dropdownitem[1]/li/label");
	
	By SelectElement=By.xpath("//app-bulkupload/div/div[2]/div[2]/table/tbody/tr/tr/td[1]/p-dropdown/div/span");
	By FirstElement_ElementDropdown=By.xpath("//ul/p-dropdownitem[1]/li/span");
	
	By IfTextbox=By.xpath("//*[@id='ifValue00']");
	By ChangeToTextbox=By.xpath("//*[@id='changeTo00']");
	By PlusIcon=By.xpath("//app-bulkupload/div/div[2]/div[2]/table/tbody/tr/tr/td[7]/a/em");
	
	By DeleteLoop=By.xpath("//app-bulkupload/div/div[2]/div[2]/table/tbody/tr/tr/td[6]/p-checkbox/div/div[2]");
	By row_BulkUpdateInstructionsPage=By.xpath("//app-bulkupload/div/div[2]/div[2]/table/tbody/tr");
	
	By RequestType_Filter=By.xpath("//app-search/div[3]/div/form/fieldset[1]/p-multiselect/div/div[2]");
	By RequestedBy_Filter=By.xpath("//div[contains(text(),'Select User')]");
	By Status_Filter=By.xpath("//div[contains(text(),'Select Status')]");
	By BulkUpdateOption_RequestTypeFilter=By.xpath("//span[contains(text(),'Bulk Update')]");
	By RequestedStartDate_Filter=By.xpath("//app-search/div[3]/div/form/fieldset[3]/p-calendar/span/Input");
	
	By Searchbox_RequestedByFilter=By.xpath("//app-search/div[3]/div/form/fieldset[2]/p-multiselect/div/div[4]/div[1]/div[2]/input");
	By SearchResult_RequestedByFilter=By.xpath("//app-search/div[3]/div/form/fieldset[2]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem/li/label");

	
	By Button_ApplyFilter=By.xpath("//span[contains(text(),'Apply Filter')]");
	By ErrorTextemptyLoop_BulkUpdate=By.xpath("//div[contains(text(),'Please select loop details to continue')]");
	By Dropdown_RequestType=By.xpath("//app-search/div[3]/div/form/fieldset[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem");
	By Dropdown_Status=By.xpath("//app-search/div[3]/div/form/fieldset[5]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem");
	By Dropdown_RequestedBy=By.xpath("//app-search/div[3]/div/form/fieldset[2]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem");
	
	By Username_UserProfile=By.xpath("//app-user-profile/div/div[2]/div/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr/td[1]");
	By EmptyMessage=By.xpath("//li[contains(text(),'No results found')]");
  
	By Link_InputFileName_ReqWorkflow=By.xpath("//app-search/div[5]/p-sidebar/div/div[2]/div/div/div/div[2]/div/table/tr[4]/td[2]/a");
	By List_RequestId_uploadHistory=By.xpath("//app-search[1]/div[4]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr/td[1]/a[1]");
	By Button_CancelProcess=By.xpath("//Button[contains(text(),'Cancel Process')]");
	By Button_ConfirmPopup_Yes=By.xpath("//app-search/p-toast[2]/div/p-toastitem/div/div/div[3]/button[1]");
	
public void clickUploadLink_SearchView() throws InterruptedException
{
	
Thread.sleep(10000);
wait.until(ExpectedConditions.elementToBeClickable(link_upload_SearchViewpage));
driver.findElement(link_upload_SearchViewpage).click();
	
}	

public void clickCreateNewRequest()
{
	//wait.until(ExpectedConditions.elementToBeClickable(link_CreateNewRequest));
	driver.findElement(link_CreateNewRequest).click();
			
}

public void selectViewType_Claims()
{
   driver.findElement(radiobutton_ViewType_Claims).click();	
    }

public void clickNextButton()
{
	wait.until(ExpectedConditions.elementToBeClickable(NextButton));
	driver.findElement(NextButton).click();	
	}	

public void selectInputColumns()
{

	wait.until(ExpectedConditions.presenceOfElementLocated(InputColumn_value));
	driver.findElement(InputColumn_value).click();
  
	wait.until(ExpectedConditions.elementToBeClickable(rightChevron));
	driver.findElement(rightChevron).click();	
	
	wait.until(ExpectedConditions.elementToBeClickable(NextButton));
	driver.findElement(NextButton).click();
	
	}	
	
public void selectOutputColumns()
{

	wait.until(ExpectedConditions.presenceOfElementLocated(OutputColumn_value));
	driver.findElement(OutputColumn_value).click();
  
	wait.until(ExpectedConditions.elementToBeClickable(rightChevron));
	driver.findElement(rightChevron).click();	
	
	wait.until(ExpectedConditions.elementToBeClickable(NextButton));
	driver.findElement(NextButton).click();
	
	}		

public WebElement verifyActions()
{
	WebElement Actions=driver.findElement(span_Actions);
	return Actions;
 }


public void clickDownChevron_Actions() throws InterruptedException
{
	Thread.sleep(3000);
	//wait.until(ExpectedConditions.presenceOfElementLocated(downChevron_Actions));
	driver.findElement(downChevron_Actions).click();
	}

public String listDropdownValues_Actions()
{
driver.findElement(downChevron_Actions).click();
String dropdownActions=driver.findElement(dropdownValues_Actions).getText();
// System.out.println(dropdownActions);
 
 
 /*
  System.out.println("dropdownActions size->"+dropdownActions.size());
  
 List<String> dropdownValues = new ArrayList<String>();
 for(int j=0;j<dropdownActions.size();j++)
 {

	String xpath_dropdownActions="//p-splitbutton/div/p-menu/div/ul/li["+(j+1)+"]/a/span";
	 //String value=driver.findElement(By.xpath(xpath_dropdownActions)).getText();
	String value=dropdownActions.get(j).getText();
	 System.out.println("Read Value->"+value);
	 dropdownValues.add(value);
	 
	}
	*/
 System.out.println("dropdownValues->"+dropdownActions);
 return dropdownActions;	
}


public void clickRequestIdLink()
{
	/*
	try{
	driver.findElement(RequestIdLink).click();
	}
	catch(Exception e)
	{
	System.out.println(e.getMessage());
	
	}
	*/
	
	driver.findElement(RequestIdLink).click();
}


public String getTitlePageOnclickingRequestIdLink()
{
	wait.until(ExpectedConditions.elementToBeClickable(RequestIdLink));
	WebElement Element=driver.findElement(RequestIdLink);
	
		if (Element.isEnabled() && Element.isDisplayed()) 
		{
		System.out.println("Clicking on element with using java script click");

		((JavascriptExecutor) driver).executeScript("arguments[0].click();", Element);
			
		} 
		else 
		{
			System.out.println("Unable to click on element");
		}

	String Pagetitle=driver.findElement(Title_RequestWorkflow).getText();
   return Pagetitle;
}
               

public void clickDownloadInputFile_RequestWorkFlow()
{
	driver.findElement(By.xpath("InputFile_RequestWorkFlow")).click();
  }

public void clickDownloadTemplate()
{
	driver.findElement(Link_DownloadTemplate).click();
	
}

public void upload_file() throws IOException, InterruptedException
{
	  String[] Value = base.getPropertyValue();
	  String DownloadFilepath=Value[2];
	  System.out.println(DownloadFilepath);
	  
	
	
	
//  test.log(LogStatus.INFO, "Getting Downloaded File Name");
	  File getLatestFile = base.getLatestFilefromDir(DownloadFilepath);
	  
	  String fileName = getLatestFile.getName();
	  System.out.println("Downloaded File name->"+fileName);
	
	  
	  
	  
	  WebElement Upload=driver.findElement(Upload_File);
	  String Path_UploadedFile=DownloadFilepath+"\\"+fileName;
	  Upload.sendKeys(Path_UploadedFile);
	
	  
	}

 public void clickBulkUpdate_Actions() throws InterruptedException
 {
driver.findElement(downChevron_Actions).click();

driver.findElement(BulkUpdate_Actions).click();
 }

 public void FillDetailsBulkUpdate() throws InterruptedException
 {
//Select loop
Thread.sleep(3000);
driver.findElement(SelectLoop).click();
driver.findElement(FirstElement_LoopDropdown).click();

//Select Segment
driver.findElement(SelectSegment).click();
driver.findElement(FirstElement_SegmentDropdown).click();

//Select Element
driver.findElement(SelectElement).click();
driver.findElement(FirstElement_ElementDropdown).click();

//Check Delete loop
driver.findElement(DeleteLoop).click();


//Enter Comments in Text area
driver.findElement(TextArea_BulkUpdate).sendKeys("OK");
 }
 
 public void verifyLoopSegmentElementPlusIcon() throws InterruptedException
 {
	 SoftAssert softassert=new SoftAssert();
	 
	 Thread.sleep(3000);
	 
	 List<WebElement> row1=driver.findElements(row_BulkUpdateInstructionsPage);
	 int Rowsize_PriorClickPlusIcon=row1.size();
	 System.out.println("Rowsize_PriorClickPlusIcon->"+Rowsize_PriorClickPlusIcon);
	 
	 WebElement Loop=driver.findElement(SelectLoop);
	 WebElement Segment=driver.findElement(SelectSegment);
	 WebElement Element=driver.findElement(SelectElement);
	 
	 WebElement If=driver.findElement(IfTextbox);
	 WebElement ChangeTo=driver.findElement(ChangeToTextbox);
	 
	 WebElement Plus=driver.findElement(PlusIcon);
	 
	
	 
	 Plus.click();
	 Thread.sleep(2000);
	 List<WebElement> row2=driver.findElements(row_BulkUpdateInstructionsPage);
	 int Rowsize_PostClickPlusIcon=row2.size();
	 System.out.println("Rowsize_PostClickPlusIcon->"+Rowsize_PostClickPlusIcon);
	 
	 softassert.assertTrue(Loop.isDisplayed(),"Loop textbox not displaying"); 
	 softassert.assertTrue(Segment.isDisplayed(),"Segment textbox not displaying"); 
	 softassert.assertTrue(Element.isDisplayed(),"Element textbox not displaying"); 
	 softassert.assertTrue(Loop.isDisplayed(),"Loop textbox not displaying"); 
	 softassert.assertTrue(If.isDisplayed(),"If textbox not displaying"); 
	 softassert.assertTrue(ChangeTo.isDisplayed(),"ChangeTo textbox not displaying"); 
	 softassert.assertTrue(Rowsize_PriorClickPlusIcon==Rowsize_PostClickPlusIcon-1,"Row not created upon clicking Plus icon"); 
	 
	 softassert.assertAll(); 
	 
	 
 }
 
 
 
 
 public void submit_BulkUpdateReq()
 {
//Click On Submit button
driver.findElement(Button_Submit).click();

}

public String Capture_Error() throws InterruptedException
{
	Thread.sleep(2000);
	driver.switchTo().defaultContent();

	String Errortext=driver.findElement(ErrorTextemptyLoop_BulkUpdate).getText();
	return Errortext;
}

public int Count_Records()
{
	try
	{
	String Message_FileUploadHistory=driver.findElement(CountMessage_FileUploadHistory).getText();
    String Count[]=Message_FileUploadHistory.split("-");
    System.out.println("No of rows in File Upload history table->"+Integer.parseInt(Count[1].trim()));
	return +Integer.parseInt(Count[1].trim());
	}
	
	catch(Exception e)
	{
		System.out.println(e.getMessage());
		System.out.println("Message not present as no rows in file upload history");
		int Count_rows=0;
		return Count_rows;
	}
}


public String getRequestType_FileUploadHistory()
{
	String RequestType=driver.findElement(RequestType_FileUploadHistory).getText();
	return RequestType;
	
}

public String getInputFileName_FileUplaodHistory()
{
	String InputFileName=driver.findElement(InputFileName_FileUploadHistory).getText();
	return InputFileName;
	}

public void DownloadInputFile_RequestWorkflow() throws InterruptedException 
{
	wait.until(ExpectedConditions.elementToBeClickable(Link_InputFileName_ReqWorkflow));
	driver.findElement(Link_InputFileName_ReqWorkflow).click();
  Thread.sleep(10000);
  }

public void ApplyFilter() throws InterruptedException
{
	//Selecting Requestid as 'Bulk Update'
	driver.findElement(RequestType_Filter).click();
	driver.findElement(BulkUpdateOption_RequestTypeFilter).click();;
	driver.findElement(By.xpath("//html//body")).click();
	
	//Select Requested by
	
		driver.findElement(RequestedBy_Filter).click();
		driver.findElement(Searchbox_RequestedByFilter).sendKeys("Ram KK");
	    driver.findElement(SearchResult_RequestedByFilter).click();
	    driver.findElement(By.xpath("//html//body")).click();
		
	
	
	
	//Select requested Start date as 2 month earlier date
	
	driver.findElement(RequestedStartDate_Filter).click();
  
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM/dd/yyyy");  
	LocalDateTime now = LocalDateTime.now(); 
	now=now.minusMonths(1);
	System.out.println("Date 1 months ago from Today's date->"+dtf.format(now));
	String DatetobeEntered=dtf.format(now).trim();
	
	
	driver.findElement(RequestedStartDate_Filter).sendKeys(Keys.chord(Keys.CONTROL,"a",Keys.DELETE));
	driver.findElement(RequestedStartDate_Filter).sendKeys(DatetobeEntered);
	driver.findElement(By.xpath("//html//body")).click();
	
	//Click on Apply Filter
	 driver.findElement(Button_ApplyFilter).click();
	
    }


public void VerifyRequestType()
{
	 SoftAssert softAssert = new SoftAssert();

	int Count_records=Count_Records();
 
  for(int j=0;j<Count_records;j++)
  {
	String xpath_RequestType="//tbody/tr["+(j+1)+"]/td[2]/span[1]";
	String RequestType=driver.findElement(By.xpath(xpath_RequestType)).getText().trim();
	 
	softAssert.assertTrue(RequestType.equalsIgnoreCase("Bulk Update"), "Request Type not Bulk Update");
      }
  softAssert.assertAll();
  }


 public List<String> getDropdownValues_RequestType()
 {
	 driver.findElement(RequestType_Filter).click();
	 List<WebElement> RequestType_filtervalues=driver.findElements(Dropdown_RequestType);
     
	 List<String> RequestType_values=new ArrayList<String>();
	 for(int j=0;j<RequestType_filtervalues.size();j++)
	 {
	 String xpath_requestType="//app-search/div[3]/div/form/fieldset[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem["+(j+1)+"]";
	 String value=driver.findElement(By.xpath(xpath_requestType)).getText();
	 RequestType_values.add(value);
		 
	 }
	 
	System.out.println("RequestType_values->"+RequestType_values) ;
  return RequestType_values;
 
 }
 
 

public List<String> getDropdownValues_Status()
  {
		 driver.findElement(Status_Filter).click();
		 List<WebElement> Status_filtervalues=driver.findElements(Dropdown_Status);
	     
		 List<String> Status_values=new ArrayList<String>();
		 for(int k=0;k<Status_filtervalues.size();k++)
		 {
		 String xpath_status="//app-search/div[3]/div/form/fieldset[5]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem["+(k+1)+"]";
		 String value=driver.findElement(By.xpath(xpath_status)).getText();
		 Status_values.add(value);
			 
		 }
		 
		System.out.println("Status_values->"+Status_filtervalues) ;
		
	  return Status_values;
	 }

public List<String> getDropdownValues_RequestedBy()
{
		 driver.findElement(RequestedBy_Filter).click();
		 List<WebElement> RequestedBy_Filter=driver.findElements(Dropdown_RequestedBy);
	     
		 List<String> RequestedBy_values=new ArrayList<String>();
		 for(int k=0;k<RequestedBy_Filter.size();k++)
		 {
		 String xpath_requestedby="//app-search/div[3]/div/form/fieldset[2]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem["+(k+1)+"]";
		 String value=driver.findElement(By.xpath(xpath_requestedby)).getText();
		 RequestedBy_values.add(value.trim());
			 
		 }
		 
		System.out.println("RequestedBy_values->"+RequestedBy_values) ;
		
	  return RequestedBy_values;
	 }

  public List<String> activeUserList_userProfile() throws InterruptedException
  { 
	  
	List<WebElement> UserList_userProfile=driver.findElements(Username_UserProfile);
	List<String> activeUserList=new ArrayList<String>();
	
	Thread.sleep(3000);
	
	 for(int k=0;k<UserList_userProfile.size();k++)
	 {
		 
		 
	 String xpath_activeUserRows="//app-user-profile/div/div[2]/div/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr["+(k+1)+"]";
	 String xpath_userList="//app-user-profile/div/div[2]/div/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr["+(k+1)+"]/td[1]";
	 if((driver.findElement(By.xpath(xpath_activeUserRows))).getAttribute("class").equals("ng-star-inserted"))
	      {
		 String value=driver.findElement(By.xpath(xpath_userList)).getText();
		 activeUserList.add(value.trim());
		    }
	 }
	 System.out.println("activeUserList->"+activeUserList) ;
	 return activeUserList;
 
  }

public String getSegmentEmptymessage()
{
	driver.findElement(SelectSegment).click();
	String Message=driver.findElement(EmptyMessage).getText();
    return Message;
}

public String getElementEmptymessage()
{
	driver.findElement(SelectElement).click();
	String Message=driver.findElement(EmptyMessage).getText();
    return Message;
}
	
public void readStatus_uploadhistory() throws InterruptedException
{
	 SoftAssert softassert=new SoftAssert();
	  List<WebElement> List_RequestId=driver.findElements(List_RequestId_uploadHistory);
	  
	  for(int j=0;j<List_RequestId.size();j++)
	  {
	String xpath_status="//app-search[1]/div[4]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr["+(j+1)+"]/td[8]/span[1]";
	String Status_uploadHistory=driver.findElement(By.xpath(xpath_status)).getText();
	System.out.println("preStatus_uploadHistory->"+Status_uploadHistory);
	
	if (!(Status_uploadHistory.equalsIgnoreCase("cancelled")))
	  {
		 String xpath_RequestId="//app-search[1]/div[4]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr["+(j+1)+"]/td[1]/a[1]" ;
		  
		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpath_RequestId)));
		 driver.findElement(By.xpath(xpath_RequestId)).click();
		 
		 //Click on cancel process
		 wait.until(ExpectedConditions.elementToBeClickable(Button_CancelProcess));
		 driver.findElement(Button_CancelProcess).click();
		 
		 Thread.sleep(2000);
		 driver.switchTo().defaultContent();
		 
		driver.findElement(Button_ConfirmPopup_Yes).click();
		Thread.sleep(2000);
		 
		String postStatus_uploadHistory=driver.findElement(By.xpath(xpath_status)).getText();
		System.out.println("postStatus_uploadHistory->"+postStatus_uploadHistory);
		softassert.assertTrue(postStatus_uploadHistory.equalsIgnoreCase("Cancelled"));
		
		 break;
		 
	      }
	 
	  }
	  softassert.assertAll();
	 
		
	}




}

