package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.base;

public class userDashboardPage extends base 
{

	By label_pageTitleUserDashboard=By.xpath("//a[contains(text(),'User Dashboard')]");
	By link_ResourceProductivtyReport=By.xpath("//a[contains(text(),'Resource Productivity Report')]");
	By label_pageTitleResourceProductivityReport=By.xpath("//h1[contains(text(),'Resource Productivity Report')]");
	By link_ExportToExcel_Dashboard=By.xpath("//app-performance[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[1]/a[1]/em[1]");
	By label_SectionsToExport=By.xpath("//div[contains(text(),'Select Sections to Export')]");
	By Multiselect_SectionsToExport=By.xpath("//app-performance[1]/div[1]/div[1]/div[1]/div[1]/div[1]/p-multiselect[1]/div[1]/div[4]/div[1]/div[1]/div[2]");
	By Options_SectionsToExport=By.xpath("//app-performance/div[1]/div/div/div[1]/div/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem/li/span");
	By link_Claim=By.xpath("//app-pendeditem/div/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[1]/a");
	By header_friendlyUI=By.xpath("//app-editor-business/app-editor-side-section/header");
	By table_MyPerformance=By.xpath("//user-dashboard/div/app-performance/div[1]/div/div/div[1]");
	By todaysWorkItemsSection=By.xpath("//user-dashboard/div/app-performance/div[1]/div/div/div[2]/div/div");
	By todaysProductivitySection=By.xpath("//app-performance[1]/div[1]/div[1]/div[1]/div[3]/div[1]/div[1]");
	By todaysHoursSection=By.xpath("//user-dashboard/div/app-performance/div[1]/div/div/div[4]/div/div");
	By PendedItemsSection_Header=By.xpath("//div[contains(text(),'PENDED ITEMS')]");
	By PendedItemsSection_BodyHeader=By.xpath("//user-dashboard/div/app-pendeditem/div/div/div[2]/p-table/div/div/div/div[1]");
	By PendedItemsSection_Content=By.xpath("//user-dashboard/div/app-pendeditem/div/div/div[2]/p-table/div/div/div");
	
	
	By link_DemandDraw=By.xpath("//span[contains(text(),'Demand Draw')]");
	By button_Search_WorkItemDemandDraw=By.xpath("//button[contains(text(),'Search')]");
	By link_ExportToExcel_WorkItemDemandDraw=By.xpath("//app-workdemanddrawitem/div/div/div/div/div[4]/div/div[1]/div/ul/li[1]/a/em");
	By label_ClaimNumber_WorkItemsDemandDrawPage=By.xpath("//app-workdemanddrawitem/div/div/div/div/div[1]/div[1]/input");
	By label_QueueName_WorkItemsDemandDrawPage=By.xpath("//app-workdemanddrawitem[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/p-multiselect[1]/div[1]/div[2]");
	By label_Status_WorkItemsDemandDrawPage=By.xpath("//div[contains(text(),'Select Status')]");	
	By label_DateCreated_WorkItemsDemandDrawPage=By.xpath("//app-workdemanddrawitem[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/p-calendar[1]/span[1]/input[1]");
	By link_Calendar_Today=By.xpath("//span[contains(text(),'Today')]");
	By SearchResultSection_WorkitemsDemandDrawPage=By.xpath("//app-workdemanddrawitem[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[1]");
	By Button_Reset_WorkitemsDemandDrawPage=By.xpath("//button[contains(text(),'Reset')]");
    By dropdown_AssignedStatus_WorkItemsDemandDrawPage=By.xpath("//label[contains(text(),'Assigned')]");
    By searchResult_1stRow_WorkItemsDemandDrawPage=By.xpath("//*[@id='demand']/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[1]/a");
    By Error_AssignedDemandDraw=By.xpath("//div[contains(text(),'Unable to demand draw this work item')]");
    
    
	//Main page 
	By Sorticon_Claim_Mainpage=By.xpath("//thead/tr[1]/th[1]/p-sorticon[1]/i[1]");
    By webtable_ClaimNumber_mainpage=By.xpath("//app-pendeditem/div/div/div[2]/p-table/div/div/div/div[2]/table/tbody");
	By rows_ClaimNumber_mainpage=By.tagName("tr");
	By cols_ClaimNumber_mainpage=By.tagName("td");
	
   //Work items Demand draw page
	By Sorticon_workItems_DemandDrawPage=By.xpath("//*[@id='demand']/p-table/div/div/div/div[1]/div/table/thead/tr/th[1]/p-sorticon/i");
	By webtable_WorkItem_DemandDrawPage=By.xpath("//app-workdemanddrawitem[1]/div[1]/div[1]/div[1]/div[1]/div[4]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody");
	By rows_WorkItem_mainpage=By.tagName("tr");;
	By cols_WorkItem_mainpage=By.xpath("td");
	
	
	public void clickResoureProductivityreport()
	{
	driver.findElement(link_ResourceProductivtyReport).click();
		
	}
	
	public String getResourceProductivityRptTitle()
	{
		String ResourceProductivityRptTitle=driver.findElement(label_pageTitleResourceProductivityReport).getText();
		System.out.println("ResourceProductivityRptTitle->"+ResourceProductivityRptTitle);
		
		return ResourceProductivityRptTitle;
	
	}
	
	public List getoptionsSectionstoExport()
	{
		 driver.findElement(label_SectionsToExport).click();
		 List<WebElement> Options=driver.findElements(Options_SectionsToExport);

		 return Options;
	}
	
	
	
	
	 public void DownloadExcel_Dashboard() throws InterruptedException 
	 {
		 driver.findElement(label_SectionsToExport).click();
		 driver.findElement(Multiselect_SectionsToExport).click();
		 driver.findElement(link_ExportToExcel_Dashboard).click();
	     Thread.sleep(10000);
	 }
	 
	public void clickClaimLink()
	{
	 driver.findElement(link_Claim).click();
	}
	 
  public String getOpenPageHeader()
  {
	String OpenPageHeader=driver.findElement(header_friendlyUI).getText();
	return OpenPageHeader;
  }

  public WebElement getMyPerformanceTable()
  {
	 return driver.findElement(table_MyPerformance) ;  
  }
  
  
  
  public String getMyPerformanceTableContent()
 {
	  String MyPerformanceTableContent=driver.findElement(table_MyPerformance).getText();  
	  return MyPerformanceTableContent; 
  }
  
  public WebElement gettodaysWorkItemsSection()
  {
	  return driver.findElement(todaysWorkItemsSection) ;
	 
  }
  
  public WebElement gettodaysProductivitySection()
  {
	 return driver.findElement(todaysProductivitySection) ;
	 
   }
  
  public WebElement gettodaysHoursSection()
  {
	return driver.findElement(todaysHoursSection) ;
   }
  
  public WebElement getPendedItemsSection_header()
  {
	return driver.findElement(PendedItemsSection_Header) ;
   }
  
  public WebElement getPendedItemsSection_Bodyheader()
  {
	return driver.findElement(PendedItemsSection_BodyHeader) ;
   }
  
  public WebElement getPendedItemsSection_content()
  {
	return driver.findElement(PendedItemsSection_Content) ;
   }
  
  
  public void clickDemanadDraw()
  {
	driver.findElement(link_DemandDraw).click();  
	  
	 }
 
  public void clickSearchButtonWorkItemDemandDraw()
  {
	  driver.findElement(button_Search_WorkItemDemandDraw).click();  
  }
  
  public void DownloadExcelWorkItemDemandDraw()
  {
	  driver.findElement(button_Search_WorkItemDemandDraw).click();  
  }
  
  public void DownloadExcel_WorkItemDemandDraw() throws InterruptedException 
	 {
		 
		 driver.findElement(link_ExportToExcel_WorkItemDemandDraw).click();
	     Thread.sleep(10000);
	 }
   
  public String getValueClaimNumber_WorkitemsDemandDrawPage()
  {
	  String ClaimNumber_Default=driver.findElement(label_ClaimNumber_WorkItemsDemandDrawPage).getAttribute("placeholder");
	  return ClaimNumber_Default;
  }
  
  public String getValueQueueName_WorkitemsDemandDrawPage()
  {
	  String QueueName_Default=driver.findElement(label_QueueName_WorkItemsDemandDrawPage).getText();
       return QueueName_Default;
  }
  
  public String getValueStatus_WorkitemsDemandDrawPage()
  {
	  String Status_Default=driver.findElement(label_Status_WorkItemsDemandDrawPage).getText();
	  return Status_Default;
  }
   
  
  
  
  
  public String getValueDateCreated_WorkitemsDemandDrawPage()
  {
	  String ClaimNumber_Default=driver.findElement(label_DateCreated_WorkItemsDemandDrawPage).getAttribute("placeholder");
	  return ClaimNumber_Default;
  }
  
  public void selectDateCreated__WorkitemsDemandDrawPage()
  {
	  driver.findElement(label_DateCreated_WorkItemsDemandDrawPage).click();
	  
	  driver.findElement(link_Calendar_Today).click();
	  
  }
  
  public WebElement getSearchResultSection_WorkitemsDemandDrawPage()
  {
	 return driver.findElement(SearchResultSection_WorkitemsDemandDrawPage) ;
	 }
  
  public void clickReset_WorkitemsDemandDrawPage()
  {
	  driver.findElement(Button_Reset_WorkitemsDemandDrawPage).click();
  }
  
  public void clickSorticon_claim()
  {
  driver.findElement(Sorticon_Claim_Mainpage).click();
  }
  
  public void clickSorticon_workItems_DemandDrawPage()
  {
  driver.findElement(Sorticon_workItems_DemandDrawPage).click();
  }
  
  public void SelectStatusAssigned()
  {
	  driver.findElement(label_Status_WorkItemsDemandDrawPage).click();
	  driver.findElement(dropdown_AssignedStatus_WorkItemsDemandDrawPage).click();
	  driver.findElement(By.xpath("//html//body")).click();
  }
  
  public void click_WorkItemSearchResultlink()
  {
	  driver.findElement(searchResult_1stRow_WorkItemsDemandDrawPage).click(); 
  }
  
 public String captureError_AssignedDemandDraw() throws InterruptedException
 {
	 Thread.sleep(2000);
	 driver.switchTo().defaultContent();
	 String error=driver.findElement(Error_AssignedDemandDraw).getText();
	 return error;
 }
  
  
  public List<String> ascendingOrderList_Claim()
  {
	  WebElement webtable_ClaimNumber_asc_mainpage=driver.findElement(webtable_ClaimNumber_mainpage);
	  List<WebElement> rows_ClaimNumber_asc=webtable_ClaimNumber_asc_mainpage.findElements(rows_ClaimNumber_mainpage);
	  List<WebElement> cols_ClaimNumber_asc=rows_ClaimNumber_asc.get(0).findElements(cols_ClaimNumber_mainpage);
	  System.out.println(rows_ClaimNumber_asc.size());
	  System.out.println( cols_ClaimNumber_asc.size()); 
			
//Getting Rows list
				 
	 List<String> rows_Claim_asc = new ArrayList<String>();
     for(int j=0;j<rows_ClaimNumber_asc.size();j++)
		 {
		 //System.out.println(rows_Rolename_asc.get(j).getText().replace("\n", " "));
		  rows_Claim_asc.add(rows_ClaimNumber_asc.get(j).getText().replace("\n", " ")); 
			 }
     return rows_Claim_asc;
	}
	
		
	

  public List<String> descendingOrderList_Claim()
  {
	  WebElement webtable_ClaimNumber_desc_mainpage=driver.findElement(webtable_ClaimNumber_mainpage);
	  List<WebElement> rows_ClaimNumber_desc=webtable_ClaimNumber_desc_mainpage.findElements(rows_ClaimNumber_mainpage);
	  List<WebElement> cols_ClaimNumber_desc=rows_ClaimNumber_desc.get(0).findElements(cols_ClaimNumber_mainpage);
	  
	  System.out.println(rows_ClaimNumber_desc.size());
	  System.out.println( cols_ClaimNumber_desc.size()); 
				 
		//Getting Rows List		
	   List<String> rows_claim_desc = new ArrayList<String>();
  
	   for(int j=0;j<rows_ClaimNumber_desc.size();j++)
		 {
	     //System.out.println(rows_Rolename_asc.get(j).getText().replace("\n", " "));
		   rows_claim_desc.add(rows_ClaimNumber_desc.get(j).getText().replace("\n", " ")); 
						
		  }
		 
   return rows_claim_desc; 
  }
  
  public List<String> ascendingOrderList_Workitems_DemandDraw()
  {
	  WebElement webtable_Workitems_asc_DemandDrawpage=driver.findElement(webtable_WorkItem_DemandDrawPage);
	  List<WebElement> rows_Workitems_asc=webtable_Workitems_asc_DemandDrawpage.findElements(rows_WorkItem_mainpage);
	  List<WebElement> cols_Workitems_asc=rows_Workitems_asc.get(0).findElements(cols_WorkItem_mainpage);
		 
	  System.out.println("Rows in Woekitem Demand draw page->"+rows_Workitems_asc.size());
      System.out.println("Cols in Woekitem Demand draw page->"+cols_Workitems_asc.size()); 
				 
			
			
				 //Getting Active Rows list
				 
	 List<String> rows_WI_asc = new ArrayList<String>();
 
	 for(int j=0;j<rows_Workitems_asc.size();j++)
		 {
		//System.out.println(rows_Rolename_asc.get(j).getText().replace("\n", " "));
		 rows_WI_asc.add(rows_Workitems_asc.get(j).getText().replace("\n", " ")); 
		 }
		return rows_WI_asc;
		 
  }
  
  public List<String> descendingOrderList_Workitems_DemandDraw()
  {
	  WebElement webtable_Workitem_desc_DemandDrawpage=driver.findElement(webtable_WorkItem_DemandDrawPage);
	  List<WebElement> rows_Workitems_desc=webtable_Workitem_desc_DemandDrawpage.findElements(rows_WorkItem_mainpage);
	  List<WebElement> cols_Workitems_desc=rows_Workitems_desc.get(0).findElements(cols_WorkItem_mainpage);
		 
		 System.out.println("Rows in Woekitem Demand draw page->"+rows_Workitems_desc.size());
		 System.out.println("Cols in Woekitem Demand draw page->"+cols_Workitems_desc.size()); 
				 
			
				 //Getting  Rows list
				 
	 List<String> rows_WI_desc = new ArrayList<String>();
  
		 for(int j=0;j<rows_Workitems_desc.size();j++)
		 {
           //System.out.println(rows_Rolename_asc.get(j).getText().replace("\n", " "));
			 rows_WI_desc.add(rows_Workitems_desc.get(j).getText().replace("\n", " ")); 
	      }
		 
			return rows_WI_desc; 
  }
  
  
  
  
}
