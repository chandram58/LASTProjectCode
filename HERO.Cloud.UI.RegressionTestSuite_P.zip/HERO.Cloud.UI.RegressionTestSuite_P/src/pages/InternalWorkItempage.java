package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.base;

public class InternalWorkItempage extends base{
	
	By btn_drwnxtitm=By.xpath("//span[contains(text(),'Draw-Next Item')]//parent::li");
	By label_pageTitle=By.xpath("//app-editor-business/app-non-friendly-ui/header/div/div/div[1]/div/h1/a");
	By btn_pend=By.xpath("//a[contains(text(),'PEND')]//parent::li");
	By btn_retry=By.xpath("//a[@name='FRIENDLY_UI_BTN_RETRY']");
	By btn_movefrd=By.xpath("//a[contains(text(),'MOVE FORWARD')]");
	By btn_assignQ=By.xpath("//a[contains(text(),'ASSIGN TO QUEUES')]");
	By btn_cancel=By.xpath("//a[contains(text(),'CANCEL')]");
	By pop_assignQue=By.xpath("//textarea[contains(@id,'addDescription')]");
	By label_alert=By.xpath("//div[contains(@role,'alert')]");
	By btn_ok=By.xpath("//span[contains(text(),'OK')]");
	By btn_addnote=By.xpath("//button[@id='searchLdapUserBtn']");
	By label_notes_manual=By.xpath("//div[@id='notesEditor']");
	By btn_save=By.xpath("//span[contains(text(),'Save')]");
	By label_not=By.xpath("//*[@id=\"p-tabpanel-0\"]/app-noteslist-nonfriendlyui/div/div[1]");
	By btn_confirm=By.xpath("//span[contains(text(),'Confirm')]");
	By label_notes=By.xpath("//span[contains(text(),'Notes')]");
	By label_histry=By.xpath("//span[contains(text(),'History')]");
	By label_pop=By.xpath("//div[contains(text(),'Confirmation')]");
	 By btn_popupCancel=By.xpath("//span[contains(text(),'Cancel')]");
	 //EPss Scenario
	By label_cfprov=By.xpath("//label[contains(text(),'CF-PROV')]//parent::p-radiobutton//div[1]"); 
	By field_cfprov=By.xpath("//input[@id='CF-PROV']");
	By label_cfpayempa=By.xpath("//label[contains(text(),'CF-PAYEE-NO-MPA')]//parent::p-radiobutton//div[1]");
	By field_cfpayeempa=By.xpath("//input[@id='CF-PAYEE-NO-MPA']");
	By label_cfppvdind=By.xpath("//label[contains(text(),'CF-PP-PVD-IND')]//parent::p-radiobutton//div[1]");
	By field_cfppvind=By.xpath("//input[@id='CF-PP-PVD-IND']");
	//enroll
	By label_enroll=By.xpath("//label[contains(text(),'CF-EMP-NO')]//parent::p-radiobutton//div[1]");
	By field_empno=By.xpath("//input[@id='CF-EMP-NO']");
	//demandraw
	
	By link_demandraw=By.xpath("//span[contains(text(),'Demand Draw')]");
	By label_claimnbr=By.xpath("//app-navigation-bar/div[2]/app-workdemanddrawitem/div/div/div/div/div[1]/div[1]/input");
	By btn_search=By.xpath("//button[contains(text(),'Search')]");
	By link_workitem=By.xpath("//*[@id=\"demand\"]/p-table/div/div/div/div[2]/table/tbody/tr/td[1]/a");
	By link_837details=By.xpath("//app-non-friendly-ui/header/div/div/div[2]/div/div/ul/li[2]/a");
	By label_837=By.xpath("//h1[contains(text(),'837 Details')]");
	By field_837=By.xpath("//input[@name='ST-ST01']");
	By queueName_Demanddraw=By.xpath("//div[contains(text(),'Select Queues')]");
	By selectOption_Queuename=By.xpath("//label[@title='Contract owner queue']");
	By title_DemandDraw=By.xpath("//h1[contains(text(),'Work Item - Demand Draw')]");
	By status_DemandDraw=By.xpath("//div[contains(text(),'Select Status')]");
	
	
	//835
	By link_835=By.xpath("//a[contains(text(),'835')]");
	By link_835_deta=By.xpath("//app-editor-business/app-non-friendly-ui/header/div/div/div[3]/ul/li/a");
	By label_835=By.xpath("//h1[contains(text(),'835 Details')]");
	By fields_835=By.xpath("//*[@id=\"p-accordiontab-0-content\"]/div/div/div/div[1]/input");
	
	Actions action;
	 WebDriverWait wait=new WebDriverWait(driver,200);
	 public WebElement getfieldsof835details() throws InterruptedException {
		 Thread.sleep(2000);
		 
		 action = new Actions(driver);
			wait=new WebDriverWait(driver,20);
			//wait.until(ExpectedConditions.elementToBeClickable(det));
			action.moveToElement(driver.findElement(fields_835)).perform();
			WebElement det=driver.findElement(fields_835);
		 return det;
	 }
	 public WebElement getpagetitlefor835Details() throws InterruptedException {
		 Thread.sleep(2000);
		
		 action = new Actions(driver);
			wait=new WebDriverWait(driver,20);
			
			action.moveToElement(driver.findElement(label_835)).perform();
			 WebElement det=driver.findElement(label_835);
		 return det;
	 }
	 public WebElement clickon835hyperlink() throws InterruptedException {
		 Thread.sleep(2000);
		 WebElement det=driver.findElement(link_835);
		 det.click();
		 action = new Actions(driver);
			wait=new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(link_835_deta));
			action.moveToElement(driver.findElement(link_835_deta)).click().perform();
		
		 return det;
	 }
	 public WebElement getfieldsof837details() throws InterruptedException {
		 Thread.sleep(2000);
		 
		 action = new Actions(driver);
			wait=new WebDriverWait(driver,20);
			//wait.until(ExpectedConditions.elementToBeClickable(det));
			action.moveToElement(driver.findElement(field_837)).perform();
			WebElement det=driver.findElement(field_837);
		 return det;
	 }
	 public WebElement getpagetitlefor837Details() throws InterruptedException {
		 Thread.sleep(2000);
		
		 action = new Actions(driver);
			wait=new WebDriverWait(driver,20);
			
			action.moveToElement(driver.findElement(label_837)).perform();
			 WebElement det=driver.findElement(label_837);
		 return det;
	 }
	 public WebElement clickon837hyperlink() throws InterruptedException {
		 Thread.sleep(2000);
		 WebElement det=driver.findElement(link_837details);
		 action = new Actions(driver);
			wait=new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(det));
			action.moveToElement(driver.findElement(link_837details)).click().perform();
		
		 return det;
	 }
	 public WebElement getCFEmpno() throws InterruptedException {
		 Thread.sleep(2000);
		 WebElement payee=driver.findElement(field_empno);
		 return payee;
	 }
	 public WebElement clickonCfEmpNo() throws InterruptedException {
		 Thread.sleep(1000);
		 WebElement pp=driver.findElement(label_enroll);
		 return pp;
	 }
	 public void clickonOkbtn() {
		 driver.switchTo().defaultContent();
		wait.until(ExpectedConditions.presenceOfElementLocated(btn_ok));
		driver.findElement(btn_ok).click();
	 }
	 public WebElement clickonWorkitem() {
		 WebElement workitm=driver.findElement(link_workitem);
		 return workitm;
	 }
	 public void clickonSearchbtn() {
		 driver.findElement(btn_search).click();
	 }
	 public WebElement getClaimNumber(String claim) {
		 WebElement claimnbr=driver.findElement(label_claimnbr);
		 claimnbr.sendKeys(claim);
		 return claimnbr;
	 }
	 public void clickonDemandDraw() throws InterruptedException {
		 action = new Actions(driver);
			wait=new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(link_demandraw));
			action.moveToElement(driver.findElement(link_demandraw)).click().release().build().perform();
			Thread.sleep(3000);
		
	 }
	 
	 public void clickselectQueueDropdown_DemandDraw()
	 {
	wait.until(ExpectedConditions.presenceOfElementLocated(queueName_Demanddraw));
	 driver.findElement(queueName_Demanddraw).click();
	 }
	 
	 public void selectOptionselectQueueDropdown_DemandDraw(String queuename)
	 {
		 String xpath_Queuename="//label[@title='"+queuename+"']";
		 driver.findElement(By.xpath(xpath_Queuename)).click();
		 driver.findElement(title_DemandDraw).click();
	
	 }
	 
	 public void clickselectStatusDropdown_DemandDraw()
	 {
	wait.until(ExpectedConditions.presenceOfElementLocated(status_DemandDraw));
	 driver.findElement(status_DemandDraw).click();
	 } 
	 
	 public void selectOptionselectStatusDropdown_DemandDraw(String status)
	 {
		 String xpath_Status="//label[@title='"+status+"']";
		 driver.findElement(By.xpath(xpath_Status)).click();
		 driver.findElement(title_DemandDraw).click();
	
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	 public WebElement getCFPPVDIND() throws InterruptedException {
		 Thread.sleep(2000);
		 WebElement payee=driver.findElement(field_cfppvind);
		 return payee;
	 }
	 public WebElement clickonCfppvdind() throws InterruptedException {
		 Thread.sleep(1000);
		 WebElement pp=driver.findElement(label_cfppvdind);
		 return pp;
	 }
	 public WebElement getCFPayeeradiobtn() throws InterruptedException {
		 Thread.sleep(1000);
		 WebElement payee=driver.findElement(field_cfpayeempa);
		 return payee;
	 }
	 public WebElement clickonCfpayeementmpa() throws InterruptedException {
		 Thread.sleep(1000);
		 WebElement paye=driver.findElement(label_cfpayempa);
		 return paye;
	 }
	 public WebElement getCFProvraidiobtn() throws InterruptedException {
		 Thread.sleep(1000);
		 WebElement prov=driver.findElement(field_cfprov);
		 return prov;
	 }
	 public WebElement clickonCFProvraidiobtn() throws InterruptedException {
		 Thread.sleep(1000);
		 WebElement prov=driver.findElement(label_cfprov);
		 return prov;
	 }
	 public void clikconpopuCancel() {
		 driver.findElement(btn_popupCancel).click();
	 }
	 public WebElement getconfirmationpopup() throws InterruptedException {
		 Thread.sleep(2000);
		 WebElement mess=driver.findElement(label_pop);
			
		 return mess;  
	 }
	 
	 public WebElement gethistorysection() {
		 WebElement histr=driver.findElement(label_histry); 
		 return histr;
	 }
	 public WebElement getnotesSection() {
		 WebElement notes=driver.findElement(label_notes); 
		 return notes;
	 }
	 public WebElement getnotesSection_entered() {
		 WebElement notes=driver.findElement(label_not); 
		 return notes;
	 }
	 public void clickonConfirmBtn() {
		 driver.findElement(btn_confirm).click();
	 }
	 public void clickonComments(String Comments) {
		 WebElement cmnts=driver.findElement(pop_assignQue);
		 cmnts.sendKeys(Comments);
	 }
	 public void getalert() {
		 action = new Actions(driver);
			wait=new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(label_alert));
			action.moveToElement(driver.findElement(label_alert)); 
	 }
	public WebElement clickonCancelbtn() {
		WebElement cnl=driver.findElement(btn_cancel);
		return cnl;	
	}
	public WebElement clickonAssigntoQue() {
		WebElement agnQ=driver.findElement(btn_assignQ);
		return agnQ;	
	}
	public WebElement clickonMovefrd() {
		WebElement Mfrd=driver.findElement(btn_movefrd);
		return Mfrd;	
	}
	
	public WebElement clickonRetry() {
		wait.until(ExpectedConditions.presenceOfElementLocated(btn_retry));
		WebElement rtry=driver.findElement(btn_retry);
		
		rtry.click();
		return rtry;
	}
	public WebElement clickonPend() {
		WebElement pnd=driver.findElement(btn_pend);
		return pnd;	
	}
	public WebElement getPageTitle_claim() {
		wait.until(ExpectedConditions.presenceOfElementLocated(label_pageTitle));
		WebElement title=driver.findElement(label_pageTitle);
		return title;
	}
	public void clickonDrawnextItem() throws InterruptedException {
		action = new Actions(driver);
		wait=new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.elementToBeClickable(btn_drwnxtitm));
		action.moveToElement(driver.findElement(btn_drwnxtitm)).click().release().build().perform();
		Thread.sleep(3000);
		
		//driver.findElement(btn_drwnxtitm).click();
	}
	
	public String getpageURlofWorkitem() {
		String pagUrl=driver.getCurrentUrl();
		return pagUrl;
	}

}
