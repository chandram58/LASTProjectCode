package pages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.base;

public class GroupMaintenancePage  extends base
{


	By label_pageTitleGrpMaintenance=By.xpath("/html/body/app-root/div/app-admin-layout/div/app-group/div/div[1]/div/div[1]/h1");
	By btn_addNewGroup=By.xpath("//button[@label='Add New Group']");
	By rows_activeGroupRecords=By.xpath("//table/tbody/tr[not (contains(@class,'hasExpired'))]");
	By rows_inActiveGroupRecords=By.xpath("//table/tbody/tr[contains(@class,'hasExpired')]");
	By label_groupName_grpList,btn_edit_GroupList, label_groupStartDate_GroupList,label_groupEndDate_GroupList,btn_copy_GroupList;
	By label_serchgroup=By.xpath("//app-group/div/div[1]/div/div[2]/div/div/input");
	By cols_descriptionfrmtable=By.xpath("//td[contains(@class,'description ng-star-inserted')]/div");
	By cols_groupfrmtablebyserch=By.xpath("//app-group/div/div[2]/div/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[1]/div");
	By txt_grouptable=By.xpath("//app-group/div/div[2]/div/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr[1]");
	By rows_searchResult=By.xpath("//app-group/div/div[2]/div/div/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr");
	By input_Searchbox=By.xpath("//input[@placeholder='Search Groups']");
	By groupList_UI=By.xpath("//tbody/tr[@class='ng-star-inserted']/td[1]/div[1]");

	//New Group
	By txt_groupName_newGrp=By.xpath("//input[@id='addGroupName']");
	By txt_description_newGrp=By.xpath("//textarea[@id='addDescription']");
	By dd_addUsers=By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]");
	By list_userList_NewGrp=By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div[1]/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem");
	By btn_save_newGrp=By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[3]/div[1]/div[1]/button[1]/span[1]");
	By btn_cancel_newGrp=By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[3]/div[1]/div[1]/button[2]/span[1]");
	By btn_cancel_confirmBoxNewGrp=By.xpath("//app-group/div/p-toast[2]/div/p-toastitem/div/div/div/button[2]");
	By btn_ok_confirmBoxNewGrp=By.xpath("//button/span[contains(text(),'OK')]");
	By label_serchuser=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[4]/div[1]/div[2]/input");
	By dd_selectuser=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem[1]/li");
	By firstUser=By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem[6]/li/div[2]");
	By btn_delete_UsersTable_newGrp,chk_userList_NewGrp;
	By txt_endDate_user=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div/div[5]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr/td[3]/div/p-calendar/span/input");
	By btn_today=By.xpath("//span[contains(text(),'Today')]");
	By dropdown_SelectUsers=By.xpath("//div[contains(@class,'p-multiselect-label-container')]");
	By error_RoleAlreadyExists=By.xpath("//div[contains(text(),'Group already Exists!')]");
	By error_UserAlreadyExistinOtherGp=By.xpath("//span[@title='The selected user already exists in another group']");
	By error_UserEndDateLesserThanGroupEndDate=By.xpath("//span[@title='User end date should be lesser than group end date']");
	By error_MandatoryValidationGpName=By.xpath("//div[contains(text(),'Group Name is required.')]");
	By error_MandatoryValidationDesc=By.xpath("//div[contains(text(),'Description is required.')]");
	By error_MandatoryValidationStartDt=By.xpath("//span[contains(text(),'Start Date is required.')]");
	By error_MandatoryValidationEndDt=By.xpath("//span[normalize-space()='End Date is req..']");
	By txtbox_StartDt=By.xpath("//*[@id='addStartDate']/span/input");
	By txtbox_EndDt=By.xpath("//*[@id='addEndDate']/span/input");
	By blankArea=By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div");
    By btn_Decline=By.xpath("//span[contains(text(),'Decline')]");
    By btn_Accept=By.xpath("//span[contains(text(),'Accept')]");
	
	//Edit Group
	By table_userList=By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]");
	By rows_userRows_editGrp=By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody/tr");
	By btn_save_editGrp=By.xpath("//app-group[1]/div[1]/div[4]/form[1]/div[2]/div[3]/div[1]/div[1]/button[1]/span[1]");
	By btn_cancel_editGrp=By.xpath("//app-group[1]/div[1]/div[4]/form[1]/div[2]/div[3]/div[1]/div[1]/button[2]/span[1]");
	By btn_delete_UsersTable_EditGrp,txt_endDate_UsersTable_EditGrp;
	By txt_endDate_editGrp=By.xpath("//p-calendar[@id='addEndDate']/span/input");
	By txt_groupname=By.xpath("//input[@id='addGroupName']");
	
	By label_newGroupHeader=By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[1]/div[1]/h3[1]");
	By label_successMsg=By.xpath("//div[contains(text(),'Group has been created successfully')]");
	
	//filtersection
		By filtersection=By.xpath("//a[contains(@class,'toggleTabContentBtn')]//em");
		By txt_grpName=By.xpath("//input[@id='group']");
		By text_Userdd=By.xpath("//label[contains(text(),'Users')]//following::p-multiselect[1]//div[1]");
		By select_user=By.xpath("//app-group/div/div[2]/div/div[1]/div/form/div/div[1]/div[2]/p-multiselect/div/div[4]/div[1]/div[1]/div[2]");
		By txt_StartDate=By.xpath("//app-group/div/div[2]/div/div[1]/div/form/div/div[1]/div[3]/div/p-calendar/span/input");
		By txt_endDate=By.xpath("//app-group/div/div[2]/div/div[1]/div/form/div/div[1]/div[4]/div/p-calendar/span/input");
		By txt_Description=By.xpath("//app-group/div/div[2]/div/div[1]/div/form/div/div[2]/div/input");
		By btn_applyFilter=By.xpath("//span[contains(text(),'Apply Filter')]//parent::button[1]");
		By webtable=By.xpath("//app-group/div/div[2]/div/div[2]/div/div[2]/div/p-table/div/div/table/tbody");
		By btn_reset=By.xpath("//span[contains(text(),'Reset')]");
		
		
		
		WebDriverWait wait=new WebDriverWait(driver,200);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		WebElement webtablegrp=driver.findElement(webtable);
		
		List<WebElement> rows=null;
	    List<WebElement> cols = null;
	   Actions  action = new Actions(driver);
		
	   
	   public WebElement getexpriedgroupaftersearch() {
		   WebElement grpN=driver.findElement(txt_grouptable);
		   return grpN;
	   }
	   public void clickonTodaybtn() throws InterruptedException {
		   Thread.sleep(5000);
		   action.moveToElement(driver.findElement(btn_today)).click().perform();
	   }
	   public WebElement getgroupfieldfrmfilter() {
		   WebElement grpN=driver.findElement(By.xpath("//input[@id='group']"));
		   return grpN;
	   }
		public void clickonResetbtn() {
			driver.findElement(btn_reset).click();
		}
		public WebElement validateGroupAfterfilter() throws InterruptedException
		{
			Thread.sleep(3000);	
			WebElement	label_groupName_grpList=driver.findElement(By.xpath("//tr[@class='ng-star-inserted']/td[1]"));
			
			return label_groupName_grpList;
		}
		public WebElement validateGroupDescriptionAfterfilter() throws InterruptedException {
			Thread.sleep(3000);	
			WebElement	label_groupName_grpList=driver.findElement(By.xpath("//tr[@class='ng-star-inserted']/td[2]"));
			
			return label_groupName_grpList;
		}
		public WebElement validateGroupUsersAfterfilter() throws InterruptedException {
			Thread.sleep(3000);	
			WebElement	label_groupName_grpList=driver.findElement(By.xpath("//tr[@class='ng-star-inserted']/td[3]"));
			
			return label_groupName_grpList;
		}
		public WebElement validateGroupStartDateAfterfilter() throws InterruptedException {
			Thread.sleep(3000);	
			WebElement	label_groupName_grpList=driver.findElement(By.xpath("//tr[@class='ng-star-inserted']/td[4]"));
			
			return label_groupName_grpList;
		}
		public WebElement validateGroupenddateAfterfilter() throws InterruptedException {
			Thread.sleep(3000);	
			WebElement	label_groupName_grpList=driver.findElement(By.xpath("//tr[@class='ng-star-inserted']/td[2]"));
			
			return label_groupName_grpList;
		}
		
		public void clickonFilterbtn() throws InterruptedException {
			Thread.sleep(3000);
			WebElement btn=driver.findElement(btn_applyFilter);	
			js.executeScript("arguments[0].click()",btn );
		}
		public WebElement getDescriptionfrmFilter(String Description) {
			WebElement desc=driver.findElement(txt_Description);
			desc.sendKeys(Description);
			return desc;
		}
		public WebElement selectEndDatefrmFilter(String EndDate) throws InterruptedException {
			Thread.sleep(3000);
			Actions action = new Actions(driver);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//app-group/div/div[2]/div/div[1]/div/form/div/div[1]/div[4]/div/p-calendar/span/input")));
			action.moveToElement(driver.findElement(By.xpath("//app-group/div/div[2]/div/div[1]/div/form/div/div[1]/div[4]/div/p-calendar/span/input"))).perform(); 
			
			WebElement endDate=driver.findElement(txt_endDate);
			endDate.sendKeys(EndDate);
			return endDate;
		}
		
		public WebElement selectStartDatefrmFilter(String Date) throws InterruptedException {
			Thread.sleep(3000);
			Actions action = new Actions(driver);
			wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//app-group/div/div[2]/div/div[1]/div/form/div/div[1]/div[3]/div/p-calendar/span/input")));
			action.moveToElement(driver.findElement(By.xpath("//app-group/div/div[2]/div/div[1]/div/form/div/div[1]/div[3]/div/p-calendar/span/input"))).perform(); 
			WebElement StartDate=driver.findElement(txt_StartDate);
			StartDate.sendKeys(Date);
			return StartDate;
		}
		public WebElement getUserfrmFilter() throws InterruptedException {
			Thread.sleep(3000);
			WebElement Userdd=driver.findElement(text_Userdd);	
			js.executeScript("arguments[0].click()",Userdd );
			WebElement UserSelect=driver.findElement(select_user);	
			js.executeScript("arguments[0].click()",UserSelect );
			return Userdd;
		}
		public WebElement getGroupNamefrmFilter(String GroupName) {
			WebElement grpName=driver.findElement(txt_grpName);	
			grpName.sendKeys(GroupName);
			return grpName;
		}
		public void clickonFiltersection() {
			WebElement filter=driver.findElement(filtersection);
			js.executeScript("arguments[0].click()",filter );
		}
		public WebElement getUserEnddate() throws InterruptedException {
			Thread.sleep(3000);
			WebElement useEndDate=driver.findElement(txt_endDate_user);
			js.executeScript("return arguments[0].text", useEndDate);
			Thread.sleep(3000);
			//useEndDate.click();
			return useEndDate;
		}
	public WebElement getgroupNamefromTablebysearch() throws InterruptedException {
		Thread.sleep(2000);
		WebElement gn=driver.findElement(cols_groupfrmtablebyserch);
		return gn;
	}
	public void clickseacheduserfromDd() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(dd_selectuser).click();
	}
	public WebElement getUserbySearch(String user) {
		WebElement usersearch=driver.findElement(label_serchuser);
		usersearch.sendKeys(user);
		return usersearch;
	}
	
	public WebElement getDescriptionfromTable() throws InterruptedException {
		Thread.sleep(2000);
		WebElement desc=driver.findElement(cols_descriptionfrmtable);
		return desc;
	}
	public WebElement getGroupNamebySearch(String groupname) {
		WebElement serch=driver.findElement(label_serchgroup);
		serch.sendKeys(groupname);
		return serch;
	}
	public String getPageHeader_GroupMaintenance()
	{
		return driver.findElement(label_pageTitleGrpMaintenance).getText();
	}
	public void clickAddNewGroup()
	{
		
		wait=new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(btn_addNewGroup));
		//driver.findElement(btn_addNewGroup).click();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].click()", driver.findElement(btn_addNewGroup));
		
	}
	
	//NewGroup
	public void inputNewGroupName(String groupName)
	{
		wait.until(ExpectedConditions.elementToBeClickable(txt_groupName_newGrp));
		driver.findElement(txt_groupName_newGrp).sendKeys(groupName);
	}
	
	public void inputNewGrpDescription(String groupDescription)
	{
		wait.until(ExpectedConditions.elementToBeClickable(txt_description_newGrp));
		driver.findElement(txt_description_newGrp).sendKeys(groupDescription);
	}
	
	public void selectFirstUserToGroup() throws InterruptedException
	{
		  By firstUser=By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem[6]/li/div[2]");
		 // wait.until(ExpectedConditions.elementToBeClickable(firstUser));	
		  Thread.sleep(2000);
		  driver.findElement(dropdown_SelectUsers).click();
		  Thread.sleep(2000);
		  driver.findElement(firstUser).click(); 
		  //clicking on blank area
		  driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div")).click();
	}
	
	public void selectAnotherGroupUserToGroup() throws InterruptedException
	{
		 
		 
		  Thread.sleep(2000);
		  driver.findElement(dropdown_SelectUsers).click();
		  Thread.sleep(2000);
		 List<WebElement> userlist=driver.findElements(list_userList_NewGrp);
		 //Selecting Last user in the list
		 String xpath_lastuser="//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div[1]/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem"+"["+userlist.size()+"]";
		 driver.findElement(By.xpath(xpath_lastuser)).click();
		  //clicking on blank area
		  driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div")).click();
	}	
	
	
	public void clickSelectUsers_NewGroup()
	{
	driver.findElement(dd_addUsers).click();
	}
	
	public void clickSave_NewGroup()
	{
		 driver.findElement(btn_save_newGrp).click();
	}
	
	public String getSuccessMessage(String action) throws InterruptedException
	{
		driver.switchTo().defaultContent();
		Thread.sleep(2000);
		if(action.equalsIgnoreCase("new"))
		{
		label_successMsg=By.xpath("//div[contains(text(),'Group has been created successfully')]");
		}else if(action.equalsIgnoreCase("update"))
		{
			label_successMsg=By.xpath("//div[contains(text(),'Group has been updated successfully')]");
		}
		String Message=driver.findElement(label_successMsg).getText();
		System.out.println(Message);
		return Message;
	}
	
	public boolean validateGroupCreated(String grpName)
	{
		Boolean grpCreatedFlag=false;		
		label_groupName_grpList=By.xpath("//tr[@class='ng-star-inserted']/td[1]/div[contains(text(),'"+grpName+"')]");
		try {
			driver.findElement(label_groupName_grpList);
			grpCreatedFlag=true;
			System.out.println("Group Created is displayed in the List");
			} 
		catch (NoSuchElementException e)
		{
			System.out.println("Group Created is not displayed in the List");
		}
		return grpCreatedFlag;
	}
	
	public void clickCancel_NewGroup() throws InterruptedException 
	{
		 
		 try {
			 driver.findElement(btn_cancel_newGrp).click();
			} catch (ElementClickInterceptedException e) {
				
				 driver.findElement(btn_cancel_newGrp).click();
			}
		 Thread.sleep(1000);
	}
	
	public void clickCancel_ConfirmBoxNewGroup() throws InterruptedException 
	{
		 wait.until(ExpectedConditions.elementToBeClickable(btn_cancel_confirmBoxNewGrp));
	 
		 Actions act = new Actions(driver);

		//Double click on element
		WebElement ele = driver.findElement(btn_cancel_confirmBoxNewGrp); 
		act.moveToElement(ele).build().perform();
		act.click(ele).perform();
		//act.doubleClick(ele).perform();
		
		 System.out.println("Cancel on Confirm Box is clicked");
		 Thread.sleep(1000);
	}
	
	public String getPageHeader_NewGrp_GroupMaintenance()
	{
		return driver.findElement(label_newGroupHeader).getText();
	}
	
	public void clickOK_ConfirmBoxNewGroup() throws InterruptedException 
	{
		
		wait.until(ExpectedConditions.elementToBeClickable(btn_ok_confirmBoxNewGrp));
		try {
			driver.findElement(btn_ok_confirmBoxNewGrp).click();
		} catch (ElementClickInterceptedException e) {
			
			driver.findElement(btn_ok_confirmBoxNewGrp).click();
		}
		Thread.sleep(1000);
	}
	
	public Boolean deleteButtonExitsForAddedUser() 
	{
		Boolean deleteButtonForAddedUser=false;
		btn_delete_UsersTable_newGrp=By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody/tr[1]/td[4]/a");
		try 
		{
		driver.findElement(btn_delete_UsersTable_newGrp);
		deleteButtonForAddedUser=true;
		} 
	catch (NoSuchElementException e)
	{
		System.out.println("Delete Button is not displayed in the Added Users List");
	}
		return deleteButtonForAddedUser;
	}
	
	//Edit Group
	public void clickEditGroup(int rowIndex) {
		btn_edit_GroupList=By.xpath("//tbody/tr["+rowIndex+"]/td[6]/div[1]/a[2]/em[1]");
		driver.findElement(btn_edit_GroupList).click();
		
	}
	
	public void clickCancel_EditGroup() 
	{
		 driver.findElement(btn_cancel_editGrp).click();
		
	}
	
	public void clickSave_EditGroup() 
	{
		 driver.findElement(btn_save_editGrp).click();
		
	}
	
	public boolean verifyUsersExists() {
		
		try {
			if(driver.findElement(table_userList).isDisplayed())
				return true;
			} 
		catch (NoSuchElementException e) 
		{
			System.out.println("Users doesn't exists in the selected group");
		}
		return false;
	}
	
	public Boolean verifyDeleteButtonForSavedUsers() {
		
		int usersSize=driver.findElements(rows_userRows_editGrp).size();
		System.out.println("No of user in Users Table="+usersSize);
		Boolean deleteButtonForSavedUsersFlag=false;
		WebDriverWait  wait1=new WebDriverWait(driver,1);
		 driver.manage().timeouts().implicitlyWait(0,TimeUnit.SECONDS);	//resetting the implicit wait because, explicit wait is not being implemented
		
		for(int i=1;i<=usersSize;i++)
		{
			btn_delete_UsersTable_EditGrp=By.xpath("//app-group[1]/div[1]/div[4]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody/tr["+i+"]/td[4]/a");
		
			try {
					wait1.until(ExpectedConditions.presenceOfElementLocated(btn_delete_UsersTable_EditGrp));
					deleteButtonForSavedUsersFlag=true;
					break;				
			}
					
			 catch (TimeoutException e) 
			{
				System.out.println("Delete button doesn't exists for Saved User"+i);
			}
	}
		return deleteButtonForSavedUsersFlag;
	}
	
	public List<String> getGroupStartDateForActiveGrps() {
		int rowSize=driver.findElements(rows_activeGroupRecords).size();
		System.out.println("No of active groups on Group Maintenance Table->"+ rowSize);
		String startDate;
		List<String> ActivegroupStartDateList = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
			label_groupStartDate_GroupList=By.xpath("//table/tbody/tr[not (contains(@class,'hasExpired'))]["+i+"]/td[4]/div");
			
			startDate=driver.findElement(label_groupStartDate_GroupList).getText().trim();
			System.out.println("StartDate in Row"+i+"="+startDate);
			ActivegroupStartDateList.add(startDate);
		}
		return ActivegroupStartDateList;
	}
	
	public List<String> getGroupEndDateForInActiveGrps() {
		int rowSize=driver.findElements(rows_activeGroupRecords).size();
		String endDate;
		List<String> InactivegroupEndDateList = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
			label_groupEndDate_GroupList=By.xpath("//table/tbody/tr[contains(@class,'hasExpired')]["+i+"]/td[5]/div");
			
			endDate=driver.findElement(label_groupEndDate_GroupList).getText().trim();
			System.out.println("EndDate in Row"+i+"="+endDate);
			InactivegroupEndDateList.add(endDate);
		}
		return InactivegroupEndDateList;

	}
	
	public Boolean verifyCopyButtonForInActiveGroups() {
		int rowSize=driver.findElements(rows_inActiveGroupRecords).size();
		System.out.println("No of Inactive Group Rows="+rowSize);
		Boolean copyButtonForInActiveGrpFlag=null;
		for(int i=1;i<=rowSize;i++)
		{
			btn_copy_GroupList=By.xpath("//p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody/tr["+i+"]/td[6]/div/a[1]");
		
			try {
				if(driver.findElement(btn_copy_GroupList).isDisplayed())
				{
					copyButtonForInActiveGrpFlag=true;
					System.out.println("Copy button exists for InActive group"+i);
					
				}				
			}
					
			 catch (NoSuchElementException e) 
			{
				System.out.println("Copy button doesn't exists for InActive group"+i);
				copyButtonForInActiveGrpFlag=false;
				break;
			}
	}	
		return copyButtonForInActiveGrpFlag;
	}
	
	public void updateEndDateForUsers_EditGroup(String updateDate) 
	{
		int usersSize=driver.findElements(rows_userRows_editGrp).size();
		
		for(int i=1;i<=usersSize;i++)
		{
			txt_endDate_UsersTable_EditGrp=By.xpath("//app-group[1]/div[1]/div[4]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr["+i+"]/td[3]/div[1]/p-calendar[1]/span/input");
		
			driver.findElement(txt_endDate_UsersTable_EditGrp).clear();
			driver.findElement(txt_endDate_UsersTable_EditGrp).sendKeys(updateDate);
	}		
	}
	
	public void updateEndDateForGroup_EditGroup(String updateDate) throws InterruptedException 
	{
	
		driver.findElement(txt_endDate_editGrp).click();;
		Thread.sleep(2000);
		//driver.findElement(txt_endDate_editGrp).sendKeys(updateDate);
	}
	public WebElement getgroupNameforupdateintable(int rowIndex) {
		WebElement groupname=driver.findElement(By.xpath("//tbody/tr["+rowIndex+"]/td[1]/div[1]"));
		return groupname;
	}
	public String getEndDateForGroup(int rowIndex) {
		
		label_groupEndDate_GroupList=By.xpath("//tbody/tr["+rowIndex+"]/td[5]/div[1]");
		return driver.findElement(label_groupEndDate_GroupList).getText().trim();
	}
	public List<String> getUserListGrpmaintenance() 
	{
		
		int usersListSize=driver.findElements(list_userList_NewGrp).size();
		System.out.println("No of Users in List->"+ usersListSize);
		String user;
		List<String> UserListGrpmaintenance = new ArrayList<String>();
		for(int i=1;i<=usersListSize;i++)
		{
			chk_userList_NewGrp=By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem["+i+"]/li");
			
			user=driver.findElement(chk_userList_NewGrp).getText();
			System.out.println("User_"+i+"="+user);
			UserListGrpmaintenance.add(user);
		}
		return UserListGrpmaintenance;
	}

public String getUserForGroup(int rowIndex) {
		
		label_groupEndDate_GroupList=By.xpath("//tbody/tr["+rowIndex+"]/td[3]/div[1]");
		return driver.findElement(label_groupEndDate_GroupList).getText().trim();
	}
	
public WebElement ViewbtnforInActiveGroups() {
	WebElement viewbtn=driver.findElement(By.xpath("//a[contains(@title,'View')]//em"));
	return viewbtn;
	
}
public WebElement getViewPageforexpried() {
	WebElement viepage=driver.findElement(By.xpath("//h3[contains(text(),'View Group')]"));
	return viepage;
}

public void clickViewcancel() throws InterruptedException {
	Thread.sleep(2000);
	
	 action.moveToElement(driver.findElement(By.xpath("//button[contains(@label,'Cancel')]//span"))).click().perform();
}
public List<WebElement> getSearchResult() throws InterruptedException
{
	 Thread.sleep(5000);
     List<WebElement> searchResult_rows=driver.findElements(rows_searchResult);
	   return searchResult_rows;	
}

public void inputTxt_Searchbox(String input)
{
	driver.findElement(input_Searchbox).sendKeys(input);
}

public List<String> getListActiveGroupsUIMainTbl() throws InterruptedException
{
	Thread.sleep(6000);
	driver.switchTo().defaultContent();
	List<WebElement> groupListUI=driver.findElements(groupList_UI);
	
  List<String> grouplist = new ArrayList<String>();
					 //    Boolean flag = true;
	    System.out.println("3");
		
	    int groupcount=0;
	for(int j=0;j<groupListUI.size();j++) 
		{
		groupListUI=driver.findElements(groupList_UI);
	String groups=groupListUI.get(j).getText();
	grouplist.add(groups);
	 groupcount++;
	groupListUI=driver.findElements(groupList_UI);
					}
						
	System.out.println("No of Elements in list->"+groupcount);
    System.out.println("No of Elements in list->"+grouplist.size());
						
return grouplist;
}

public String getErrorMessageRoleAlreadyExists() throws InterruptedException
{
Thread.sleep(2000);
driver.switchTo().defaultContent();
String Message=driver.findElement(error_RoleAlreadyExists).getText();
return Message; 

}


public String getErrorMessageUserAlreadyExistsinOtherGp() throws InterruptedException
{
Thread.sleep(2000);
driver.switchTo().defaultContent();
String Message=driver.findElement(error_UserAlreadyExistinOtherGp).getText();
return Message; 

}

public String getErrorUserEndDateLesserThanGroupEndDate() throws InterruptedException
{
Thread.sleep(2000);
driver.switchTo().defaultContent();
String Message=driver.findElement(error_UserEndDateLesserThanGroupEndDate).getAttribute("Title");
return Message; 

}


public String getMandatoryValidationGpName() throws InterruptedException
{
	Thread.sleep(2000);
	String Message=driver.findElement(error_MandatoryValidationGpName).getText();
	return Message; 
}

public String getMandatoryValidationDesc() throws InterruptedException
{
	Thread.sleep(2000);
	String Message=driver.findElement(error_MandatoryValidationDesc).getText();
	return Message; 
}
public void clearGroupStartDt() throws InterruptedException
{
	Thread.sleep(2000);
	driver.findElement(txtbox_StartDt).sendKeys(Keys.chord(Keys.CONTROL, "a"));
	driver.findElement(txtbox_StartDt).sendKeys(Keys.DELETE);
}

public void clearGroupEndDt() throws InterruptedException
{
	Thread.sleep(2000);
	driver.findElement(txtbox_EndDt).sendKeys(Keys.chord(Keys.CONTROL, "a"));
	driver.findElement(txtbox_EndDt).sendKeys(Keys.DELETE);
}



public String getMandatoryValidationStartDt() throws InterruptedException
{
	clearGroupStartDt();
    driver.findElement(blankArea).click();
	String Message=driver.findElement(error_MandatoryValidationStartDt).getText();
	return Message; 
}

public String getMandatoryValidationEndDt() throws InterruptedException
{
	clearGroupEndDt();
	driver.findElement(blankArea).click();
	String Message=driver.findElement(error_MandatoryValidationEndDt).getText();
	return Message; 
}




public void inputStartDt(String date) throws Exception
{
	driver.findElement(txtbox_StartDt).click();
	//driver.findElement(txtbox_StartDt).sendKeys(date);
	selectDate(date);
	driver.findElement(blankArea).click();
	
}

public void clickDecline_confirmbox() throws InterruptedException
{
	Thread.sleep(3000);
driver.switchTo().defaultContent();
driver.findElement(btn_Decline).click();
}


public void clickAccept_confirmbox()
{
driver.switchTo().defaultContent();
driver.findElement(btn_Accept).click();
}




}
