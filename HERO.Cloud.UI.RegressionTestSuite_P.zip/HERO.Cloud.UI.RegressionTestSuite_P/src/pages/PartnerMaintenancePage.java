package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.base;

public class PartnerMaintenancePage extends base
{
	By searchResult=By.xpath("//app-partner-maintenance/div/div[2]/div/div[2]/p-table/div/div[1]/div/div[2]/table/tbody/tr");
	By txtPageHeading=By.xpath("//h1[@class='header-style']");
	By btnEditPartner=By.xpath("//a[@title='Edit Partner']");
	By rbSuspendProfesClaimSubmission = By.xpath("//*[contains(@id,'p-tabpanel-')]/div/div[1]/div/label");
	By inputSearchPartner=By.xpath("//input[@placeholder='Search Partner']");
	By btnSave=By.xpath("//*[@id='p-tabpanel-14']/div/div[12]/div/button[1]]");
	By clickSearchPartner = By.xpath("//span[@class='p-button-icon fas fa-search']");
	By validatTxtSearchPartner = By.xpath("//span[@class='totalRecords ng-star-inserted']");
	By btnRequestNewPartner = By.xpath("//button[@label='Request New Partner']");
	By btnRequestNewPartnerHeadText = By.xpath("//*[@id='viewAddEditSection']/div/div[2]/form/div[1]/div[1]/h3");
	By partnerStatusText  = By.xpath("(((//tbody[@class='p-datatable-tbody'])[2]//tr)[41]//td)[3]//div//span");
	By numofRowsPartnerMaintenancePage = By.xpath("(//tbody[@class='p-datatable-tbody'])[2]//tr");
	By txtTotalRecordCount = By.xpath("//span[@class='totalRecords ng-star-inserted']");
	By txtTotalSpanCountinTable=By.xpath("(//div[@class='row no-marbatch']//div//span)[14]");
	By totalSpaninTableGrid = By.xpath("//div[@class='row no-marbatch']//div//span");
    By editAllCheckBoxDiv = By.xpath("//div[@class='p-checkbox-box ng-tns-c101-49']");
    By selectedAginingRanges = By.xpath("//td[@class='text-right']//a");
    By listFromRange = By.xpath("//p-dropdown[@placeholder='From Range']");
    By listToRange = By.xpath("//p-dropdown[@placeholder='To Range']");
    By oneDayLlLeftLabel = By.xpath("//li[@aria-label='1 days']");
    By oneDayLlRightLabel = By.xpath("//li[@aria-label='5 days']");
    By addButton = By.xpath("//button[@label='ADD']");
    By clickSaveButton = By.xpath("//*[@id='p-tabpanel-2']/div/div[12]/div/button[1]");
    By editFinalTextCheck = By.xpath("((//tbody[@class='p-datatable-tbody'])[4]//tr//td)[1]");
    By firstInputSwitch = By.xpath("(//p-inputswitch[@class='ng-untouched ng-pristine'])[1]");
    By RequestNewPArtnerButton = By.xpath("//button[@class='actionbtn-ad p-button p-component']");
    By PlusAddAnchorTag = By.xpath("//a[@id='p-tabpanel-1-label']");
    By SelectDocType = By.xpath("//p-dropdown[@placeholder='Select Doc Type']");
    By FirstDocTypeItem  = By.xpath("//li[@aria-label='837 INSTITUTIONAL']");
    By btnsaveBtn  = By.xpath("//button[@class='saveBtn']");
    By secondCloseCrxMrk=By.xpath("(//span[@class='p-tabview-close pi pi-times ng-star-inserted'])[2]");
    By TotlsCloseCrxMrk=By.xpath("//span[@class='p-tabview-close pi pi-times ng-star-inserted']");
    By docbtnsaveBtn  = By.xpath("//button[@label='OK']");
    
    public boolean verifyDoccanbeaddedforNewRequestPartnerProfile() throws InterruptedException {
		// TODO Auto-generated method stub
    
    	driver.findElement(RequestNewPArtnerButton).click();
    	driver.findElement(PlusAddAnchorTag).click();
    	driver.findElement(SelectDocType).click();
    	driver.findElement(FirstDocTypeItem).click();
    	driver.findElement(btnsaveBtn).click();
    
    	driver.findElement(secondCloseCrxMrk).click();
    	Thread.sleep(3000);
    	driver.findElement(docbtnsaveBtn).click();
    	Thread.sleep(3000);
    	List<WebElement> ls=driver.findElements(TotlsCloseCrxMrk);
    	if(ls.size()==0)
    	return true;
    	    	
		return false;
		
	}
    public List<WebElement> getSearchResult()
    {
		List<WebElement> serachResult_rows=driver.findElements(searchResult);
		return serachResult_rows;
     }
    
    public boolean verifyPlusSymbolInNewPartnetMenu() throws InterruptedException {
    	
		// TODO Auto-generated method stub
    	
    	driver.findElement(RequestNewPArtnerButton).click();
    	driver.findElement(PlusAddAnchorTag).click();
    	driver.findElement(SelectDocType).click();
    	driver.findElement(FirstDocTypeItem).click();
    	driver.findElement(btnsaveBtn).click();
    	driver.findElement(secondCloseCrxMrk).click();
    	Thread.sleep(3000);
    	driver.findElement(docbtnsaveBtn).click();
    	Thread.sleep(3000);
    	List<WebElement> ls=driver.findElements(TotlsCloseCrxMrk);
    	if(ls.size()==0)
    	return true;
    	    	
		return false;
	}
	
    public int clickeditFinalTextCheck()
    {
    	return driver.findElements(selectedAginingRanges).size();
    }
    
    public boolean checkIsSuspendToggleButtonOnLandingGrid() throws InterruptedException {
		// TODO Auto-generated method stub
    	
    	Thread.sleep(4000);
    	String strPartnerID;
    	By PartnerStatusHeader = By.xpath("(//th[@role='columnheader'])[3]");
    	By FirstActivePartnerID = By.xpath("(((//tbody[@class='p-datatable-tbody'])[2]//tr)[1]//td)[1]//div//span" );
    	By FirstDiable = By.xpath("(//span[@class='p-inputswitch-slider'])[1]");
    	By noOfRows =By.xpath("(//tbody[@class='p-datatable-tbody'])[2]//tr");
    //	By  = By.xpath();
   // 	By  = By.xpath();
   // 	By  = By.xpath();
    	
    	driver.findElement(PartnerStatusHeader).click();
    	driver.findElement(PartnerStatusHeader).click();
    	strPartnerID = driver.findElement(FirstActivePartnerID).getText();
    	Thread.sleep(2000);
    	driver.findElement(FirstDiable).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//button[@label='OK']")).click();
    	Thread.sleep(2000);
    		driver.findElement(inputSearchPartner).sendKeys(strPartnerID);
    		Thread.sleep(2000);
    		List<WebElement> ls= driver.findElements(noOfRows);
    		 int RSiz=ls.size();
    		 for(int i=1;i<=RSiz;i++)
    		 { if(driver.findElement(By.xpath("(((//tbody[@class='p-datatable-tbody'])[2]//tr)["+i+"]//td)[1]//div//span")).getText().trim().equals(strPartnerID.trim()))
    		    if(driver.findElement(By.xpath("(((//tbody[@class='p-datatable-tbody'])[2]//tr)["+i+"]//td)[3]//div//span")).getText().contains("Suspended"))
    				return true; 
    		 
    		 }
    /*	int Fistcheck=0,SecondCheck=0;
    	 
    	    
    	
    	
    	List<WebElement> ls=driver.findElements(numofRowsPartnerMaintenancePage);
    	
    	
    	
    	for(int i=ls.size();i>0;i--)
    	{
    	partnerStatusText  = By.xpath("(((//tbody[@class='p-datatable-tbody'])[2]//tr)["+i+"]//td)[3]//div//span");
			if(driver.findElement(partnerStatusText).getText().contains("Suspended"))
		Fistcheck++;
		else
		break;
    	}
    	
    	System.out.println(Fistcheck);
    	driver.findElement(By.xpath("(//th[@role='columnheader'])[3]")).click();
    	driver.findElement(By.xpath("(//th[@role='columnheader'])[3]")).click();
    	Thread.sleep(2000);
    	driver.findElement(firstInputSwitch).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//button[@label='Ok']")).click();
    	Thread.sleep(2000);
    	ls=driver.findElements(numofRowsPartnerMaintenancePage);
    	
    	for(int i=ls.size();i>0;i--)
    	{
    	partnerStatusText  = By.xpath("(((//tbody[@class='p-datatable-tbody'])[2]//tr)["+i+"]//td)[3]//div//span");
    	
    	if(driver.findElement(partnerStatusText).getText().contains("Suspended"))
		SecondCheck++;
		else
		break;
    	}
    	
    	System.out.println(SecondCheck);
    	
    	if((Fistcheck+1)==SecondCheck)
    	return true;
    	else */
		return false;
	}
    
    
    
    public boolean verifyErrorMessageInavlidRangeFun()
    {
    	WebElement wl;
    	
    	// Adding Two records first add is in proper ranger and second one invalid range
    	wait.until(ExpectedConditions.presenceOfElementLocated(listFromRange));
     	driver.findElement(listFromRange).click();
    	wl=driver.findElement(listFromRange);
    	wl.findElement(oneDayLlLeftLabel).click();
    	
    	wait.until(ExpectedConditions.presenceOfElementLocated(listToRange));
    	driver.findElement(listToRange).click();
    	wl=driver.findElement(listToRange);
    	wl.findElement(oneDayLlRightLabel).click();   
    	
    	wait.until(ExpectedConditions.presenceOfElementLocated(listFromRange));
     	driver.findElement(listFromRange).click();
    	wl=driver.findElement(listFromRange);
    	wl.findElement(oneDayLlRightLabel).click();
    	
    	wait.until(ExpectedConditions.presenceOfElementLocated(listToRange));
    	driver.findElement(listToRange).click();
    	wl=driver.findElement(listToRange);
    	wl.findElement(oneDayLlLeftLabel).click();   
    	 
    	driver.findElement(addButton).click();
    	
    	return driver.getPageSource().contains("Invalid Range! To Range should be greater than the From Range");
    }
    
    public boolean verifyErrorMessageDuplicateRangeFun() {
		// TODO Auto-generated method stub
    	// First Remove All elements
    	
    	wait.until(ExpectedConditions.presenceOfElementLocated(selectedAginingRanges));
    	List<WebElement> al=driver.findElements(selectedAginingRanges);

System.out.println(al.size());
    	for(int i=0;i<al.size();i++)
    		al.get(i).click();
    	
    	WebElement wl;
    	
    	// Adding Two records first add is in proper ranger and second one also same range duplicate
    	wait.until(ExpectedConditions.presenceOfElementLocated(listFromRange));
     	driver.findElement(listFromRange).click();
    	wl=driver.findElement(listFromRange);
    	wl.findElement(oneDayLlLeftLabel).click();
    	
    	wait.until(ExpectedConditions.presenceOfElementLocated(listToRange));
    	driver.findElement(listToRange).click();
    	wl=driver.findElement(listToRange);
    	wl.findElement(oneDayLlRightLabel).click(); 
    	
    	driver.findElement(addButton).click();
    	
    	wait.until(ExpectedConditions.presenceOfElementLocated(listFromRange));
     	driver.findElement(listFromRange).click();
    	wl=driver.findElement(listFromRange);
    	wl.findElement(oneDayLlLeftLabel).click();
    	
    	wait.until(ExpectedConditions.presenceOfElementLocated(listToRange));
    	driver.findElement(listToRange).click();
    	wl=driver.findElement(listToRange);
    	wl.findElement(oneDayLlRightLabel).click(); 
    	
    	driver.findElement(addButton).click();
    	
		return driver.getPageSource().contains("Duplicate! 1 days to 5 days already present. please select other range");
	}
    public void validateEditFunctionality() throws InterruptedException
	{
    	wait.until(ExpectedConditions.presenceOfElementLocated(selectedAginingRanges));
    	List<WebElement> al=driver.findElements(selectedAginingRanges);

System.out.println(al.size());
    	for(int i=0;i<al.size();i++)
    		al.get(i).click();
    	
    	wait.until(ExpectedConditions.presenceOfElementLocated(listFromRange));
     	driver.findElement(listFromRange).click();
    	WebElement wl=driver.findElement(listFromRange);
    	wl.findElement(oneDayLlLeftLabel).click();
    	
    	wait.until(ExpectedConditions.presenceOfElementLocated(listToRange));
    	driver.findElement(listToRange).click();
    	WebElement wl2=driver.findElement(listToRange);
    	wl.findElement(oneDayLlRightLabel).click();
    	
    	driver.findElement(addButton).click();
    	
    	driver.findElement(clickSaveButton).click();
    	
    	driver.navigate().refresh();
    	
	/*	//if(driver.findElement(editAllCheckBoxDiv)
		//driver.findElement(rbSuspendProfesClaimSubmission).click();
    	// Check the changes 
    	  	btnEditPartner();
    	     wait.until(ExpectedConditions.presenceOfElementLocated(editFinalTextCheck));
    	     try
    	     {
    	    	return driver.findElement(editFinalTextCheck).getText().contains("1 days to 5 days");
    	     }
    	     catch(StaleElementReferenceException ex)
    	     {
    	    	 return driver.findElement(editFinalTextCheck).getText().contains("1 days to 5 days");
    	     }
    	// To Avoid Stale Element exception we use direct xpath after reopeing edit button for final validation 
    	
    	  	
		//driver.findElement(editFinalTextCheck).getText().contains("1 days to 5 days");*/
	}
    
	public boolean isCountAppearBottonofthePage()
	{
		int LastSpanInGrid=driver.findElements(totalSpaninTableGrid).size();
		String TextCheck =driver.findElement(By.xpath("(//div[@class='row no-marbatch']//div//span)["+LastSpanInGrid+"]")).getText();
		if(TextCheck.contains("Total records showing"))
		return true;
		else
		return false;
		
	}
	
	public void sendInputClickSearchPartner(String Searchterm)
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(txtPageHeading));
		driver.findElement(inputSearchPartner).sendKeys(Searchterm);
	}
	
	
	public boolean validateCount(String Searchterm) throws InterruptedException
	{
		sendInputClickSearchPartner(Searchterm);
		int txtRowCount= Integer.parseInt(driver.findElement(txtTotalRecordCount).getText().trim().substring(24));
	    int tableRowCount = driver.findElements(numofRowsPartnerMaintenancePage).size();
		Thread.sleep(2000);
		if(txtRowCount==tableRowCount)
	    return true ;
		else
		return false;
	}
	
	
	
	public String getEndColumPartnerStatusText(int Size)
	{
		String xpathValue="(((//tbody[@class='p-datatable-tbody'])[2]//tr)["+Size+"]//td)[3]//div//span";
		partnerStatusText  = By.xpath(xpathValue);
		return driver.findElement(partnerStatusText).getText();
		
	}
	public int  totalRowsPartnerMaintenancePage( )
	{
		return driver.findElements(numofRowsPartnerMaintenancePage).size();
		
	}
	public boolean textCheckHeadRequestNewPartner()
	{
		 
		return driver.findElement(btnRequestNewPartnerHeadText).getText().contains("Request Partner Profile Changes");

		
	}
	
	
	public String getTitle_MainPage()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(txtPageHeading));
		
		String Title=driver.findElement(txtPageHeading).getText();
		
		return Title;
	}
	
	public void btnEditPartner()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(btnEditPartner));
		
		driver.findElement(btnEditPartner).click();
		
		
	}
	
	public void clickbtnRequestNewPartner()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(btnRequestNewPartner));
		
		driver.findElement(btnRequestNewPartner).click();
		
		
	}
	
	public void clicKRbSuspendProfesClaimSubmission()
	{
	
		wait.until(ExpectedConditions.presenceOfElementLocated(rbSuspendProfesClaimSubmission));
		
		driver.findElement(rbSuspendProfesClaimSubmission).click();
		
		
	}
	
	
	public String getCSSRbSuspendProfesClaimSubmission()
	{
		
		wait.until(ExpectedConditions.presenceOfElementLocated(rbSuspendProfesClaimSubmission));
		String Title=driver.findElement(rbSuspendProfesClaimSubmission).getAttribute("class");
		return Title;
	
	}
	
	public void  clickbtnSave()
	{
		
	
		wait.until(ExpectedConditions.presenceOfElementLocated(btnSave));
		
		driver.findElement(btnSave).click();
		
	}
	
	public boolean  verifyAddNewPartnerLanding()
	{
		
	
		wait.until(ExpectedConditions.presenceOfElementLocated(btnSave));
		return false;
		
				
	}

	

	

	

	
	
	
	
	
}
