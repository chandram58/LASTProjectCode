package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.base;

public class RolesManagementPage extends base
{
	
	By title_MainPage=By.xpath("//h1[contains(text(),'Roles Management')]");
	By searchRole=By.xpath("//input[@placeholder='Search Role']");
	By searchResult=By.xpath("//app-admin-layout/div/app-role/div[1]/div[2]/div/div/p-table/div/div/div/div[2]/table/tbody/tr");
	By breadCrumbTitle=By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-role[1]/div[1]/div[1]/div[1]/div[1]/ul[1]");
	By btn_addNewRole=By.xpath("//span[contains(text(),'Add New Role')]");
	By btn_save_AddNewRole=By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-role[1]/div[2]/form[1]/div[2]/div[3]/div[1]/div[1]/button[1]/span[1]");
	By label_errorMsg_roleName=By.xpath("//input[@id='addRoleName']/following-sibling::div/descendant::label");
	By label_errorMsg_description=By.xpath("//textarea[@id='description']/following-sibling::span/descendant::label");
	By label_errorMsg_permission=By.xpath("//p-multiselect/parent::div/descendant::span[text()]");
	By dd_searchAndSelectScreen=By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[2]");
	By icon_expandScreen_Row1=By.xpath("//body[1]/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-role[1]/div[2]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-treetable[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/p-treetabletoggler[1]/button/i[1]");
	By list_fieldNameRows=By.xpath("//*[@id='viewAddEditSection'][contains(@class,'active')]/div[2]/div/div[5]/div/div[2]/p-treetable/div/div/table/tbody/tr");
	By label_screenName_dropDownList,label_fieldName_dropDownList;
	By rows_table=By.xpath("//app-role/div[1]/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr");
	By rows_edit=By.xpath("//tbody/tr/td[6]/div[1]/a[2]");
	By btn_saveupdate=By.xpath("//button[@class='saveBtn p-button p-component ng-star-inserted']//span[@class='p-button-label'][normalize-space()='Save']");
	By message_accept=By.xpath("//span[contains(text(),'Accept')]");
	By message_Decline=By.xpath("//span[contains(text(),'Decline')]");
	By message_roleCreateSuccess=By.xpath("//div[contains(text(),'role has been created successfully')]");
	
	By btn_Edit=By.xpath("//em[@class='fa fa-edit iconColor enableCopyIcon pointerAll']");
    By RoleList_UI=By.xpath("//tbody/tr/td[1]/div[1]");
	By rows_UIMainTbl=By.xpath("//tbody/tr");
	//Add new Role
	By title_newRole=By.xpath("//h3[normalize-space()='New Role']");
	By label_roleName=By.xpath("//input[@id='addRoleName']");

	By label_description=By.xpath("//textarea[@id='description']");
	By dd_selectscrren=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[2]");
	By dd_serch=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[4]/div[1]/div[2]/input");
	By dd_screen=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem[1]/li");
	By chkbox_editScreen=By.xpath("//label[@class='p-checkbox-label ng-star-inserted'][normalize-space()='Edit']");
	By label_updateendDate=By.xpath("//*[@id='updateRoleEndDate']/span/input");
	By selectQassignment=By.xpath("");
	By errormessage_RoleExists=By.xpath("//div[contains(text(),'Role already Exists!')]");
	
	//Update Role   //View role //Copy role
	By label_rolename_updateRole=By.xpath("//input[@id='updateRoleName']");//works for view page as well
	By title_UpdateRole=By.xpath("//h3[contains(text(),'Update Role')]");
	By title_ViewRole=By.xpath("//h3[contains(text(),'View Role')]");
	By title_CopyRole=By.xpath("//app-role[1]/div[3]/form[1]/div[2]/div[1]/div[1]/h3[1]");
	By btnCancel_UpdateRole=By.xpath("//form[@class='ng-untouched ng-pristine ng-valid']//div//span[@class='p-button-label'][normalize-space()='Cancel']");
	By errormessage_PermissionDateLesserRoleEnddate=By.xpath("//span[@class='invalidError dateError ng-star-inserted']");
	By errormessage_EndDateGreaterthanStartDate=By.xpath("//span[@title='End date should be greater than Start Date']");
	By label_updatepermissionendDate=By.xpath("//input[contains(@name,'updatePermissionEndDate')]");
	By message_roleUpdateSuccess=By.xpath("//div[contains(text(),'role has been updated successfully')]");
	By label_TodayEndDate=By.xpath("//span[normalize-space()='Today']");
	
	Actions action= new Actions(driver);
	WebDriverWait wait=new WebDriverWait(driver,200);
	
	 public void clickonAcceptbtn() {
		
			wait.until(ExpectedConditions.elementToBeClickable(message_accept));
			action.moveToElement(driver.findElement(message_accept)).click().perform();
	 }

	 public void clickonDeclinebtn()
	 {
		 wait.until(ExpectedConditions.elementToBeClickable(message_Decline));
		 action.moveToElement(driver.findElement(message_Decline)).click().perform();
		 
	 }
	 
	 
	 public void clickonSaveupdate() {
		 WebElement save=driver.findElement(btn_saveupdate);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
			
			js.executeScript("arguments[0].click();", save);
		
	 }
	public void clickRoleEndDate()
	{
	driver.findElement(label_updateendDate).click();	
	}
	
	public void clickTodayDate_RoleEndDate_UpdateRole()
	{
		clickRoleEndDate();
		driver.findElement(label_TodayEndDate).click();
		
	}
	
	public void clickNewRoleTitle()
	{
		wait.until(ExpectedConditions.elementToBeClickable(title_newRole));
		driver.findElement(title_newRole).click();
	}
	
	
	
	
	
	
	
	public void clickPermissionEndDate()
	{
	driver.findElement(label_updatepermissionendDate).click();	
	}
	
	
	
	 public WebElement getUpdateEndate() {
		 WebElement roleend=driver.findElement(label_updateendDate);
		 return roleend;
	 }
	 
	 
	
	 public void clickEditButtonMainPage()
	 {
	  driver.findElement(btn_Edit).click();
	 }
	 
	 
	 
	 public void clickonEditChkbox() {
		 wait.until(ExpectedConditions.presenceOfElementLocated(chkbox_editScreen));
		 driver.findElement(chkbox_editScreen).click();
	 }
	public void clickonscreenfromDpdn() {
		driver.findElement(dd_screen).click();
	}
	public void clickSelectScreen() {
		wait.until(ExpectedConditions.presenceOfElementLocated(dd_selectscrren));
		driver.findElement(dd_selectscrren).click();
	}
	public WebElement getDescriptioninnewrole(String Description) {
		 wait.until(ExpectedConditions.elementToBeClickable(label_description));
		WebElement role=driver.findElement(label_description);
				role.sendKeys(Description);
		return role;
	}
	//For add new Role Screen
	public WebElement getSearchScreen(String input) {
		WebElement role=driver.findElement(dd_serch);
				role.sendKeys(input);
		return role;
	}
	
	public WebElement getRoleNameinAddrole(String RoleName) 
	{
		wait.until(ExpectedConditions.elementToBeClickable(label_roleName));
		WebElement role=driver.findElement(label_roleName);
		role.sendKeys(RoleName);
		return role;
	}
	
	
	public String getBreadCrumbTitle() {
		
		return driver.findElement(breadCrumbTitle).getText();
	}
	public void clickAddNewRole()
	{
		wait.until(ExpectedConditions.elementToBeClickable(btn_addNewRole));
		driver.findElement(btn_addNewRole).click();
	}
	public void clickSave_AddNewRole()
	{
		 action = new Actions(driver);
			wait=new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.elementToBeClickable(btn_save_AddNewRole));
			action.moveToElement(driver.findElement(btn_save_AddNewRole)).click().perform();
		
		//driver.findElement(btn_save_AddNewRole).click();
	}
	
	public String getErrorMsg_roleName()
	{
		return driver.findElement(label_errorMsg_roleName).getText();
	}
	public String getErrorMsg_description()
	{
		return driver.findElement(label_errorMsg_description).getText();
	}
	public String getErrorMsg_permission()
	{
		return driver.findElement(label_errorMsg_permission).getText();
	}
	public void clickSelectScreensDropDown()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(dd_searchAndSelectScreen));
		driver.findElement(dd_searchAndSelectScreen).click();
	}
	public void selectScreen(String screenName) 
	{
		
		label_screenName_dropDownList=By.xpath("//span[contains(text(),'"+screenName+"')]");
	    wait.until(ExpectedConditions.presenceOfElementLocated(label_screenName_dropDownList));
		driver.findElement(label_screenName_dropDownList).click();
		//clickNewRoleTitle();
		clickonEditChkbox();
		
	
	}
	
	
	public void clickExpandIcon_Row1()
	{
		driver.findElement(icon_expandScreen_Row1).click();
	}
	public List<String> getFieldsListDisplayed() {
		List<String> fieldsDisplayed=new ArrayList<String>();
		int rowSize=driver.findElements(list_fieldNameRows).size();
		System.out.println("Fields Displayed ="+(rowSize-1));
		for(int i=2;i<=rowSize;i++) 
		{
			label_fieldName_dropDownList=By.xpath("//*[@id='viewAddEditSection'][contains(@class,'active')]/div[2]/div/div[5]/div/div[2]/p-treetable/div/div/table/tbody/tr["+i+"]/td[1]/div");
			fieldsDisplayed.add(driver.findElement(label_fieldName_dropDownList).getText().trim());
		}
		System.out.println("Field List Size="+fieldsDisplayed.size());
		return fieldsDisplayed;
	}
	public WebElement getroleNamefromTable(int i) {
	WebElement	role_table=driver.findElement(By.xpath("//app-role/div[1]/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr["+i+"]/td[1]/div"));
		return role_table;
	}
	public void clickonUpdateBtn(int i) {
		WebElement update=driver.findElement(By.xpath("//tbody/tr["+i+"]/td[6]/div[1]/a[2]"));
		update.click();
	}
	public WebElement getEndDatefromTable(int i) {
		WebElement	role_table=driver.findElement(By.xpath("//app-role/div[1]/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr["+i+"]/td[5]/div"));
			return role_table;
		}
	
	public WebElement geDatesforNewRole() {
		By dd_month_datepicker=By.xpath("//select[contains(@class,'p-datepicker-month')]");
	driver.findElement(dd_month_datepicker).click();
	driver.findElement(By.xpath("//option[contains(text(),'October')]")).click();
	WebElement dates=driver.findElement(By.xpath("/html/body/div/div[1]/div/div[2]/table/tbody/tr[1]/td[6]/span"));
	return dates;
		
	}
	public void clickonStartDate() {
		driver.findElement(By.xpath("//*[@id=\"addStartDate\"]/span/input")).click();;
	}
	public WebElement getExpiredRoles(){
		
		By rows_exp=By.xpath("//tr[@class,'hasExpired ng-star-inserted']");
		WebElement expRole=driver.findElement(rows_exp);
		return expRole;
		
	}
	
	public WebElement getroleNamefromCopy() {
		WebElement expRole=driver.findElement(By.xpath("//input[@id='updateRoleName']"));
		
		return expRole;
	}
	
	 public String getRoleName_UpdateRolePage()
	 {
		String role=driver.findElement(label_rolename_updateRole).getAttribute("value");
		return role;
	 }
	
	
	
	public WebElement clickoncopybtn() {
		WebElement expRole=driver.findElement(By.xpath("//input[@id='updateRoleName']"));
		return expRole;
		
	}
	public void clickonsaveforcopy() {
		driver.findElement(By.xpath("//*[@id=\"viewAddEditSection\"]/div[3]/div/div/button[1]/span")).click();
	}
	public WebElement getSearchboxinmain(String role) 
	{
		WebElement search=driver.findElement(searchRole);
		search.sendKeys(role);
		return search;
	}
	
	
	public WebElement getrowsfrntable(int i) {
		WebElement rows=driver.findElement(By.xpath("//tbody/tr[\"+i+\"]"));
		return rows;
		
	}
	/*public WebElement clickonSearchandSelectScreens() {
		driver.findElement("selectQassignment").click();
		// TODO Auto-generated method stub
		return null;
	}*/
	public void clickonPartnerDropdn() {
		driver.findElement(By.xpath("//*[@id=\"updatePartners1\"]/div/div[2]/div")).click();
		// TODO Auto-generated method stub		
	}
	public void clickonPartner() {
		driver.findElement(By.xpath("//div/div[2]/ul/p-multiselectitem[1]/li/span")).click();
		// TODO Auto-generated method stub
	}
	public void clickCancel_UpdateRole() {
		driver.findElement(btnCancel_UpdateRole).click();
		
	}
	public void clickoncancelOK() {
		// TODO Auto-generated method stub
		driver.findElement(By.xpath("//app-role/p-toast[2]/div/p-toastitem/div/div/div[2]/button[1]/span")).click();
	}
	public void clickOnSearchIcon() {
		// TODO Auto-generated method stub
		
	}
	
	
	public List<WebElement> getSearchResult() throws InterruptedException
	{
       Thread.sleep(5000);
       List<WebElement> searchResult_rows=driver.findElements(searchResult);
	   return searchResult_rows;
	}
	
	public String getRoleUpdateSuccessMessage()
	{
		driver.switchTo().defaultContent();
		 wait.until(ExpectedConditions.presenceOfElementLocated(message_roleUpdateSuccess));
	     String Message=driver.findElement(message_roleUpdateSuccess).getText();
	    return Message;
	    	
	}
	
	public String getValidationMessageRoleExists() throws InterruptedException
	{
		 Thread.sleep(2000);
		 driver.switchTo().defaultContent();
	     String ErrorMessage=driver.findElement(errormessage_RoleExists).getText();
		 return ErrorMessage;
		
	}
	public String getTitle_UpdateRole()
	{
		String PageTitle=driver.findElement(title_UpdateRole).getText();
		return PageTitle;
	}
	
	public String getTitle_MainPage()
	{
		String PageTitle=driver.findElement(title_MainPage).getText();
		return PageTitle;
	}
	
	public String getErrorMsgPermissionDateLesserThanRoleEndDate()
	{
		String error=driver.findElement(errormessage_PermissionDateLesserRoleEnddate).getAttribute("title");
		return error;
	}
	
	public String getErrorMsgEndDateGreaterthanStartDate()
	{
		String error=driver.findElement(errormessage_EndDateGreaterthanStartDate).getAttribute("title");
		return error;
	
	}
	
	public String getSuccessfulRoleCreationMsg() throws InterruptedException
	{
	
	driver.switchTo().defaultContent();
    wait.until(ExpectedConditions.presenceOfElementLocated(message_roleCreateSuccess));
	String Msg=driver.findElement(message_roleCreateSuccess).getText();
	return Msg;
	}
	
	public List<String> getListActiveRolesUIMainTbl() throws InterruptedException
	{
		Thread.sleep(6000);
		driver.switchTo().defaultContent();
		List<WebElement> roleListUI=driver.findElements(RoleList_UI);
		
      List<String> Rolelist = new ArrayList<String>();
						 //    Boolean flag = true;
		    System.out.println("3");
			
		    int rolecount=0;
		for(int j=0;j<roleListUI.size();j++) 
			{
			roleListUI=driver.findElements(RoleList_UI);
		if(roleListUI.get(j).getAttribute("class").equals("ng-star-inserted"))
		{ 
		 String roles=roleListUI.get(j).getText().toLowerCase();
									  
			Rolelist.add(roles);
			rolecount++;
								     
			roleListUI=driver.findElements(RoleList_UI);
								     }
									
									}
							
		System.out.println("No of Elements in list->"+rolecount);
        System.out.println("No of Elements in list->"+Rolelist.size());
							
	return Rolelist;
									
		
	}
	
	public List<String> getListInactiveRolesUIMainTbl() throws InterruptedException
	{
		Thread.sleep(6000);
		
	List<WebElement> rows=driver.findElements(rows_UIMainTbl);
	List<String> inActiveRoleList = new ArrayList<String>();
   
	int rolecount=0;
	for(int j=0;j<rows.size();j++) 
	{
		rows=driver.findElements(rows_UIMainTbl);
		if(rows.get(j).getAttribute("class").equals("hasExpired ng-star-inserted"))
		{ 
		 String roles=rows.get(j).getText();
		 inActiveRoleList.add(roles);
			rolecount++;
			rows=driver.findElements(rows_UIMainTbl);
				}
		}
							
		System.out.println("No of Elements in list->"+rolecount);
        System.out.println("No of Elements in list->"+inActiveRoleList.size());
							
	return inActiveRoleList;
									
}

public int getNumberofRowsUIMaintbl()
{
	List<WebElement> rows=driver.findElements(rows_UIMainTbl);
	int NumberofRowsUIMaintbl=rows.size();
	return NumberofRowsUIMaintbl;
}
	
	
	public void clickViewIconInactiveList(int i)
	{
		
	String xpath_View="//tbody/tr["+(i)+"]/td[6]/div[1]/a[2]/em[1]";
    System.out.println("xpath_View->"+xpath_View);
	  WebElement ViewButton=driver.findElement(By.xpath(xpath_View));
	  ViewButton.click();	
	}
	
	public void clickCopyIcon(int i)
	{
		
	String xpath_Copy="//tbody/tr["+(i)+"]/td[6]/div[1]/a[1]/em[1]";
    System.out.println("xpath_Copy->"+xpath_Copy);
	  WebElement copyButton=driver.findElement(By.xpath(xpath_Copy));
	  copyButton.click();	
	}
	
	public String getRolenameInactiveListMainTbl(int i)
	{
	String xpath_RoleName="//tbody/tr["+(i)+"]/td[1]";
    System.out.println("xpath_RoleName->"+xpath_RoleName);
	 String roleName=driver.findElement(By.xpath(xpath_RoleName)).getAttribute("title");
	 return roleName;
	}
	
	public String getRolenameViewPage()
	{
		String rolnameViewPage=driver.findElement(label_rolename_updateRole).getAttribute("value");
		return rolnameViewPage ;
	}
	
	public String getTitleViewPage()
	{
		String titleViewPage=driver.findElement(title_ViewRole).getText();
		return titleViewPage ;	
	}
	public String getTitleCopyPage() throws InterruptedException
	{
		Thread.sleep(3000);
		String titleCopyPage=driver.findElement(title_CopyRole).getText();
		return titleCopyPage ;	
	}
	
	
	public String getDisableFlagViewPage()
	{
		String Disablechk=driver.findElement(label_rolename_updateRole).getAttribute("disabled");
		return Disablechk;
	}
	
	
	
	
	
	
	
	
}
