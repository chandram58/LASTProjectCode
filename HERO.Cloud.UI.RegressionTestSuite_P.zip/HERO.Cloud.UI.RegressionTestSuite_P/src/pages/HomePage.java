package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.base;

public class HomePage extends base
{
	By tab_administration=By.xpath("//ul[@class='mainNavigation']//a[contains(text(),'Administration')]");
	By tab_dashboard=By.xpath("//ul[@class='mainNavigation']//a[normalize-space()='Dashboard']");
	By tab_reporting=By.xpath("//ul[@class='mainNavigation']//a[normalize-space()='Reporting']");
	
	By tabsearchAndView=By.xpath("//app-navigation-bar/div[1]/ul/li[4]/a");
    By link_SearchView=By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[4]/ul[1]/li[1]/a[1]");
	By link_FileUpload=By.xpath("//app-navigation-bar/div[1]/ul/li[4]/ul/li[3]/a");
	

	By link_moduleName;
	Actions action;
	 
	public void mouseHoverAdministration() throws InterruptedException
	{
		action = new Actions(driver);
	wait.until(ExpectedConditions.elementToBeClickable(tab_administration));
		action.moveToElement(driver.findElement(tab_administration)).perform();
		Thread.sleep(1000);
	}
	
	public void mouseHoverDashboard() throws InterruptedException
	{
		action = new Actions(driver);
	wait.until(ExpectedConditions.elementToBeClickable(tab_dashboard));
		action.moveToElement(driver.findElement(tab_dashboard)).perform();
		Thread.sleep(1000);
	}
	
	
	
	
	public void openModule(String moduleName) throws InterruptedException
	{
		Thread.sleep(1000);
		action = new Actions(driver);
		link_moduleName=By.xpath("//a[contains(text(),'"+moduleName+"')]");
		wait.until(ExpectedConditions.elementToBeClickable(link_moduleName));
		action.moveToElement(driver.findElement(link_moduleName)).click().release().build().perform();
		
	}
	public void mouseHoverSearchAndView() throws InterruptedException{
		
		action = new Actions(driver);
	wait.until(ExpectedConditions.elementToBeClickable(tabsearchAndView));
		action.moveToElement(driver.findElement(tabsearchAndView)).perform();
		Thread.sleep(1000);
	}
	
	public void mouseHoverReporting() throws InterruptedException
	{
		action = new Actions(driver);
	   wait.until(ExpectedConditions.elementToBeClickable(tab_reporting));
		action.moveToElement(driver.findElement(tab_reporting)).perform();
		Thread.sleep(1000);
	}
	
  	
	
	public void openSearchView() throws InterruptedException
	{
		action = new Actions(driver);
		wait=new WebDriverWait(driver,2000);
		
		wait.until(ExpectedConditions.elementToBeClickable(link_SearchView));
		action.moveToElement(driver.findElement(link_SearchView)).click().release().build().perform();
	
		Thread.sleep(1000);
	}
	
	public void openFileUpload() throws InterruptedException
	{
		action = new Actions(driver);
		wait=new WebDriverWait(driver,2000);
		
		wait.until(ExpectedConditions.elementToBeClickable(link_FileUpload));
		action.moveToElement(driver.findElement(link_FileUpload)).click().release().build().perform();
	
		Thread.sleep(1000);
	}








}
