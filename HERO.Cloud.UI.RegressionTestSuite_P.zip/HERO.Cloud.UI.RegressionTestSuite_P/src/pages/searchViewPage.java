package pages;


import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.asserts.SoftAssert;

import base.base;

public class searchViewPage extends base
{
By dropdown_Select=By.xpath("//app-search[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/p-dropdown[1]");
By dropdownvalueSelect_Claimid=By.xpath("//p-dropdown[1]/div[1]/div[3]/div[2]/ul[1]/p-dropdownitem[7]/li");
By textbox_Searchpage=By.xpath("//app-search[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/input[1]");
By searchIcon_direct=By.xpath("//app-search[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[2]/p-button[1]");
By searchIcon_guided=By.xpath("//app-search[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/p-button[1]/button[1]");

By claimsTab_searchResult=By.xpath("//app-searchviews/div[2]/ul/li[1]/a");
By link_ExportToCSV=By.xpath("//app-searchviews/div[2]/div[1]/div[1]/div[2]/div/a[1]/em");
By link_ExportToPDF=By.xpath("//i[contains(@class,'far fa-file-pdf')]");

By RadioButton_guided=By.xpath("//label[contains(text(),'GUIDED')]");
By dropdown_selectCombination=By.xpath("//span[contains(text(),'Select Combination')]");

By Link_BreadcrumbResult_Home=By.xpath("//a[contains(text(),'Home')]");
By Link_BreadcrumbResult_Search=By.xpath("//app-searchviews/div[1]/div/div/div/div[1]/ul/li[2]/a");
By Link_BreadcrumbEditComb_Search=By.xpath("//app-filteredit[1]/div[1]/div[1]/div[1]/ul[1]/li[2]/a[1]");
By dropdown_editCombinationLink=By.xpath("//p-dropdown[1]/div[1]/div[3]/div[4]/ul[1]/p-dropdownitem[5]/li[1]/div[1]/div[2]/a[1]/i[1]");
By errortxt_GuidedSearch=By.xpath("//div[contains(text(),'Please select a Combination')]");

By AddRemoveColumn_SearchResult=By.xpath("//app-searchviews[1]/div[2]/button[2]/i[1]");
By Claims_Chevron=By.xpath("//app-columnsfilter/div/div[2]/div[1]/ul/li/p-tree/div/div[2]/ul/p-treenode[1]/li/div/button/span");
By Claims_Column_ServiceBeginDate=By.xpath("//app-columnsfilter/div/div[2]/div[1]/ul/li/p-tree/div/div[2]/ul/p-treenode[1]/li/ul/p-treenode[1]/li/div/span/span/label");
By button_Apply_addRemoveSection=By.xpath("//app-columnsfilter/div/div[2]/div[2]/div/div[1]/button");

By SearchResult_ColumnHeader=By.xpath("//app-searchviews/div[2]/div/p-table/div/div/div/div[1]/div/table/thead");
By Link_MyCombinations=By.xpath("//span[contains(text(),'MY COMBINATIONS')]");
By Link_AddCombination=By.partialLinkText("Add Combi");
By Text_defaultSearchtype=By.xpath("//*[@id='filtereditcontainer']/div[2]/div/div[2]/p-dropdown/div/span");
By Link_AddToMyCombination=By.xpath("//span[contains(text(),'Add to my combination')]");
By Txt_MaxCombinationsError=By.xpath("//div[contains(text(),'Cannot have more than 10 combinations.')]");
By List_MyCombination=By.xpath("//app-searchviews[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/p-menu[1]/div[1]/ul[1]/li");
By Label_Resultpage_MyCombinations=By.xpath("//label[contains(text(),'MY COMBINATIONS')]");
By icon_trash_MyCombination_ResultPage=By.xpath("//p-menu[1]/div[1]/ul[1]/li[1]/a[1]/span[1]");

By Button_Ok_DeleteConfirmation=By.xpath("//span[contains(text(),'OK')]");
By SelectTradingPartner_NewCombination=By.xpath("//app-filteredit[1]/div[1]/div[2]/div[1]/div[1]/p-multiselect[1]/div[1]/div[2]");
By MultiSelect_SelectTradingPartner_NewCombination=By.xpath("//app-filteredit[1]/div[1]/div[2]/div[1]/div[1]/p-multiselect[1]/div[1]/div[4]/div[1]/div[1]/div[2]");
By SelectUser_NewCombination=By.xpath("//app-filteredit[1]/div[1]/div[2]/div[1]/div[3]/p-multiselect[1]/div[1]/div[2]");
By MultiSelect_SelectUser_NewCombination=By.xpath("//app-filteredit[1]/div[1]/div[2]/div[1]/div[3]/p-multiselect[1]/div[1]/div[4]/div[1]/div[1]/div[2]");
By Columnname_QueryBuilder=By.xpath("//app-filteredit[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]/p-dropdown[1]/div[1]/span[1]");
By SelectNameOption=By.xpath("//p-dropdown/div/div[3]/div[2]/ul/cdk-virtual-scroll-viewport/div[1]/p-dropdownitem[11]/li/div/span");
By AddToFilter_NewComb=By.xpath("//app-filteredit[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[4]/div[1]/button[1]/span[1]");
By SelectOperator_QueryBuilder=By.xpath("//app-filteredit[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[2]/p-dropdown[1]/div[1]/span[1]");
By SelectOperatorOption=By.xpath("//p-dropdown[1]/div[1]/div[3]/div[1]/ul[1]/p-dropdownitem[1]/li[1]");
By Textbox_Querybuilder=By.xpath("//app-filteredit[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/div[3]/input[1]");
By Button_Save_MyCombination=By.xpath("//app-filteredit[1]/div[1]/div[1]/div[2]/div[1]/button[2]");
By Textbox_Searchname_SaveNewCombination=By.xpath("//app-filteredit[1]/div[1]/div[2]/p-dialog[1]/div[1]/div[1]/div[2]/div[1]/div[1]/input[1]");
By Button_Save_SaveNewCombination=By.xpath("//app-filteredit[1]/div[1]/div[2]/p-dialog[1]/div[1]/div[1]/div[2]/div[3]/button[1]");

By SelectCombinationDropdownOptions=By.xpath("//p-dropdown[1]/div[1]/div[3]/div[4]/ul[1]");
By selectCombinationOption;



  public void clickSelectDropdown()
    {
	  wait.until(ExpectedConditions.elementToBeClickable(dropdown_Select));
	  driver.findElement(dropdown_Select).click();
	  
	  wait.until(ExpectedConditions.elementToBeClickable(dropdown_Select));
	  driver.findElement(dropdownvalueSelect_Claimid).click();
	
     }
	
  public void enterValueTextbox(String Claimid)
  {
	  wait.until(ExpectedConditions.presenceOfElementLocated(textbox_Searchpage));
	  driver.findElement(textbox_Searchpage).sendKeys(Claimid);
      }
	
  public void clickSearchIcon_Direct()
  {
	wait.until(ExpectedConditions.elementToBeClickable(searchIcon_direct));
	 driver.findElement(searchIcon_direct).click(); 
  }
  public void clickSearchIcon_Guided()
  {
	wait.until(ExpectedConditions.elementToBeClickable(searchIcon_guided));
	 driver.findElement(searchIcon_guided).click(); 
  }
  
  
  public void clickClaimstab()
  {
	  wait.until(ExpectedConditions.elementToBeClickable(claimsTab_searchResult));
	  driver.findElement(claimsTab_searchResult).click();
  }

public void DownloadCSV() throws InterruptedException 
  {
	wait.until(ExpectedConditions.elementToBeClickable(link_ExportToCSV));
	driver.findElement(link_ExportToCSV).click();
    Thread.sleep(10000);
    }

public void DownloadPDF() throws InterruptedException 
{
	wait.until(ExpectedConditions.elementToBeClickable(link_ExportToPDF));
	driver.findElement(link_ExportToPDF).click();
  Thread.sleep(10000);
  }

	
  public void selectGuidedRadioButton()
  {
		wait.until(ExpectedConditions.elementToBeClickable(RadioButton_guided));
	  driver.findElement(RadioButton_guided).click();  
  }
  public void clickSelectCombination()
  {
	  wait.until(ExpectedConditions.elementToBeClickable(dropdown_selectCombination));
	  driver.findElement(dropdown_selectCombination).click();
  }
  
  public void selectGuidedSearchOption()
  {
	By selectCombinationOption=By.xpath("//div[contains(text(),'TESTGudided')]");
	 driver.findElement(selectCombinationOption).click();//Selecting Shweta1 combination
  }
 
  public String clickHomeLinkSearchResult() throws InterruptedException
  {
	  driver.findElement(Link_BreadcrumbResult_Home).click();
	  Thread.sleep(3000);
	  String URL=driver.getCurrentUrl();
	  return URL;
	  
  }
  
  public String clickSearchLinkSearchResult() throws InterruptedException
  {
	  driver.findElement(Link_BreadcrumbResult_Search).click();
	  Thread.sleep(3000);
	  String URL=driver.getCurrentUrl();
	  return URL;
	  
    }
  
  public void clickEditCombination()
  {
	  driver.findElement(dropdown_editCombinationLink).click(); 
	    
  }
  
  public String clickSearchLinkEditCombination() throws InterruptedException
  {
	  driver.findElement(Link_BreadcrumbEditComb_Search).click();
	  Thread.sleep(3000);
	  String URL=driver.getCurrentUrl();
	  return URL;
	  
    }
  
  public void waitForPageLoad()
  {
	wait.until(ExpectedConditions.elementToBeClickable(searchIcon_direct));  
  }
  
  public String getEmptyValidationErrortxt()
  {
	  driver.switchTo().defaultContent();
	  String ErrorTxt=driver.findElement(errortxt_GuidedSearch).getText();
	  return ErrorTxt;
  }
 
  public void clickAddColumn()
  {
	driver.findElement(AddRemoveColumn_SearchResult).click();  
	driver.findElement(Claims_Chevron).click();
	
   driver.findElement(Claims_Column_ServiceBeginDate).click();
   
   //Click On Apply Button
   
   driver.findElement(button_Apply_addRemoveSection).click();
	
	
  }
  
  public String getSearchResultHeader()
  {
	  String SearchResultHeaders=driver.findElement(SearchResult_ColumnHeader).getText();
	  return SearchResultHeaders;
  }
  
  public void clickAddCombinationslink()
  {
	  driver.findElement(Link_AddCombination).click();
	  
  }
  
  public String getDefaultSearchType()
  {
	  String defaultSearchtype=driver.findElement(Text_defaultSearchtype).getText();
	  return defaultSearchtype;
	//*[@id="filtereditcontainer"]/div[2]/div/div[2]/p-dropdown/div/span  
  }
  
  public void clickAddToMyCombination()
  {
	 driver.findElement(Link_AddToMyCombination).click();
	  
  }
  
  public String getMaxCombinationsError()
  {
	driver.switchTo().defaultContent();
	String MaxCombinationsErrortxt=driver.findElement(Txt_MaxCombinationsError).getText();
	return MaxCombinationsErrortxt;
    }
  
  public int getCountCombination_MyCombinations() throws InterruptedException
  {
	  int combinationCount=0;
	  
	  Thread.sleep(2000);
	  driver.findElement(Label_Resultpage_MyCombinations).click();
	  List<WebElement> MyCombinationsList=driver.findElements(List_MyCombination);
	  
	  combinationCount=MyCombinationsList.size();
	  return combinationCount; 
  }
  
  public void clickTrashiconAndConfirm() throws InterruptedException
  {
	  driver.findElement(icon_trash_MyCombination_ResultPage).click();
	  Thread.sleep(2000);
	 driver.switchTo().defaultContent();
	 driver.findElement(Button_Ok_DeleteConfirmation).click();
	 
	 
  }
  
  
  public void AddNewCombination_Verify() throws InterruptedException
  {
	  driver.findElement(Link_AddCombination).click();;
	  Thread.sleep(3000);
	 
	  //Select Trading Partner in New Combination Page
	  
	  driver.findElement(SelectTradingPartner_NewCombination).click();
	  driver.findElement(MultiSelect_SelectTradingPartner_NewCombination).click();
	  driver.findElement(By.xpath("//html//body")).click();
	  
	  //Select all users in Select Drop down
	  driver.findElement(SelectUser_NewCombination).click();
	  driver.findElement(MultiSelect_SelectUser_NewCombination).click();
	  driver.findElement(By.xpath("//html//body")).click(); 
	  
	 //Enter Query in QuereyBuilder 
	  
	  //Click and Select  Column name
	  driver.findElement(Columnname_QueryBuilder).click();
	  driver.findElement(SelectNameOption).click();
	  driver.findElement(By.xpath("//html//body")).click(); 
	  
	  //Click and Select Operator
	  driver.findElement(SelectOperator_QueryBuilder).click();
	  driver.findElement(SelectOperatorOption).click();
	  driver.findElement(By.xpath("//html//body")).click(); 
	  
	  //Enter value in Text Box
	  driver.findElement(Textbox_Querybuilder).sendKeys("80882");
	  
	  
	  //Click on Apply filter Button
     driver.findElement(AddToFilter_NewComb).click();
	  
	 //Click on Save Button
    driver.findElement(Button_Save_MyCombination).click();
    
    //Enter name of combination in 'SaveNewCombination' textbox
    driver.switchTo().defaultContent();
    
    Date d=new Date();
    String CombinationName="Comb"+d;
    
    
    System.out.println("CombinationName->"+CombinationName);
    
    driver.findElement(Textbox_Searchname_SaveNewCombination).sendKeys(CombinationName);
    
    //Click on Save
    driver.findElement(Button_Save_SaveNewCombination).click();
    
	
    Thread.sleep(10000);
    driver.findElement(RadioButton_guided).click();

    driver.findElement(dropdown_selectCombination).click();
    Thread.sleep(1000);
    String DropdownOptions=driver.findElement(SelectCombinationDropdownOptions).getText();
    System.out.println("DropdownOptions->"+DropdownOptions);
    SoftAssert softassert=new SoftAssert();
    softassert.assertTrue(DropdownOptions.contains(CombinationName), "Newly created combination not present Select CombinationDropdown ");
    softassert.assertAll();
    
    
  }
  
  
  
  
  
  
 }
