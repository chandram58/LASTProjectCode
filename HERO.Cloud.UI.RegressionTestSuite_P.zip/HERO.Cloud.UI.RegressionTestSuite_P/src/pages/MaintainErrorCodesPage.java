package pages;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.base;

public class MaintainErrorCodesPage extends base{
	
	By webtable_UIMainPage=By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/p-table/div/div/div/div[2]/table");
	By txt_belowMainTbl=By.xpath("//span[contains(@class,'totalRecord')]");
	By addnewerrcode=By.xpath("//span[contains(text(),'Add New Error Code')]");
	By newpageTitle=By.xpath("//h3[contains(text(),'New Error Code')]");
	By updatepageTitle=By.xpath("//h3[normalize-space()='Update Error Code']");
	By modulepageTitle=By.xpath("//h1[contains(text(),'Maintain Error Codes')]");
	By TPDd=By.xpath("//span[contains(text(),'Select Trading Partner')]");
	By addTP=By.xpath("//a[@class='addcombinationBtn']");  
	By slectTPid=By.xpath("//div[contains(text(),'Select Trading Partner')]");            //*[@id=\"partnerDetails0\"]/div/div[2]/div
	By TxtTPSearch=By.xpath("//input[@placeholder='Search Trading Partner']");
	By txt_TP=By.xpath("//span[contains(text(),'ALL')]");
	By severityDP=By.xpath("//span[contains(text(),'Select Severity')]");
	By slctSeverity=By.xpath("//span[contains(text(),'Informational')]");
	By severityList_Dropdown=By.xpath("//body/div/div/ul/p-dropdownitem/li");
	By errorcodename=By.xpath("//input[@id='errorCodeName']");
	By errorTypeList_Dropdown=By.xpath("//body/div/div/ul/p-dropdownitem/li");
	By errorTypeDP=By.xpath("//span[contains(text(),'Select Error Type')]");
	By selctErrortypedp=By.xpath("//span[contains(text(),'Business Rules')]");
    By btn_save=By.xpath("//span[contains(text(),'Save')]//parent::button");
    By serchbtninmain=By.xpath("//app-error-code/div/div[1]/div/div[2]/div/div/input");
    By webTablerow=By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody/tr");
    By errorcodesnotes=By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody/tr/td[4]");
    By btn_DownloadToCSV=By.xpath("//em[@class='far fa-file']")  ;
    By btn_DownloadToPDF=By.xpath("//em[@class='far fa-file-pdf']");
    By searchResult=By.xpath("//p-table/div/div/div/div[2]/table/tbody/tr/td[1]");
    By btn_edit_1strow=By.xpath("//tbody/tr[1]/td[8]/span[1]/a[1]/i[1]");
    By textbox_Description_Update=By.xpath("//textarea[@name='updateDescription']");
    By icon_sort_MainPage=By.xpath("//thead/tr[1]/th[1]/p-sorticon[1]/i[1]");
    By msg_ErrorCodeCreation=By.xpath("//div[contains(text(),'Error code has been created successfully')]");
    By txtbox_newErrorCode=By.xpath("//input[@id='errorCodeName']");
    By link_BacktoErrorCodeDetails=By.xpath("//a[@class='smallfont']");
    
    //Update error code
    By txtbox_update_ErrorCode=By.xpath("//input[@id='updateErrorCode']");
    By txtbox_update_Startdate=By.xpath("//*[@id='updateErrorCodeStartDate']/span/input");
    By txtbox_update_Enddate=By.xpath("//*[@id='updateErrorCodeEndDate']/span/input");
    By txtbox_update_Desc=By.xpath("//textarea[@name='updateDescription']");
    By dropdown_update_ErrorType=By.xpath("//span[contains(@class,'p-dropdown-label p-inputtext ng-star-inserted')]");
    By txtbox_update_Loop=By.xpath("//input[@id='loopId']");
    By txtbox_update_Segment=By.xpath("//input[@id='segmentId']");
    By txtbox_update_Element=By.xpath("//input[@id='elementId']");
    By dropdown_update_SelectTradingPartner=By.xpath("//span[contains(text(),'Select Trading Partner')]");
    By dropdown_update_TradingPartnerId=By.xpath("//div[contains(text(),'Select Trading Partner')]");
    By dropdown_update_Selectseverity=By.xpath("//span[contains(text(),'Select Severity')]");
    By radiobtn_update_PasteInst=By.xpath("//label[normalize-space()='Paste Instructions']");
    By radiobtn_update_FileUpload=By.xpath("//label[normalize-space()='File Upload']");
    By txtbox_update_Paste=By.xpath("//div[contains(@class,'ql-editor')]");
    By placeholder_update_NotesDesc=By.xpath("//input[@placeholder='Description']");
    By placeholder_update_NotesDetail=By.xpath("//textarea[@placeholder='Detailed Notes']");
    
    
    
   
    Actions action = new Actions(driver);
    public List<String> geterrorcodefromTable() {
    	
    		int rowSize=driver.findElements(webTablerow).size();
    		String endDate;
    		List<String> activeeerorcodelist = new ArrayList<String>();
    		for(int i=1;i<=rowSize;i++)
    		{
    			errorcodesnotes=By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody/tr/td[4]");
    			
    			endDate=driver.findElement(errorcodesnotes).getText().trim();
    			System.out.println("EndDate in Row"+i+"="+endDate);
    			activeeerorcodelist.add(endDate);
    		}
    		return activeeerorcodelist;

    	}
    public List<String> geterrorcodeTPfrmtable() throws InterruptedException {
    	Thread.sleep(2000);
		int rowSize=driver.findElements(webTablerow).size();
		String endDate;
		List<String> activeeerorcodelistTP = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
		By	errorcodesTP=By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody/tr/td[2]");
			Thread.sleep(4000);
		String	TP=driver.findElement(errorcodesTP).getText().trim();
			System.out.println("EndDate in Row"+i+"="+TP);
			activeeerorcodelistTP.add(TP);
		}
		return activeeerorcodelistTP;

	}

    
    public void inputCodeSerach(String ErrorCode) throws InterruptedException {
		Thread.sleep(1000);
		//driver.findElement(By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/span[1]/p-paginator/div/span/button[3]")).click();
		Thread.sleep(1000);
		 driver.findElement(serchbtninmain).sendKeys(ErrorCode);
	}
    
    
    public List<WebElement> getSearchResult()
    {
    	
		
		List<WebElement> serachResult_rows=driver.findElements(searchResult);
		return serachResult_rows;
    	
    }
    
    public void clickonSaveBTn() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(btn_save).click();
	}
    
    public void enterNewErrorCode(String errorCodeName)
    {
    driver.findElement(txtbox_newErrorCode).sendKeys(errorCodeName);
    }
    
	public void selectErrorType(String ErrorType) 
	{
		clickErrorTypeDropdown();
		driver.findElement(By.xpath("//span[contains(text(),'"+ErrorType+"')]")).click();
	}
	
	public void clickErrorTypeDropdown() 
	{
		wait.until(ExpectedConditions.elementToBeClickable(errorTypeDP));
		driver.findElement(errorTypeDP).click();	
	}
	
	
	public void inputErrorCodeName(String ErrorCode) throws InterruptedException {
		Thread.sleep(2000);
		 driver.findElement(errorcodename).sendKeys(ErrorCode);;
	}
	public void clickOnBackTOerrorcodepage() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"viewAddEditSection\"]/a")).click();
	}
	public void selectSeverityfrmDP(String Severity) throws InterruptedException {
		Thread.sleep(1000);
		 driver.findElement(By.xpath("//span[contains(text(),'"+Severity+"')]")).click();
	}
	public void clickonSeverityDP() throws InterruptedException {
		
		wait.until(ExpectedConditions.elementToBeClickable(severityDP));
		driver.findElement(severityDP).click();
	}
	public void clickonAddNewErrorCode() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(addnewerrcode).click();
	}
	public String clickandSelectTradingPatnerDropdown() throws InterruptedException {
		Thread.sleep(3000);
		action.moveToElement(driver.findElement(slectTPid)).click().perform();
		WebElement TPDP=driver.findElement(txt_TP);
		TPDP.click();
		return TPDP.getText();
		}
	public String clickOnSelectTPmultipleDp() throws InterruptedException {
		Thread.sleep(3000);
		action.moveToElement(driver.findElement(slectTPid)).click().perform();
		WebElement TPDP=driver.findElement(By.xpath("//*[@id=\"partnerDetails1\"]/div/div[2]/div"));
		//TPDP.click();
		return TPDP.getText();
		}
	public String searchTPinDP(String TPName) throws InterruptedException {
		Thread.sleep(1000);
		WebElement SearchTp=driver.findElement(TxtTPSearch);
		SearchTp.sendKeys(TPName);
		
		return SearchTp.getText();
		
	}
	
	//Clicking All option in Trading partners dropdown
	public void SelectTPFRMDPAfterSearch() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(txt_TP).click();
	}
	public void clickonTPDP() {
		driver.findElement(TPDd).click();
		driver.findElement(addTP).click();
		
	}
	
	public String getNewPageTitle() {
		WebElement TextEntered1=driver.findElement(newpageTitle);
		return TextEntered1.getText();
	}
	
	public String getUpdatePageTitle() {
		WebElement TextEntered1=driver.findElement(updatepageTitle);
		return TextEntered1.getText();
	}
	
	public String getModulePageTitle() throws InterruptedException {
		Thread.sleep(4000);
		WebElement TextEntered1=driver.findElement(modulepageTitle);
		return TextEntered1.getText();
	}
	
	public String getDescription_NotesSection() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[contains(text(),'Notes')]")).click();
		driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]")).sendKeys("Description");
		String TextEntered1=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]")).getAttribute("value");
		System.out.println("Text entered in Description->"+TextEntered1);
		 
		return TextEntered1;
	}
  public String getDetailedNotes_NotesSection() throws InterruptedException {
	  Thread.sleep(1000);
	  driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/textarea[1]")).sendKeys("Detailed Notes");
      String TextEntered2=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/textarea[1]")).getAttribute("value");
		System.out.println("Text entered in Detailed Notes->"+TextEntered2);
		
	return TextEntered2;
}
  
  public void clickDownloadCSVbtn()
	{
		System.out.println("Clicking On Export to CSV icon");
		driver.findElement(btn_DownloadToCSV).click();
	}
	
	public void clickDownloadPDFbtn()
	{
		System.out.println("Clicking On Export to PDF icon");
		driver.findElement(btn_DownloadToPDF).click();
	}
  
  public void clickEditbtn()
  {
	System.out.println("Clicking on First row Edit Icon");
	wait.until(ExpectedConditions.elementToBeClickable(btn_edit_1strow));
	driver.findElement(btn_edit_1strow).click();
  }
  
  
  public void editDescription()
  {
	 System.out.println("Updating Description");
	 driver.findElement(textbox_Description_Update).clear();
	 driver.findElement(textbox_Description_Update).sendKeys("Description Update");
  }
  
  public int getRecordCountUIMainPage()
  {
	  WebElement webtable=driver.findElement(webtable_UIMainPage);
	  List<WebElement> rows1;
	  List<WebElement> cols1 = null;
	  rows1=webtable.findElements(By.tagName("tr"));
	  
      List<String> ActiveErrorcodeList_UI = new ArrayList<String>();
		int recordcount=0; 
	     for(int j=0;j<rows1.size();j++) 
		   {
				cols1=rows1.get(j).findElements(By.tagName("td"));
		        //System.out.println(cols1.get(0).getAttribute("rowspan"));
				if(((rows1.get(j).getAttribute("class")).equals("ng-star-inserted")) )
			     { 
				 if(cols1.get(0).getAttribute("rowspan")!=null)
				          {
				            String Errorcode=cols1.get(0).getText();
			               
			                ActiveErrorcodeList_UI.add(Errorcode.trim());
			                recordcount++;
			               }
				 }
	        }
	return recordcount;  
	  
	  
	  
	  
	  
  }
  
  
  
  
  
  
  public List<String> getActiveErrorCodeList_UI()
  {
	  WebElement webtable=driver.findElement(webtable_UIMainPage);
	  List<WebElement> rows1;
	  List<WebElement> cols1 = null;
	  rows1=webtable.findElements(By.tagName("tr"));
	   System.out.println("No of rows on Maintain Error Code Table->"+ rows1.size());
      List<String> ActiveErrorcodeList_UI = new ArrayList<String>();
		 
	     for(int j=0;j<rows1.size();j++) 
		   {
				cols1=rows1.get(j).findElements(By.tagName("td"));
		        //System.out.println(cols1.get(0).getAttribute("rowspan"));
				if(((rows1.get(j).getAttribute("class")).equals("ng-star-inserted")) )
			     { 
				 if(cols1.get(0).getAttribute("rowspan")!=null)
				          {
				            String Errorcode=cols1.get(0).getText();
			                System.out.println(Errorcode);
			                ActiveErrorcodeList_UI.add(Errorcode.trim());
			               }
				 }
	        }
	return ActiveErrorcodeList_UI;	  
	  
  }
  
  
  
  
  
  
  
  
  public List<String> ActiveErrorcodeList_DB() throws SQLException
  {
	  String ErrorCodename_DB = null;
	  List<String> ActiveErrorcodeList_DB = new ArrayList<String>();
	  try
          {
		String Query1="Select ERROR_CODE_NAME from HERO_UI_WORK_ERROR_CODES  where END_DATE >=CAST (GETDATE() AS DATE)";

	      PreparedStatement readStatement = dbcon.prepareStatement(Query1);
	    	  rs = readStatement.executeQuery();
	    	  while(rs.next())
	    	  {
	    	  ErrorCodename_DB=rs.getString(1);
	    	  System.out.println(ErrorCodename_DB);
	    	  ActiveErrorcodeList_DB.add(ErrorCodename_DB.trim());
	    	  }
	    	 
          }
	    	  
	   catch (NullPointerException err)
	          {
		         err.getMessage();
			 	    }
			   
	  return ActiveErrorcodeList_DB;
  }

  public List<String> getSeverityList_UI()
  {
   List<WebElement> Dropdown=driver.findElements(severityList_Dropdown);
	
   List<String> SeverityList_UI=new ArrayList<String>();
				
				for(int j=0;j<Dropdown.size();j++)
				{
					String value=Dropdown.get(j).getText();
					SeverityList_UI.add(value.trim());
					
				}  
				return SeverityList_UI;
  }
  
  public List<String> getSeverityList_DB() throws SQLException
  {
	  List<String> SeverityList_DB=new ArrayList<String>();
      try
        {
		String Query1="Select Type,NAME from HERO_UI_XREF where TYPE like 'severity'";
	    	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
	    	  rs = readStatement.executeQuery();
	    	  while(rs.next())
	    	  {
	    	   String Severity_DB=rs.getString(2);
	    	  System.out.println(Severity_DB);
	    	  SeverityList_DB.add(Severity_DB.trim());
	    	  }
	    	 
        }
	    	  
	    	  
	   catch (NullPointerException err)
	          {
		         err.getMessage();
			 	    }
			 
	 return SeverityList_DB;
		
  }
  
  public List<String> getErrorTypeList_UI()
  {
   List<WebElement> Dropdown=driver.findElements(errorTypeList_Dropdown);
		List<String> ErrorTypeList_UI=new ArrayList<String>();
		
		for(int j=0;j<Dropdown.size();j++)
		{
			String value=Dropdown.get(j).getText();
			ErrorTypeList_UI.add(value.trim());
	       }
		return ErrorTypeList_UI;
  }
  
  public List<String> getErrorTypeList_DB() throws SQLException
  {
    List<String> ErrorTypeList_DB=new ArrayList<String>();
	  try
        {
		String Query1="Select Type,NAME from HERO_UI_XREF where TYPE like 'errorType'";
        PreparedStatement readStatement = dbcon.prepareStatement(Query1);
  	   rs = readStatement.executeQuery();
  	  while(rs.next())
  	  {
  	   String ErrorType_DB=rs.getString(2);
  	  System.out.println(ErrorType_DB);
  	  ErrorTypeList_DB.add(ErrorType_DB.trim());
  	  }
   }
	 
	  catch (NullPointerException err)
	          {
		         err.getMessage();
			 	    }
			return ErrorTypeList_DB;   
  }
  
  
  
  public void clickSortIcon()
  {
	  driver.findElement(icon_sort_MainPage).click(); 
	  
  }
 
  public String getErrorCodeCreatedMessage() throws InterruptedException
  {
	driver.switchTo().defaultContent();
	Thread.sleep(3000);
	String Message=driver.findElement(msg_ErrorCodeCreation).getText();
	return Message;
  }
  
  public String[] get_Note_Desc_DB() throws SQLException
  {
     String ERROR_DESC_DB = null,ERROR_NOTE_DB=null;
	String[] Error_Note_DESC_DB={ERROR_DESC_DB,ERROR_NOTE_DB};
 	  
	try
	     {
		String Query1="Select * from HERO_UI_WORK_ERROR_NOTE where LAST_UPDATED_BY like 'CRK2305' and Cast(LAST_UPDATED_DATE as DATE) =(SELECT CAST(GETDATE() AS DATE)) ORDER BY LAST_UPDATED_DATE DESC";
        PreparedStatement readStatement = dbcon.prepareStatement(Query1);
        rs = readStatement.executeQuery();
        rs.next();
        
        ERROR_DESC_DB=rs.getString(3);
		ERROR_NOTE_DB=rs.getString(4);
		System.out.println("ERROR_DESC_DB->"+ERROR_DESC_DB);
		System.out.println("ERROR_NOTE_DB->"+ERROR_NOTE_DB);
		  
	     }
		catch (NullPointerException err)
		  {
			err.getMessage();
	       }
	
	return Error_Note_DESC_DB;
				   
  }
  

  
 public String getDisabledFlag(String st)
 {
	 String DisabledFlag = null;
	 switch(st)
	 {
	 case "Errorcode":
		 WebElement Errorcode=driver.findElement(txtbox_update_ErrorCode);
		 DisabledFlag=Errorcode.getAttribute("disabled");	 
		 break;
	 
	 case "Startdate":
		 WebElement Startdate=driver.findElement(txtbox_update_Startdate);
		  DisabledFlag=Startdate.getAttribute("disabled"); 
		 break;
		 
	 case "Description": 
	  WebElement Description=driver.findElement(txtbox_update_Desc);
	  DisabledFlag=Description.getAttribute("disabled"); 
	     break;	 
	
	 case "Errortype":
		 WebElement Errortype=driver.findElement(dropdown_update_ErrorType);
		 DisabledFlag=Errortype.getAttribute("disabled");	 
		 break;
		
	 case "Enddate":
		 WebElement Enddate=driver.findElement(txtbox_update_Enddate);
		 DisabledFlag=Enddate.getAttribute("disabled");
		 break;
		 
	 case "Loop":
		  WebElement Loop=driver.findElement(txtbox_update_Loop);
		    DisabledFlag=Loop.getAttribute("disabled");
		    break; 
		    
	 case "Segment":
	        WebElement Segment=driver.findElement(txtbox_update_Segment);
	       DisabledFlag=Segment.getAttribute("disabled"); 
		   break;
	 case "Element":   
	    WebElement Element=driver.findElement(txtbox_update_Element);
	    DisabledFlag=Element.getAttribute("disabled");   
	    break;  
	
	 case "TradingPartnerDropdown":
	     WebElement TradingPartnerDropdown=driver.findElement(dropdown_update_SelectTradingPartner);
	    DisabledFlag=TradingPartnerDropdown.getAttribute("disabled");
	    break; 
	    
	 case "TradingpartnerId":  
		 WebElement TradingpartnerId=driver.findElement(dropdown_update_TradingPartnerId);
		 DisabledFlag=TradingpartnerId.getAttribute("disabled"); 
		 break;
	  
	 case "Severity":	 
		 WebElement Severity=driver.findElement(dropdown_update_Selectseverity);
		 DisabledFlag=Severity.getAttribute("disabled"); 
		 break;
		 
	 case "PasteRadio":	 
		  WebElement PasteRadio=driver.findElement(radiobtn_update_PasteInst);
		  DisabledFlag=PasteRadio.getAttribute("disabled"); 
		  break;
	
	 case "FileUploadradio":
		 WebElement FileUploadradio=driver.findElement(radiobtn_update_FileUpload);
		 DisabledFlag=FileUploadradio.getAttribute("disabled");  
		 break; 
	
	 case "PasteTextbox":
	  WebElement PasteTextbox=driver.findElement(txtbox_update_Paste);
	  DisabledFlag=PasteTextbox.getAttribute("disabled"); 
	    
	 case "NotesDescription":   
	 WebElement NotesDescription=driver.findElement(placeholder_update_NotesDesc);
	DisabledFlag=NotesDescription.getAttribute("disabled");
	  break; 
	  
	 case "NotesDetail":
	 WebElement NotesDetail=driver.findElement(placeholder_update_NotesDetail);
	 DisabledFlag=NotesDetail.getAttribute("disabled");
	    break; 
	 
	  
	 }
	 System.out.println("DisabledFlag for "+st+"->"+DisabledFlag);
	 return DisabledFlag;

 }
 
 public String getTextBelowMainTbl()
 {
	 wait.until(ExpectedConditions.presenceOfElementLocated(txt_belowMainTbl));
String text=driver.findElement(txt_belowMainTbl).getText();	 
	return text;
	 
 }
 
 
 public void clickLinkBacktoErrorcodedetails()
 {
wait.until(ExpectedConditions.elementToBeClickable(link_BacktoErrorCodeDetails));
driver.findElement(link_BacktoErrorCodeDetails).click();
 }
 
 
 
 


 
 
 



 
 
 
}
