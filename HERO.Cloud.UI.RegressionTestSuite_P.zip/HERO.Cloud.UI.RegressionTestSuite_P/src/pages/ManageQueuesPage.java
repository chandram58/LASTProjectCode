package pages;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import base.base;

public class ManageQueuesPage extends base{
	//manage queues main page
	By label_pageTitleMangequeues=By.xpath("//h1[contains(text(),'Manage Queues')]");
	By label_breadcrumbTitle=By.xpath("//app-admin-layout[1]/div[1]/app-queue[1]/div[1]/div[1]/div[1]/div[1]/ul[1]");
	By btn_sortinginMainTable=By.xpath("//app-queue/div/div[2]/div/div[2]/div/p-table/div/div/div/div[1]/div/table/thead/tr/th[4]/span[1]/p-sorticon/i");
	By Table_ManageQuesus=By.xpath("//app-queue/div/div[2]/div/div[2]/div/p-table/div/div/div/div[2]/table/tbody");
	By btn_ViewUserFunctionality=By.xpath("//tbody//tr[contains(@class,'ng-star-inserted')]//td[6]//div[1]//a[3]");
	By label_breadcrumbTitleAfterclickonViewuser=By.xpath("//app-admin-layout/div/app-user-profile/div[1]/div/div/div[1]/ul");
	By label_pageTitleafterClickOnViewUser=By.xpath("//h1[contains(text(),'User Profile')]");
	By btn_SortingQueue_table=By.xpath("//thead/tr[1]/th[3]/span[1]/p-sorticon[1]/i[1]");
	By btn_sortingQueueProperties=By.xpath("//thead/tr[1]/th[4]/span[1]/p-sorticon[1]/i[1]");
	By btn_sortingQueueAtrributesforascen=By.xpath("//thead/tr[1]/th[5]/span[1]/p-sorticon[1]/i[1]");
	By btn_copyFunctionality=By.xpath("//app-queue/div/div[2]/div/div[2]/div/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[6]/div/a[1]");
	By txt_SearchQueue=By.xpath("//app-admin-layout/div/app-queue/div/div[1]/div/div[2]/div/div/input");
	By page_svabtn=By.xpath("//span[contains(text(),'Save')]");
	By message_savepage=By.xpath("//div[contains(text(),'has been updated successfully!')]");
	By btn_csv=By.xpath("//a[contains(@title,'Export to CSV')]/em");
	By btn_pdf=By.xpath("//a[contains(@title,'Export to PDF')]/em");
	By label_tableworsDta=By.xpath("//app-queue/div/div[2]/div/div[2]/div/p-table/div/div/div/div[2]/table/tbody/tr");
	By label_totalRecords=By.xpath("//app-queue/div/div[2]/div/div[3]/div[1]/div/span");
	By label_viewclaims=By.xpath("//app-queue/div/div[2]/div/div[2]/div/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[6]/div/a[4]/em");
	By label_userpage=By.xpath("//*[@id=\"viewAddEditSection\"]/div/div[2]/div[1]/div[1]/h3");
	By btn_cancelUserpage=By.xpath("//span[contains(text(),'Cancel')]");
	//expried Queue copy 
	By btn_expriedQueue_Copy=By.xpath("//tbody//tr[contains(@class,'hasExpired ng-star-inserted')]//td[6]//div[1]//a[1]");
	By txt_expriedQueueName=By.xpath("//tbody//tr[contains(@class,'hasExpired ng-star-inserted')]//td[3]//div");
	By label_pageTitleafterclickoncopy=By.xpath("//h3[contains(text(),'New Queue')]");
	By  txt_updateQueueNameinCopyFunctionality=By.xpath("//input[@id='updateManangeQueueName']");
	By  btn_saveintxt_updateQueueNameinCopyFunctionality=By.xpath("//*[@id='viewAddEditSection']/div[2]/div[2]/div/div/button[1]");
	By  label_successMsg=By.xpath("//div[contains(text(),'Queue has been created successfully!')]");
	//expried Queue View
	By btn_ExpriedQueueView=By.xpath("//tbody//tr[contains(@class,'hasExpired ng-star-inserted')]//td[6]//div[1]//a[2]");
	By label_expriedQueueViewpageTitle=By.xpath("//h3[contains(text(),'View Queue')]");
	//Add new Queue page
	By btn_EndDate=By.xpath("//*[@id=\"addQueueEndDate\"]/span/input");
	By btn_sartDate=By.xpath("//*[@id=\"addQueueStartDate\"]/span/input");
	By btn_cancel_new=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[2]/div/div/button[2]");
	By btn_close=By.xpath("//*[@id=\"viewAddEditSection\"]/div[1]/div[2]/a");
	By label_notifiEscla=By.xpath("//label[contains(text(),'Notification for Escalation')]");
	By btn_AddNewQueue=By.xpath("//span[contains(text(),'Add New Queue')]");
	By label_pageTitleAddNewQueuepage=By.xpath("//h3[contains(text(),'New Queue')]");
	By  QueueName_UITable=By.xpath("//tbody//tr[contains(@class,'ng-star-inserted')]//td[3]");
	By link_tooltipRegularQueue=By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/span");
	By txt_NewQueue=By.xpath("//input[@id='newManangeQueue']");
	By txt_NewQueueDescription=By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[4]/textarea");
	By rbtn_RegularQueue=By.xpath("//label[contains(text(),'Regular Queue')]//parent::p-radiobutton[1]//div[2]");
	By select_EscalationQueue=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[5]/div[1]/div[2]/div[1]/div/p-dropdown/div");
	By select_ContactownerQueue=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[5]/div[1]/div[2]/div[2]/div/p-dropdown/div");
	By selectDateType=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[5]/div[2]/div[2]/p-dropdown/div");
	By selectDateofService=By.xpath("//span[contains(text(),'Date Of Service')]");
	By selectErrorDate=By.xpath("//span[contains(text(),'Error Date')]");
	By selectReceviedDate=By.xpath("//span[contains(text(),'Receive Date')]");
	By selectpaidDate=By.xpath("//span[contains(text(),'Paid Date')]");
	By rbtn_EsclationQueue=By.xpath("//label[contains(text(),'Escalation Queue')]//parent::p-radiobutton[1]//div[2]");
	By rbtn_contractownerQueue=By.xpath("//label[contains(text(),'Contract Owner Queue')]//parent::p-radiobutton[1]//div[2]");
	By rbtn_catchallQueue=By.xpath("//label[contains(text(),'Catch All Queue')]//parent::p-radiobutton[1]//div[2]");
	By txt_SuccessMessage=By.xpath("//div[contains(text(),'Queue has been created successfully!')]");
	By btn_NotificationforEscalation=By.xpath("//label[contains(text(),'Notification for Escalation')]");
	By txt_errormessage=By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[1]/div/span");
	By list_DateTypes=By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[2]/div[2]/p-dropdown/div/div[3]/div/ul/p-dropdownitem/li");
	By label_dateErrormessage=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[3]/div/span");
	//new queue QueryBulider
	By selectColumn=By.xpath("//span[contains(text(),'Select Column')]");
	By selectColumnValue=By.xpath("//span[contains(text(),'PARTNER ID')]");
	By selectoperator=By.xpath("//span[contains(text(),'Select Operator')]");
	By selectOperatorValue=By.xpath("//span[text()='=']//parent::li");
	By txt_ValueinQuerybulider=By.xpath("//label[contains(text(),'Value')]//following::input[1]");
	By btn_applyFilter=By.xpath("//span[contains(text(),'Add to Filter')]");
	By btn_saveNewQueue=By.xpath("//*[@id='viewAddEditSection']/div[2]/div[2]/div/div/button[1]");
	By btn_ExamptRecycle=By.xpath("//label[contains(text(),'Exempt from Recycle')]");
	//EditQueue
	By btn_editQueue=By.xpath("//app-queue/div/div[2]/div/div[2]/div/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[6]/div/a[2]");
	By label_pageTitleAfterEdit=By.xpath("//h3[contains(text(),'Update Queue')]");
	By select_EndinUpdateQ=By.xpath("//*[@id='updateManageQueueEndDate']/span/input");
	
	//updated Query bulider elements
	By field_Query=By.xpath("//app-query-builder/div/div[2]/ngx-codemirror/div/div[6]/div[1]/div/div/div/div[5]/div/pre/span");
	By btn_validate=By.xpath("//button[contains(@label,'Validate')]//span");
	By btn_cancel=By.xpath("//button[contains(@label,'More')]/following::button[1]");
	//searchandView
	By label_searchview=By.xpath("//h1[contains(text(),'Search & Views')]");
	By breadcrumb_serchview=By.xpath("//app-searchviews/div[1]/div/div/div/div[1]/ul");
	By resultlabelMQ=By.xpath("//app-searchviews/div[1]/div/div/div/div[1]/ul/li[2]/a");
	
	 JavascriptExecutor js = (JavascriptExecutor) driver;
	Actions action = new Actions(driver);
	WebElement webtable=driver.findElement(Table_ManageQuesus);
	
    List<WebElement> rows;
     List<WebElement> cols = null;
     
     
     public void clickonOkbtn() {
    	 driver.findElement(By.xpath("//span[contains(text(),'OK')]")).click();
     }
     public WebElement  getEndDate() {
    	 WebElement  txt=driver.findElement(btn_EndDate);
    	 return txt;
     }
     public WebElement  getStartDate() {
    	 WebElement  txt=driver.findElement(btn_sartDate);
    	 return txt;
     }
     public WebElement  getErrormessageforstartdategreaterthanEndDate() {
    	 WebElement  msg=driver.findElement(label_dateErrormessage);
    	 return msg;
     }
     public WebElement  clickonClosebtninnewQ() {
    	 WebElement  txt=driver.findElement(btn_close);
    	 return txt;
     }
     public WebElement  clickonCancelbtninNewQ() {
    	 WebElement  txt=driver.findElement(btn_cancel_new);
    	 return txt;
     }
     public void clickonCancelbtninUserpage() {
    	 driver.findElement(btn_cancelUserpage).click();
     }
     public WebElement  getUserpage() {
    	 WebElement  txt=driver.findElement(label_userpage);
    	 return txt;
     }
     public WebElement  getBackNavidationforviewclaim() {
    	 WebElement  txt=driver.findElement(resultlabelMQ);
    	 return txt;
     }
     public WebElement  getResulstofViewclaim() {
    	 WebElement  txt=driver.findElement(breadcrumb_serchview);
    	 return txt;
     }
     public WebElement  pagetitleforSearandView() {
    	 WebElement  txt=driver.findElement(label_searchview);
    	 return txt;
     }
     public WebElement  clickonViewClaim() {
    	 WebElement  txt=driver.findElement(label_viewclaims);
    	 return txt;
     }
     public WebElement  getTotalRecordsText() {
    	 WebElement  txt=driver.findElement(label_totalRecords);
    	 return txt;
     }
     public WebElement  getRowsDatainMainTable(String row,String col) {
    	 WebElement  serc=driver.findElement(By.xpath("//app-queue/div/div[2]/div/div[2]/div/p-table/div/div/div/div[2]/table/tbody/tr[+row+]/td[+col+]"));
    	 return serc;
     }
     public WebElement  getSerchFieldinpage() {
    	 WebElement  serc=driver.findElement(txt_SearchQueue);
    	 return serc;
     }
     public WebElement  getexamptfromRecycle() {
    	 WebElement  exp=driver.findElement(btn_ExamptRecycle);
    	 return exp;
     }
     public WebElement  getNotificationforEscalationQ() {
    	 WebElement  notiEsc=driver.findElement(label_notifiEscla);
    	 return notiEsc;
     }
     public void clickonPDFbtn() {
    	 WebElement pdfbtn=driver.findElement(btn_pdf);
    	 pdfbtn.click();
         File getLatestFile = base.getLatestFilefromDir(DOWNLOADFILEPATH);
		    String fileName = getLatestFile.getName();  
		    System.out.println("Downloaded File name->"+fileName);
		  try  {
		    SoftAssert softassert = new SoftAssert();
		    softassert.assertTrue(isFileDownloaded(DOWNLOADFILEPATH, fileName), "Download Failed");
       softassert.assertTrue(fileName.contains("pdf") && fileName.contains("Queues"),"It is not a pdf file");
          softassert.assertAll();
	        }
		   
  catch(Throwable e)
			     {
	  Assert.fail(e.getMessage());
			     }
			 
     }
     public void clickonCSVbtn() {
    	 WebElement csvbtn=driver.findElement(btn_csv);
    	 csvbtn.click();
         File getLatestFile = base.getLatestFilefromDir(DOWNLOADFILEPATH);
		    String fileName = getLatestFile.getName();  
		    System.out.println("Downloaded File name->"+fileName);
		  try  {
		    SoftAssert softassert = new SoftAssert();
		    softassert.assertTrue(isFileDownloaded(DOWNLOADFILEPATH, fileName), "Download Failed");
       softassert.assertTrue(fileName.contains("csv") && fileName.contains("Queues"),"It is not a csv file");
          softassert.assertAll();
	        }
		   
  catch(Throwable e)
			     {
	  Assert.fail(e.getMessage());
			     }
			 
     }
     public void clickonCancelpopinmore() throws InterruptedException {
    	 Thread.sleep(2000);
    	 driver.findElement(btn_cancel).click();
     }
     public void clickonValidatebtn() {
    	 driver.findElement(btn_validate).click();
     }
    public void getQueryBuliderData(String S) throws InterruptedException {
    	
    	action.moveToElement(driver.findElement(By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[5]/app-query-builder/div"))).perform();
    	Thread.sleep(3000);
    	WebElement query=driver.findElement(field_Query);
    	
    	
    	JavascriptExecutor jsExecutor = (JavascriptExecutor) driver; 
    	
    	// set the text
    	//jsExecutor.executeScript("arguments[0].value=Partner_ID='CMS'", query); 
    	jsExecutor.executeScript("arguments[0].scrollIntoView(true);", query); 
    //	jsExecutor.executeScript("arguments[0].click();", query);
    	jsExecutor.executeScript("arguments[0].setAttribute('value', '" + S +"')", query);
    	
        query.click();
    	query.sendKeys(S);
    	//return query;
    }
     
     public List<String> getQueuefrmManageQueue() {
    		rows=webtable.findElements(By.tagName("tr"));
    	    
    		 System.out.println("No of rows on Manage Queues Table->"+ rows.size());
    	     
    	    
    	    List<String> ActiveQueueList1 = new ArrayList<String>();
    		 
    	    for(int j=0;j<rows.size();j++) 
    		   {
    				cols=rows.get(j).findElements(By.tagName("td"));
    				
    				
    				if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
    			     { 
    				
    				String Queue=cols.get(2).getText();
    			   // System.out.println(Queue);
    			    ActiveQueueList1.add(Queue);
    				
    				
    			     }
    				}
    	    return ActiveQueueList1;
    	 }

     public void   clickOnAddNewQueue() {
    	 driver.findElement(btn_AddNewQueue).click();
  
     }
     public WebElement errormessagemaxQueueName() throws InterruptedException {
    	 Thread.sleep(2000);
    	WebElement errormessage= driver.findElement(txt_errormessage);
     return errormessage;
     }
     public WebElement getNewQueueEditble() {
    	
    	  WebElement queuevalue=driver.findElement(txt_NewQueue);
    	    return queuevalue;
    	    	
     }
     public List<String> getDateTypeDropDownlist() {
    	List<WebElement> dateTypeDropdownlist=driver.findElements(list_DateTypes);
    	System.out.println(dateTypeDropdownlist);
    	 ArrayList<String> Actuallist=new ArrayList<String>();
    	 for(int j=0;j<dateTypeDropdownlist.size();j++)
		  {
			  System.out.println(dateTypeDropdownlist.get(j).getText());
			  Actuallist.add(dateTypeDropdownlist.get(j).getText());
		  }
		return Actuallist;
     }
     public void clickonEditbtn() {
    	 driver.findElement(btn_editQueue).click();
     }
     public String getpageTitleUpdateQ() {
    	String pageTiltle= driver.findElement(label_pageTitleAfterEdit).getText();
    	return pageTiltle;
     }
     public void updateQueueEndDate() throws InterruptedException {
    	 Thread.sleep(2000);
    	// driver.findElement(select_EndinUpdateQ).clear(); 
    	 Thread.sleep(2000);
    	 driver.findElement(select_EndinUpdateQ).click();
    	 Thread.sleep(2000);
    	 driver.findElement(By.xpath("//tbody/tr[5]/td[5]/span[1]")).click();
     }
     
     public void clickonCopyFunctionality() throws InterruptedException {
    	 Thread.sleep(3000);
    	 driver.findElement(btn_copyFunctionality).click(); 
     }
     public void clickonsortingIconQueueAtrributeAsec() throws InterruptedException {
    	 Thread.sleep(3000);
    	 driver.findElement(btn_sortingQueueAtrributesforascen).click();
//    	 Thread.sleep(3000);
//    	 driver.findElement(btn_sortingQueueAtrributes).click();
     }
     public void clickonsortingIconQueueAtrributeDsec() throws InterruptedException {
    	 Thread.sleep(3000);
    	 driver.findElement(btn_sortingQueueAtrributesforascen).click();
   	 Thread.sleep(3000);
    	 driver.findElement(btn_sortingQueueAtrributesforascen).click();
     }
     public void clickonsortingIconQueueprope() throws InterruptedException {
    	 Thread.sleep(3000);
    	 driver.findElement(btn_sortingQueueProperties).click();
    	 Thread.sleep(3000);
    	 driver.findElement(btn_sortingQueueProperties).click();
     }
     public void clickonSortingIconinMaintable() throws InterruptedException {
    	 Thread.sleep(3000);
    	 driver.findElement(btn_SortingQueue_table).click();
    	 Thread.sleep(3000);
    	 driver.findElement(btn_SortingQueue_table).click();
     }
     public void  clickonExamptReCycle() {
    	 driver.findElement(btn_ExamptRecycle).click();
     }
     public String getSucessnewqueue() {
    	 String Message =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(txt_SuccessMessage)).getText(); 
     return Message;
     }
    public void clickSelectColumn() throws InterruptedException {
    	 driver.findElement(selectColumn).click();
    	 Thread.sleep(3000);
    WebElement	serchcolu= driver.findElement(By.xpath("//app-query-builder/div/div/div[2]/div[1]/p-dropdown/div/div[3]/div[1]/div/input"));
    serchcolu.sendKeys("partner");
    //	 wait.until(ExpectedConditions.elementToBeClickable(selectColumnValue));
    	 WebElement column =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(selectColumnValue));
    	 js.executeScript("arguments[0].click();",column);
    }
    public void clickonoperator() throws InterruptedException {
    	Thread.sleep(3000);
    	 driver.findElement(selectoperator).click();
    	 WebElement operator =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(selectOperatorValue));	
    	 js.executeScript("arguments[0].click();",operator);
    }
    public void getValueinQueryBulider() throws InterruptedException {
    	Thread.sleep(3000);
    	driver.findElement(txt_ValueinQuerybulider).sendKeys("CMS");;	
    }
    
    public void clickonApplyFilter() {
    	driver.findElement(btn_applyFilter).click();	
    }
    public void clickOnSavebtnNewq() throws InterruptedException {
    	Thread.sleep(2000);
    	driver.findElement(btn_saveNewQueue).click();	
    }
     public WebElement clickonSelectDateType() {
    	 WebElement DateType=driver.findElement(selectDateType);
    	 DateType.click();
    	 return DateType;
     }
     public WebElement clickonSelectDateTypeasDateofService() throws InterruptedException {
    	 Thread.sleep(2000);
    	 WebElement dtofServc= driver.findElement(selectDateofService);
    	 dtofServc.click();
    	 return dtofServc;
     }
    public WebElement clickonSelectDateTypeasErrordate() {
    	WebElement erDate= driver.findElement(selectErrorDate);
    	erDate.click();
    	return erDate;
    }
    public void clickonSelectDateTypeasPaiddate() {
   	 driver.findElement(selectpaidDate).click();
   }
    public void clickonSelectDateTypeasReceviedate() {
      	 driver.findElement(selectReceviedDate).click();
      }
    public WebElement selectEsclationQueue() throws InterruptedException {
   	 	
   	 WebElement EsclationQueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(rbtn_EsclationQueue));
   	// regularqueue.click();
   	 js.executeScript("arguments[0].click();",EsclationQueue);
   	 WebElement ContactownerQueuefrmEsclation =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(select_ContactownerQueue));
   	 js.executeScript("arguments[0].click();",ContactownerQueuefrmEsclation);
   	 //select from Dropdown of contract queue
   	 Thread.sleep(2000);
   	driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[1]/div[2]/div[2]/div/p-dropdown/div/div[3]/div/ul/p-dropdownitem[3]/li/span")).click();
  
   	WebElement ContactownerQueuefrmEsclationtxt=new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[1]/div[2]/div[2]/div/p-dropdown/div")));
   	return ContactownerQueuefrmEsclationtxt;
    }
    
    public WebElement selectCatchallQueue() {

     	 WebElement Catchallqueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(rbtn_catchallQueue));
     	 js.executeScript("arguments[0].click();",Catchallqueue);
     	 WebElement EscalationQueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(select_EscalationQueue));
       	 js.executeScript("arguments[0].click();",EscalationQueue);
       	 //select from Dropdown of escalation queue
       	driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[1]/div[2]/div[1]/div/p-dropdown/div/div[3]/div/ul/p-dropdownitem[2]/li/span")).click();
		
        WebElement ContactownerQueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[1]/div[2]/div[2]/div/p-dropdown/div")));
      	 return ContactownerQueue;
     	 
    }
    public void selectContractownerQueue() throws InterruptedException {
   	 	
      	 WebElement ContractownerQueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(rbtn_contractownerQueue));
      	// regularqueue.click();
      	 js.executeScript("arguments[0].click();",ContractownerQueue);
      	
       }
    public WebElement clickonRegularQueue() {
    	 WebElement regularqueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(rbtn_RegularQueue));
     	 regularqueue.click();
    	 return regularqueue;
    }
    public WebElement selectEscalationQueuefrmRegularQueue() throws InterruptedException {
    	Thread.sleep(3000);
   	 WebElement esclation =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(select_EscalationQueue));
    	// regularqueue.click();
   	// js.executeScript("arguments[0].click();",esclation);
	 //select from Dropdown of esclation queue
	// driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[1]/div[2]/div[1]/div/p-dropdown/div/div[3]/div/ul/p-dropdownitem[2]/li/span")).click();
		
   	 return esclation;
   }
    public WebElement selectcontractownerQfrmRegulaQ() throws InterruptedException {
    	Thread.sleep(3000);
    	 WebElement ContactownerQueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(select_ContactownerQueue));
       	 return ContactownerQueue;
    }
    
    
     public void selectRegularQueue() throws InterruptedException {
    	 
    	
    	 WebElement regularqueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(rbtn_RegularQueue));
    	// regularqueue.click();
    	 js.executeScript("arguments[0].click();",regularqueue);
    	 
    	 WebElement esclation =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(select_EscalationQueue));
    	 js.executeScript("arguments[0].click();",esclation);
    	 //select from Dropdown of esclation queue
    	 driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[1]/div[2]/div[1]/div/p-dropdown/div/div[3]/div/ul/p-dropdownitem[2]/li/span")).click();
 		
     }
     public WebElement getTxtofNotificationforEscalation() {
    	 WebElement NotificationforEscalation =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(btn_NotificationforEscalation));
    	 return NotificationforEscalation;
    }
     public WebElement getTxtofExamptRecyl() {
    	 WebElement ExamptRecycle =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(btn_ExamptRecycle));
    	 return ExamptRecycle;
    }
     public WebElement getTxtofradiobtnCatchallQ() {
    	 WebElement Catchallqueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(rbtn_catchallQueue));
    	 return Catchallqueue;
    }
     
     public WebElement getTxtofradiobtnContractQ() {
    	 WebElement ContractownerQueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(rbtn_contractownerQueue));
       
    	 return ContractownerQueue;
    }
    public WebElement getTxtofradiobtnregluarQ() {
    	 WebElement regularqueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(rbtn_RegularQueue));
    	// return regularqueue.getText();
    	 return regularqueue;
    }
    public WebElement getTxtofradiobtnEscalationQ() {
    	 WebElement EsclationQueue =new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(rbtn_EsclationQueue));
   	 return EsclationQueue;
   }

     public String inputForNewQueueName(String QueueName) throws InterruptedException {
    	 Thread.sleep(3000);
    	// wait.until(ExpectedConditions.elementToBeClickable(txt_NewQueue));
 		driver.findElement(txt_NewQueue).sendKeys(QueueName);
 		return QueueName.trim().toLowerCase();
 		
     }
     public String inptnewQDescription(String QueueDescription) throws InterruptedException {
    	 Thread.sleep(3000);
    	// wait.until(ExpectedConditions.elementToBeClickable(txt_NewQueueDescription));
  		driver.findElement(txt_NewQueueDescription).sendKeys(QueueDescription);
  		return QueueDescription;
     }
     public WebElement inptnewQDescriptioneditble() {
   WebElement description= 	 driver.findElement(txt_NewQueueDescription);
  return description;
     }
     public String gettooltipRegularQueue() {
    	 
    	 WebElement tooltipRegularQueue=driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/span"));
		 
		  action.clickAndHold(tooltipRegularQueue).perform();
		  
	      String tooltiptextRegularQueue=tooltipRegularQueue.getAttribute("title");
	      return tooltiptextRegularQueue;

     }
     public String sepllcheckValidationinDescription() {
    		WebElement Descripion=driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[4]/textarea"));
		     String Flag=Descripion.getAttribute("spellcheck");
		     System.out.println(Flag);
		     return Flag;
     }
     public String gettooltipEscalationQueue() {
    	 WebElement tooltipEscalationQueue=driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[1]/div[1]/div[2]/span/span"));
		 
		  action.clickAndHold(tooltipEscalationQueue).perform();
		  
	      String tooltiptextEscalationQueue=tooltipEscalationQueue.getAttribute("title");
	      return tooltiptextEscalationQueue;
     }
     
     public String  getPageTitleAfterClickonAddNewQueue() {
    	 return driver.findElement(label_pageTitleAddNewQueuepage).getText();
     }
     
	public String getPageHeader_ManageQueues()
	{
		return driver.findElement(label_pageTitleMangequeues).getText();
	}
	public String getbreadcrumbTitle_ManageQueues()
	{
		return driver.findElement(label_breadcrumbTitle).getText();

	}
	public String getPageHeaderAfterClickonViewUser() {
		return driver.findElement(label_pageTitleafterClickOnViewUser).getText();
	}
	public String getbreadcrumbTitleafterclickOnViewUser() {
	String	breadcrumbTitle=driver.findElement(label_breadcrumbTitleAfterclickonViewuser).getText();
	return breadcrumbTitle;
	}
	public void clickOnViewUserFunctionality() {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//wait.until(ExpectedConditions.elementToBeClickable(btn_expriedQueue_Copy));	
		js.executeScript("arguments[0].scrollIntoView();",  driver.findElement(btn_ViewUserFunctionality));
		  driver.findElement(btn_ViewUserFunctionality).click();
	}
	
	public void clickonSortingIcon_ManageQueues() throws InterruptedException
	{
		Thread.sleep(5000);
	 driver.findElement(btn_sortinginMainTable).click();

	}
	public List<String> getQueuePropertyList() {
		
		     List<String> QueuePropertyList = new ArrayList<String>();
		 //    Boolean flag = true;
		     
		  	System.out.println("3");
		     
		     rows=webtable.findElements(By.tagName("tr"));
		     
		    System.out.println("No of rows on Manage Queues table->"+ rows.size());
         
		    
		    int ActiveQueueCount=0;
			 
			for(int j=0;j<rows.size();j++) 
			   {
					cols=rows.get(j).findElements(By.tagName("td"));
					
					if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
				     { 
				     String QueueProperties=cols.get(3).getText();
					  
					  QueuePropertyList.add(QueueProperties);
					  ActiveQueueCount++;
				     }
					}
			
			System.out.println("No of Elements in list->"+ActiveQueueCount);
			System.out.println("No of Elements in list->"+QueuePropertyList.size());
			
		return QueuePropertyList;
				
				
			}
	public List<Boolean> getExpriedQueueslist_Actionverification() throws InterruptedException {
	
	     List<String> AttributeList = new ArrayList<String>();
	     Boolean flag1 = false;
	     Boolean flag2 = true;
	     WebElement CopyAction,ViewAction,ViewUsersAction,ViewClaimsAction;
	  	System.out.println("3");
	     
	     rows=webtable.findElements(By.tagName("tr"));
	     
	    System.out.println("No of rows on Manage Queues table->"+ rows.size());
      
		 
		for(int j=0;j<rows.size();j++) 
		   {
				cols=rows.get(j).findElements(By.tagName("td"));
				
				if(rows.get(j).getAttribute("class").equals("hasExpired ng-star-inserted"))
			     { 
			      String xpathexpCopy="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[1]";
			      String xpathexpView="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[2]";
			      String xpathexpViewUsers="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[3]";
			      String xpathexpViewClaims="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[3]";
			      
			      Thread.sleep(4000);
			      
			      CopyAction=new WebDriverWait(driver,20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathexpCopy)));
			      ViewAction=new WebDriverWait(driver,20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathexpView)));
			      ViewUsersAction=new WebDriverWait(driver,20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathexpViewUsers)));
			      ViewClaimsAction=new WebDriverWait(driver,20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpathexpViewClaims)));
			      
			      
				  flag1=CopyAction.getAttribute("class").contains("viewDisable") && ViewAction.getAttribute("class").contains("viewDisable"); 
				  System.out.println("flag1 for row no "+(j+1)+"->"+flag1);
				  
				  flag2=ViewUsersAction.getAttribute("class").contains("viewDisable") && ViewClaimsAction.getAttribute("class").contains("viewDisable"); 
				  System.out.println("flag2 for row no "+(j+1)+"->"+flag2);
				  
				  if(flag1.equals(true) && flag2.equals(false))
				  {
				  break;
				  }
				
			     }
				}
		  List<Boolean> FlaglistList = new ArrayList<Boolean>();
		  FlaglistList.add(flag1);
		  FlaglistList.add(flag2);
		  	return FlaglistList;
		
		
		
	}
	
	public List<String> expriedlistwithQueueName() throws InterruptedException {
		 Thread.sleep(2000);
		     List<String> ExpiredQueuenameList_UI = new ArrayList<String>();
		     
		     WebElement CopyAction;
		  	System.out.println("3");
		     
		     rows=webtable.findElements(By.tagName("tr"));
		 
		    System.out.println("No of rows on Manage Queues table->"+ rows.size());
		    
		    int ExpiredQueueCount_UI=0;
      
		    for(int j=0;j<rows.size();j++)
		    {
		    cols=rows.get(j).findElements(By.tagName("td"));
		       
		    if(rows.get(j).getAttribute("class").equals("hasExpired ng-star-inserted"))
		     { 
		    String ExpiredQueuename=cols.get(2).getText().trim().toLowerCase();
			//System.out.println(ExpiredQueuename);
			ExpiredQueuenameList_UI.add(ExpiredQueuename);
		    ExpiredQueueCount_UI++;
		   
		     }	
		    }
		    System.out.println("No of Expired queues present on UI->"+ExpiredQueueCount_UI); 
		    System.out.println(ExpiredQueuenameList_UI);
		    return ExpiredQueuenameList_UI;
		 
		    
	}
		 
		public void clikonCopybtninExpriedQueue() {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			//wait.until(ExpectedConditions.elementToBeClickable(btn_expriedQueue_Copy));	
			js.executeScript("arguments[0].scrollIntoView();",  driver.findElement(btn_expriedQueue_Copy));
			  driver.findElement(btn_expriedQueue_Copy).click(); 
		}
		public String getSuccesMessageUpdateQ() {
			String Message=new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Queue has been updated successfully')]"))).getText();
			
			System.out.println(Message);
			return Message;
		}
		  public String getSuccessMessage(String action) throws InterruptedException {
			  Thread.sleep(5000);
			  if(action.equalsIgnoreCase("new"))
				{
				  label_successMsg=By.xpath("//app-queue/p-toast[1]/div/p-toastitem/div/div/div/div[2]");
				}else if(action.equalsIgnoreCase("update"))
				{
					label_successMsg=(By) new WebDriverWait(driver, 5).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Queue has been updated successfully!')]")));
				}
				String Message=driver.findElement(label_successMsg).getText();
			
				System.out.println(Message);
				return Message;
			}
		  
		  public String   pageTitleafterclickoncopy() {
			  
			  String pageTitleCopy= driver.findElement(label_pageTitleafterclickoncopy).getText();
		  
			  return pageTitleCopy;
		  }
			  
			  
		  public void UpdateQueuefromCopyfunctionality(String UpdatedQueuename) {
				
//					wait.until(ExpectedConditions.elementToBeClickable(btn_expriedQueue_Copy));		  
//					  driver.findElement(btn_expriedQueue_Copy).click(); 
					//  driver.findElement(label_pageTitleafterclickoncopy).getText();
					 
					  driver.findElement(txt_updateQueueNameinCopyFunctionality).clear();
					driver.findElement(txt_updateQueueNameinCopyFunctionality).sendKeys(UpdatedQueuename);;
					
						 System.out.println("Queuenamegiven on the page is ->"+UpdatedQueuename);
				
			}
		    
	public void UpdateexpriedQueuefromCopyfunctionality(String UpdatedQueuename) {
		try{
//			wait.until(ExpectedConditions.elementToBeClickable(btn_expriedQueue_Copy));		  
//			  driver.findElement(btn_expriedQueue_Copy).click(); 
			//  driver.findElement(label_pageTitleafterclickoncopy).getText();
			 
			  driver.findElement(txt_updateQueueNameinCopyFunctionality).clear();
			driver.findElement(txt_updateQueueNameinCopyFunctionality).sendKeys(UpdatedQueuename);;
			
				 System.out.println("Queuenamegiven on the page is ->"+UpdatedQueuename);
		
	}
		catch(Exception e)
		{
			System.out.println("expried Queue is not present");
		}
		
	}
		
	public void clickonSavebtnupdatequeuefromcopy() {
		  driver.findElement(btn_saveintxt_updateQueueNameinCopyFunctionality).click(); 
	}
	
	public List<String> getQueueNamefromMainTable() {

		
		   List<String> QueuenameList_UI = new ArrayList<String>();
		     
		     WebElement CopyAction;
		  	System.out.println("3");
		     
		     rows=webtable.findElements(By.tagName("tr"));
		     		 
		    System.out.println("No of rows on Manage Queues table->"+ rows.size());
		    
		    int QueueCount_UI=0;
    
		    for(int j=0;j<rows.size();j++)
		    {
		    cols=rows.get(j).findElements(By.tagName("td"));
		       
		    if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
		     { 
		    String Queuename=cols.get(2).getText().trim().toLowerCase();
		   
			//System.out.println(ExpiredQueuename);
			QueuenameList_UI.add(Queuename);
		    QueueCount_UI++;
		   
		     }	
		    }
		    System.out.println("No of Expired queues present on UI->"+QueueCount_UI); 
		    System.out.println(QueuenameList_UI);
		    return QueuenameList_UI;
		  }
	public List<String> getQueuelistinUIAfterSorting() {
		 List<String> ActiveQueueList2 = new ArrayList<String>();
		 List<WebElement> rows2;
	     List<WebElement> cols2 = null;
	     rows2=webtable.findElements(By.tagName("tr"));
	     for(int j=0;j<rows2.size();j++) 
		   {
				cols2=rows2.get(j).findElements(By.tagName("td"));
				
				
				if(rows2.get(j).getAttribute("class").equals("ng-star-inserted"))
			     { 
				
				String Queuename=cols2.get(2).getText().toLowerCase();
			    System.out.println(Queuename);
			    ActiveQueueList2.add(Queuename);
		
			     }
				}
		
		return ActiveQueueList2;
	}
	
	public void clickOnExpriedQueueViewIcon() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();",  driver.findElement(btn_ExpriedQueueView));
		  driver.findElement(btn_ExpriedQueueView).click(); 
	}
		
		public String getlabelofExpriedQueueViewpage() {
			 String PageTitle=driver.findElement(By.xpath("//h3[contains(text(),'View Queue')]")).getText();
			 return PageTitle;
			 
		}
		
	public String verifyQueuePropertiesinUI() {
		 WebElement CopyAction;
		  	
		     
		 rows=webtable.findElements(By.xpath("//tr[2]"));
		 
		    System.out.println("No of rows on Manage Queues table->"+ rows.size());
		    
		  
		    String QueueName_UI = null,QueueProperty_UI = null,QueueAttribute_UI = null;
      
		    for(int j=0;j<rows.size();j++)
		    {
		    cols=rows.get(j).findElements(By.tagName("td"));
		       
		    if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
		     { 
		    	QueueName_UI=cols.get(2).getText().trim();
		   
		    	QueueProperty_UI=cols.get(3).getText().trim();
		    
		        QueueAttribute_UI=cols.get(4).getText().trim();
			
			
		    break;
		     }
		    }
		   
		    System.out.println("Selected Expired Queue Property on UI->"+QueueProperty_UI);
		    
		    return QueueProperty_UI;
	}
	public String getQueueAttribute_UI() throws InterruptedException {
		 rows=webtable.findElements(By.xpath("//tr[2]"));
		 
		    System.out.println("No of rows on Manage Queues table->"+ rows.size());
		    
		  Thread.sleep(5000);
		    String QueueName_UI = null,QueueProperty_UI = null,QueueAttribute_UI = null;
   
		    for(int j=0;j<rows.size();j++)
		    {
		    cols=rows.get(j).findElements(By.tagName("td"));
		       
		    if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
		     { 
		    	QueueName_UI=cols.get(2).getText().trim(); 
		        QueueAttribute_UI=cols.get(4).getText().trim();
			
			
		    break;
		     }
		    }
		    return QueueAttribute_UI;
		
	}
	public String getQueueName_UI() {
		 rows=webtable.findElements(By.xpath("//tr[2]"));
		 
		    System.out.println("No of rows on Manage Queues table->"+ rows.size());
		    
		  
		    String QueueName_UI = null,QueueProperty_UI = null,QueueAttribute_UI = null;
  
		    for(int j=0;j<rows.size();j++)
		    {
		    cols=rows.get(j).findElements(By.tagName("td"));
		       
		    if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
		     { 
		    	QueueName_UI=cols.get(2).getText().trim(); 
		        QueueAttribute_UI=cols.get(4).getText().trim();
			
			
		    break;
		     }
		    }
		    return QueueName_UI;
	}
	public List<String> getqueuepropertiesaftersorting() {
		List<String> QueuePropertyList = new ArrayList<String>();
	     Boolean flag = true;
	     
	  	System.out.println("3");
	     
	     rows=webtable.findElements(By.tagName("tr"));
	     
	    System.out.println("No of rows on Manage Queues table->"+ rows.size());
     
	    
	    int ActiveQueueCount=0;
		 
		for(int j=0;j<rows.size();j++) 
		   {
				cols=rows.get(j).findElements(By.tagName("td"));
				
				if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
			     { 
			     String QueueProperties=cols.get(3).getText();
				  System.out.println(QueueProperties);
				  QueuePropertyList.add(QueueProperties);
				  ActiveQueueCount++;
			     }
				}
		return QueuePropertyList;
	}
public List<String> getAttributelist() {
	rows=webtable.findElements(By.tagName("tr"));
    
	 System.out.println("No of rows on Manage Queues Table->"+ rows.size());
     
    
    List<String> ActiveQueueAttributeList1 = new ArrayList<String>();
	 
    for(int j=0;j<rows.size();j++) 
	   {
			cols=rows.get(j).findElements(By.tagName("td"));
			
			
			if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
		     { 
			
			String QueueAttribute=cols.get(4).getText();
		    System.out.println(QueueAttribute);
		    ActiveQueueAttributeList1.add(QueueAttribute);
			
			
		     }
			}
    return ActiveQueueAttributeList1;
 }
public List<String> getAttributelistAftersorting() {
	 rows=webtable.findElements(By.tagName("tr"));
	  	System.out.println("3");
	     
	  	List<String> ActiveQueueAttributeList2 = new ArrayList<String>();
	    
	    int ActiveGroupCount=0;
		 
		for(int j=0;j<rows.size();j++) 
		   {
				cols=rows.get(j).findElements(By.tagName("td"));
				
				
				if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
			     { 
				
				String QueueAttribute=cols.get(4).getText();
			    System.out.println(QueueAttribute);
			    ActiveQueueAttributeList2.add(QueueAttribute);
				ActiveGroupCount++;
				
			     }
				}
		return ActiveQueueAttributeList2;
}
public void SerchQueueforViewUsers(String SelectedQueue) throws InterruptedException {
	WebElement Searchwordbox= driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[1]/div/div[2]/div/div/input"));
	  Searchwordbox.sendKeys(SelectedQueue);
	  List<WebElement> serachResult_rows=driver.findElements(By.xpath("//app-queue/div/div[2]/div/div[2]/div/p-table/div/div/div/div[2]/table/tbody/tr"));
	  
      System.out.println("No of Search Result->"+serachResult_rows.size());
      
      //System.out.println(serachResult_rows.get(0).getText().trim());
		
      Thread.sleep(5000);
      for(int j=0;j<serachResult_rows.size();j++)
	   {
		   String xpathexp_Queuename="//app-queue/div/div[2]/div/div[2]/div/p-table/div/div/div/div[2]/table/tbody/tr/td[3]";
		   String xpathexp_Viewusers="//p-table/div/div/div/div[2]/table/tbody/tr/td[6]/div/a[3]";
		
	  if((driver.findElement(By.xpath(xpathexp_Queuename)).getText().equalsIgnoreCase(SelectedQueue)))
		        {
		  Thread.sleep(5000);
			       driver.findElement(By.xpath(xpathexp_Viewusers)).click();
			     
			        break;
			 }
	   
		   
	   }
     
}

public List<String> getuserslistfromUserProfile() throws InterruptedException {
	  Thread.sleep(5000);
	WebElement webtable=driver.findElement(By.xpath("//app-user-profile/div/div[2]/div/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody"));
    
    List<WebElement> rows_userProfile;
    List<WebElement> cols_userProfile = null;
    List<String> QueueUsersList_UI = new ArrayList<String>();
    

 	System.out.println("3");
    
 	rows_userProfile=webtable.findElements(By.tagName("tr"));

   System.out.println("No of rows on User Profile  table->"+ rows_userProfile.size());
   
 Thread.sleep(5000);

   for(int j=0;j<rows_userProfile.size();j++)
   {
   	cols_userProfile=rows_userProfile.get(j).findElements(By.tagName("td"));
        String QueueUserID_UI=cols_userProfile.get(5).getText().trim();
        System.out.println(QueueUserID_UI);
        QueueUsersList_UI.add(QueueUserID_UI.trim());
	
        System.out.println(QueueUsersList_UI);
   }
   return QueueUsersList_UI;

}
public String gettargetRowTxtBeforeSave(String target) {
	 WebElement rowPriority=driver.findElement(By.xpath("//tbody/tr["+target+"]/td[1]/div[1]/input[1]"));
    
     String RowtextbeforeSave=driver.findElement(By.xpath("//tbody/tr["+target+"]")).getText();

		//  System.out.println(" row text after Dragging 2nd row to 1st row and  before clicking Save button->"+RowtextbeforeSave);
     
   //  System.out.println(" row Priority after Dragging 2nd row to 1st row and  before clicking Save button->"+rowPriority.getAttribute("value"));
    return RowtextbeforeSave;
	
}
public String getSourceRowTxtBeforeSave(String source) {
	
    WebElement rowPriority=driver.findElement(By.xpath("//tbody/tr["+source+"]/td[1]/div[1]/input[1]"));
    String RowtextbeforeSave=driver.findElement(By.xpath("//tbody/tr["+source+"]")).getText();
    //source row txt
  
    //System.out.println("Second row text after Dragging 2nd row to 1st row and  before clicking Save button->"+RowtextbeforeSave);
    
  //  System.out.println("Second row Priority after Dragging 2nd row to 1st row and  before clicking Save button->"+rowPriority.getAttribute("value"));
  
	return RowtextbeforeSave;
}
public void QueueprirorityDragandDrop(String source,String target) throws InterruptedException {
	  //Dragging 2nd row into 1st row
	Thread.sleep(5000);
    WebElement source1=driver.findElement(By.xpath("//*[@id='"+source+"']/img"));
    WebElement target1=driver.findElement(By.xpath("//*[@id='"+target+"']/img"));
    
    String java_script1 =
            "var src=arguments[0],tgt=arguments[1];var dataTransfer={dropEffe" +
            "ct:'',effectAllowed:'all',files:[],items:{},types:[],setData:fun" +
            "ction(format,data){this.items[format]=data;this.types.append(for" +
            "mat);},getData:function(format){return this.items[format];},clea" +
            "rData:function(format){}};var emit=function(event,target){var ev" +
            "t=document.createEvent('Event');evt.initEvent(event,true,false);" +
            "evt.dataTransfer=dataTransfer;target.dispatchEvent(evt);};emit('" +
            "dragstart',src);emit('dragenter',tgt);emit('dragover',tgt);emit(" +
            "'drop',tgt);emit('dragend',src);";
    JavascriptExecutor js1 = (JavascriptExecutor) driver;
    js1.executeScript(java_script1, source1, target1);
     
    // wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Save')]//parent::button[1]")));
    WebElement Savebtn = driver.findElement(By.xpath("//span[contains(text(),'Save')]//parent::button[1]"));

    Actions act = new Actions(driver);

    

    //Double click on element
   // WebElement ele =Savebtn 
    act.moveToElement(Savebtn).build().perform();
   // act.click(ele).perform();
    act.doubleClick(Savebtn).perform();
	 //js.executeScript("arguments[0].click();",Savebtn);
	// js.executeScript("arguments[0].click();",Savebtn);
	 System.out.println(Savebtn.getText());
    
    
}
public String getqueuepriorityUpdatemessage() throws InterruptedException {
	//Thread.sleep(3000);
	//div[contains(text(),'Queue Priority has been updated successfully!')]
	WebDriverWait wait=new WebDriverWait(driver,5);
	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Queue Priority has been updated successfully!')]")));
	 WebElement SuccessMessage = driver.findElement(By.xpath("//div[contains(text(),'Queue Priority has been updated successfully!')]"));
	return SuccessMessage.getText();
}
public void getSavebtnfunctioninpage() throws InterruptedException {
	  WebElement FirstrowPriority=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]"));
       WebElement SecondrowPriority=driver.findElement(By.xpath("//tbody/tr[2]/td[1]/div[1]/input[1]"));
       
       FirstrowPriority.clear();
       FirstrowPriority.sendKeys("2");
       
       String FirstRowtextbeforeSave=driver.findElement(By.xpath("//tbody/tr[1]")).getText();
       System.out.println("First row text after changing prirority to 2 and before clicking Save button->"+FirstRowtextbeforeSave);
        
       SecondrowPriority.clear();
       SecondrowPriority.sendKeys("1");
       
       String SecondRowtextbeforeSave=driver.findElement(By.xpath("//tbody/tr[2]")).getText();
       System.out.println("Second row text after changing prirority to 1 and before clicking Save button->"+SecondRowtextbeforeSave);
        
     
     //  Now click on Save Button
		 
		driver.findElement(By.xpath("//span[contains(text(),'Save')]")).click();
		
	
	    driver.switchTo().defaultContent();
	    
	    Thread.sleep(3000);
	 	  
	    String Message=driver.findElement(By.xpath("//div[contains(text(),'has been updated successfully!')]")).getText();
	
	     System.out.println(Message);
	     
	     driver.findElement(By.xpath("//div[contains(text(),'has been updated successfully!')]")).click();
	     
	     driver.switchTo().defaultContent();
	     
	     WebElement FirstrowPriority1=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]"));
       WebElement SecondrowPriority1=driver.findElement(By.xpath("//tbody/tr[2]/td[1]/div[1]/input[1]"));
       
	     
	     System.out.println(FirstrowPriority1.getAttribute("value"));
	     System.out.println(SecondrowPriority1.getAttribute("value"));
	     
	     String FirstRowtextafterSave=driver.findElement(By.xpath("//tbody/tr[1]")).getText();
       System.out.println("First row text after clicking Save button->"+FirstRowtextafterSave);
        
       String SecondRowtextafterSave=driver.findElement(By.xpath("//tbody/tr[2]")).getText();
       System.out.println("Second row text after clicking Save button->"+SecondRowtextafterSave);
	       
  try{  
 
		
     SoftAssert softAssert = new SoftAssert();
     
     softAssert.assertTrue(Message.contains("has been updated successfully"), "Message not coming for save button");
     softAssert.assertTrue((FirstrowPriority1.getAttribute("value")).equals("1")&& (SecondrowPriority1.getAttribute("value")).equals("2") , "Priority not getting rearraged after Clicking Save Button");
     softAssert.assertTrue(FirstRowtextbeforeSave.equals(SecondRowtextafterSave)&& SecondRowtextbeforeSave.equals(FirstRowtextafterSave) , "Save Button functionality not working properly");
          softAssert.assertAll();
		        }
		   
catch(Throwable e)
		     {
			   
				  Assert.fail(e.getMessage());
				     
			   
		      }}



public void Resetfunctionalityinpage() throws InterruptedException {
	 WebElement FirstrowPriority=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]"));
     WebElement SecondrowPriority=driver.findElement(By.xpath("//tbody/tr[2]/td[1]/div[1]/input[1]"));
     
     FirstrowPriority.clear();
     FirstrowPriority.sendKeys("2");
     
     String FirstRowtextbeforeReset=driver.findElement(By.xpath("//tbody/tr[1]")).getText();
     System.out.println("First row text after changing prirority to 2 and before clicking Reset button->"+FirstRowtextbeforeReset);
      
     String SecondRowtextbeforeReset=driver.findElement(By.xpath("//tbody/tr[2]")).getText();
     System.out.println("Second row text after changing prirority to 1 and before clicking Reset button->"+SecondRowtextbeforeReset);
      
   
     SecondrowPriority.clear();
     SecondrowPriority.sendKeys("1");
   
   //  Now click on Reset Button
	 
	driver.findElement(By.xpath("//span[contains(text(),'Reset')]")).click();
	
    Thread.sleep(3000);
 	  
   
    WebElement FirstrowPriority1=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]"));
     WebElement SecondrowPriority1=driver.findElement(By.xpath("//tbody/tr[2]/td[1]/div[1]/input[1]"));
    System.out.println(FirstrowPriority1.getAttribute("value"));
  
     System.out.println(SecondrowPriority1.getAttribute("value"));
     
     String FirstRowtextafterReset=driver.findElement(By.xpath("//tbody/tr[1]")).getText();
     System.out.println("First row text after clicking Save button->"+FirstRowtextafterReset);
      
     String SecondRowtextafterReset=driver.findElement(By.xpath("//tbody/tr[2]")).getText();
     System.out.println("Second row text after clicking Save button->"+SecondRowtextafterReset);

try{  

	
   SoftAssert softAssert = new SoftAssert();
   
 
   softAssert.assertTrue((FirstrowPriority1.getAttribute("value")).equals("1")&& (SecondrowPriority1.getAttribute("value")).equals("2") , "Priority not getting rearraged after Clicking Save Button");
   softAssert.assertTrue(FirstRowtextbeforeReset.equals(FirstRowtextafterReset)&& SecondRowtextbeforeReset.equals(SecondRowtextafterReset) , "Reset Button functionality not working properly");
        softAssert.assertAll();
	     
	        }
	   
catch(Throwable e)
	     {
		   System.out.println("TC010_manageQueues Failed");
	
			  Assert.fail(e.getMessage());
			     
		   
	      }
}

	
}

	


