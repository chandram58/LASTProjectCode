package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import base.base;

public class MaintainErrorCodePage extends base{
	By addnewerrcode=By.xpath("//span[contains(text(),'Add New Error Code')]");
	By newpageTilt=By.xpath("//h3[contains(text(),'New Error Code')]");
	By TPDd=By.xpath("//span[contains(text(),'Select Trading Partner')]");
	By addTP=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[2]/div/p-dropdown/div/div[3]/div[1]/a");
	By slectTPdd=By.xpath("//*[@id=\"partnerDetails0\"]/div/div[2]/div");
	By TxtTPSearch=By.xpath("//app-error-code[1]/div[2]/form[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/p-multiselect[1]/div[1]/div[4]/div[1]/div[2]/input[1]");
	By txt_TP=By.xpath("//app-error-code[1]/div[2]/form[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/p-multiselect[1]/div[1]/div[4]/div[2]/ul[1]/p-multiselectitem[1]/li[1]");
	By severityDP=By.xpath("//*[@id=\"viewAddEditSection\"]/div/div/div/div/div/div[2]/div[2]/p-dropdown/div/span");
	By slctSeverity=By.xpath("//span[contains(text(),'Informational')]");
	By errorcodename=By.xpath("//input[@id='errorCodeName']");
	By errorTypeDP=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[3]/div/div[1]/p-dropdown/div/span");
	By selctErrortypedp=By.xpath("//span[contains(text(),'Business Rules')]");
    By btn_save=By.xpath("//span[contains(text(),'Save')]//parent::button");
    By serchbtninmain=By.xpath("//app-error-code/div/div[1]/div/div[2]/div/div/input");
    By webTablerow=By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody/tr");
    By errorcodesnotes=By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody/tr/td[4]");
    
    
    Actions action = new Actions(driver);
    public List<String> geterrorcodefromTable() {
    	
    		int rowSize=driver.findElements(webTablerow).size();
    		String endDate;
    		List<String> activeeerorcodelist = new ArrayList<String>();
    		for(int i=1;i<=rowSize;i++)
    		{
    			errorcodesnotes=By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody/tr/td[4]");
    			
    			endDate=driver.findElement(errorcodesnotes).getText().trim();
    			System.out.println("EndDate in Row"+i+"="+endDate);
    			activeeerorcodelist.add(endDate);
    		}
    		return activeeerorcodelist;

    	}
    public List<String> geterrorcodeTPfrmtable() throws InterruptedException {
    	Thread.sleep(2000);
		int rowSize=driver.findElements(webTablerow).size();
		String endDate;
		List<String> activeeerorcodelistTP = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
		By	errorcodesTP=By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody/tr/td[2]");
			Thread.sleep(4000);
		String	TP=driver.findElement(errorcodesTP).getText().trim();
			System.out.println("EndDate in Row"+i+"="+TP);
			activeeerorcodelistTP.add(TP);
		}
		return activeeerorcodelistTP;

	}

    
    public void SerachErrorcode(String ErrorCode) throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/span[1]/p-paginator/div/span/button[3]")).click();
		Thread.sleep(1000);
		 driver.findElement(serchbtninmain).sendKeys(ErrorCode);
	}
    public void clickonSaveBTn() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(btn_save).click();
	}
	public void selectErrorType(String ErrorType) throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(errorTypeDP).click();
		 driver.findElement(By.xpath("//span[contains(text(),'"+ErrorType+"')]")).click();
	}
	
	public void inputErrorCodeName(String ErrorCode) throws InterruptedException {
		Thread.sleep(2000);
		 driver.findElement(errorcodename).sendKeys(ErrorCode);;
	}
	public void clickOnBackTOerrorcodepage() throws InterruptedException {
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"viewAddEditSection\"]/a")).click();
	}
	public void selectSeverityfrmDP(String Severity) throws InterruptedException {
		Thread.sleep(1000);
		 driver.findElement(By.xpath("//span[contains(text(),'"+Severity+"')]")).click();
	}
	public void clickonSeverityDP() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(severityDP).click();
	}
	public void clickonAddNewErrorCode() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(addnewerrcode).click();
	}
	public String clickOnSelectTPDp() throws InterruptedException {
		Thread.sleep(3000);
		action.moveToElement(driver.findElement(slectTPdd)).click().perform();
		WebElement TPDP=driver.findElement(slectTPdd);
		//TPDP.click();
		return TPDP.getText();
		}
	public String clickOnSelectTPmultipleDp() throws InterruptedException {
		Thread.sleep(3000);
		action.moveToElement(driver.findElement(By.xpath("//*[@id=\"partnerDetails1\"]/div/div[2]/div"))).click().perform();
		WebElement TPDP=driver.findElement(By.xpath("//*[@id=\"partnerDetails1\"]/div/div[2]/div"));
		//TPDP.click();
		return TPDP.getText();
		}
	public String searchTPinDP(String TPName) throws InterruptedException {
		Thread.sleep(1000);
		WebElement SearchTp=driver.findElement(TxtTPSearch);
		SearchTp.sendKeys(TPName);
		
		return SearchTp.getText();
		
	}
	public void SelectTPFRMDPAfterSearch() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(txt_TP).click();
	}
	public void clickonTPDP() {
		driver.findElement(TPDd).click();
		driver.findElement(addTP).click();
		
	}
	public String getPageTitle() {
		WebElement TextEntered1=driver.findElement(newpageTilt);
		return TextEntered1.getText();
	}
	public String getNotesSection() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[contains(text(),'Notes')]")).click();
		driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]")).sendKeys("Description");
		String TextEntered1=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]")).getAttribute("value");
		System.out.println("Text entered in Description->"+TextEntered1);
		 
		return TextEntered1;
	}
  public String getDetailedNotesSection() throws InterruptedException {
	  Thread.sleep(1000);
	  driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/textarea[1]")).sendKeys("Detailed Notes");
      String TextEntered2=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/textarea[1]")).getAttribute("value");
		System.out.println("Text entered in Detailed Notes->"+TextEntered2);
		
	return TextEntered2;
}
}
