package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.base;

public class UserProfilePage extends base
{
	By title_MainPage=By.xpath("//h1[contains(text(),'User Profile')]");
	By rows_activeUserRecords=By.xpath("//table/tbody/tr[not (contains(@class,'hasExpired'))]");
	By rows_inActiveUserRecords=By.xpath("//table/tbody/tr[contains(@class,'hasExpired')]");
	By label_userName_UserList,label_humanaID_UserList;
	By btn_edit=By.xpath("//em[@class='fas fa-edit iconColor pointerAll']");

	
	
	By btn_saveUpdateone=By.xpath("//span[contains(text(),'Save')]//parent::button");
	
	By btn_ViewUser=By.xpath("//tr[contains(@class,'hasExpired ng-star-inserted')]//td[10]//a[2]");
	By iconview_expiredUser=By.xpath("//em[@class='fa fa-eye iconColor enableCopyIcon pointerAll']");
	By iconCopy_expiredUser=By.xpath("//em[@class='far fa-copy iconColor pointerAll']");
	By label_viewUser=By.xpath("//h3[contains(text(),'View User')]");
	By btn_copyUserbtn=By.xpath("//tbody/tr[66]/td[10]/div[1]/a[1]/em[1]");
	By btn_cancelViewUser=By.xpath("//span[contains(text(),'Cancel')]");
	By btn_filtersection=By.xpath("//a[contains(@class,'toggleTabContentBtn')]//em");
	By txt_roledd=By.xpath("//label[contains(text(),'Roles')]//following::p-multiselect[1]//div[1]//div[2]");
	By txt_role=By.xpath("//span[text()='Admin']");
	By btn_applyfilter=By.xpath("//span[contains(text(),'Apply Filter')]//parent::button");
	By txt_roleintable=By.xpath("//tbody//tr[contains(@class,'ng-star-inserted')]/td[7]");
	By btn_reset=By.xpath("//span[contains(text(),'Reset')]//parent::button");
	By rowsintableactive=By.xpath("//tbody//tr[contains(@class,'ng-star-inserted')]");
	By lable_copyUser=By.xpath("//h3[contains(text(),'New User')]");
	By cancel_copyuser=By.xpath("//span[contains(text(),'Cancel')]");
	By btn_searchMain=By.xpath("//input[@placeholder='Search User Profile']");
	By searchResult=By.xpath("//table/tbody/tr");
	By link_Username=By.xpath("//table/tbody/tr[1]/td[1]/div/a");
	By Title_ViewUser=By.xpath("//h3[normalize-space()='View User']");
	By clearOption_calendar=By.xpath("//span[contains(text(),'Clear')]");
	By closeicon_ViewUser=By.xpath("//em[@class='fas fa-times']");
	
	By txtbox_ErrorCode_NewCode=By.xpath("//input[@id='errorCodeName']");
	
	
	//Copy User
	
	By Title_CopyUser=By.xpath("//h3[normalize-space()='New User']");
	
	
	
	
	//Update User

	By userEndDate=By.xpath("//input[@name='userEndDate']");
	By roleEndDate=By.xpath("//tbody/tr[1]/td[3]/div[1]/p-calendar[1]/span[1]/input[1]");
	By btn_UpdateUser_Save=By.xpath("//button[@class='saveBtn saveButton p-button p-component ng-star-inserted']");
	By txt_UpdateUser_HeroAkaName=By.xpath("//input[@id='heroAkaName']");
	By label_updateuser=By.xpath("//h3[contains(text(),'Update User')]");
	By btn_Decline_Confirmpopup=By.xpath("//span[normalize-space()='Decline']");
	By btn_Accept_Confirmpopup=By.xpath("//span[normalize-space()='Accept']");
	By btn_UpdateUser_save=By.xpath("//span[contains(text(),'Save')]");
	By btn_UpdateUser_Cancel=By.xpath("//span[contains(text(),'Cancel')]");
	By txt_userRoleEndDate=By.xpath("//input[@name='userEndDate']");
	By btn_endDatAccept=By.xpath("//span[contains(text(),'Accept')]//parent::button[1]");
	By error_notNull_UserEnddate=By.xpath("//div[contains(text(),'End Date is required.')]");
	By error_notNull_RoleEnddate=By.xpath("//div[normalize-space()='End Date is required..']");
	By error_roleEndDateLessThanUserEndDate=By.xpath("//span[@title='Role end date should be lesser than user end date']");
	By searchResult_AddRoleDropdown=By.xpath("//p-multiselect[1]/div[1]/div[4]/div[2]/ul[1]/p-multiselectitem/li[1]/span[1]");
	By SelectRoleDropdown_UpdateUser=By.xpath("//div[contains(text(),'Select Roles')]");
	By Searchbox_SelectRoleDD_UpdateUser=By.xpath("//input[@placeholder='Search Roles']");
	
	JavascriptExecutor js = (JavascriptExecutor) driver;
	
	public WebElement clickonCancelCopyUser() throws InterruptedException {
		Thread.sleep(1000);
		WebElement cancel=driver.findElement(cancel_copyuser);
		 js.executeScript("arguments[0].click();",cancel);
		return cancel;
	}
	
	public WebElement getexpiredCopyPageTitle() throws InterruptedException {
		Thread.sleep(1000);
		WebElement PageTitle=driver.findElement(lable_copyUser);
		
		return PageTitle;
	}
	public void clickCopyIconExpiredUser() throws InterruptedException {
		Thread.sleep(2000);
		WebElement expireduser=driver.findElement(rows_inActiveUserRecords);
		 js.executeScript("arguments[0].scrollIntoView(true);", expireduser);
		 WebElement copy=driver.findElement(iconCopy_expiredUser);
		 js.executeScript("arguments[0].click();",copy);
		
	}
	public List<String> getRoleinWebTable() throws InterruptedException {
		
	int rows=driver.findElements(By.xpath("//table//tbody//tr[@class='ng-star-inserted']")).size();
	//System.out.println(rows);
		List<String> roleslist = new ArrayList<String>();
		for(int i=1;i<=rows;i++)
		{
			
			txt_roleintable=By.xpath("//tbody//tr[@class='ng-star-inserted']["+i+"]/td[7]");
			Thread.sleep(5000);
	String	roles=driver.findElement(txt_roleintable).getText().trim();
		//System.out.println("roles in Row"+i+"="+roles);
		roleslist.add(roles);
		}
		return roleslist;
	}
	public void clickRestButton() {
		WebElement betnRest=driver.findElement(btn_reset);
		 js.executeScript("arguments[0].click();",betnRest);
	}
	public void clickOnapplyFilter() {
		WebElement betnfltr=driver.findElement(btn_applyfilter);
		 js.executeScript("arguments[0].click();",betnfltr);
	}
	public void getroleSelect() {
		WebElement selectrole=driver.findElement(txt_role);
		 js.executeScript("arguments[0].click();",selectrole);
	}
	public void clickRolesFiled() {
		WebElement roledd=driver.findElement(txt_roledd);
		 js.executeScript("arguments[0].click();",roledd);
	}
	public void clickonFilterSection() {
		WebElement fltsection=driver.findElement(btn_filtersection);
		 js.executeScript("arguments[0].click();",fltsection);
	}
	public void clickOnCancelviewuser() {
		WebElement cancel=driver.findElement(btn_cancelViewUser);
		 js.executeScript("arguments[0].click();",cancel);
	}
	public WebElement getexpiredviewPageTitle() throws InterruptedException {
		Thread.sleep(1000);
		WebElement PageTitle=driver.findElement(label_viewUser);
		return PageTitle;
	}
	public void clickExpiredUserViewIcon() throws InterruptedException {
		 Thread.sleep(1000);
		WebElement exp=driver.findElement(iconview_expiredUser);
		 js.executeScript("arguments[0].scrollIntoView(true);", exp);
		 WebElement expriedView=driver.findElement(btn_ViewUser);
		 Thread.sleep(1000);
		 js.executeScript("arguments[0].click();",expriedView);
	}
	public void clickonEditButton() throws InterruptedException {
		Thread.sleep(1000);
		wait.until(ExpectedConditions.elementToBeClickable(btn_edit));
		WebElement edit=driver.findElement(btn_edit);
		edit.click();
	}
	public String getTitle_updatePage() throws InterruptedException {
		Thread.sleep(1000);
		String PageTitle=driver.findElement(label_updateuser).getText();
		
		return PageTitle;
	}
 public String getUserEndDate() throws InterruptedException {
	 Thread.sleep(1000);
	String endDate=driver.findElement(userEndDate).getAttribute("value");
	System.out.println("endDate->"+endDate);
	return endDate;	
 }
	
 public WebElement clickonPOPboxforAcceptEndaDate() throws InterruptedException {
	 Thread.sleep(1000);
	 WebElement Accept=driver.findElement(btn_endDatAccept);
		return Accept;
 }
  public String getRoleEndDate() throws InterruptedException {
	  Thread.sleep(1000);
		 String RoleEndDate=driver.findElement(roleEndDate).getAttribute("value");
		 System.out.println("RoleEndDate->"+RoleEndDate);
			return RoleEndDate;
  }
  public void clickOnSaveBtn() throws InterruptedException {
	  Thread.sleep(1000);
		 WebElement savebtn=driver.findElement(btn_UpdateUser_save);
		 js.executeScript("arguments[0].scrollIntoView(true);", savebtn);
		 js.executeScript("arguments[0].click();",savebtn);
		
  }
  
	public List<String> getInactiveUserNameAndUserIdasList() 
	{
		int rowSize=driver.findElements(rows_inActiveUserRecords).size();
		System.out.println("No of InActive users in UserProfile Table->"+ rowSize);
		
		List<String> InactiveUsersList = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
			label_userName_UserList=By.xpath("//table/tbody/tr[contains(@class,'hasExpired')]["+i+"]/td[1]/div/a");
			label_humanaID_UserList=By.xpath("//table/tbody/tr[contains(@class,'hasExpired')]["+i+"]/td[6]/div");
			String Username=driver.findElement(label_userName_UserList).getText();
			String HumanaId=driver.findElement(label_humanaID_UserList).getText();
			String CombFormat=Username+" ("+HumanaId+")";
			
			InactiveUsersList.add(CombFormat);
		}
		return InactiveUsersList;
		
	}
	
	//will not work
	public void setuserEndDate() throws InterruptedException {
		Thread.sleep(3000);
		driver.findElement(By.xpath("//body/div[2]/div[1]/div/div[1]/div/select[2]")).click();
		WebElement year=driver.findElement(By.xpath("//option[contains(text(),'9999')]"));
		js.executeScript("arguments[0].click();",year);
		Thread.sleep(2000);
		WebElement Month=driver.findElement(By.xpath("//option[contains(text(),'December')]"));
		js.executeScript("arguments[0].click();",Month);
		Thread.sleep(2000);
		WebElement date=driver.findElement(By.xpath("//tbody/tr[5]/td[5]/span[1]"));
		js.executeScript("arguments[0].click();",date);
				
		
	}
	
	public void clickRoleEndDate()
	{
	wait.until(ExpectedConditions.presenceOfElementLocated(roleEndDate));
	driver.findElement(roleEndDate).click();
	}
	
	public void clickUserEndDate()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(userEndDate));
		driver.findElement(userEndDate).click();
	}
	
	public List<String> getactiveUserNameAndUserIdasList() 
	{
		int rowSize=driver.findElements(rows_activeUserRecords).size();
		System.out.println("No of Active users in UserProfile Table->"+ rowSize);
		
		List<String> activeUsersList = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
			label_userName_UserList=By.xpath("//table/tbody//tr[@class='ng-star-inserted']["+i+"]/td[1]/div/a");
			label_humanaID_UserList=By.xpath("//table/tbody//tr[@class='ng-star-inserted']["+i+"]/td[6]/div");
			String Username=driver.findElement(label_userName_UserList).getText();
			String HumanaId=driver.findElement(label_humanaID_UserList).getText();
			String CombFormat=Username+" ("+HumanaId+")";
			
			activeUsersList.add(CombFormat);
		}
		return activeUsersList;
	}
	
	public List<String> getactiveUserNameList() 
	{
		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(rows_activeUserRecords));
		int rowSize=driver.findElements(rows_activeUserRecords).size();
		System.out.println("No of Active users in UserProfile Table->"+ rowSize);
		
		List<String> activeUsersList = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
			label_userName_UserList=By.xpath("//table/tbody//tr[@class='ng-star-inserted']["+i+"]/td[1]/div/a");
			
			String Username=driver.findElement(label_userName_UserList).getText();
		
					
			activeUsersList.add(Username);
		}
		return activeUsersList;
	}
	
	
	
	
	
	 public void inputCodeSerach(String ErrorCode) throws InterruptedException {
			Thread.sleep(1000);
	       driver.findElement(btn_searchMain).sendKeys(ErrorCode);
		}
	    
	public List<WebElement> getSearchResult()
    {
		List<WebElement> serachResult_rows=driver.findElements(searchResult);
		return serachResult_rows;
     }
	
	public void clickSave_UpdateUser()
	{
		driver.findElement(btn_UpdateUser_Save).click();
	}
	public void clickCancel_UpdateUser()
	{
		driver.findElement(btn_UpdateUser_Cancel).click();
	}
	
	
	public void click_Usernamelink()
	{
		wait.until(ExpectedConditions.elementToBeClickable(link_Username));
		driver.findElement(link_Username).click();
	}
	
	public String getTitle_ViewUser()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(Title_ViewUser));
		String Title=driver.findElement(Title_ViewUser).getText();

		return Title;
	}
	
	public String getTitle_MainPage()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(title_MainPage));
		String Title=driver.findElement(title_MainPage).getText();
		
		return Title;
	}
	
	public String getTitle_CopyUser()
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(Title_CopyUser));
		String Title=driver.findElement(Title_CopyUser).getText();
		return Title;
	}
	
 public void editHeroAkaName(String Text)
 {
	 driver.findElement(txt_UpdateUser_HeroAkaName).clear();
	 driver.findElement(txt_UpdateUser_HeroAkaName).sendKeys(Text);
 }
 
 
public String getHeroAkaName()	
{
String HeroAkaName=driver.findElement(txt_UpdateUser_HeroAkaName).getAttribute("value");
System.out.println("HeroAkaName->"+HeroAkaName);
return HeroAkaName;
	
}
 
public void clickDeclineBtn()
{
	driver.switchTo().defaultContent();
driver.findElement(btn_Decline_Confirmpopup).click();	
}


public void clickAcceptBtn()
{
	driver.switchTo().defaultContent();
driver.findElement(btn_Accept_Confirmpopup).click();	
}



public void clearUserEndDate_Updateuser()
{
clickUserEndDate();
driver.findElement(clearOption_calendar).click();		
}

public void clearRoleEndDate_Updateuser()
{
	clickRoleEndDate();
	driver.findElement(clearOption_calendar).click();		
}

public String getNotNullErrorUserEnddate()
{
wait.until(ExpectedConditions.presenceOfElementLocated(error_notNull_UserEnddate));
String Error=driver.findElement(error_notNull_UserEnddate).getText();
return Error;
	
}

public String getNotNullErrorRoleEnddate()
{
wait.until(ExpectedConditions.presenceOfElementLocated(error_notNull_RoleEnddate));
String Error=driver.findElement(error_notNull_RoleEnddate).getText();
return Error;
}


public String getErrorRoleEndDateLesserThanUserEndDate()
{
wait.until(ExpectedConditions.presenceOfElementLocated(error_roleEndDateLessThanUserEndDate));
String Error=driver.findElement(error_roleEndDateLessThanUserEndDate).getAttribute("title");
return Error;
}

public String[] getErrorBorderColorUserEndDate()
{
String color_BorderField_Bottom=driver.findElement(userEndDate).getCssValue("border-bottom-color");
String color_BorderField_Top=driver.findElement(userEndDate).getCssValue("border-top-color");
String color_BorderField_Left=driver.findElement(userEndDate).getCssValue("border-left-color");
String color_BorderField_Right=driver.findElement(userEndDate).getCssValue("border-right-color");

String[] color={color_BorderField_Bottom,color_BorderField_Top,color_BorderField_Left,color_BorderField_Right};
return color;

}

public String getErrorBorderColorRoleEndDate()
{
String color_BorderField=driver.findElement(roleEndDate).getCssValue("border-color");
return color_BorderField;

}

public void clickCloseIcon_ViewUser()
{
	wait.until(ExpectedConditions.presenceOfElementLocated(closeicon_ViewUser));
	driver.findElement(closeicon_ViewUser).click();
}

public void clickSelectRoleDropdown_UpdateUser()
{
	wait.until(ExpectedConditions.elementToBeClickable(SelectRoleDropdown_UpdateUser));
	driver.findElement(SelectRoleDropdown_UpdateUser).click();
}
public void enterTxtSearchbox_SelectRoleDD_UpdateUser(String txt)
{
	wait.until(ExpectedConditions.presenceOfElementLocated(SelectRoleDropdown_UpdateUser));
	driver.findElement(Searchbox_SelectRoleDD_UpdateUser).sendKeys(txt);	
}

public List<WebElement> getSearchResult_SelectRoleDD_UpdateUser()
{
	wait.until(ExpectedConditions.presenceOfElementLocated(searchResult_AddRoleDropdown));
	List<WebElement> result=driver.findElements(searchResult_AddRoleDropdown);	
	return result;
}





}
