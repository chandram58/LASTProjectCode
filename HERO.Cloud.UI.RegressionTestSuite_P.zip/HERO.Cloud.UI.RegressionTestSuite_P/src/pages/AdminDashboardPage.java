package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.base;

public class AdminDashboardPage extends base {
	By calender=By.xpath("//app-admin-dashboard/div[1]/app-filters/div/div/div[2]/div/p-calendar/span/input");
	By workitem_tdylabel=By.xpath("//app-admin-dashboard/div[2]/div/div/div[1]/div[1]/app-work-item/div/div/div[3]/p-table/div/div/div/div[1]/div/table/thead/tr[1]/th[2]");
   By  tdylabelinAck=By.xpath("//app-admin-dashboard/div[2]/div/div/div[2]/div[1]/app-ack-outbound/div/div[3]/div[2]/app-bar-chart/div/div[1]");
   By tdylabelbound=By.xpath("//app-admin-dashboard/div[2]/div/div/div[2]/div[2]/app-ack-outbound/div/div[3]/div[2]/app-bar-chart/div/div[1]");
  By filter=By.xpath("//span[contains(text(),'Apply Filter')]");
   By field_TP=By.xpath("//app-admin-dashboard/div[1]/app-filters/div/div/div[1]/p-multiselect/div/div[2]/div");
   By  serchTP_check=By.xpath("//app-admin-dashboard/div[1]/app-filters/div/div/div[1]/p-multiselect/div/div[4]/div[1]/div[1]/div[2]");
   By TPs_Link=By.xpath("//app-admin-dashboard/div[1]/app-filters/div/div/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem[1]/li");
   By asofDate=By.xpath("//app-admin-dashboard/div[1]/app-filters/div/div/div[2]/div/p-calendar");
   By ack_todayDatefield=By.xpath("//app-admin-dashboard/div[2]/div/div/div[2]/div[1]/app-ack-outbound/div/div[3]/div[2]/app-bar-chart/div/div[1]");
   By outbound_todayDate=By.xpath("//app-admin-dashboard/div[2]/div/div/div[2]/div[2]/app-ack-outbound/div/div[3]/div[2]/app-bar-chart/div/div[1]");
   By errorpop_TP=By.xpath("//div[contains(text(),'Please select atleast one trading partner')]");
   
   By link_WorkitemValue=By.xpath("//td[contains(text(),'277CA')]//following::td[1]//a");
   By breadCrumbSearchResult=By.xpath("//ul[contains(@class,'breadcrumb')]");
   By dropdown_workitem_SelectYear=By.xpath("//header/p-dropdown[1]/div[1]/span[1]");
   By selectedvalue_workitem_SelectYear=By.xpath("//app-work-item/div/div/div[2]/header/p-dropdown/div");
   By link_ActivityStateValue=By.xpath("//td[contains(text(),'ACCEPTED')]//following::td[1]//a");
   By link_AgingValue=By.xpath("//td[contains(text(),'ACCEPTED')]//following::td[1]//a");
   By link_TopHitsValue=By.xpath("//app-rule-hits/div/div/div[2]/div/div[1]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[2]/a");
   By link_MaxPercentageValue=By.xpath("//app-rule-hits/div/div/div[2]/div/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[2]/a");
   By link_LandedStatus=By.xpath("//*[@id='legend-0-item']/a");
   
   By tab_aging=By.xpath("//label[@for='aging']");
   By dropdown_SectionstoExport=By.xpath("//app-admin-dashboard/div[1]/app-filters/div/div/div[4]/div/p-multiselect/div/div[3]");
   By option_Workitem_dropdown_SectionstoExport=By.xpath("//span[contains(text(),'Work items')]");
   By option_Intake_dropdown_SectionstoExport=By.xpath("//span[contains(text(),'Intake')]");
   By option_InSystemActions_dropdown_SectionstoExport=By.xpath("//span[contains(text(),'In-system Actions')]");
   By option_LandedStatus_dropdown_SectionstoExport=By.xpath("//span[contains(text(),'Landed Status')]");
   By option_OutboundFiles_dropdown_SectionstoExport=By.xpath("//span[contains(text(),'Outbound files')]");
   By option_Rulehits_dropdown_SectionstoExport=By.xpath("//span[contains(text(),'Rule Hits')]");
   By option_ActivityState_dropdown_SectionstoExport=By.xpath("//span[contains(text(),'Activity state')]");
   
   By alloption_Workitem_dropdown_SectionstoExport=By.xpath("//div[@role='checkbox']");
   By logo_Humana=By.xpath("//img[@class='humanaLogo']");
   By exportCSV_SectiontoExport=By.xpath("//em[@class='far fa-file exportColor']");
   By exportPDF_SectiontoExport=By.xpath("//em[@class='far fa-file-pdf exportColor']");
   By dropdown_Years_Workitem=By.xpath("//header/p-dropdown[1]/div[1]/span[1]"); 
   By option_dropdown_Years_Workitem=By.xpath("//header/p-dropdown[1]/div[1]/div[3]/div[1]/ul[1]/p-dropdownitem[2]");
   

  Actions action = new Actions(driver);
  JavascriptExecutor js=(JavascriptExecutor) driver;

  
  public static void clickonHeropa() {
	  driver.findElement(By.xpath("/html/body/app-root/div/app-header/div[1]/div[1]/img")).click();
  }
  public WebElement getoutboundTodayDate() {
	  action.moveToElement(driver.findElement(outbound_todayDate)).perform();
	  WebElement msg=driver.findElement(outbound_todayDate);
	  return msg;
  }
  public WebElement getacknowldgeTodayDate() {
	  action.moveToElement(driver.findElement(ack_todayDatefield)).perform();
	  WebElement msg=driver.findElement(ack_todayDatefield);
	  return msg;
  }
  public WebElement clickonAsofDatefield() {
	  WebElement asofD=driver.findElement(asofDate);
	  return asofD;
  }
  public WebElement getErrorpupforTPs() {
	  action.moveToElement(driver.findElement(errorpop_TP)).perform();
	  WebElement msg=driver.findElement(errorpop_TP);
	  return msg;
  }
  public void clickonEmptyspace() {
	  driver.findElement(By.xpath("/html/body/app-root/div/dashboard-layout/div/app-navigation-bar/div[1]/ul")).click();
  }
  public WebElement getTPfromDPs(String TP) {
	  WebElement TP1=driver.findElement(By.xpath("//app-admin-dashboard/div[1]/app-filters/div/div/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem["+TP+"]/li"));
	  return TP1;
  }
  public WebElement clickonCheckboxinSearchTP() {
	  WebElement TP=driver.findElement(serchTP_check);
	  return TP;
  }
  public WebElement clickonTPfield() {
	  WebElement TP=driver.findElement(field_TP);
	  return TP;
  }
  public void clickonFilterbtn() throws InterruptedException {
	  Thread.sleep(3000);
	  driver.findElement(filter).click();
  }
   public WebElement clickonCalender() throws InterruptedException {
	   driver.findElement(By.xpath("//label[contains(text(),'TRADING PARTNER')]")).click();
	   Thread.sleep(4000);
	   action.moveToElement(driver.findElement(calender)).perform();
	 WebElement datepick=  driver.findElement(calender);
	 datepick.click();
	 return datepick;
   }
   
   public WebElement gettodaylabelfromWorkitemSection() throws InterruptedException {
	   Thread.sleep(3000);
	   WebElement tlbel=  driver.findElement(workitem_tdylabel);
	   return tlbel;
   }
   public WebElement gettodaylabelfromAcknoweldgementSection() {
	   WebElement tlbel=  driver.findElement(tdylabelinAck);
	   return tlbel;
   }
   public WebElement gettodaylabelfromoutboundSection() {
	   WebElement tlbel=  driver.findElement(tdylabelbound);
	   return tlbel;
   }
   
   public WebElement getfuturDate() {
	   WebElement ftrdt=driver.findElement(By.xpath("//p-calendar/span/div/div[1]/div/div[2]/table/tbody/tr[5]/td[7]/span"));
	   return ftrdt;
   }
   
   public WebElement gethyperlinkenablingasperDate() {
	   WebElement dataen=  driver.findElement(By.xpath("//app-work-item/div/div/div[3]/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[3]"));
	    return dataen;
   }
   
   public void clickWorkitemValueLink()
   {
	   wait.until(ExpectedConditions.elementToBeClickable(link_WorkitemValue));
      driver.findElement(link_WorkitemValue).click();;
	   
   }
   
   public String getBreadcrumbSearchResultPage()
   {
	   wait.until(ExpectedConditions.presenceOfElementLocated(breadCrumbSearchResult));
	   String breadCrumbSearchResultPage=driver.findElement(breadCrumbSearchResult).getText();
	   return breadCrumbSearchResultPage;
   }
   
   public void clickSelectYears_WorkItem()
   {
	  wait.until(ExpectedConditions.elementToBeClickable(dropdown_workitem_SelectYear));
	driver.findElement(dropdown_workitem_SelectYear).click();
	
   }

   public void selectValueYearsValue_WorkItem(int year)
   {
	   String xpath_year="//span[contains(text(),'"+year+"')]";
	   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath_year)));
	   driver.findElement(By.xpath(xpath_year)).click();   
   }
   
   
   public String getselectedYearsValue_WorkItem()
   {
	 
	   wait.until(ExpectedConditions.presenceOfElementLocated(selectedvalue_workitem_SelectYear));
	   String value=driver.findElement(selectedvalue_workitem_SelectYear).getText(); 
	   return value;
   }
   
   public void clickActivityStateValueLink()
   {
	   wait.until(ExpectedConditions.elementToBeClickable(link_ActivityStateValue));
      driver.findElement(link_ActivityStateValue).click();;
	   
   }
   
   public void clickTopHitsValueLink()
   {
	   wait.until(ExpectedConditions.elementToBeClickable(link_TopHitsValue));
      driver.findElement(link_TopHitsValue).click();;
	   
   }
   public void clickMaxPercentageValueLink()
   {
	   wait.until(ExpectedConditions.elementToBeClickable(link_MaxPercentageValue));
      driver.findElement(link_MaxPercentageValue).click();
	   
   }
   public void clickLandedStatusHyperLink()
   {
	   wait.until(ExpectedConditions.elementToBeClickable(link_LandedStatus));
	   driver.findElement(link_LandedStatus).click();
		      
   }
   
   
   public void clickAgingTab()
   {
	   
	   js.executeScript("arguments[0].scrollIntoView();",driver.findElement(tab_aging) );
		
		WebElement aging=driver.findElement(tab_aging);
//		agening.sendKeys(Keys.ARROW_LEFT);
		js.executeScript("arguments[0].click();",aging);
	   
   }
   
   public String getAgingTabText()
   {
	   wait.until(ExpectedConditions.presenceOfElementLocated(tab_aging));
	   String Tabtext=driver.findElement(tab_aging).getText();
	   return Tabtext;
   }
   
   
   
   
   
   public void clickAgingValueLink()
   {
	   wait.until(ExpectedConditions.elementToBeClickable(link_AgingValue));
      driver.findElement(link_AgingValue).click();;
	   
   }
   
   public void clickSectiontoExportDropdown()
   {
	   wait.until(ExpectedConditions.elementToBeClickable(dropdown_SectionstoExport));
	   driver.findElement(dropdown_SectionstoExport).click();
	   
   }
   
   public void selectWorkItems_SectiontoExportDropdown()
   {
	   wait.until(ExpectedConditions.presenceOfElementLocated(option_Workitem_dropdown_SectionstoExport));
	   driver.findElement(option_Workitem_dropdown_SectionstoExport).click(); 
	   driver.findElement(logo_Humana).click();
   }
  
   public void selectIntake_SectiontoExportDropdown()
   {
	   wait.until(ExpectedConditions.presenceOfElementLocated(option_Intake_dropdown_SectionstoExport));
	   driver.findElement(option_Intake_dropdown_SectionstoExport).click(); 
	   driver.findElement(logo_Humana).click();
   }
   public void selectInSystemActions_SectiontoExportDropdown()
   {
	   wait.until(ExpectedConditions.presenceOfElementLocated(option_InSystemActions_dropdown_SectionstoExport));
	   driver.findElement(option_InSystemActions_dropdown_SectionstoExport).click(); 
	   driver.findElement(logo_Humana).click();
   }
   public void selectLandedStatus_SectiontoExportDropdown()
   {
	   wait.until(ExpectedConditions.presenceOfElementLocated(option_LandedStatus_dropdown_SectionstoExport));
	   driver.findElement(option_LandedStatus_dropdown_SectionstoExport).click(); 
	   driver.findElement(logo_Humana).click();
   }
   public void selectOutboundFiles_SectiontoExportDropdown()
   {
	   wait.until(ExpectedConditions.presenceOfElementLocated(option_OutboundFiles_dropdown_SectionstoExport));
	   driver.findElement(option_OutboundFiles_dropdown_SectionstoExport).click(); 
	   driver.findElement(logo_Humana).click();
   }
  
   public void selectRuleHits_SectiontoExportDropdown()
   {
	   wait.until(ExpectedConditions.presenceOfElementLocated(option_Rulehits_dropdown_SectionstoExport));
	   driver.findElement(option_Rulehits_dropdown_SectionstoExport).click(); 
	   driver.findElement(logo_Humana).click();
   }
  
   public void selectActivityState_SectiontoExportDropdown()
   {
	   wait.until(ExpectedConditions.presenceOfElementLocated(option_ActivityState_dropdown_SectionstoExport));
	   driver.findElement(option_ActivityState_dropdown_SectionstoExport).click(); 
	   driver.findElement(logo_Humana).click();
   }
   
   
   
   
   public void selectAllOptions_SectiontoExportDropdown()
   {
	   wait.until(ExpectedConditions.presenceOfElementLocated(alloption_Workitem_dropdown_SectionstoExport));
	   driver.findElement(alloption_Workitem_dropdown_SectionstoExport).click(); 
	   driver.findElement(logo_Humana).click();
   } 
   
   
   
   public void clickExportCSV_SectiontoExport()
   {
	   wait.until(ExpectedConditions.elementToBeClickable(exportCSV_SectiontoExport));
	   driver.findElement(exportCSV_SectiontoExport).click();
	    
   }
   
   public void clickExportPDF_SectiontoExport()
   {
	   wait.until(ExpectedConditions.elementToBeClickable(exportPDF_SectiontoExport));
	   driver.findElement(exportPDF_SectiontoExport).click();
	 }
   
   public void clickYearsDropdown_WorkItems()
   {
	   wait.until(ExpectedConditions.presenceOfElementLocated(dropdown_Years_Workitem));
	   driver.findElement(dropdown_Years_Workitem).click(); 
   }
   
   public void selectYearDropdown_WorkItems()
   {
	   wait.until(ExpectedConditions.elementToBeClickable(option_dropdown_Years_Workitem));
	   driver.findElement(option_dropdown_Years_Workitem).click(); 
   }
   
   
   
   
   
   
   
   
   
}
