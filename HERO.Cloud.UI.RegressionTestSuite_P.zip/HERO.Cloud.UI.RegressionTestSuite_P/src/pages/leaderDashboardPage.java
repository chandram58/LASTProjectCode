package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.base;

public class leaderDashboardPage extends base{
	//Dashboard
	By link_queuename=By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[1]/div/div/div/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[1]/a");
	By label_queuereport=By.xpath("//h1[contains(text(),'Queue Inventory Report')]");
	By txt_queues_highpriority=By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[1]/div/div/div/p-table/div/div/div/div[2]/table/tbody/tr/td[1]/a");
	By rows_highpriority=By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[1]/div/div/div/p-table/div/div/div/div[2]/table/tbody/tr");
	//QueueInventoryReport
	By queuesfromhighpriority;
	By link_queuereport=By.xpath("//a[contains(text(),'Queue Inventory Report')]");
	By multiselctQueue=By.xpath("//app-inventoryreport/div[2]/div/div/div/form/fieldset[1]/p-multiselect/div/div[2]");
	By selectQueue=By.xpath("//app-inventoryreport/div[2]/div/div/div/form/fieldset[1]/p-multiselect/div/div[4]/div[1]/div[1]/div[2]");
	By filterbtn=By.xpath("//span[contains(text(),'Apply Filter')]");
	By tableQueue=By.xpath("//app-inventoryreport/div[2]/div/div[2]/div/p-treetable/div/div/div/div[2]/table/tbody/tr[1]/td[2]/div/p-treetablecheckbox/div/div[2]");
    By btn_assiagn=By.xpath("//a[contains(@title,'Assign to')]//em");
    By assign_user=By.xpath("//app-inventoryreport/div[2]/div/div[2]/header/div/div/p-dialog/div/div/div[2]/p-dropdown/div/span");
    By serch_user=By.xpath("/html/body/div[2]/div[1]/div/input");
    By select_user=By.xpath("//body/div[2]/div[2]/ul/p-dropdownitem[1]/li");
    By ass_reassign_btn=By.xpath("//button[contains(text(),'Assign/Reassign')]");
    By btn_unassign=By.xpath("//button[contains(text(),'Unassign')]");
    By err_message1=By.xpath("//div[contains(text(),'Please select atleast one Work item or a Queue')]");
    By succ_mesg=By.xpath("//app-leaderdashboard/div[2]/p-sidebar/div/div[2]/div/app-inventoryreport/div[2]/p-toast/div/p-toastitem/div/div/div/div[2]");
    By pop_ok=By.xpath("//app-inventoryreport/p-toast/div/p-toastitem/div/div/div[2]/button[1]/span");
    By cancel_queuereport=By.xpath("//body/app-root/div/dashboard-layout/div/app-leaderdashboard/div[2]/p-sidebar/div/div[1]/button/span");
    By link_queue_workitem=By.xpath("//app-inventoryreport/div[2]/div/div[2]/div/p-treetable/div/div/div/div[2]/table/tbody/tr[1]/td[2]/div/p-treetabletoggler/button/i");
    By link_queuereport_workitem=By.xpath("//app-inventoryreport/div[2]/div/div[2]/div/p-treetable/div/div/div/div[2]/table/tbody/tr[2]/td[2]/a");
    
    JavascriptExecutor js = (JavascriptExecutor) driver;
   Actions action = new Actions(driver);
  
   WebDriverWait wait=new WebDriverWait(driver,200);
   
   public List<String> getQueuesfromHighpriority() {
		int rowSize=driver.findElements(rows_highpriority).size();
		System.out.println("No of Queues in high priority page"+ rowSize);
		String Queues;
		List<String> Queueslistinprioritypage = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
			 queuesfromhighpriority=By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[1]/div/div/div/p-table/div/div/div/div[2]/table/tbody/tr["+i+"]/td[1]/a");
			
			 Queues=driver.findElement(queuesfromhighpriority).getText().trim();
			//System.out.println("Queues in Row"+i+"="+Queues);
			Queueslistinprioritypage.add(Queues);
		}
		return Queueslistinprioritypage;
   }
   public String getfriendlyUI() throws InterruptedException {
	   Thread.sleep(4000);
	   String WI=driver.getCurrentUrl();
	  
	   return WI;
   }
   
   public WebElement clickonWorkitemlinkinqueuepage() throws InterruptedException {
	   Thread.sleep(4000);
	   WebElement WI=	driver.findElement(link_queuereport_workitem);
	   js.executeScript("arguments[0].click();",WI);
	   return WI;
   }

   public WebElement clickonQueueNamelink() throws InterruptedException {
	   Thread.sleep(4000);
	   WebElement que=	driver.findElement(link_queue_workitem);
	   js.executeScript("arguments[0].click();",que);
	   return que;
   }
   public WebElement getpagetitleofqueuereport() throws InterruptedException {
	   Thread.sleep(2000);
	   WebElement que=	driver.findElement(label_queuereport);
	   return que;
   }
   public WebElement clickonQueueName() throws InterruptedException {
	   Thread.sleep(2000);
	   WebElement que=	driver.findElement(link_queuename);
	   return que;
   }
    public void clcikOnPopBtnOK() throws InterruptedException {
    	Thread.sleep(3000);
    	wait.until(ExpectedConditions.elementToBeClickable(pop_ok));
        WebElement pop=	driver.findElement(pop_ok);
        js.executeScript("arguments[0].click();",pop);
        }
    public WebElement getSuccessMessageforWorkItem() throws InterruptedException {
    	
    	wait.until(ExpectedConditions.visibilityOfElementLocated(succ_mesg));
        WebElement meesage=	driver.findElement(succ_mesg);
        return meesage;
        }
    public WebElement getErrrorMessageforWorkItem() throws InterruptedException {
    	Thread.sleep(3000);
    WebElement meesage=	driver.findElement(err_message1);
    return meesage;
    }
    public void clickOnQueueInventory() throws InterruptedException {
    	Thread.sleep(3000);
    	driver.findElement(link_queuereport).click();
    }
    public void clickOnSelectQueue() throws InterruptedException {
    	Thread.sleep(1000);
    	driver.findElement(multiselctQueue).click();
    	Thread.sleep(2000);
    	driver.findElement(selectQueue).click();
    }
    public void clickOnApplyfilter() throws InterruptedException {
    	driver.findElement(By.xpath("//h1[contains(text(),'Queue Inventory Report')]")).click();
    	Thread.sleep(3000);
    	driver.findElement(filterbtn).click();
    }
    
    public void getSelect1stQueueTable() throws InterruptedException {
    	Thread.sleep(2000);
    	driver.findElement(tableQueue).click();
    }
    public WebElement clickonAssignBtn() throws InterruptedException {
    	Thread.sleep(3000);
    	driver.findElement(btn_assiagn).click();
    	Thread.sleep(2000);
    WebElement userdp=	driver.findElement(assign_user);
    userdp.click();
    return userdp;
   }
     public WebElement getSerachUser(String user) throws InterruptedException {
    	 Thread.sleep(1000);
    	 WebElement user1=	driver.findElement(serch_user);
    	 user1.sendKeys(user);
    	 return user1;
    }
    
     public void clickuserfrmdpaftersearch() throws InterruptedException {
    	 Thread.sleep(3000);
    	 driver.findElement(select_user).click();
     }
     public void clickAissign_reassignbtn() throws InterruptedException {
    	 Thread.sleep(3000);
    	 driver.findElement(ass_reassign_btn).click();
     	
     }
     
    
    
}
