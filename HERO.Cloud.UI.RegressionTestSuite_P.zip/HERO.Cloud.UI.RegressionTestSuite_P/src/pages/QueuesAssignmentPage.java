package pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.asserts.SoftAssert;

import base.base;

public class QueuesAssignmentPage extends base
{
	By label_pageTitle=By.xpath("/html/body/app-root/div/app-admin-layout/div/app-queue-assignment/div/div[1]/div/div[1]/h1");
	By dd_userOrGroupDropdown=By.xpath("//app-queue-assignment/div[1]/div[2]/div[1]/div/div[1]/p-dropdown");
	By dd_searchbox=By.xpath("//app-queue-assignment/div[1]/div[2]/div[1]/div/div[2]/p-dropdown/div/span");
	By btn_downloadExcel=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[1]/div/div[2]/descendant::a[@title='Export to Excel']");
	By btn_downloadPDF=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[1]/div/div[2]/descendant::a[@title='Export to PDF']");
	By txt_userGroupSearch=By.xpath("//app-queue-assignment/div[1]/div[2]/div[1]/div/div[2]/p-dropdown/div/div[3]/descendant::input");
	By list_searchResults_userOrGroup=By.xpath("//app-queue-assignment/div[1]/div[2]/div[1]/div/div[2]/p-dropdown/div/div[3]/div[2]/ul/p-dropdownitem/li/span");
	By label_userOrGroup,label_userOrGroupFromDropDownList,label_userListUserProfile,label_rowUserProfile;

	By label_listofQueuesSectionHeader=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[1]/div/div[1]/p/span");
	By label_userName_ListofQueuesSection=By.xpath("//app-queue-assignment[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/p[1]/span[2]/span[1]/span[1]");
	By section_ListofQueues=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]");
	By section_totalQueues=By.xpath("//div[@class='queuesContainerBody']/descendant::div[contains(@class,'availablequeue')]");
	By section_primaryQueues=By.xpath("//h4[text()='Primary Queues']/ancestor::div[3]/following-sibling::div");
	By section_secondaryQueues=By.xpath("//h4[text()='Secondary Queues']/ancestor::div[3]/following-sibling::div");
	By dd_searchAndSelectDropdown=By.xpath("//p-multiselect/descendant::*[contains(text(),'Search and Select Queues')]");
	By txt_searchAndSelectQueues=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div[2]/p-multiselect/div/div[4]/div[1]/div[2]/input");
	By list_searchResults_Queues=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div[2]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem/li");
	By btn_sort_queueName=By.xpath("(//p-table/div/div/div/div[1]/div/table/thead/tr/th[1]/p-sorticon/i)[1]");
	By list_queues_QueuesSection=By.xpath("//div[contains(@class,'availablequeue')]/p-table/div/div/div/div[2]/table/tbody/tr");
	By label_queueFromDropDownList,label_queueName;
	By btn_save=By.xpath("//span[contains(text(),'Save')]");
	By text_empty_primaryQueue=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/div/div[2]/table/tbody/tr/td");
	By text_empty_SecondaryQueue=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/div/div[2]/table/tbody/tr/td");
	By webtable_Queue=By.xpath("//app-queue-assignment[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody");
	By rows_Queue=By.tagName("tr");
	By cols_Queue=By.tagName("td");
	By searchBox_Input=By.xpath("//app-queue-assignment/div[1]/div[2]/div[1]/div/div[2]/p-dropdown/div/div[3]/div[1]/div/input");
	By searchResultPopulated_user=By.xpath("//app-queue-assignment/div[1]/div[2]/div[1]/div/div[2]/p-dropdown/div/div[3]/div[2]/ul/p-dropdownitem/li/span");
	By groupSelected_searchResult=By.xpath("//app-queue-assignment[1]/div[1]/div[2]/div[1]/div[1]/div[2]/p-dropdown[1]/div[1]/div[3]/div[2]/ul[1]/p-dropdownitem[1]/li[1]");
	By pageHeader_QueueAssignment=By.xpath("//h1[contains(text(),'Queues Assignment')]");
	By firstOption_SearchResult_Group=By.xpath("//app-queue-assignment[1]/div[1]/div[2]/div[1]/div[1]/div[2]/p-dropdown[1]/div[1]/div[3]/div[2]/ul[1]/p-dropdownitem[1]/li[1]");
	By queueSerachPlaceholder=By.xpath("//div[contains(text(),'Search and Select Queues')]");
 	By searchTextInput_SearchQueues=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div[2]/p-multiselect/div/div[4]/div[1]/div[2]/input");
	By multiSelect_SearchQueue=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div[2]/p-multiselect/div/div[4]/div[1]/div[1]/div[2]");
 	By queuelist_SearchQueueResult=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div[2]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem/li");
    By chevron_selectPriority_primary=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[1]/div/div[2]/p-dropdown/div/div[2]/span");
 	By priorityOptionPrimary_QueueDate=By.xpath("//ul[1]/p-dropdownitem[2]/li[1]/span[1]");
 	By chevron_selectPriority_secondary=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[1]/div/div[2]/p-dropdown/div/div[2]/span");
 	By priorityOptionSecondary_QueueDate=By.xpath("//ul/p-dropdownitem[2]/li/span");
 	By btn_Revert=By.xpath("//a[@title='Revert all queues to groups']");
    By primarySectionContent=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/table/tbody");
    By secondarySectionContent=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/div/p-table/div/div[1]/table/tbody");
 	By QueuenameFirstRow_primarySection=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/div/div[2]/table/tbody/tr[1]/td[1]");
 	By QueuenameSecondRow_primarySection=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/div/div[2]/table/tbody/tr[2]/td[1]");
 	By QueuenameFirstRow_secondarySection=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/p-table/div/div[1]/div/div[2]/table/tbody/tr[1]/td[1]");
 	By QueuenameSecondRow_secondarySection=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/p-table/div/div[1]/div/div[2]/table/tbody/tr[2]/td[1]");
 	By firstQueue_QueueTable=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[2]/div[1]/p-table/div/div/table/tbody/tr[1]/td[1]/div");
 	By secondQueue_QueueTable=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[2]/div[1]/p-table/div/div/table/tbody/tr[2]/td[1]/div");
 	By primaryQueue=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/table/tbody");
 	By btn_Revert_UserAssignment=By.xpath("//a[@title='Revert all queues to groups']");
 	By userList_UserprofilePage=By.xpath("//app-user-profile/div/div[2]/div/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr/td[1]");
 	
 	
 	JavascriptExecutor js = (JavascriptExecutor) driver;
 //Thread.sleep(3000);
	
	
	public void dragAndDrop(WebElement from, WebElement to) {
      
        js.executeScript("function createEvent(typeOfEvent) {\n" + "var event =document.createEvent(\"CustomEvent\");\n"
                        + "event.initCustomEvent(typeOfEvent,true, true, null);\n" + "event.dataTransfer = {\n" + "data: {},\n"
                        + "setData: function (key, value) {\n" + "this.data[key] = value;\n" + "},\n"
                        + "getData: function (key) {\n" + "return this.data[key];\n" + "}\n" + "};\n" + "return event;\n"
                        + "}\n" + "\n" + "function dispatchEvent(element, event,transferData) {\n"
                        + "if (transferData !== undefined) {\n" + "event.dataTransfer = transferData;\n" + "}\n"
                        + "if (element.dispatchEvent) {\n" + "element.dispatchEvent(event);\n"
                        + "} else if (element.fireEvent) {\n" + "element.fireEvent(\"on\" + event.type, event);\n" + "}\n"
                        + "}\n" + "\n" + "function simulateHTML5DragAndDrop(element, destination) {\n"
                        + "var dragStartEvent =createEvent('dragstart');\n" + "dispatchEvent(element, dragStartEvent);\n"
                        + "var dropEvent = createEvent('drop');\n"
                        + "dispatchEvent(destination, dropEvent,dragStartEvent.dataTransfer);\n"
                        + "var dragEndEvent = createEvent('dragend');\n"
                        + "dispatchEvent(element, dragEndEvent,dropEvent.dataTransfer);\n" + "}\n" + "\n"
                        + "var source = arguments[0];\n" + "var destination = arguments[1];\n"
                        + "simulateHTML5DragAndDrop(source,destination);", from, to);
    }
    
	
	
	
	
	
	
	
	
	
	public void removeQueuefrmPrimary() throws InterruptedException 
	{
		WebElement fromprimaryQueue,toqueuetable;
		

		 fromprimaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/table/tbody/tr/td[1]"));
		 toqueuetable=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[2]/div[1]/p-table/div/div/table/tbody/tr[1]/td[1]/div"));
		
	
		Thread.sleep(5000); 
		

	
		
		  do{
			
			 fromprimaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/table/tbody/tr/td[1]"));
			 toqueuetable=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[2]/div[1]/p-table/div/div/table/tbody/tr[1]/td[1]"));
			
			 dragAndDrop(fromprimaryQueue,toqueuetable) ;
		
	        fromprimaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/table/tbody/tr/td[1]"));
			 toqueuetable=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[2]/div[1]/p-table/div/div/table/tbody/tr[1]/td[1]"));
			
			  
	        
		  }
		  while(!(fromprimaryQueue.getText().equalsIgnoreCase("No records found")));
	}	
	

	
	
	public void removeQueuefrmsecondary() throws InterruptedException {
		WebElement secondaryQueue,queuetable;
		
	
		Thread.sleep(5000); 
		Actions builder = new Actions(driver);

	
		
		 JavascriptExecutor js = (JavascriptExecutor)driver;
		 do{
				 secondaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/div/p-table/div/div[1]/table/tbody/tr/td[1]")); 
				 queuetable=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[2]/div[1]/p-table/div/div/table/tbody/tr[1]/td[1]/div"));
				 
				 dragAndDrop(secondaryQueue,queuetable);
  
		
	        secondaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/div/p-table/div/div[1]/table/tbody/tr/td[1]")); 
			 queuetable=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[2]/div[1]/p-table/div/div/table/tbody/tr[1]/td[1]"));
			  
	        
	        
		}while(!(secondaryQueue.getText().equalsIgnoreCase("No records found")));
	
	}
	
	
	public void moveQueuefrmPrimarytoSecondary() throws InterruptedException 
	{
		WebElement fromprimaryQueue,secondaryQueue;
		

		 fromprimaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
		 secondaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
		
	
		Thread.sleep(5000); 
		

	
		
		  do{
				 fromprimaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
				 secondaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
				
			
			 
			 dragAndDrop(fromprimaryQueue,secondaryQueue) ;
		
	        fromprimaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
	        secondaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
			
			  
	        
		  }
		  while(!(fromprimaryQueue.getText().equalsIgnoreCase("No records found")));
	}	
	
	
	public void moveQueuefrmSecondarytoPrimary() throws InterruptedException 
	{
		WebElement fromprimaryQueue,secondaryQueue;
		

		 fromprimaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
		 secondaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
		
	
		Thread.sleep(5000); 
		

	
		
		  do{
				 fromprimaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
				 secondaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
				
			
			 
			 dragAndDrop(secondaryQueue,fromprimaryQueue) ;
		
	        fromprimaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
	        secondaryQueue=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/p-table/div/div[1]/div/div[2]/table/tbody/tr/td[1]"));
			
			  
	        
		  }
		  while(!(secondaryQueue.getText().equalsIgnoreCase("No records found")));
	}	
	
	
	public boolean revertBtnAvailability()
	{
		boolean revertBtnAvl=driver.findElement(btn_Revert).isDisplayed();
		return revertBtnAvl;
				
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void clickonSave() {
		driver.findElement(btn_save).click();
		
	}
	public String getqueueStable() throws InterruptedException {
		Thread.sleep(3000);
		WebElement queueforfromS=driver.findElement(firstQueue_QueueTable);
		
		return queueforfromS.getText();
	}
	public String getqueueptable() throws InterruptedException {
		Thread.sleep(3000);
		WebElement queueforfromP=driver.findElement(secondQueue_QueueTable);
		
		return queueforfromP.getText();
	}
	public String getprimaryTable() throws InterruptedException {
		Thread.sleep(3000);
		WebElement primaryQueueTable=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[1]/div[2]/div/p-table/div/div[1]/table/tbody"));

		return primaryQueueTable.getText();
	}
	public String getSecondaryTable() throws InterruptedException {
		Thread.sleep(3000);
		WebElement secondaryQueueTable=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/div/p-table/div/div[1]/table/tbody"));

		return secondaryQueueTable.getText();
	}
	
	
public void DragandDropofQueueforSecondaryQueue() throws InterruptedException {
	Thread.sleep(3000);
	WebElement queueforfromS=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[2]/div[1]/p-table/div/div/table/tbody/tr[1]/td[1]"));
	WebElement secondaryQueueTable=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[3]/div/div[2]/div[2]/div/p-table/div/div[1]/table/tbody"));
	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", secondaryQueueTable);
	Thread.sleep(500); 
	
	dragAndDrop(queueforfromS,secondaryQueueTable);
	
	}




	public void DragandDropofQueueforPrimaryQueue() throws InterruptedException {
		Thread.sleep(3000);
		WebElement SecondqueueTable=driver.findElement(secondQueue_QueueTable);
		
		WebElement primaryQueueTable=driver.findElement(primaryQueue);

		dragAndDrop(SecondqueueTable,primaryQueueTable);
		
		
	}
	
	public void DragandDropFirstQueuefromTabletoPrimary() throws InterruptedException 
	{
		Thread.sleep(3000);
		WebElement FirstQueueTable=driver.findElement(firstQueue_QueueTable);
		
		WebElement primaryQueueTable=driver.findElement(primaryQueue);

		dragAndDrop(FirstQueueTable,primaryQueueTable);
	}
	
	//below method not working
	public void ShufflingPrimarySectionQueue() throws InterruptedException 
	{
		Thread.sleep(3000);
		WebElement FirstRow_primaryQueue=driver.findElement(QueuenameFirstRow_primarySection);
		WebElement SecondRow_primaryQueue=driver.findElement(QueuenameSecondRow_primarySection);
		//dragAndDrop(a,b);
        
   
	}
	

	public String getPageHeader_QueueAssignment()
	{
		return driver.findElement(label_pageTitle).getText();
	}
	public String getSectionHeader_ListOfQueues()
	{
		return driver.findElement(label_listofQueuesSectionHeader).getText();
	}
	public String getUserName_ListOfQueues()
	{
		return driver.findElement(label_userName_ListofQueuesSection).getText();
	}
	
	public void clickSaveButton()
	{
		driver.findElement(btn_save).click();	
	}
	
	public void selectPriority_primaryQueue()
	{
		driver.findElement(chevron_selectPriority_primary).click();
		driver.findElement(priorityOptionPrimary_QueueDate).click();
		
	}
	
	public void selectPriority_secondaryQueue()
	{
		driver.findElement(chevron_selectPriority_secondary).click();
		driver.findElement(priorityOptionSecondary_QueueDate).click();
		
	}
	

	public void selectUserOrGroupFromDropdown(String value) {

		driver.findElement(dd_userOrGroupDropdown).click();
		label_userOrGroup=By.xpath("//span[text()='"+value+"'][@class='ng-star-inserted']");
		wait.until(ExpectedConditions.presenceOfElementLocated(label_userOrGroup));
		driver.findElement(label_userOrGroup).click();

	}

	public String getValueFromSearchBox() {

		return driver.findElement(dd_searchbox).getText();
	}

	public void clickSelectUsersOrGroupsSearch() {

		wait.until(ExpectedConditions.presenceOfElementLocated(dd_searchbox));
		driver.findElement(dd_searchbox).click();

	}

	public void selectUserOrGroupFromSearchDropdown(String groupname) {
		label_userOrGroupFromDropDownList=By.xpath("//span[@class='ng-star-inserted'][normalize-space()='"+groupname+"']");
		wait.until(ExpectedConditions.presenceOfElementLocated(label_userOrGroupFromDropDownList));
		driver.findElement(label_userOrGroupFromDropDownList).click();
	}

	public void clickDownloadExcel() {

		driver.findElement(btn_downloadExcel).click();	
	}
	public void clickDownloadPDF() {

		driver.findElement(btn_downloadPDF).click();	
	}
	public Boolean verifyListofQueuesSection() {

		return driver.findElement(section_ListofQueues).isDisplayed();
	}
	public Boolean verifyQueuesSection() {
		return driver.findElement(section_totalQueues).isDisplayed();
	}
	public Boolean verifySecondaryQueuesSection() {
		return driver.findElement(section_secondaryQueues).isDisplayed();
	}
	public Boolean verifyPrimaryQueuesSection() {
		return driver.findElement(section_primaryQueues).isDisplayed();

	}
	public void inputUserOrGrpToSearch(String value) 
	{
		driver.findElement(txt_userGroupSearch).sendKeys(value);
	}
	public ArrayList<String> getSearchResultsList()
	{
		ArrayList<String> searchResultList= new ArrayList<String>();
		int resultsCount=driver.findElements(list_searchResults_userOrGroup).size();
		System.out.println("Results Count->"+resultsCount);
		for(int i=1;i<=resultsCount;i++)
		{
			label_userOrGroupFromDropDownList=By.xpath("//app-queue-assignment/div[1]/div[2]/div[1]/div/div[2]/p-dropdown/div/div[3]/div[2]/ul/p-dropdownitem["+i+"]/li/span");
			searchResultList.add(driver.findElement(label_userOrGroupFromDropDownList).getText().toLowerCase().trim());
		}
        System.out.println("searchResultList in QueueAssignment page->"+searchResultList);
		return searchResultList;
	}
	
	public void clickSearchAndSelectQueuesDropDown() {
		driver.findElement(dd_searchAndSelectDropdown).click();
		
	}
	public void inputSearchAndSelectQueue(String searchterm) {
		driver.findElement(txt_searchAndSelectQueues).sendKeys(searchterm);
	}
	public List<String> getSearchResultsList_Queues() throws InterruptedException {
		Thread.sleep(5000);
		List<String> searchResultList= new ArrayList<String>();
		int resultsCount=driver.findElements(list_searchResults_Queues).size();
		System.out.println("User Count in QueueAssignment DropDown->"+resultsCount);
		for(int i=1;i<=resultsCount;i++)
		{
			label_queueFromDropDownList=By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[2]/div[1]/div[1]/div/div/div[1]/div/div[2]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem["+i+"]/descendant::label");
			searchResultList.add(driver.findElement(label_queueFromDropDownList).getText());
		}
        System.out.println("searchResultList->"+searchResultList);
		return searchResultList;
	}
	
	
	public void clickSortQueueName_Queues() {
		driver.findElement(btn_sort_queueName).click();
		
	}
	public List<String> getQueueNamesList_Queues() {
		List<String> queuesNameList_Queues= new ArrayList<String>();
		int rowcount=driver.findElements(list_queues_QueuesSection).size();
		
		System.out.println("Queues Count in table="+rowcount);
		for(int i=1;i<=rowcount;i++)
		{
			label_queueName=By.xpath("//div[contains(@class,'availablequeue')]/p-table/div/div/div/div[2]/table/tbody/tr["+i+"]/td[1]/div");
			queuesNameList_Queues.add(driver.findElement(label_queueName).getText().trim());
			//System.out.println("i and value="+i+"-"+queuesNameList_Queues.get(i-1));
		}
		System.out.println("Queues List Size="+queuesNameList_Queues.size());
		System.out.println(queuesNameList_Queues);
		return queuesNameList_Queues;
	}
	
	public List<String> ascendingOrderList_Claim()
	  {
		  WebElement webtable_asc=driver.findElement(webtable_Queue);
		  List<WebElement> rows_asc=webtable_asc.findElements(rows_Queue);
		  List<WebElement> cols_asc=rows_asc.get(0).findElements(cols_Queue);
		  System.out.println("No of Rows in table->"+rows_asc.size());
		  System.out.println( "No of Cols in table->"+cols_asc.size()); 
				
	//Getting Rows list
					 
		 List<String> rows_Claim_asc = new ArrayList<String>();
	     for(int j=0;j<rows_asc.size();j++)
			 {
			 //System.out.println(rows_Rolename_asc.get(j).getText().replace("\n", " "));
			  rows_Claim_asc.add(rows_asc.get(j).getText().replace("\n", " ")); 
				 }
	     return rows_Claim_asc;
		}
		
			
		

	  public List<String> descendingOrderList_Claim()
	  {
		  WebElement webtable_desc=driver.findElement(webtable_Queue);
		  List<WebElement> rows_desc=webtable_desc.findElements(rows_Queue);
		  List<WebElement> cols_desc=rows_desc.get(0).findElements(cols_Queue);
		  System.out.println("No of Rows in table->"+rows_desc.size());
		  System.out.println( "No of Cols in table->"+cols_desc.size()); 
				
	//Getting Rows list
					 
		 List<String> rows_Claim_asc = new ArrayList<String>();
	     for(int j=0;j<rows_desc.size();j++)
			 {
			 //System.out.println(rows_Rolename_asc.get(j).getText().replace("\n", " "));
			  rows_Claim_asc.add(rows_desc.get(j).getText().replace("\n", " ")); 
				 }
	     return rows_Claim_asc; 
	  }
	
	  public List<WebElement> getSearchUserResult(String searchterm)
	  {
        driver.findElement(searchBox_Input).sendKeys(searchterm);
		List<WebElement> SearchResult=driver.findElements(searchResultPopulated_user);
		return SearchResult;
	  }
        
		  
	 public List<WebElement> getSearchResultQueuewithGroup(String searchTermQueue) throws InterruptedException
	 {
		 
		   String selectedGroup=driver.findElement(groupSelected_searchResult).getText();
		   System.out.println("Selected Group -> "+selectedGroup);
		 
		   driver.findElement(firstOption_SearchResult_Group).click();
		   driver.findElement(pageHeader_QueueAssignment).click();
			
           driver.findElement(queueSerachPlaceholder).click();
			
			
         
			driver.findElement(searchTextInput_SearchQueues).sendKeys(searchTermQueue);
			
			WebElement Multiselect=driver.findElement(multiSelect_SearchQueue);
			Multiselect.click();
			
			
			
			Thread.sleep(10000);
			
		List<WebElement> ListQueues_SearchQueueResult=driver.findElements(queuelist_SearchQueueResult);
       
		return ListQueues_SearchQueueResult; 
	 }
	
	 
	 public WebElement getAssociatedUsers_Group()
	 {
		// wait.until(ExpectedConditions.presenceOfElementLocated(label_userName_ListofQueuesSection));
			WebElement AssociatedUsers=driver.findElement(label_userName_ListofQueuesSection);
			System.out.println("Associated Users -> "+AssociatedUsers.getText());
			return AssociatedUsers; 
	 }
	 
	 public WebElement getAssociatedGroup_Users()
	 {
		 //wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[1]/div/div[1]/p/span[2]/a")));
			WebElement AssociatedGroup=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[1]/div/div[1]/p/span[2]/a"));
			System.out.println("Associated Group -> "+AssociatedGroup.getText());
			return AssociatedGroup; 
	 }
	 
	 
	 public String getPopulatedgroup()
	  {
		  String PopulatedGroup=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[1]/div/div[1]/p/span[2]/a")).getText();
	      System.out.println("Populated Group -> "+PopulatedGroup);
	      return PopulatedGroup;

	  }
	 
	 
	  public String getSectionTitle()
	  {
		  String SectionTitle=driver.findElement(By.xpath("//app-queue-assignment/div[1]/div[2]/div[2]/div/div[1]/div/div[1]/p/span")).getText();
			System.out.println("SectionTitle -> "+SectionTitle);
			return SectionTitle;

	  }
	 
	  public String getPrimaryQueuesectionContent()
	  {
		  String PrimaryQueuesectionContent=driver.findElement(primarySectionContent).getText();
			System.out.println("Primary Queue Section Content->"+PrimaryQueuesectionContent);
			return PrimaryQueuesectionContent;

	  }
	  
	  public String getFirstRowQueuename_Primary()
	  {
		  String FirstRow=driver.findElement(QueuenameFirstRow_primarySection).getText();
		  return FirstRow;
		  
	  }
	  
	  public String getSecondRowQueuename_Primary()
	  {
		  String SecondRow=driver.findElement(QueuenameSecondRow_primarySection).getText();
		  return SecondRow;
		  
	  }
	  
	  public String getFirstRowQueuename_Secondary()
	  {
		  String FirstRow=driver.findElement(QueuenameFirstRow_secondarySection).getText();
		  return FirstRow;
		  
	  }
	  
	  public String getSecondRowQueuename_Secondary()
	  {
		  String SecondRow=driver.findElement(QueuenameSecondRow_secondarySection).getText();
		  return SecondRow;
		  
	  }
	  
	  public void clickRevert()
	  {
		  WebElement Revert=driver.findElement(btn_Revert);
		  Revert.click();
	  }
	  
	  
	  
	  
	  
	  
	 
	  public String getSecondaryQueuesectionContent()
	  {
		  String SecondaryQueuesectionContent=driver.findElement(secondarySectionContent).getText();
			System.out.println("Secondary Queue Section Content->"+SecondaryQueuesectionContent);
			return SecondaryQueuesectionContent;

	  }
	 
	 
	 public List<String> getActiveUserList_UserProfile() throws InterruptedException
	 {
		 Thread.sleep(5000);
	
		 List<String> ActiveUserListUserProfile = new ArrayList<String>();
	     int resultsCount=driver.findElements(userList_UserprofilePage).size();
			System.out.println("User Count in User Profile Page="+resultsCount);
			
				
		       int ActiveUserCount=0;
		       for(int j=1;j<resultsCount;j++) 
                {
		    	   label_rowUserProfile=By.xpath("//app-user-profile[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/p-table[1]/div[1]/div[1]/table[1]/tbody[1]/tr["+j+"]");
		    	//   label_userListUserProfile=By.xpath("//app-user-profile/div/div[2]/div/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr["+j+"]/td[1]");
		        if(driver.findElement(label_rowUserProfile).getAttribute("class").equals("ng-star-inserted"))
	              { 
		         String Username=driver.findElement(label_rowUserProfile).findElement(By.tagName("td")).getText().toLowerCase();
	             ActiveUserListUserProfile.add(Username.trim());
		         ActiveUserCount++;
	                }
		          }

               System.out.println("Active Users list in User profile page");  
		       System.out.println(ActiveUserListUserProfile);
		       System.out.println("Number of Active Users in User profile page->"+ActiveUserCount); 
             
			return ActiveUserListUserProfile;
	 
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
}
	  
	  

