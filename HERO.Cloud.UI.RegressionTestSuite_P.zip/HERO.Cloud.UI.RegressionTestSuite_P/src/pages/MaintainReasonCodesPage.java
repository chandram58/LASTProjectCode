package pages;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.base;

public class MaintainReasonCodesPage extends base 
{
	By label_pageTitle=By.xpath("//h1[contains(text(),'Maintain Reason Codes')]");
	By rows_activeReasonCodes=By.xpath("//table/tbody/tr[not (contains(@class,'hasExpired'))]");
	By rows_inActiveReasonCodes=By.xpath("//table/tbody/tr[contains(@class,'hasExpired')]");
	By rows_reasonCodesTable=By.xpath("//table/tbody/tr");
	By label_codeName,label_description,label_startDate,label_endDate;
	By icon_sortCodeName=By.xpath("//thead/tr[1]/th[1]/span[1]/p-sorticon[1]/i[1]");
	By icon_sortDescription=By.xpath("//thead/tr[1]/th[2]/span[1]/p-sorticon[1]/i[1]");
	By icon_sortStartDate=By.xpath("//thead/tr[1]/th[3]/span[1]/p-sorticon[1]/i[1]");
	By icon_sortEndDate=By.xpath("//thead/tr[1]/th[4]/span[1]/p-sorticon[1]/i[1]");
	By label_totalRecordsShowing=By.xpath("//span[contains(text(),'Total records showing')]");
	By btn_addNewTimeTrackingReasonCode=By.xpath("//span[contains(text(),'Add New Time Tracking Reason Code')]");
	By btn_edit_reasonCode;
	By btn_searchResult_Reasoncode;
	By btn_searchResult_Edit;
	By btn_searchResult_Enddate;
	By webtable=By.xpath("//app-reason-code/div/div[2]/div/div[3]/p-table/div/div/div/div[2]/table/tbody/tr[1]/td[1]");
    By btn_DownloadToCSV=By.xpath("//em[@class='far fa-file']")  ;
    By btn_DownloadToPDF=By.xpath("//em[@class='far fa-file-pdf']");
    By input_SearchTextbox=By.xpath("//input[@placeholder='Search Reason Codes']");
    By rows_SearchResult=By.xpath("//app-reason-code/div/div[2]/div/div[3]/p-table/div/div/div/div[2]/table/tbody/tr");
    By text_RecordCountDisplayed=By.xpath("//span[contains(text(),'Total records showing')]");
    By label_ReasonRequiredOnReturn=By.xpath("//app-reason-code[1]/div[1]/div[4]/form[1]/div[2]/div[2]/div[1]/div[6]/div[1]/p-checkbox[1]/label[1]");
    By chkbox_ReasonRequiredOnReturn=By.xpath("//p-checkbox[@name='updateIsReasonReqOnReturn']//div[@class='p-checkbox-box']");
    By popup_toggleSwitch=By.xpath("//app-header/div[2]");
    By dropdown_Toggle_SelectReason=By.xpath("//span[contains(text(),'Select Reason')]");
    By label_Savebtn_Toggle=By.xpath("//button[contains(text(),'Save')]");
    By validationError_ReasonDesc_Toggle=By.xpath("//label[contains(text(),'Reason Description required')]");
    
    
	//New Reason Code
	By label_pageTitle_newCode=By.xpath("//h3[contains(text(),'New Reason Code')]");
	By txt_reasonCodeName=By.xpath("//input[@id='addReason']");
	By label_errorMsgForReasonCode=By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[1]/div/span");
	By txt_description=By.xpath("//textarea[@id='addDescription']");
	By label_errorMsgForDescription=By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[4]/div/span");
	
	By label_errorForMaxDailyMin=By.xpath("//span[@title='Max Daily Minutes can not be more than max weekly minutes']");
	By label_error2ForMaxMinPerInstance=By.xpath("//span[@title='Max Minutes per instance can not be more than max daily minutes']");
	By label_error1ForMaxMinPerInstance=By.xpath("//span[@title='Max Minutes per instance can not be more than max weekly minutes']");
	By txt_startDate_newReasonCode=By.xpath("//*[@id='addReasonStartDate']/span/input");
	By txt_endDate_newReasonCode=By.xpath("//*[@id='addReasonEndDate']/span/input");
	By txt_endDate_updateReasonCode=By.xpath("//input[@name='updateEndDate']");
	By icon_close_newReasonCode=By.xpath("//*[@id='viewAddEditSection']/div[1]/div[2]/a/em");
			
	//By chk_reasonRequiredOnReturn=By.xpath("//app-reason-code[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[6]/div[1]/p-checkbox[1]/div[1]");

	//Edit Reason Code
	By label_pageTitle_editCode=By.xpath("//h3[contains(text(),'Update Reason Code')]");
	By txt_endDate_UpdateReasonCode=By.xpath("//*[@id='updateReasonEndDate']/span/input");

	//common for new/edit
	By txt_maxDailyMin=By.xpath("//app-reason-code[1]/div[1]/div/form[1]/div[2][contains(@class,'active')]/div[2]/div[1]/div[5]/div[1]/input[1]");
	By txt_maxWeeklyMin=By.xpath("//app-reason-code[1]/div[1]/div/form[1]/div[2][contains(@class,'active')]/div[2]/div[1]/div[5]/div[2]/input[1]");
	By txt_maxInstancesPerWeek=By.xpath("//app-reason-code[1]/div[1]/div/form[1]/div[2][contains(@class,'active')]/div[2]/div[1]/div[5]/div[3]/input[1]");
	By txt_maxMinPerInstance=By.xpath("//app-reason-code[1]/div[1]/div/form[1]/div[2][contains(@class,'active')]/div[2]/div[1]/div[5]/div[4]/input[1]");
	By chk_reasonRequiredOnReturn=By.xpath("//app-reason-code[1]/div[1]/div/form[1]/div[2][contains(@class,'active')]/div[2]/div[1]/div[6]/div[1]/p-checkbox[1]/div[1]");
	By btn_save=By.xpath("//div[@id='viewAddEditSection'][contains(@class,'active')]/descendant::button/span[text()='Save']");
	By btn_cancel=By.xpath("//div[@id='viewAddEditSection'][contains(@class,'active')]/descendant::button/span[text()='Cancel']");

	By label_successMsg, label_errorMsg;
	//coypandduplicatebutton
	By btn_Copy_active=By.xpath("//tr[contains(@class,'ng-star-inserted')]//child::td[5]//div[1]//a[1]//em");
	By label_copy_pageTitle=By.xpath("//app-reason-code[1]/div[1]/div[4]/form[1]/div[2]/div[1]/div[1]/h3[1]");
	By btn_save_copy=By.xpath("//span[contains(text(),'Save')]//parent::button[1]");
	By btn_cancel_copy=By.xpath("//*[@id=\"viewAddEditSection\"]/div[1]/div[2]/a//em");
	By btn_copy_inActive=By.xpath("//tr[contains(@class,'hasExpired ng-star-inserted')]//child::td[5]//div[1]//a[1]//em");
	By txt_copyReasoncodeName=By.xpath("//input[@id='updateReason']");
	
	
	WebDriverWait wait=new WebDriverWait(driver,200);
	JavascriptExecutor js=(JavascriptExecutor)driver;
	
	public String getReasoncodenameCopy() {
		String ReasonCodeName=driver.findElement(txt_copyReasoncodeName).getAttribute("value");
		return ReasonCodeName;
	}
	public WebElement clickOnCopyBtnActiveReason() throws InterruptedException {
		Thread.sleep(4000);
		WebElement copy=driver.findElement(btn_Copy_active);
	   	js.executeScript("arguments[0].click()",copy );
	   		return copy;
	}
	public void enterPageTitleforCopy()
	{
		 Random r = new Random();
		 char c = (char)(r.nextInt(26) + 'a');
	      String copyReasoncodeName=driver.findElement(txt_copyReasoncodeName).getAttribute("value");
	      System.out.println("copyReasoncodeName->"+copyReasoncodeName);
	     String newReasonCodeName=copyReasoncodeName+c;
				 
				
		 driver.findElement(txt_copyReasoncodeName).clear();
		 driver.findElement(txt_copyReasoncodeName).sendKeys(newReasonCodeName);
	}
	
	public String getPageTitleforCopy() throws InterruptedException {
		Thread.sleep(5000);
		String PageTitle=driver.findElement(label_copy_pageTitle).getText();
		return PageTitle;
	}
	
	
	public WebElement clickOnCopypBtnInactiveReason() throws InterruptedException {
		Thread.sleep(4000);
		js.executeScript("arguments[0].scrollIntoView();",driver.findElement(btn_copy_inActive) );
		WebElement copy=driver.findElement(btn_copy_inActive);
	   	js.executeScript("arguments[0].click()",copy );
	   		return copy;
	}
	

	public List<String> getActiveCodesList(String colName) 
	{
		wait.until(ExpectedConditions.presenceOfElementLocated(rows_activeReasonCodes));
		int rowSize=driver.findElements(rows_activeReasonCodes).size();
		System.out.println("No of active codes on ReasonCodes Table->"+ rowSize);


		String codeValue=null;
		List<String> ActiveCodesColumnList = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
			switch(colName)
			{
			case "Code Name":
				label_codeName=By.xpath("//table/tbody/tr[not (contains(@class,'hasExpired'))]["+i+"]/td[1]/div");
				codeValue=driver.findElement(label_codeName).getText().trim();
				break;

			case "Description":
				label_description=By.xpath("//table/tbody/tr[not (contains(@class,'hasExpired'))]["+i+"]/td[2]/div");
				codeValue=driver.findElement(label_description).getText().trim();			
				break;

			case "Start Date":
				label_startDate=By.xpath("//table/tbody/tr[not (contains(@class,'hasExpired'))]["+i+"]/td[3]/div");
				codeValue=driver.findElement(label_startDate).getText().trim();	
				break;

			case "End Date":
				label_endDate=By.xpath("//table/tbody/tr[not (contains(@class,'hasExpired'))]["+i+"]/td[4]/div");
				codeValue=driver.findElement(label_endDate).getText().trim();
				break;
			}

			ActiveCodesColumnList.add(codeValue);
		}
		System.out.println("ActiveCodesColumnList Size for Column:"+colName+"="+ActiveCodesColumnList.size());
		return ActiveCodesColumnList;
	}
	public void clickSortCodeName()
	{
		driver.findElement(icon_sortCodeName).click();
	}
	public void clickSortDescription()
	{
		driver.findElement(icon_sortDescription).click();
	}
	public void clickSortStartDate()
	{
		driver.findElement(icon_sortStartDate).click();
	}
	public void clickSortEndDate()
	{
		driver.findElement(icon_sortEndDate).click();
	}
	public int getTotalRows_ReasonCodes() 
	{
		int rowsCount=driver.findElements(rows_reasonCodesTable).size();
		System.out.println("No. of Rows in Reason Codes Table="+rowsCount);
		return rowsCount;
	}
	public int getTotalRecordsShowing_ReasonCodes() {
		String totalRecordsShowingText=driver.findElement(By.xpath("//span[contains(text(),'Total records showing')]")).getText();
		String recordcount=totalRecordsShowingText.substring(totalRecordsShowingText.indexOf("-")+1,totalRecordsShowingText.length()).trim();
		int recordCount=Integer.parseInt(recordcount);
		System.out.println("Count present in message below table->"+recordCount);
		return recordCount;
	}
	public String getPageTitle() 
	{

		return driver.findElement(label_pageTitle).getText();
	}
	public Boolean verifyAddNewTimeTrackingReasonCodeButton() {

		return driver.findElement(btn_addNewTimeTrackingReasonCode).isDisplayed();
	}
	public void clickAddNewTimeTrackingReasonCodeButton() 
	{
		driver.findElement(btn_addNewTimeTrackingReasonCode).click();	
	}
	public String getPageTitle_newReasonCode() {
		return driver.findElement(label_pageTitle_newCode).getText();
	}
	
	public void inputReasonCodeName(String value) {
		driver.findElement(txt_reasonCodeName).sendKeys(value);

	}
	public String getErrorMessageForReasonCodeNameByTitle() {

		return driver.findElement(label_errorMsgForReasonCode).getAttribute("title");

	}
	public String getErrorMessageForReasonCodeNameByText() {
		return driver.findElement(label_errorMsgForReasonCode).getText();
	}

	public void inputDescription(String value) {
		driver.findElement(txt_description).sendKeys(value);

	}
	public String getErrorMessageForDecription() {

		return driver.findElement(label_errorMsgForDescription).getText();
	}

	public void clickSave()		//save click works for both new/edit functions
	{
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", driver.findElement(btn_save));
	}
	public void inputMaxDailyMin(String string) {
		driver.findElement(txt_maxDailyMin).sendKeys(string);		
	}
	public void inputMaxWeeklyMin(String string) {
		driver.findElement(txt_maxWeeklyMin).sendKeys(string);	

	}
	public void inputMaxInstancesPerWeek(String string) {
		driver.findElement(txt_maxInstancesPerWeek).sendKeys(string);	

	}
	public void inputMaxMinPerInstance(String string) {
		driver.findElement(txt_maxMinPerInstance).sendKeys(string);	

	}
	public String getMaxDailyMinValue() {
		return driver.findElement(txt_maxDailyMin).getAttribute("value");

	}
	public String getMaxWeeklyMinValue() {
		return driver.findElement(txt_maxWeeklyMin).getAttribute("value");

	}
	public String getMaxInstancesPerWeekValue() {
		return driver.findElement(txt_maxInstancesPerWeek).getAttribute("value");

	}
	public String getMaxMinPerInstanceValue() {
		return driver.findElement(txt_maxMinPerInstance).getAttribute("value");

	}
	public String getErrorForMaxDailyMin() 
	{
        return driver.findElement(label_errorForMaxDailyMin).getAttribute("title");
	}
	
	
	public String getError1ForMaxMinPerInstance() {

		return driver.findElement(label_error1ForMaxMinPerInstance).getAttribute("title");
	}

	public String getError2ForMaxMinPerInstance() {

		return driver.findElement(label_error2ForMaxMinPerInstance).getAttribute("title");
	}

	
	
	public void selectReasonRequiredOnReturn() {
		driver.findElement(chk_reasonRequiredOnReturn).click();

	}
	public Boolean verifyReasonRequiredOnReturnSelected() {

		return driver.findElement(chk_reasonRequiredOnReturn).getAttribute("class").contains("p-checkbox-checked");
	}
	public void clickEdit_ReasonCode(String rowIndex) throws InterruptedException
	{
		btn_edit_reasonCode=By.xpath("//tbody/tr["+rowIndex+"]/td[5]/div[1]/a[2]");
		driver.findElement(btn_edit_reasonCode).click();
		Thread.sleep(1000);
	}
	public String getPageTitle_editReasonCode() {
		return driver.findElement(label_pageTitle_editCode).getText();
	}
	public void editEndDate_UpdateReasonCode(String newEnddate) {

		driver.findElement(txt_endDate_UpdateReasonCode).sendKeys(Keys.chord(Keys.CONTROL, "a"));
		driver.findElement(txt_endDate_UpdateReasonCode).sendKeys(Keys.DELETE);

		driver.findElement(txt_endDate_UpdateReasonCode).sendKeys(newEnddate);
		driver.findElement(label_pageTitle_editCode).click();	
	}
	public String getSuccessMessage(String action)
	{

		if(action.equalsIgnoreCase("new"))
		{
			label_successMsg=By.xpath("//div[contains(text(),'Reason code has been created successfully')]");
		}else if(action.equalsIgnoreCase("update"))
		{
			label_successMsg=By.xpath("//div[contains(text(),'Reason code has been updated successfully')]");
		}
		String Message=driver.findElement(label_successMsg).getText();
		System.out.println(Message);
		return Message;
	}
	public String getEndDate_ReasonCodeList(String rowIndex) {
		label_endDate=By.xpath("//tbody/tr["+rowIndex+"]/td[4]/div");

		return driver.findElement(label_endDate).getText().trim();
	}

	public String getErrorMsg(String error)
	{
		driver.switchTo().defaultContent();
		label_errorMsg=By.xpath("//div[contains(text(),'"+error+"')]");
		return driver.findElement(label_errorMsg).getText();
	}
	
	
	public void clickCancel()
	{
		driver.findElement(btn_cancel).click();
	}
	public String getStartDate_ReasonCodeList(String rowIndex) {
		label_startDate=By.xpath("//tbody/tr["+rowIndex+"]/td[3]/div");

		return driver.findElement(label_startDate).getText().trim();
	}
	public String getDescription_ReasonCodeList(String rowIndex) {
		label_description=By.xpath("//tbody/tr["+rowIndex+"]/td[2]/div");

		return driver.findElement(label_description).getText().trim();
	}
	public String getReasonCodeName_ReasonCodeList(String rowIndex) {
		label_codeName=By.xpath("//tbody/tr["+rowIndex+"]/td[1]/div");

		return driver.findElement(label_codeName).getText().trim();
	}
	public void clickStartDate_NewReasonCode()
	{
		driver.findElement(txt_startDate_newReasonCode).click();
		System.out.println("StartDate clicked");
	}

	
	public String getStartDate_newReasonCode() {

		return driver.findElement(txt_startDate_newReasonCode).getAttribute("value");
	}
	public String getEndDate_newReasonCode() {
		return driver.findElement(txt_endDate_newReasonCode).getAttribute("value");
	}
	public void clickEndDate_NewReasonCode() {
		driver.findElement(txt_endDate_newReasonCode).click();
		System.out.println("EndDate clicked");
	}
	public void clickEndDate_UpdateReasonCode() {
		driver.findElement(txt_endDate_updateReasonCode).click();
		System.out.println("EndDate clicked");
	}
	
	
	public List<String> getExpiredCodesList() {
		int rowSize=driver.findElements(rows_inActiveReasonCodes).size();
		System.out.println("No of expired codes on ReasonCodes Table->"+ rowSize);

		String codeValue=null;
		List<String> ExpiredCodesColumnList = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
			
				label_codeName=By.xpath("//table/tbody/tr[contains(@class,'hasExpired')]["+i+"]/td[1]/div");
				codeValue=driver.findElement(label_codeName).getText().trim();
				ExpiredCodesColumnList.add(codeValue);
		}
			System.out.println("Expired Codes List Size="+ExpiredCodesColumnList.size());
			return ExpiredCodesColumnList;
	}
	
	public List<String> getUIactivereasoncodelist()
	{
    driver.switchTo().defaultContent();
	List<String> Reasoncodelist = new ArrayList<String>();
				 //    Boolean flag = true;
   
	List<WebElement> rows=driver.findElements(rows_reasonCodesTable);
	List<WebElement> cols;
    int codecount=0;
					 
	for(int j=0;j<rows.size();j++) 
	{
	rows=driver.findElements(rows_reasonCodesTable);
						
	if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
	{ 
	      cols=rows.get(j).findElements(By.tagName("td"));
		 String codes=cols.get(0).getAttribute("title");
							  
		 Reasoncodelist.add(codes);
		 codecount++;
	rows=driver.findElements(rows_reasonCodesTable);
	 }
}
	System.out.println("No of Elements in list->"+codecount);
	System.out.println("No of Elements in list->"+Reasoncodelist.size());
	
    return Reasoncodelist;					
					
}
	

	public void clickDownToExcelbtn()
	{
		System.out.println("Clicking On Export to CSV icon");
		driver.findElement(btn_DownloadToCSV).click();
	}
	
	public void clickDownToPDFbtn()
	{
		System.out.println("Clicking On Export to PDF icon");
		driver.findElement(btn_DownloadToPDF).click();
	}
	
	public void clickCloseicon_neweErrorCode()
	{
		driver.findElement(icon_close_newReasonCode).click();
	}

	public List<WebElement> getSearchResult_rows(String ErrorCodeforSearch) throws InterruptedException
	{
		driver.findElement(input_SearchTextbox).clear();
		driver.findElement(input_SearchTextbox).sendKeys(ErrorCodeforSearch);
		
		Thread.sleep(3000);
		List<WebElement> serachResult_rows=driver.findElements(rows_SearchResult);
		
		return serachResult_rows;
	}
	
	public void search_Click(List<WebElement> rows,String Selectedreasoncode)
	{
		 for(int j=0;j<rows.size();j++)
		   {
			 // btn_edit_reasonCode=By.xpath("//tbody/tr["+rowIndex+"]/td[5]/div[1]/a[2]");
			   btn_searchResult_Reasoncode=By.xpath("//tbody/tr["+(j+1)+"]/td[1]/div[1]");
			   btn_searchResult_Edit=By.xpath("//tbody/tr["+(j+1)+"]/td[5]/div[1]/a[2]/em[1]");
			 
			  if((driver.findElement(btn_searchResult_Reasoncode).getText().equalsIgnoreCase(Selectedreasoncode)))
					  {
				  driver.findElement(btn_searchResult_Edit).click();
		
				  break;
				 }
			   
		   }
		      
	}
	
	public String getEndDate_Searchresult(List<WebElement> rows,String Selectedreasoncode)
	{
		 String Enddate_UI = null;
		 for(int j=0;j<rows.size();j++)
		   {
			 btn_searchResult_Reasoncode=By.xpath("//tbody/tr["+(j+1)+"]/td[1]/div[1]");
			  btn_searchResult_Enddate=By.xpath("//tbody/tr["+(j+1)+"]/td[5]/div[1]/a[2]/em[1]");
	    	  
			   String xpathexp_Enddate="//tbody/tr["+(j+1)+"]/td[4]/div[1]";
			 
			  if((driver.findElement(btn_searchResult_Reasoncode).getText().equalsIgnoreCase(Selectedreasoncode)))
					  {
				  System.out.println(driver.findElement(btn_searchResult_Reasoncode).getText());
				   Enddate_UI=driver.findElement(By.xpath(xpathexp_Enddate)).getText();
				  System.out.println("Enddate_UI->"+Enddate_UI);
		
				  break;
				 }
			   
			   
		   }
		 return Enddate_UI;
	}
	
	
	public List<WebElement> getNumberofRows_UIMainPage() throws InterruptedException
	{
		WebElement webtable=driver.findElement(By.xpath("//app-reason-code/div/div[2]/div/div[3]/p-table/div/div/div/div[2]/table/tbody"));
		
		Thread.sleep(5000);
	     
	     List<WebElement> rows;
	     rows=webtable.findElements(By.tagName("tr"));
	     return rows;
	}
	
	public String getRecordCount_UIMaintable()
	{
		String RecordCountDisplayed=driver.findElement(text_RecordCountDisplayed).getText();
		 String recordcount=RecordCountDisplayed.substring(RecordCountDisplayed.indexOf("-")+1,RecordCountDisplayed.length());
		 System.out.println("Count present in message below table->"+recordcount.trim());
		 return recordcount.trim();
	}
	
	public int getRecordCount_DB() throws SQLException
	{
	 int Count_DB = 0;
		   
		    try
	          {
				
		    	String Query="SELECT count(*) as Count FROM HERO_UI_REASON_CODES";
		    	 Statement stmt = dbcon.createStatement();
		    	 ResultSet rs = stmt.executeQuery(Query);
		           rs.next();
		    	  Count_DB=rs.getInt("Count");
		    	  System.out.println("Reason Code count in DB->"+Count_DB);
		    	  
		             }
		    	  
		    	  
		   catch (NullPointerException err)
		          {
			         System.out.println(err.getMessage());
				 	    }
				 
	  return Count_DB;
		  	
	}
	
	
	public String getLabelClassReasonRequiredonReturnChkbox() throws InterruptedException
	{
		WebElement Label=driver.findElement(label_ReasonRequiredOnReturn);
		
		
		String labelClassInitial=Label.getAttribute("class");
		String labelClassFinal;
		System.out.println("Label Class ->"+labelClassInitial);
		if(labelClassInitial.contains("p-checkbox-label-active"))
		   {
			 System.out.println("Checkbox already checked");
			 labelClassFinal=labelClassInitial;
			 System.out.println("labelClassFinal->"+labelClassFinal);
		   }
		   else
		   {
			   System.out.println("Checkbox not checked");
			   WebElement checkbox=driver.findElement(chkbox_ReasonRequiredOnReturn);
			  //checkbox.click();
				js.executeScript("arguments[0].click()",checkbox );
				Thread.sleep(5000);
			   labelClassFinal=Label.getAttribute("class");
			   System.out.println("labelClassFinal after checking checkbox->"+labelClassFinal); 
		   }
		
		return labelClassFinal;
	}
	
	public void clickToggle() throws InterruptedException
	{
		Thread.sleep(2000);
		WebElement Toggle=driver.findElement(By.xpath("//app-header/div[1]/div[2]/div[1]/ul[1]/li[2]/div[1]/label[1]"));
		Toggle.click();
	}
	
	public String getValidationErrorToggleSwitch(String inputreasoncode)
	{
		driver.switchTo().defaultContent();
		WebElement popup=driver.findElement(popup_toggleSwitch);
		driver.findElement(dropdown_Toggle_SelectReason).click();
		String Xpath_dropdown="//span[contains(text(),'"+inputreasoncode+"')]";
		driver.findElement(By.xpath(Xpath_dropdown)).click();
		driver.findElement(By.xpath("//button[contains(text(),'Save')]")).click();
		
		String Validationerror=driver.findElement(validationError_ReasonDesc_Toggle).getText();
		System.out.println("Error received->"+Validationerror);
		return Validationerror;	
	}
	
	
	
}


