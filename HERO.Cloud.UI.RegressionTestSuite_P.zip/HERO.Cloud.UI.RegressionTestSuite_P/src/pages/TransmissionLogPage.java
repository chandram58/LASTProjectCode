package pages;

import java.io.File;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.asserts.SoftAssert;

import utilities.dbConnector;
import base.base;

public class TransmissionLogPage extends base 
{

 By label_pageTitleTransmissionLog=By.xpath("//a[contains(text(),'Transmission Log')]");
 By dropdown_tradingPartner=By.xpath("//app-transmissionlog-filter[1]/div[1]/div[1]/div[1]/p-multiselect[1]/div[1]/div[2]");
 By multiselectoption_dropdown_tradingPartner=By.xpath("//app-transmissionlog-filter[1]/div[1]/div[1]/div[1]/p-multiselect[1]/div[1]/div[4]/div[1]/div[1]/div[2]");	
 By submissionFromDate=By.xpath("//app-transmissionlog-filter[1]/div[1]/div[1]/div[2]/div[1]/p-calendar[1]/span[1]/input[1]"); 
 By submissionToDate=By.xpath("//app-transmissionlog-filter[1]/div[1]/div[1]/div[3]/div[1]/p-calendar[1]/span[1]/input[1]"); 
 By ClearOption=By.xpath("//span[contains(text(),'Clear')]");
 By TodayOption=By.xpath("//span[contains(text(),'Today')]");
 By dropdown_claimType=By.xpath("//app-transmissionlog-filter[1]/div[1]/div[1]/div[4]/p-multiselect[1]/div[1]/div[2]");
 By multiselectoption_dropdown_claimType=By.xpath("//app-transmissionlog-filter[1]/div[1]/div[1]/div[4]/p-multiselect[1]/div[1]/div[4]/div[1]/div[1]/div[2]/span");	
 By link_ISA_ID=By.xpath("//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr[1]/td[1]/a");
 By link_receivedDate=By.xpath("//tbody/tr[1]/td[12]/a[1]");
 By link_Duplicate=By.xpath("//tbody/tr[7]/td[15]/a[1]");
 By link_ExportToCSV=By.xpath("//em[@class='far fa-file']");
 By label_ResetButton=By.xpath("//button[@class='cancelBtn']");
 By label_ApplyFilterButton=By.xpath("//button[contains(text(),'Apply Filter')]");
 By CalendarSubmissionFrom=By.xpath("//app-transmissionlog-filter/div/div/div[2]/div/p-calendar/span/button/span[1]");
 By PageTitleOutboundTransmissions=By.xpath("//h5[contains(text(),'View Batch SID')]");
 By PageTitleViewAcknowledgement=By.xpath("//h5[contains(text(),'View Acknowledgement')]");
 
//Main page 
   By Sorticon_ISAID_Mainpage=By.xpath("//thead/tr[2]/th[1]/tr[1]/span[1]/p-sorticon[1]/i[1]");
   By RightPaginatorIcon=By.xpath("//app-transmissionlog-list[1]/div[1]/span[1]/p-paginator[1]/div[1]/button[4]/span[1]");
   By webtable_ListofTransmission_mainpage=By.xpath("//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody");
   By rows_ListofTransmission_mainpage=By.tagName("tr");
   By cols_ListofTransmission_mainpage=By.tagName("td");
   
   By ErrorTxt_TradingPartner=By.xpath("//div[contains(text(),'Please select Trading Partner')]");
   By ErrorTxt_From=By.xpath("//div[contains(text(),'Please select From Date')]");
   By ErrorTxt_To=By.xpath("//div[contains(text(),'Please select To Date')]");
   By ErrorTxt_ClaimType=By.xpath("//div[contains(text(),'Please Select Claim Type')]");
   By CloseIconErrorPopup1=By.xpath("//span[contains(@class,'p-toast-icon-close-icon')]");
   By selectTradingPartner=By.xpath("//app-transmissionlog-filter/div/div/div[1]/p-multiselect/div/div[2]");
   By FromDatePicker=By.xpath("//app-transmissionlog-filter[1]/div[1]/div[1]/div[2]/div[1]/p-calendar[1]/span[1]/input[1]");
   By ToDatePicker=By.xpath("//app-transmissionlog-filter[1]/div[1]/div[1]/div[3]/div[1]/p-calendar[1]/span[1]/input[1]");
  
   By lateAckLink=By.xpath("//app-transmissionlog-statistics/section/div/div[2]/p-table/div/div/table/tbody/tr[2]/td[2]/a");
   
   By column_999_Receiveddate=By.xpath("//app-transmission/div/app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr/td[12]/a");
   By column_277CA_Receiveddate=By.xpath("//app-transmission/div/app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr/td[22]/a");
   By column_MA002_Receiveddate=By.xpath("//app-transmission/div/app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr/td[32]/a");
   
   
   
public void clickTradingPatnerDropdownUnselectAllValues()
{
	driver.findElement(dropdown_tradingPartner).click();
	driver.findElement(multiselectoption_dropdown_tradingPartner).click();
	driver.findElement(By.xpath("//html//body")).click();
}
 
 public void clearSubmissionFromDate()
 {
	 wait.until(ExpectedConditions.presenceOfElementLocated(submissionFromDate));
	 driver.findElement(submissionFromDate).click();
     driver.findElement(ClearOption).click();
	} 
 
 public void clearSubmissionToDate()
 {
	 wait.until(ExpectedConditions.presenceOfElementLocated(submissionToDate));
	 driver.findElement(submissionToDate).click();
     driver.findElement(ClearOption).click();
	} 

public void clickClaimTypeDropdownUnselectAllValues()
{
	driver.findElement(dropdown_claimType).click();
	driver.findElement(multiselectoption_dropdown_claimType).click();
	driver.findElement(By.xpath("//html//body")).click();
	
}

public void clickLinkISAID()
{
	wait.until(ExpectedConditions.elementToBeClickable(link_ISA_ID));
	driver.findElement(link_ISA_ID).click();	
}

public String getPageTitleOutboundTransmissions()
{
String PageTitle=driver.findElement(PageTitleOutboundTransmissions).getText();
return PageTitle;
}

public void clickLinkReceiveDate()
{
	driver.findElement(link_receivedDate).click();	
}

public String getPageTitleViewAcknowledgement()
{
String PageTitle=driver.findElement(PageTitleViewAcknowledgement).getText();
return PageTitle;
}


 public void DownloadCSV() throws InterruptedException 
 {
	 driver.findElement(link_ExportToCSV).click();
     Thread.sleep(10000);
 }
 
 public void unselectTradingPartner()
 {
	//Clicking On Trading Partner Dropdown and Unselecting all
	 
	    driver.findElement(dropdown_tradingPartner).click();
		driver.findElement(multiselectoption_dropdown_tradingPartner).click();
		driver.findElement(By.xpath("//html//body")).click(); 
	 }
  
 
 public void clearValueFromField()
 {
     driver.findElement(submissionFromDate).click();
	 driver.findElement(ClearOption).click();
 }

 public void clearValueToField()
 {
     driver.findElement(submissionToDate).click();
	 driver.findElement(ClearOption).click();
         }
 public void unselectClaimType()
 {
	//Clicking On ClaimType Partner Dropdown and Unselecting all
	 driver.findElement(dropdown_claimType).click();
		driver.findElement(multiselectoption_dropdown_claimType).click();
		driver.findElement(By.xpath("//html//body")).click(); 
	    
	 }
  public void clickResetButton()
  {
	  driver.findElement(label_ResetButton).click();  
	  
    }
  
  public void clickApplyFilterButton()
  {
	  driver.findElement(label_ApplyFilterButton).click();  
	  
    }
  
  public void clickCalendarSubmissionFrom()
  {
	  driver.findElement(CalendarSubmissionFrom).click();    
  }
  
 
  public String getDefaultValueTradingPartnerBeforeReset()
  {
	  String DefaultValue_TradingPartner=driver.findElement(dropdown_tradingPartner).getText();
	  System.out.println("DefaultValue_TradingPartner->"+DefaultValue_TradingPartner);
	  return DefaultValue_TradingPartner;
  }
 
  public String getDefaultValueFromBeforeReset()
  {
	  String DefaultValue_From=driver.findElement(submissionFromDate).getAttribute("value");
	  System.out.println("DefaultValue_From->"+DefaultValue_From);
	  return DefaultValue_From;
  }

  public String getDefaultValueToBeforeReset()
  {
	  String DefaultValue_To=driver.findElement(submissionToDate).getAttribute("value");
	  System.out.println("DefaultValue_To->"+DefaultValue_To);
	  return DefaultValue_To;
  }
 
  public String getDefaultValueClaimTypeBeforeReset()
  {
	  String DefaultValue_claimType=driver.findElement(dropdown_claimType).getText();
	  System.out.println("DefaultValue_claimType->"+DefaultValue_claimType);
	  return DefaultValue_claimType;
  } 
  
  public String getDefaultValueTradingPartnerAfterReset()
  {
	  String TradingPartnerAfterReset=driver.findElement(dropdown_tradingPartner).getText();
	  System.out.println("TradingPartnerAfterReset->"+TradingPartnerAfterReset);
	  return TradingPartnerAfterReset;
  }
 
  public String getDefaultValueFromAfterReset()
  {
	  String FromAfterReset=driver.findElement(submissionFromDate).getAttribute("value");
	  System.out.println("FromAfterReset->"+FromAfterReset);
	  return FromAfterReset;
  }

  public String getDefaultValueToAfterReset()
  {
	  String ToAfterReset=driver.findElement(submissionToDate).getAttribute("value");
	  System.out.println("ToAfterReset->"+ToAfterReset);
	  return ToAfterReset;
  }
 
  public String getDefaultValueClaimTypeAfterReset()
  {
	  String claimTypeAfterReset=driver.findElement(dropdown_claimType).getText();
	  System.out.println("claimTypeAfterReset->"+claimTypeAfterReset);
	  return claimTypeAfterReset;
  } 
  
  public String getvalidationTxt_TradingPartner()
  {
	driver.switchTo().defaultContent();
    String validationTxt_TradingPartner=driver.findElement(ErrorTxt_TradingPartner).getText();
    return validationTxt_TradingPartner;
  }
  
  public void closeErrorPopup()
  {
    driver.findElement(CloseIconErrorPopup1).click();
		 //CloseIconErrorPopup1.click();
	//((JavascriptExecutor)driver).executeScript("arguments[0].click();", CloseIconErrorPopup1);
		 
  }
  
  public String getvalidationTxt_From()
  {
	driver.switchTo().defaultContent();
    String validationTxt_From=driver.findElement(ErrorTxt_From).getText();
    return validationTxt_From;
  }
  
  public void selectFromDate()
  {
	 System.out.println("Clicking FROM Date picker");
// test.log(LogStatus.INFO, "Clicking FROM Date picker");
	 driver.findElement(FromDatePicker).click();
	 driver.findElement(TodayOption).click();	
	   }
  
  
  public String getvalidationTxt_To()
  {
	driver.switchTo().defaultContent();
    String validationTxt_To=driver.findElement(ErrorTxt_To).getText();
    return validationTxt_To;
  }  
  
  public String getvalidationTxt_claimType()
  {
	driver.switchTo().defaultContent();
    String validationTxt_ClaimType=driver.findElement(ErrorTxt_ClaimType).getText();
    return validationTxt_ClaimType;
  }  
  
	    
  public void selectToDate() throws InterruptedException
  {
	 System.out.println("Clicking To Date picker");
// test.log(LogStatus.INFO, "Clicking FROM Date picker");
	 driver.findElement(ToDatePicker).click();
	 Thread.sleep(4000);
	 driver.findElement(TodayOption).click();	
	   }	
  
  
  
  
  //Entering value in Trading Partner field 
  public void selectValueTradingPartner() throws InterruptedException
  {
	  
	driver.findElement(selectTradingPartner).click();
	//wait.until(ExpectedConditions.elementToBeClickable(label_TradingPartner));
    System.out.println("Clicking on Trading partner dropdown Field");
   
    //((JavascriptExecutor)driver).executeScript("arguments[0].click();", TradingPartnerDropDown);

		
   //Selecting Drop down value
		 
     Thread.sleep(2000);
    // test.log(LogStatus.INFO, "Selecting Drop down value");
     System.out.println("Selecting Drop down value");
	//wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//p-dropdownitem[1]/li[1]/span[1]")));
     
     driver.findElement(multiselectoption_dropdown_tradingPartner).click();
     driver.findElement(By.xpath("//html//body")).click();  
	  
       }
  
  
  
  
  public void clickSorticon_ListofTransmissions_ISAID()
  {
  driver.findElement(Sorticon_ISAID_Mainpage).click();
  }
  
  public void clickRightPaginatorIcon_ListofTransmissions()
  {
  driver.findElement(RightPaginatorIcon).click();
  }
  
  
  public List<String> ascendingOrderList_ListofTransmissions_ISAID()
  {
	  WebElement webtable_ISAID_asc_mainpage=driver.findElement(webtable_ListofTransmission_mainpage);
	  List<WebElement> rows_ISAID_asc=webtable_ISAID_asc_mainpage.findElements(rows_ListofTransmission_mainpage);
	  List<WebElement> cols_ISAID_asc=rows_ISAID_asc.get(0).findElements(cols_ListofTransmission_mainpage);
	  System.out.println(rows_ISAID_asc.size());
	  System.out.println( cols_ISAID_asc.size()); 
			
//Getting Rows list
				 
	 List<String> rows_ISAID_ascList = new ArrayList<String>();
     for(int j=0;j<rows_ISAID_asc.size();j++)
		 {
		 //System.out.println(rows_Rolename_asc.get(j).getText().replace("\n", " "));
    	 rows_ISAID_ascList.add(rows_ISAID_asc.get(j).getText().replace("\n", " ")); 
    	 rows_ISAID_asc=webtable_ISAID_asc_mainpage.findElements(rows_ListofTransmission_mainpage);
			 }
     return rows_ISAID_ascList;
	}
	
		
	

  public List<String> descendingOrderList_ListofTransmissions_ISAID() throws InterruptedException
  {
	//Go to last page first
	  driver.findElement(RightPaginatorIcon).click();
	  
	  Thread.sleep(3000);
	  
	  WebElement webtable_ISAID_desc_mainpage=driver.findElement(webtable_ListofTransmission_mainpage);
	  List<WebElement> rows_ISAID_desc=webtable_ISAID_desc_mainpage.findElements(rows_ListofTransmission_mainpage);
	  List<WebElement> cols_ISAID_desc=rows_ISAID_desc.get(0).findElements(cols_ListofTransmission_mainpage);
	  
	  System.out.println(rows_ISAID_desc.size());
	  System.out.println( cols_ISAID_desc.size()); 
				 
		//Getting Rows List		
	   List<String> rows_ISAID_descList = new ArrayList<String>();
  
	   for(int j=0;j<rows_ISAID_desc.size();j++)
		 {
	     //System.out.println(rows_Rolename_asc.get(j).getText().replace("\n", " "));
		   rows_ISAID_descList.add(rows_ISAID_desc.get(j).getText().replace("\n", " ")); 
						
		  }
		 
   return rows_ISAID_descList; 
  }
  
  public List<String> getList_UI()
  {
	  WebElement webtable_ISAID_mainpage=driver.findElement(webtable_ListofTransmission_mainpage);
	  List<WebElement> rows_ISAID=webtable_ISAID_mainpage.findElements(rows_ListofTransmission_mainpage);
	  List<WebElement> cols_ISAID=rows_ISAID.get(0).findElements(cols_ListofTransmission_mainpage);
	  System.out.println(rows_ISAID.size());
	  System.out.println(cols_ISAID.size()); 
			
   //Getting list from UI
	
	  int Count_UI=0;
      List<String> rows_ISAID_Status_UIList = new ArrayList<String>();
     for(int j=0;j<rows_ISAID.size();j++)
		 {
    	String Xpath_ISAID="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(j+1)+"]/td[1]";
		String Xpath_Status="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(j+1)+"]/td[41]";
		

    	String ISA_ID_UI=driver.findElement(By.xpath(Xpath_ISAID)).getText();
    
         //System.out.println(ISA_ID_UI);
    	 
         String Status_UI=driver.findElement(By.xpath(Xpath_Status)).getText();
    
    	// System.out.println(Status_UI);
		 
    	 rows_ISAID_Status_UIList.add(ISA_ID_UI.trim()+' '+Status_UI.trim());
    	 Count_UI++;
			 }
     System.out.println("Record Count UI->"+Count_UI );
     return rows_ISAID_Status_UIList;
	}
 
  
  public List<String> getList_DB() throws SQLException
  {		
   //Getting list from DB
	 String ISA_ID_DB,STATUS_DB;
	  int Count_DB=0;
	  List<String> rows_ISAID_Status_DBList = new ArrayList<String>();
	  try
      {
		
    	String Query1="select TOP 100 ISA_ID,ACK_STATUS from HERO_UI_TRANSMISSION_LOGS_ACK "; 
    	System.out.println(utilities.dbConnector.dbcon);
    	Statement stmt=dbcon.createStatement();  
    	  rs = stmt.executeQuery(Query1);
    	  System.out.println(rs.next());
    	  
    	
    	  do {
    		ISA_ID_DB=rs.getString(1);
    		//System.out.println(ISA_ID_DB);
    		STATUS_DB=rs.getString(2);
    		//System.out.println(STATUS_DB);
    		
    		
    		rows_ISAID_Status_DBList.add(ISA_ID_DB.trim()+' '+STATUS_DB.trim());
    		Count_DB++;	 
		 	     }while(rs.next());
    				
    	
      }		 
		 			
      catch (NullPointerException err)
          {
	         err.getMessage();
		 	    }
	  System.out.println("Record Count DB->"+Count_DB );
      return rows_ISAID_Status_DBList;	
	}
  
  
    public void clickLateAcklink()
    {
    	wait.until(ExpectedConditions.elementToBeClickable(lateAckLink));
    	driver.findElement(lateAckLink).click();
    }
  
   public void ElaspedDateHighlightVerification_999()
   {
		 SoftAssert softAssert = new SoftAssert();
		 
		 String xpath_ReceivedDate,xpath_LoadDate,xpath_Elapsed_Time;
		 String Val_ElapsedTime999Acks,Class_ElapsedTime999Acks;
		 
		 
		 List<WebElement> columnval_999_Receiveddate=driver.findElements(column_999_Receiveddate);
		 System.out.println("No of Rows in Transmission table->"+columnval_999_Receiveddate.size());
		 
		 
		 
		 for(int k=0;k<columnval_999_Receiveddate.size();k++)
		 {
		 xpath_ReceivedDate="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[12]";
		 xpath_LoadDate="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[13]";
		 xpath_Elapsed_Time="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[14]";
		 
		 WebElement ReceivedDate_Col_val=driver.findElement(By.xpath(xpath_ReceivedDate));
		 WebElement LoadDate_Col_val=driver.findElement(By.xpath(xpath_LoadDate)); 
		  if(ReceivedDate_Col_val.getText().isEmpty() && LoadDate_Col_val.getText().isEmpty())
			  {
			  Val_ElapsedTime999Acks=driver.findElement(By.xpath(xpath_Elapsed_Time)).getText();
			  System.out.println("Elasped time Value in 999 Acks->"+Val_ElapsedTime999Acks);
			   Class_ElapsedTime999Acks=driver.findElement(By.xpath(xpath_Elapsed_Time)).getAttribute("class");
			  System.out.println("Elasped time Column class in 999 Acks->"+Class_ElapsedTime999Acks);
			  softAssert.assertTrue(Class_ElapsedTime999Acks.contains("columnHilighter"), "Elasped Time Column in 999 Ack not highlighted");
		       
			  }
	       
		  else
		  {
			System.out.println("Elapsed Days Values in 999 Ack is blank ") ; 
		  }
       }
		 softAssert.assertAll();  
   }
  
   public void ElaspedDateHighlightVerification_277CA()
   {
	   SoftAssert softAssert = new SoftAssert();
		 
		 String xpath_ReceivedDate_999,xpath_LoadDate_999,xpath_Elapsed_Time_999;
		 String xpath_ReceivedDate_277CA,xpath_LoadDate_277CA,xpath_Elapsed_Time_277CA;
		 String Val_ElapsedTime_999Ack,Class_ElapsedTime_999Ack;
		 String Val_ElapsedTime_277CAAck,Class_ElapsedTime_277CAAck;
		 
		 List<WebElement> columnval_277CA_Receiveddate=driver.findElements(column_277CA_Receiveddate);
		 System.out.println("No of Rows in Transmission table->"+columnval_277CA_Receiveddate.size());
		 
		 
		 
		 for(int k=0;k<columnval_277CA_Receiveddate.size();k++)
		 {
		 xpath_ReceivedDate_999="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[12]";
		 xpath_LoadDate_999="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[13]";
		 xpath_ReceivedDate_277CA="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[22]";
		 xpath_LoadDate_277CA="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[23]";
		 
		 xpath_Elapsed_Time_277CA="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[24]";
		 
		 WebElement ReceivedDate_Col_val_999=driver.findElement(By.xpath(xpath_ReceivedDate_999));
		 WebElement LoadDate_Col_val_999=driver.findElement(By.xpath(xpath_LoadDate_999)); 
		 
		 WebElement ReceivedDate_Col_val_277CA=driver.findElement(By.xpath(xpath_ReceivedDate_277CA));
		 WebElement LoadDate_Col_val_277CA=driver.findElement(By.xpath(xpath_LoadDate_277CA)); 
		 
		 
		 
		  if((!(ReceivedDate_Col_val_999.getText().isEmpty())) && (!(LoadDate_Col_val_999.getText().isEmpty())) && ReceivedDate_Col_val_277CA.getText().isEmpty() && LoadDate_Col_val_277CA.getText().isEmpty())
			  {
			  Val_ElapsedTime_277CAAck=driver.findElement(By.xpath(xpath_Elapsed_Time_277CA)).getText();
			  System.out.println("Elasped time Value in 277CA Acks->"+Val_ElapsedTime_277CAAck);
			  Class_ElapsedTime_277CAAck=driver.findElement(By.xpath(xpath_Elapsed_Time_277CA)).getAttribute("class");
			  System.out.println("Elasped time Column class in 999 Acks->"+Class_ElapsedTime_277CAAck);
			  softAssert.assertTrue(Class_ElapsedTime_277CAAck.contains("columnHilighter"), "Elasped Time Column in 277CA Ack not highlighted");
		       
			  }
	       
		  else
		  {
			System.out.println("Elapsed Days Values in 277 CA Ack is blank ") ; 
		  }
         
		 
		 
		 }
		 
		

	 softAssert.assertAll();
   
   }
  
   public void ElaspedDateHighlightVerification_MA002() throws InterruptedException
   {
	   Thread.sleep(5000);
		 
		 SoftAssert softAssert = new SoftAssert();
		 
		
		 String xpath_ReceivedDate_277CA,xpath_LoadDate_277CA,xpath_Elapsed_Time_277CA;
		 String xpath_ReceivedDate_MAO002,xpath_LoadDate_MAO002,xpath_Elapsed_Time_MAO002;
		
		 String Val_ElapsedTime_MAO002Ack,Class_ElapsedTime_MAO002Ack;
		 
		 List<WebElement> columnval_MA0002_Receiveddate=driver.findElements(column_MA002_Receiveddate);
		 System.out.println("No of Rows in Transmission table->"+columnval_MA0002_Receiveddate.size());
		 
		 
		 
		 for(int k=0;k<columnval_MA0002_Receiveddate.size();k++)
		 {
		
		 xpath_ReceivedDate_277CA="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[22]";
		 xpath_LoadDate_277CA="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[23]";
		 
		 xpath_ReceivedDate_MAO002="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[32]";
		 xpath_LoadDate_MAO002="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[33]";
		 
		 
		 xpath_Elapsed_Time_MAO002="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[34]";
		 
		
		 
		 WebElement ReceivedDate_Col_val_277CA=driver.findElement(By.xpath(xpath_ReceivedDate_277CA));
		 WebElement LoadDate_Col_val_277CA=driver.findElement(By.xpath(xpath_LoadDate_277CA)); 
		 
		 WebElement ReceivedDate_Col_val_MAO002=driver.findElement(By.xpath(xpath_ReceivedDate_MAO002));
		 WebElement LoadDate_Col_val_MAO002=driver.findElement(By.xpath(xpath_LoadDate_MAO002));
		 
		  if((!(ReceivedDate_Col_val_277CA.getText().isEmpty())) && (!(LoadDate_Col_val_277CA.getText().isEmpty())) && ReceivedDate_Col_val_MAO002.getText().isEmpty() && LoadDate_Col_val_MAO002.getText().isEmpty())
			  {
			  Val_ElapsedTime_MAO002Ack=driver.findElement(By.xpath(xpath_Elapsed_Time_MAO002)).getText();
			  System.out.println("Elasped time Value in MAO002 Acks->"+Val_ElapsedTime_MAO002Ack);
			  Class_ElapsedTime_MAO002Ack=driver.findElement(By.xpath(xpath_Elapsed_Time_MAO002)).getAttribute("class");
			  System.out.println("Elasped time Column class in MAO002 Acks->"+Class_ElapsedTime_MAO002Ack);
			  softAssert.assertTrue(Class_ElapsedTime_MAO002Ack.contains("columnHilighter"), "Elasped Time Column in 277CA Ack not highlighted");
		       
			  }
	       
		  else
		  {
			System.out.println("Elapsed Days Values in MAO-002 Ack is blank ") ; 
		  }
         
	 }
		 
		softAssert.assertAll();
   }
  
  
  public void verifyLinks_ISAID()
  {
	  List<WebElement> columnval_277CA_Receiveddate=driver.findElements(By.xpath("//app-transmissionlog-list/div/p-table/div/div/div/div[2]/table/tbody/tr/td[22]/a"));
		 System.out.println("No of Rows in Transmission table->"+columnval_277CA_Receiveddate.size());
		 
  //String Xpath_ISAID="//app-transmissionlog-list/div/p-table/div/div/div/div[2]/table/tbody/tr["+(j+1)+"]/td[1]/a";
  
  }
   
   public void verifyAckSequenceVerification() throws ParseException
   {
	   SoftAssert softAssert = new SoftAssert();
		 
		 String xpath_ReceivedDate_999,xpath_LoadDate_999;
		 String xpath_ReceivedDate_277CA,xpath_LoadDate_277CA;
		 String xpath_ReceivedDate_MAO002,xpath_LoadDate_MAO002;
		 String xpath_ReceivedDate_MAO001,xpath_LoadDate_MAO001;
		 String xpath_ElaspedDate_999,xpath_ElaspedDate_277CA,xpath_ElaspedDate_MAO002;
		 String xpath_AckStatus;
		
		

		 
		 List<WebElement> columnval_999_Receiveddate=driver.findElements(By.xpath("//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr/td[22]/a"));
		 System.out.println("No of Rows in Transmission table->"+columnval_999_Receiveddate.size());
		 
		 int correctSequenceAckcount=0;
		 
		 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		
		 
		 for(int k=0;k<20;k++)
		 {

				
					 
			     xpath_ReceivedDate_999="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[12]";
			     xpath_LoadDate_999="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[13]";	 
			    
			     
				 xpath_ReceivedDate_277CA="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[22]";
				 xpath_LoadDate_277CA="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[23]";
			
				 
				 xpath_ReceivedDate_MAO002="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[32]";
				 xpath_LoadDate_MAO002="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[33]";
				
				 
				 xpath_ReceivedDate_MAO001="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[39]";
				 xpath_LoadDate_MAO001="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[40]";
				 
				 
				 xpath_AckStatus="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[41]";
				
				 
				

				 WebElement ReceivedDate_Col_val_999=driver.findElement(By.xpath(xpath_ReceivedDate_999));
				 WebElement LoadDate_Col_val_999=driver.findElement(By.xpath(xpath_LoadDate_999));
				
				 
				 WebElement ReceivedDate_Col_val_277CA=driver.findElement(By.xpath(xpath_ReceivedDate_277CA));
				 WebElement LoadDate_Col_val_277CA=driver.findElement(By.xpath(xpath_LoadDate_277CA)); 
				
				 
				 
				 WebElement ReceivedDate_Col_val_MAO002=driver.findElement(By.xpath(xpath_ReceivedDate_MAO002));
				 WebElement LoadDate_Col_val_MAO002=driver.findElement(By.xpath(xpath_LoadDate_MAO002));
				
				 
				 WebElement ReceivedDate_Col_val_MAO001=driver.findElement(By.xpath(xpath_ReceivedDate_MAO001));
				 WebElement LoadDate_Col_val_MAO001=driver.findElement(By.xpath(xpath_LoadDate_MAO001));
				 
				
		  if((!(ReceivedDate_Col_val_999.getText().isEmpty())) && (!(ReceivedDate_Col_val_277CA.getText().isEmpty())) && ReceivedDate_Col_val_MAO002.getText().isEmpty() && ReceivedDate_Col_val_MAO001.getText().isEmpty())
			  {
			   
				 Date ReceivedDate_Col_val_999_dateformat = sdf.parse(ReceivedDate_Col_val_999.getText().trim());
				 Date ReceivedDate_Col_val_277CA_dateformat = sdf.parse(ReceivedDate_Col_val_277CA.getText().trim());
				 
			  softAssert.assertTrue(ReceivedDate_Col_val_999_dateformat.before(ReceivedDate_Col_val_277CA_dateformat), "999 and 277CA acks not coming in proper order");
			  String Ack_Status_Col_value=driver.findElement(By.xpath(xpath_AckStatus)).getText();
			  System.out.println("Ack_Status_Col_value->"+Ack_Status_Col_value);
			  
			  correctSequenceAckcount++;
			  }
		  else if((!(ReceivedDate_Col_val_999.getText().isEmpty())) && (!(ReceivedDate_Col_val_277CA.getText().isEmpty())) && (!(ReceivedDate_Col_val_MAO002.getText().isEmpty())) && ReceivedDate_Col_val_MAO001.getText().isEmpty())
		  {
			  Date ReceivedDate_Col_val_999_dateformat = sdf.parse(ReceivedDate_Col_val_999.getText().trim());
			 Date ReceivedDate_Col_val_277CA_dateformat = sdf.parse(ReceivedDate_Col_val_277CA.getText().trim());
			 Date ReceivedDate_Col_val_MAO002_dateformat = sdf.parse(ReceivedDate_Col_val_MAO002.getText().trim());
				 
			  softAssert.assertTrue(ReceivedDate_Col_val_999_dateformat.before(ReceivedDate_Col_val_277CA_dateformat) && ReceivedDate_Col_val_277CA_dateformat.before(ReceivedDate_Col_val_MAO002_dateformat), "999,277CA and MAO002 acks not coming in proper order");
			  String Ack_Status_Col_value=driver.findElement(By.xpath(xpath_AckStatus)).getText();
			  System.out.println("Ack_Status_Col_value->"+Ack_Status_Col_value);
			  correctSequenceAckcount++;
		  }
		 
		  else if((!(ReceivedDate_Col_val_999.getText().isEmpty())) && (!(ReceivedDate_Col_val_277CA.getText().isEmpty())) && (!(ReceivedDate_Col_val_MAO002.getText().isEmpty())) && (!(ReceivedDate_Col_val_MAO001.getText().isEmpty())))
		  {
			  Date ReceivedDate_Col_val_999_dateformat = sdf.parse(ReceivedDate_Col_val_999.getText().trim());
				 Date ReceivedDate_Col_val_277CA_dateformat = sdf.parse(ReceivedDate_Col_val_277CA.getText().trim());
				 Date ReceivedDate_Col_val_MAO002_dateformat = sdf.parse(ReceivedDate_Col_val_MAO002.getText().trim());
				 Date ReceivedDate_Col_val_MAO001_dateformat = sdf.parse(ReceivedDate_Col_val_MAO001.getText().trim());
				 
				 
				  softAssert.assertTrue(ReceivedDate_Col_val_999_dateformat.before(ReceivedDate_Col_val_277CA_dateformat) && ReceivedDate_Col_val_277CA_dateformat.before(ReceivedDate_Col_val_MAO002_dateformat) &&ReceivedDate_Col_val_MAO002_dateformat.before(ReceivedDate_Col_val_MAO001_dateformat), "999,277CA ,MAO002,MAO001 acks not coming in proper order");
				  String Ack_Status_Col_value=driver.findElement(By.xpath(xpath_AckStatus)).getText();
				  System.out.println("Ack_Status_Col_value->"+Ack_Status_Col_value);
				  correctSequenceAckcount++;
		  } 
		 
		 
		 }
		 
		 System.out.println("correct Sequence Ack count->"+correctSequenceAckcount);
		

	 softAssert.assertAll();  
	   
	  }

    public void verifyElapseDaysFullyRejectedScenario()
    {
    	 SoftAssert softAssert = new SoftAssert();
    	
    	String xpath_ReceivedDate_TA1 = null,xpath_LoadDate_TA1 = null;
    	 String xpath_ElaspedDate_999 = null,xpath_ElaspedDate_277CA = null,xpath_ElaspedDate_MAO002 = null;
    	 String xpath_AckStatus = null,xpath,xpath_RejectedReason = null;
    	 String Ack_Status,Rejected_Reason = null;
    	 
    	 List<WebElement> columnval_TA1_Receiveddate=driver.findElements(By.xpath("//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr/td[8]/a"));
		 System.out.println("No of Rows in Transmission table->"+columnval_TA1_Receiveddate.size());
		 
		 int correctSequenceAckcount=0;
		 
		 SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		 
		 for(int k=0;k<columnval_TA1_Receiveddate.size();k++)
		 {
		 
			 xpath_ReceivedDate_TA1="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[8]";
		     xpath_LoadDate_TA1="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[9]";	 
					    
		     xpath_ElaspedDate_999="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[14]";
		     xpath_ElaspedDate_277CA="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[24]";
		     xpath_ElaspedDate_MAO002="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[34]";
		        
		        
		    	
		     xpath_AckStatus="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[41]";
		     xpath_RejectedReason="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[42]";
		    		 
			 
		 
		 WebElement ReceivedDate_Col_val_TA1=driver.findElement(By.xpath(xpath_ReceivedDate_TA1));
		 WebElement LoadDate_Col_val_TA1=driver.findElement(By.xpath(xpath_LoadDate_TA1));
		
		 WebElement ElaspedDate_999=driver.findElement(By.xpath(xpath_ElaspedDate_999));
		 WebElement ElaspedDate_277CA=driver.findElement(By.xpath(xpath_ElaspedDate_277CA));
		 WebElement ElaspedDate_MAO002=driver.findElement(By.xpath(xpath_ElaspedDate_MAO002));
		 
		 Ack_Status=driver.findElement(By.xpath(xpath_AckStatus)).getText();
		 xpath_AckStatus=driver.findElement(By.xpath(xpath_RejectedReason)).getText();
		 

    	 if((!(ReceivedDate_Col_val_TA1.getText().isEmpty())) && (!(LoadDate_Col_val_TA1.getText().isEmpty())))
    			 {
    		  
    		 softAssert.assertTrue(ElaspedDate_999.getText().isEmpty(), "Elasped date for 999 Ack is not empty for fully rejected scenario");
    		 softAssert.assertTrue(ElaspedDate_277CA.getText().isEmpty(), "Elasped date for 277 CA Ack is not empty for fully rejected scenario");
    		 softAssert.assertTrue(ElaspedDate_MAO002.getText().isEmpty(), "Elasped date for MAO002 Ack is not empty for fully rejected scenario");
    		 softAssert.assertTrue(Ack_Status.equalsIgnoreCase("Rejected"), "Ack Status not rejected for fully rejected scenario");
    		 softAssert.assertTrue(Rejected_Reason.contains("TA1"), "TA1 not mentioned in Rejected reason for fully rejected scenario");
    		 
    			 }
    	 softAssert.assertAll();
    	    }
    	
    }
   
    
    
    
    
   public void verifyLink_ListofTransmissions()
   {
	   SoftAssert softAssert = new SoftAssert();
   	
   	String xpath_ReceivedDate_TA1 = null,xpath_ReceivedDate_999=null,xpath_ReceivedDate_277CA=null,xpath_ReceivedDate_MAO002=null,xpath_ReceivedDate_InvalidResponse=null,xpath_ReceivedDate_MAO001=null;
   	String xpath_Duplicates_999=null,xpath_Duplicates_277CA=null,xpath_Duplicates_MAO002=null;
   	String xpath_ISAID=null;
   	
	 List<WebElement> columnval_999_Receiveddate=driver.findElements(By.xpath("//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr/td[22]/a"));
	 System.out.println("No of Rows in Transmission table->"+columnval_999_Receiveddate.size());
	 
	 List<WebElement> link=driver.findElements(By.tagName("a"));
	
	 for(int j=0;j<link.size();j++)
	 {
		 //System.out.println("All Links->"+link.get(j).getText());
	 }
	 
	 for(int k=0;k<columnval_999_Receiveddate.size();k++)
	 {
		 xpath_ISAID="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[1]"; 
		 xpath_ReceivedDate_TA1="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[8]";
		 xpath_ReceivedDate_999="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[12]";
		 xpath_ReceivedDate_277CA="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[22]";
		 xpath_ReceivedDate_MAO002="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[32]";
		 xpath_ReceivedDate_MAO001="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[39]";
	    
		 xpath_Duplicates_999="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[15]";
		 xpath_Duplicates_277CA="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[25]";
		 xpath_Duplicates_MAO002="//app-transmissionlog-list/div/div[2]/p-table/div/div/table/tbody/tr["+(k+1)+"]/td[35]";
		 
		 List<WebElement> ISAID=driver.findElements(By.xpath(xpath_ISAID));
		 WebElement ReceivedDate_TA1=driver.findElement(By.xpath(xpath_ReceivedDate_TA1));
		 WebElement ReceivedDate_999=driver.findElement(By.xpath(xpath_ReceivedDate_999));
		 WebElement ReceivedDate_277CA=driver.findElement(By.xpath(xpath_ReceivedDate_277CA));
		 WebElement ReceivedDate_MAO002=driver.findElement(By.xpath(xpath_ReceivedDate_MAO002));
		 WebElement ReceivedDate_MAO001=driver.findElement(By.xpath(xpath_ReceivedDate_MAO001));
		 
		 WebElement Duplicates_999=driver.findElement(By.xpath(xpath_Duplicates_999));
		 WebElement Duplicates_277CA=driver.findElement(By.xpath(xpath_Duplicates_277CA));
		 WebElement Duplicates_MAO002=driver.findElement(By.xpath(xpath_Duplicates_MAO002));
		 
		 softAssert.assertTrue(link.containsAll(ISAID), "ISA ID values not hyperlinked");
		 
		 softAssert.assertAll();
	 }
	   
   }
   
   
   
   
   
   
   
   
  }