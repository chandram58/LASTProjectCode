package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.base;

public class RecordProductivityTimePage extends base
{

By label_toggle=By.xpath("//label[contains(@class,'onOffSwitch')]");
By span_clock=By.xpath("//li[@class='clockTime ng-star-inserted']//div[@class='ng-star-inserted']");
By txt_toggleActiveTime	=By.xpath("//span[@class='onTime']");
By txt_activeHoursUserDashboard=By.xpath("//li[1]//span[@class='legend-value']");
By dropdown_toggle=By.xpath("//span[contains(text(),'Select Reason')]");
By list_reasoncodetoggle=By.xpath("//ul/p-dropdownitem/li/span");
By btn_Logout=By.xpath("//em[@class='fas fa-sign-out-alt']");


	
public WebElement getToggle()
{
WebElement togglebtn=driver.findElement(label_toggle);
return togglebtn;
}
	
public WebElement getClock()
{
	WebElement clockbtn=driver.findElement(span_clock);
	return clockbtn;	
}	

public String getToggleActiveTime()
{ 
	wait.until(ExpectedConditions.presenceOfElementLocated(txt_toggleActiveTime));
	String time=driver.findElement(txt_toggleActiveTime).getText();
	return time;
}

public String getActiveHoursUserDashboard()
{
	wait.until(ExpectedConditions.presenceOfElementLocated(txt_activeHoursUserDashboard));
	String activehours=driver.findElement(txt_activeHoursUserDashboard).getText();
	return activehours;
}
	
public void clicktoggleResonDropdown()
{
	wait.until(ExpectedConditions.elementToBeClickable(dropdown_toggle));
	driver.findElement(dropdown_toggle).click();
	
}

public List<String> reasonListToggle()
{
  List<WebElement> reasonList=driver.findElements(list_reasoncodetoggle);
  System.out.println("Number of Elements in Dropdown->"+reasonList.size());
  List<String> reasoncodeList=new ArrayList<String>();
  
  for(int k=1;k<=reasonList.size();k++)
  {
	 String code=driver.findElement(By.xpath("//ul/p-dropdownitem["+k+"]/li/span")).getText();
	 reasoncodeList.add(code);
  }
	return reasoncodeList; 
}


public void clickLogout()
{
	wait.until(ExpectedConditions.elementToBeClickable(btn_Logout));
	driver.findElement(btn_Logout).click();

}


	
}
