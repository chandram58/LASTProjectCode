package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.base;

public class TimeCardManagementpage extends base{
	
	//NewTimeCard
  By btn_newtimecard=By.xpath("//span[contains(text(),'Add New Timecard')]//parent::button[1]");
  By label_newtimecardtitle=By.xpath("//h3[contains(text(),'New Time Card')]");
  By btn_endTime_newcard=By.xpath("//p-calendar[@id='timecardEndTime']//child::span");
  By label_userdp=By.xpath("//p-dropdown[@name='userId']//div[1]");
  By searchuserfrmDp=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[1]/p-dropdown/div/div[3]/div[1]/div/input");
  By selectUserDp7=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[1]/p-dropdown/div/div[3]/div[2]/ul/p-dropdownitem[1]/li");
  By btn_timecardDate=By.xpath("//*[@id=\"timecardDate\"]/span");
  By btn_endTimeSelect=By.xpath("/html/body/div/div/div[1]/button[1]");
  By btn_StartTime_newcard=By.xpath("//p-calendar[@id='timecardStartTime']//span");
  By btn_startTimeselect=By.xpath("/html/body/div/div/div[1]/button[1]/span");
  By btn_Endtimestampselect=By.xpath("/html/body/div/div/div[4]/button[1]/span");
  By label_productivehrs=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[2]/div/div");
  By label_Nonproductivehrs=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[3]/div/div");
  By btn_save=By.xpath("//span[contains(text(),'Save')]");
  //timecard filter section
  By label_user=By.xpath("//p-multiselect[contains(@name,'searchUser')]//child::div[2]");
  By search_user=By.xpath("//app-timecard/div/form/div/div/div/div/div/div[1]/div/form/div/div[1]/div[1]/p-multiselect/div/div[4]/div[1]/div[2]/input");
  By userDp=By.xpath("//app-timecard/div/form/div/div/div/div/div/div[1]/div/form/div/div[1]/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem[1]/li");
  By label_startdate=By.xpath("//*[@id=\"startDate\"]/span");
  By label_endDate=By.xpath("//*[@id=\"endDate\"]/span");
  By btn_filter=By.xpath("//span[contains(text(),'Apply Filter')]");
  //results table
  By btn_delete=By.xpath("//a[contains(@title,'Delete')]/i");
  By result_tablehistory=By.xpath("//app-timecard/div/form/div/div/div[2]/div[2]/p-table/div/div/table/tbody/tr");
  By btn_ok=By.xpath("//span[contains(text(),'OK')]");
  By popup_deletemessage=By.xpath("//div[contains(text(),'Timecard has been deleted successfully')]");
  By btn_reset=By.xpath("//span[contains(text(),'Reset')]");
  By popup_errormessage=By.xpath("//div[contains(text(),'Please select users.')]");
  
  //table values  fetching from main screen
  By producthrs=By.xpath("//app-timecard/div/form/div/div/div[2]/div[2]/p-table/div/div/table/tbody/tr[1]/td[3]");
  By btn_edit=By.xpath("//a[contains(@title,'Edit')]");
  By label_Dates=By.xpath("//app-timecard/div/form/div/div/div[2]/div[2]/p-table/div/div/table/tbody/tr[1]/td[2]");
  //updatepage
  By prdcthrsinupdate=By.xpath("//app-timecard/div[2]/form/div[2]/div[2]/div[2]/div/div");
  By btn_close=By.xpath("//*[@id=\"closePopBtn\"]/em");
  By btn_update_ok=By.xpath("//span[contains(text(),'OK')]");
  //NEW card
  By btn_addrecord=By.xpath("//span[contains(text(),'Add Record')]");
  By label_resoncode=By.xpath("//*[@id=\"reason name0\"]/div/span");
  By label_serchReason=By.xpath("/html/body/div/div[1]/div/input");
  By slct_reason=By.xpath("/html/body/div/div[2]/ul/p-dropdownitem[1]/li");
  By bnt_reasn_sarttime=By.xpath("/html/body/div/div/div[3]/button[1]/span");
  By btn_reasn_endtime=By.xpath("/html/body/div/div/div[3]/button[1]/span");
  By label_reasn_Sarttime=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[4]/div/div/p-table/div/div/div/div[2]/table/tbody/tr/td[3]/div[1]/p-calendar/span");
  By label_reasn_endtime=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[4]/div/div/p-table/div/div/div/div[2]/table/tbody/tr/td[4]/div[1]/p-calendar/span");
  By label_ReasonCodetable=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[4]/div/div/p-table/div/div/div/div[2]/table/tbody/tr/td[2]//div[1]/span[1]");
  By poup_succesmessag=By.xpath("//div[contains(text(),	'Timecard has been created successfully')]");
  By label_frdate=By.xpath("/html/body/div/div[1]/div/div[2]/table/tbody/tr[5]/td[5]/span");
  By btn_clse=By.xpath("//a[@id='closePopBtn']/em");
  By label_usrName_mesg=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[1]/span/div");
  By label_sart_ermsg=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[4]/div[2]//span");
  By lable_edn_msg=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[5]/div[2]/span");
  By ermesge_endtme=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[1]/div[5]/div[2]/span");
  By btn_enddtime_bck=By.xpath("/html/body/div/div/div[3]/button[2]/span");
  //update
  By popup_updatemessage=By.xpath("//div[contains(text(),'Timecard has been updated Successfully')]");
  By label_updateendtime=By.xpath("//*[@id=\"timecardEndTime\"]/span");
  By btn_endtime=By.xpath("/html/body/div/div/div[3]/button[1]/span");
  By label_reasonUpdate_srtTim=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[4]/div/div/p-table/div/div/div/div[2]/table/tbody/tr/td[3]/div[1]/p-calendar/span");
  By btn_delte=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[4]/div/div/p-table/div/div/div/div[2]/table/tbody/tr/td[7]/div/a");
 By label_Description=By.xpath("//textarea[@id='returnReason']");
 By link_excelicon=By.xpath("//a[contains(@title,'Export to CSV')]//em");
 By link_pdficon=By.xpath("//a[contains(@title,'Export to PDF')]//em");
 
 By label_pastyear=By.xpath("//select[contains(@class,'p-datepicker-year')]");
 By labekdate=By.xpath("/html/body/div/div[1]/div/div[2]/table/tbody/tr[1]/td[2]/span");
 By labek_tablere=By.xpath("//td[contains(text(),'No records found')]");
  By field_endtime=By.xpath("//app-timecard/div/form/div/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody/tr/td[3]/span");
 
  //reasoncodes
  By errmsg_desrp=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[4]/div/div/p-table/div/div/div/div[2]/table/tbody/tr/td[6]/div/span");
  By time_msage=By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[4]/div/div/p-table/div/div/div/div[2]/table/tbody/tr[2]/td[3]/div[2]/span");
 
  
 By label_usertabledatelist;
 Actions  action = new Actions(driver);

 
 public void get2ndreasoncodestarttime() throws InterruptedException {
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[4]/div/div/p-table/div/div/div/div[2]/table/tbody/tr[2]/td[3]/div[1]/p-calendar/span/input")).click(); 
	 }

 public void get2ndreasoncodeendtime() throws InterruptedException {
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[4]/div/div/p-table/div/div/div/div[2]/table/tbody/tr[2]/td[4]/div[1]/p-calendar/span/input")).click(); 
	 }

 public WebElement geterrormessageixstrecord() throws InterruptedException {
	 Thread.sleep(2000);
	 WebElement  use=driver.findElement(time_msage);
	 return use;
 }
 public WebElement geterrmesagefordesription() throws InterruptedException {
	 Thread.sleep(2000);
	 WebElement  use=driver.findElement(errmsg_desrp);
	 return use;
 }
 public WebElement getendserrmesge() throws InterruptedException {
	 Thread.sleep(2000);
	 WebElement  use=driver.findElement(ermesge_endtme);
	 return use;
 }
 public WebElement getends() {
	 WebElement  use=driver.findElement(btn_enddtime_bck);
	 return use;
 }
 public WebElement getenddateErrormessage() {
	 WebElement  use=driver.findElement(lable_edn_msg);
	 return use;
 }
 public WebElement getstartdateErrormessage() {
	 WebElement  use=driver.findElement(label_sart_ermsg);
	 return use;
 }
 public WebElement getuserNameErrormessage() {
	 WebElement  use=driver.findElement(label_usrName_mesg);
	 return use;
 }
 public WebElement getendtimefrmupdatetime() throws InterruptedException {
	 Thread.sleep(4000);
	 WebElement et= driver.findElement(field_endtime);
	 return et;
 }
 
 public WebElement getNoorecordfnd() throws InterruptedException {
	 Thread.sleep(3000);
	 WebElement re= driver.findElement(labek_tablere);
		return re;
 }
 public WebElement getpastdateinfltsart(String year) throws InterruptedException {
	 driver.findElement(label_pastyear).click();
	 By yer=By.xpath("//select[contains(@class,'p-datepicker-year')]/option[text()='"+year+"']");
	 Thread.sleep(2000);
	WebElement dts= driver.findElement(labekdate);
	return dts;
 }
 public void clickonclosebtn() {
	 driver.findElement(btn_clse).click();
 }
 public WebElement getfuturdate() {
	 WebElement frd=driver.findElement(label_frdate);
	 return frd;
 }
 public void clickonexcelbtn() {
	 driver.findElement(link_excelicon).click();
 }
 public void clickonpdfbutton() {
	 driver.findElement(link_pdficon).click();
	 }
 public WebElement getPageTitleforscreen() throws InterruptedException {
	 Thread.sleep(2000);
	 WebElement mess=driver.findElement(By.xpath("//h1[contains(text(),'Timecard Management')]"));
		
	 return mess;  
 }
 public WebElement getupdateSucess() throws InterruptedException {
	 Thread.sleep(2000);
	 WebElement mess=driver.findElement(popup_updatemessage);
		
	 return mess;  
 }
 public void getReasonEndtime() throws InterruptedException {
	 Thread.sleep(2000);
	 driver.findElement(btn_reasn_endtime).click();
	 driver.findElement(btn_reasn_endtime).click();
	 
	 driver.findElement(By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div[4]/div/div/p-table/div/div/div/div[2]/table/tbody/tr/td[5]")).click();
 }
 public void clickReasonEndtime() throws InterruptedException {
	 Thread.sleep(2000);
	 driver.findElement(label_reasn_endtime).click();
 }
 public void getReasonSarttime() throws InterruptedException {
	 Thread.sleep(2000);
	 driver.findElement(bnt_reasn_sarttime).click();
 }
 public void clickReasonSarttime() throws InterruptedException {
	 Thread.sleep(2000);
	 driver.findElement(label_reasn_Sarttime).click();
 }
 public WebElement clickonDeletbtninupdate() {
	 WebElement rc=driver.findElement(btn_delte);
		
	 return rc; 
 }
 public WebElement clickreasoncode() {
	 WebElement rc=driver.findElement(slct_reason);
	
	 return rc; 
 }
 public WebElement clickonSearchreasoncode(String reasoncode) {
	 WebElement rc=driver.findElement(label_serchReason);
	 rc.sendKeys(reasoncode);
	 return rc; 
 }
 public WebElement clickonSecltreasoncode() {
	 WebElement rc=driver.findElement(label_resoncode);
	
	 return rc; 
 }
 public WebElement clickonAddReasonCode() {
	 WebElement rc=driver.findElement(btn_addrecord);
	
	 return rc; 
 }
 public WebElement getDescriptionfield(String desription) throws InterruptedException {
	 Thread.sleep(3000);
	 WebElement desc=driver.findElement(label_Description);
	 desc.sendKeys(desription);
	 return desc; 
 }
 public WebElement getNewtimecardSuccessmessage() throws InterruptedException {
	 Thread.sleep(3000);
	 WebElement messge=driver.findElement(poup_succesmessag);
	 return messge;
 }
 public void clickonSavebtn() {
	 driver.findElement(btn_save).click();
 }
 public List<String> getallDatesinTable() {
	 String tableDates;
	 int i=0;
	 driver.findElement(By.xpath("//app-timecard/div/form/div/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody/tr"));
	 List<String> Userdatesintable = new ArrayList<String>();
	 WebElement tbl_dat=driver.findElement(By.xpath("//td[contains(@class,'colWidth ng-star-inserted')]"));
	 while(i<=4) {
		
		 tableDates= tbl_dat.getText();
		 Userdatesintable.add(tableDates);
		 Userdatesintable.add(tableDates);	
		
		 i++;
	 }
	// Userdatesintable.add(tableDates);
	 return Userdatesintable;
	 
 }
 
 public WebElement getDatesfromTable() {
	 wait.until(ExpectedConditions.presenceOfElementLocated(label_Dates));
	 WebElement tbl_dat=driver.findElement(label_Dates);
	 return tbl_dat;
 }
 
 public WebElement getfromReasoncodefrmtable() throws InterruptedException {
	 Thread.sleep(5000);
	  Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//app-timecard/div/form/div/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody"))).perform(); 
			
	 WebElement tbl_re=driver.findElement(By.xpath("//td[contains(@class,'reasonCol')]/span"));
	 return tbl_re;
 }
 public void clickonEditbutton() {
	 driver.findElement(btn_edit).click(); 
 }
 public WebElement getErrormessageforUser() {
	 WebElement Message=driver.findElement(popup_errormessage);
	 return Message;
 }
 public void clickonResetbutton() {
	  driver.findElement(btn_reset).click();
}

 public void clickonOKbtninupdate() {
	  driver.findElement(btn_update_ok).click();
 }
  public void clickonclosebtninupdate() {
	  driver.findElement(btn_close).click();
  }
 
 public WebElement getproducthoursfromypdatepage() {
	 WebElement prodhrs=driver.findElement(prdcthrsinupdate);
	 return prodhrs;
 }
 
 public WebElement getproducthoursfrommainTable() {
	 wait.until(ExpectedConditions.presenceOfElementLocated(producthrs));
	 WebElement prodhrs=driver.findElement(producthrs);
	 return prodhrs;
 }
  public List<String> getDatesfromResultTable() {
	  int rowSize=driver.findElements(result_tablehistory).size();
	  System.out.println("rowSize->"+rowSize);
		String tableDates;
		System.out.println(rowSize);
		List<String> Userdatesintable = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
			label_usertabledatelist=By.xpath("//app-timecard/div/form/div/div/div[2]/div[2]/p-table/div/div/table/tbody/tr["+i+"]/td[2]");
			
			tableDates=driver.findElement(label_usertabledatelist).getText().trim();
			//System.out.println("EndDate in Row"+i+"="+tableDates);
			Userdatesintable.add(tableDates);
		}
		return Userdatesintable;  
  }
  public List<String> getUsersfromTable() throws InterruptedException {
	  int rowSize=driver.findElements(result_tablehistory).size();
		String Users;
		System.out.println(rowSize);
		List<String> Userdetailsintable = new ArrayList<String>();
		for(int i=1;i<=rowSize;i++)
		{
		By	label_userlist=By.xpath("//app-timecard/div/form/div/div/div[2]/div[2]/p-table/div/div/div/div[2]/table/tbody/tr["+i+"]/td[1]");
			
			Users=driver.findElement(label_userlist).getText().trim();
			
			Userdetailsintable.add(Users);
			
		}
		return Userdetailsintable;  

  }
  public String getdeletemessage() {
	  driver.switchTo().defaultContent();
	  wait.until(ExpectedConditions.presenceOfElementLocated(popup_deletemessage));
	  String message=driver.findElement(popup_deletemessage).getText();
	 return message;
  }
  
  public WebElement clickonOkbtn() {
	  WebElement btnok=driver.findElement(btn_ok);
	  return btnok;
  }
  public WebElement getresulttable() {
	  WebElement tble=driver.findElement(result_tablehistory);
	  return tble;
  }
  public WebElement clickonDeletebtn() {
	  wait.until(ExpectedConditions.presenceOfElementLocated(btn_delete));
	  WebElement dlt=driver.findElement(btn_delete);
	  return dlt;
  }
  public WebElement clickFilterbtn() {
	  WebElement flter=driver.findElement(btn_filter);
	  return flter;
  }
  public WebElement clickenddate() {
	  WebElement enddate=driver.findElement(label_endDate);
	  return enddate;
  }
  public WebElement clickstartdate() {
	  WebElement startdate=driver.findElement(label_startdate);
	  return startdate;
  }
  public WebElement clickonuser() {
	  WebElement slct=driver.findElement(userDp);
	  return slct;
  }
  public WebElement getsearchuser(String user) {
	  WebElement usr=driver.findElement(search_user);
	  usr.sendKeys(user);
	  return usr;
  }
  public WebElement clickonselectuserfileldinfiltr() {
	  
	  Actions action = new Actions(driver);
	action.moveToElement(driver.findElement(label_user)).perform(); 
		
	  WebElement selectuser=  driver.findElement(label_user);
	  //selectuser.click();
	  
	  return selectuser;
  }
  public void clickonemptypacse() {
	  driver.findElement(By.xpath("//span[contains(text(),'HERO')]")).click();
  }
  
  public WebElement clickonNewTimeCard() {
	  WebElement timecardbtn=  driver.findElement(btn_newtimecard);
	  
	  return timecardbtn;
  }
  public WebElement getNewTimeCardTitle() {
	  WebElement newTitle=  driver.findElement(label_newtimecardtitle);  
	  return newTitle;
  }
  public WebElement clickonSelectUser() {
	  WebElement user=  driver.findElement(label_userdp); 
	  return user;
  }
  public WebElement SelectUserfromDropd(String User) {
	  WebElement Serachuser=  driver.findElement(searchuserfrmDp); 
	  Serachuser.sendKeys(User);
	  driver.findElement(selectUserDp7).click();
	  
	  return Serachuser;
  }
   public WebElement clicknewTimeCardDate() {
	   WebElement timecarddate=  driver.findElement(btn_timecardDate);
		  
		  return timecarddate;
  }
   
   public WebElement clickonendTimeinTimeCard() {
	   WebElement endtimecardbtn=  driver.findElement(btn_endTime_newcard); 
	   return endtimecardbtn;
   }
   public WebElement getendTimeinTimeCard() {
	   WebElement endtimecard=  driver.findElement(btn_endTimeSelect); 
	   return endtimecard;
   }
   public WebElement getendTimeinTimestamp() {
	   WebElement endtimestamp=  driver.findElement(btn_Endtimestampselect); 
	   return endtimestamp;
   }
   
   public WebElement clickonStartTimeinTimeCard() {
	   WebElement starttimecardbtn=  driver.findElement(btn_StartTime_newcard); 
	   return starttimecardbtn;
   }
   public WebElement getStartTimeinTimeCard() throws InterruptedException {
	   Thread.sleep(3000);
	   WebElement starttimecard=  driver.findElement(btn_startTimeselect); 
	   return starttimecard;
   }
   public WebElement getProductivehrsfromNewTimecard() {
	   WebElement prodhrs=  driver.findElement(label_productivehrs); 
	   return prodhrs;
   }
   public WebElement getNonProductivehrsfromNewTimecard() {
	   WebElement nonprodhrs=  driver.findElement(label_Nonproductivehrs); 
	   return nonprodhrs;
   }
  
  
  
  
  
  


	
}
