package roleManagement;

import java.io.IOException;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC5_roleManagement extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifyAddScreenOptions() throws IOException, InterruptedException
		{
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=9;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
			 Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Roles Management')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Roles Management')]"))).click().release().build().perform();
				
				String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Roles Management')]")).getText();
				
				System.out.println(PageTitle);
				
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();

			
			 // test.log(LogStatus.INFO, "Clicking on Add New Role button");
			  
			  driver.findElement(By.xpath("//span[contains(text(),'Add New Role')]")).click();
			  
			 
			  System.out.println("1");
		
			  WebElement multiselect=driver.findElement(By.xpath("//app-role[1]/div[2]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]/div[1]"));
			  
			//  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[2]/span")));
			  
	           multiselect.click();  
	           
	           String ViewEditOptions[] = new String[20] ;
				
	         
	           
	           System.out.println("2");
	           
	           Thread.sleep(10000);
	           
	 		  for(int j=1;j<=20;j++)
	 		  {
	 		String Xpathexpr="//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem["+j+"]/li/span";	  
	 		System.out.println(Xpathexpr);
	 		Thread.sleep(2000);
	 		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(Xpathexpr)));
	 		ViewEditOptions[j-1]=driver.findElement(By.xpath(Xpathexpr)).getText().trim();  
	 		  System.out.println(ViewEditOptions[j-1]);
	 		
	 		  }
			  
	 		 List<String> Actualoptions=new ArrayList(Arrays.asList(ViewEditOptions)); 
	 		  
	 		 System.out.println("3");
             
			  List<String> Expectedoptions=new ArrayList(Arrays.asList("User Landing Page","Leader Dashboard","Admin Dashboard","Friendly UI-Inst","User Profile","Roles Management","Group Maintenance","Manage Queues","Queue Assignments","Maintain Error Codes","Maintain Non-Productive Reason Codes","Modify Timecard","Partner Maintenance","Manual Batch Submission","Record Productive Time","Search and View","File Upload","Transmission Log","Kick Payments","Non-Friendly UI" ));
			   
			  Collections.sort(Actualoptions);
				  
			  Collections.sort(Expectedoptions);
			 
				 
			
				 System.out.println("4");
			 
			 //Verifying  Table Names in the view in Related Items tab
			 // test.log(LogStatus.INFO, "Verifying Options in View Edit section in New Role screen");
			 
			  
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
				
			    softassert.assertEquals(Actualoptions, Expectedoptions,"Options not matching");
			    
			    
			    softassert.assertAll();
				 
				    System.out.println("TC015_roleManagement Passed");
				    
				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC015_roleManagement Failed");
					   
					//  test.log(LogStatus.FAIL, "TC015_userProfile Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	
	
		}
	
	
}
