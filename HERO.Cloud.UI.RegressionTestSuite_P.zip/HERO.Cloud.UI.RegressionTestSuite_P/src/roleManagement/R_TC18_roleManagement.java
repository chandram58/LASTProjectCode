package roleManagement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC18_roleManagement extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifyScreenFieldsAdminDashboard() throws IOException, InterruptedException
		{
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=12;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");
			
			 
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
			 Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Roles Management')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Roles Management')]"))).click().release().build().perform();
				
				String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Roles Management')]")).getText();
				
				System.out.println(PageTitle);
				
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
			 
              

			  
			 
			 // test.log(LogStatus.INFO, "Clicking on Add New Role button");
			  
			  driver.findElement(By.xpath("//span[contains(text(),'Add New Role')]")).click();
			  
			 
			  System.out.println("1");
		
			  WebElement multiselect=driver.findElement(By.xpath("//app-role[1]/div[2]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]/div[1]"));
			  
			  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-role[1]/div[2]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]/div[1]")));
			  
	           multiselect.click();  
	           
	           System.out.println("2");
	           
	           Thread.sleep(500);
	           
	           wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Admin Dashboard')]")));
	           
	           driver.findElement(By.xpath("//span[contains(.,'Admin Dashboard')]")).click();
	           
	    //Clicking On Blank Area    
	           
	   driver.findElement(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-role[1]/div[2]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]")).click();
	           
	           
	     //Click on Expand Icon
	   
	 WebElement Expandicon=driver.findElement(By.xpath("//app-role[1]/div[2]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-treetable[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/p-treetabletoggler[1]/button[1]/i"));
	 
	 Expandicon.click();
	           
	 System.out.println("3");
	 
	 
     String ViewEditOptions[] = new String[5] ;
				
	         
	 Thread.sleep(5000);
	           
	 		  for(int j=2;j<=6;j++)
	 		  {
	 		String Xpathexpr="//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div[2]/p-treetable/div/div/table/tbody/tr["+j+"]/td[1]/div";	  
	 		System.out.println(Xpathexpr);
	 		//Thread.sleep(2000);
	 		wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(Xpathexpr)));
	 		ViewEditOptions[j-2]=driver.findElement(By.xpath(Xpathexpr)).getText();  
	 		  System.out.println(ViewEditOptions[j-2]);
	 		
	 		  }
			  
	 		 List<String> Actualoptions=new ArrayList(Arrays.asList(ViewEditOptions)); 
	 		  
	 		 System.out.println("4");
             
			  List<String> Expectedoptions=new ArrayList(Arrays.asList("Rule Hits","Activity State Toggle Button","Export Section Report","Max Change %","Top Hits"));
			   
			  Collections.sort(Actualoptions);
			  System.out.println("Actualoptions->"+Actualoptions);
				  
			  Collections.sort(Expectedoptions);
			  System.out.println("Expectedoptions->"+Expectedoptions);
				 
			
				 System.out.println("4");
			 
			 //Verifying  Table Names in the view in Related Items tab
			 // test.log(LogStatus.INFO, "Verifying Options in View Edit section in New Role screen");
			 
			  
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
				
			    softassert.assertEquals(Actualoptions, Expectedoptions,"Options not matching");
			    
			    
			    softassert.assertAll();
				 
				    System.out.println("TC018_roleManagement Passed");
				    
				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				//Closing Child pages
				driver.findElement(By.xpath("//app-role[1]/div[2]/form[1]/div[2]/div[1]/div[2]/a[1]/em[1]")).click();
				//driver.switchTo().defaultContent();
				driver.findElement(By.xpath("//span[contains(text(),'OK')]")).click();
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC018_roleManagement Failed");
					   
					//  test.log(LogStatus.FAIL, "TC018_roleManagement Failed"); 

					   
						//Closing Child pages
						//	driver.findElement(By.xpath("//app-role[1]/div[2]/form[1]/div[2]/div[1]/div[2]/a[1]/em[1]")).click();
							//driver.switchTo().defaultContent();
							//driver.findElement(By.xpath("//span[contains(text(),'OK')]")).click();
					   	   
					   
					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
					
						
				      }
	
		}
	

}
