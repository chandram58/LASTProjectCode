package roleManagement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC44_roleManagement extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifyCopyButtonInactiveUsers() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=43;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Roles Management')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Roles Management')]"))).click().release().build().perform();

				  
				   
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
			 
			WebElement webtable;
			      

			  Thread.sleep(2000);
			 
			//Looking for any disabled role
			
			  List<WebElement> element=driver.findElements(By.xpath("//*[contains(@class, 'hasExpired')]"));
			  
			  webtable=driver.findElement(By.xpath("//app-role/div[1]/div[2]/div/div[2]/p-table/div/div/div/div[2]/table/tbody"));
		
			     List<WebElement> rows,inactiverows;
			     List<WebElement> cols = null;
			     
			     Boolean flag = false;
			     
			  	System.out.println("3");
			     
			     rows=webtable.findElements(By.tagName("tr"));
			     
			     
			    System.out.println("No of active rows on Roles Management Page->"+ rows.size());
			     
			    inactiverows=rows.get(0).findElements(By.xpath("//*[contains(@class, 'hasExpired')]"));
			     
			    System.out.println("No of inactive rows on Roles Management Page->"+ inactiverows.size());
		
			    
			    
			/*    
			 for(i=0;i<inactiverows.size();i++)
			 {  
				 
			   cols=inactiverows.get(i).findElements(By.tagName("td")); 
				
			     String RoleName_UI=cols.get(0).getText();
				  
			     System.out.println(RoleName_UI);
			     
			    
			 }
			  */
			    
			    cols=inactiverows.get(0).findElements(By.tagName("td"));   
			    
			    String RoleNameMainPage=cols.get(0).getText();
				  
				  System.out.println("Role name on main page->"+RoleNameMainPage);	
			    
			     WebElement CopyButton=cols.get(5).findElement(By.xpath("//tr[contains(@class,'hasExpired ng-star-inserted')]//td[6]//div[1]//a[1]//em"));
			    
			     CopyButton.click();
				  
			// cols.get(0).findElement(By.xpath("//*[contains(@class, 'far fa-copy iconColor enableCopyIcon')]")).click();
			  
			     JavascriptExecutor js = (JavascriptExecutor) driver;
			     Thread.sleep(5000);
					
				  String PageTitle=driver.findElement(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-role[1]/div[3]/form[1]/div[2]/div[1]/div[1]/h3[1]")).getText();
				  
				  String RoleNamePrepoulatedCopyPage=driver.findElement(By.xpath("//*[@id=\"updateRoleName\"]")).getAttribute("value");
					 
				  System.out.println("Prepopulated Role name on Copy page->"+RoleNamePrepoulatedCopyPage);		  
				 // js.executeScript("window.scrollBy(0,1000)");
				  action.moveToElement(driver.findElement(By.xpath("//button[contains(@label,'Save')]//span"))).click().perform();
				//  WebElement SaveButton=driver.findElement(By.xpath("//button[contains(@label,'Save')]//span"));
				 
				 // SaveButton.click();
				 System.out.println("1");
				 //js.executeScript("arguments[0].scrollIntoView();", SaveButton);
				
				  //action.moveToElement(driver.findElement(By.xpath("//*[@id=\"viewAddEditSection\"]/div[3]/div/div/button[1]/span"))).click().perform();
				// js.executeScript("arguments[0].click();",SaveButton);
				 
		          System.out.println(2);
				  Thread.sleep(2000);
			
				  driver.switchTo().defaultContent();
					 
				  Thread.sleep(2000);
				     String Message=driver.findElement(By.xpath("//div[contains(text(),'role has been created successfully')]")).getText();
					
					System.out.println(Message);
			
			  
			 System.out.println("1");
			 
			 
			 
	       	 
	 try
			    {
			    SoftAssert softassert = new SoftAssert();
				
			    softassert.assertTrue(PageTitle.toLowerCase().contains("new role"), "Copy page is not opening"); 
				   
				   softassert.assertTrue(RoleNamePrepoulatedCopyPage.equals("Copy of "+RoleNameMainPage), "Incorrect Edit Button is getting Clicked"); 
				   
				   softassert.assertTrue(Message.contains("role has been created successfully"), "User not Received Success message"); 
					
				  
  
			    softassert.assertAll();
				 
				  System.out.println("TC041_roleManagement Passed");
				    
				     String status="Pass";
				     
				 //  test.log(LogStatus.PASS, "TC041_roleManagement Passed");    
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC041_roleManagement Failed");
					   
					//  test.log(LogStatus.FAIL, "TC041_roleManagement Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
		}
	

}
