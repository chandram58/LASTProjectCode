package roleManagement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC55_roleManagement extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifyViewButtonInactiveUsers() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=45;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
			 Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Roles Management')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Roles Management')]"))).click().release().build().perform();
				
				
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
			 
			WebElement webtable;
			      

			  Thread.sleep(2000);
			 
			//Looking for any disabled role
			
			  List<WebElement> element=driver.findElements(By.xpath("//*[contains(@class, 'hasExpired')]"));
			  
			  webtable=driver.findElement(By.xpath("//app-role[1]/div[1]/div[2]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]"));
		
			     List<WebElement> rows,inactiverows;
			     List<WebElement> cols = null;
			     
			     Boolean flag = false;
			     
			  	System.out.println("3");
			     
			     rows=webtable.findElements(By.tagName("tr"));
			     
			     
			    System.out.println("No of rows on Roles Management Page->"+(rows.size()-1));
			     
			    inactiverows=rows.get(0).findElements(By.xpath("//*[contains(@class, 'hasExpired')]"));
			     
			    System.out.println("No of inactive rows on Roles Management Page->"+ inactiverows.size());
		
			    
			    
			    /* Getting Inactive users list
			 for(i=0;i<inactiverows.size();i++)
			 {  
				 
			   cols=inactiverows.get(i).findElements(By.tagName("td")); 
				
			     String RoleName_UI=cols.get(0).getText();
				  
			     System.out.println(RoleName_UI);
			     
			    
			 }
			  */
			    
			    cols=rows.get(rows.size()-1).findElements(By.tagName("td"));   
			    
			    String RoleNameMainPage=cols.get(0).getText();
				  
				  System.out.println("Role name on Main Page->"+RoleNameMainPage);	
				  
				  System.out.println("No Of Rows On Role main page->"+rows.size());
				  
				  String xpath_View="//tbody/tr["+(rows.size())+"]/td[6]/div[1]/a[2]/em[1]";
				  System.out.println("xpath_View->"+xpath_View);
			    
			  //   WebElement ViewButton=driver.findElement(By.xpath(xpath_View));
			     
				//tbody/tr[157]/td[6]/div/a[2]/em
				  WebElement ViewButton=driver.findElement(By.xpath(xpath_View));
			    
			     ViewButton.click();
				  
			// cols.get(0).findElement(By.xpath("//*[contains(@class, 'far fa-copy iconColor enableCopyIcon')]")).click();
			  
			 
			     Thread.sleep(5000);
					
		         String PageTitle=driver.findElement(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-role[1]/div[3]/form[1]/div[2]/div[1]/div[1]/h3[1]")).getText();
				  
				  WebElement RoleNameField=driver.findElement(By.xpath("//input[@id='updateRoleName']"));
				  
				  String Disablechk=RoleNameField.getAttribute("disabled");
				  
				  System.out.println(Disablechk);	
				  
				  String RoleNamePrepoulatedViewPage=RoleNameField.getAttribute("value");
					 
				  System.out.println("Prepopulated Role name on View page->"+RoleNamePrepoulatedViewPage);		  
					 
			    //  String ButtonNamePresent=driver.findElement(By.xpath("//*[contains(@class, 'ui-button-text ui-clickable')]")).getText();
				 
				
				//  System.out.println(ButtonNamePresent); 
				  
				 System.out.println("1");
				
				 
				 
		          
				  Thread.sleep(2000);
			
				  
			 
			 
	       	 
	 try
			    {
			    SoftAssert softassert = new SoftAssert();
				
			    softassert.assertTrue(PageTitle.toLowerCase().contains("view role"), "view page is not opening"); 
				   
			    softassert.assertTrue(RoleNamePrepoulatedViewPage.equals(RoleNameMainPage), "Incorrect View Button is getting Clicked"); 
				   
			    softassert.assertTrue(Disablechk.equals("true"), "RoleNameField is not disabled"); 
					
				  
  
			    softassert.assertAll();
				 
				  System.out.println("TC055_roleManagement Passed");
				    
				     String status="Pass";
				     
				 //  test.log(LogStatus.PASS, "TC055_roleManagement Passed");    
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
      //Closing child page
				     
	   driver.findElement(By.xpath("//app-role[1]/div[3]/form[1]/div[2]/div[3]/div[1]/div[1]/button[1]/span[1]")).click();
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC055_roleManagement Failed");
					   
					//  test.log(LogStatus.FAIL, "TC055_roleManagement Failed"); 

				
					   //Closing child page
					     
					   driver.findElement(By.xpath("//app-role[1]/div[3]/form[1]/div[2]/div[3]/div[1]/div[1]/button[1]/span[1]")).click();
									     	   
					   
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
		}
	

}
