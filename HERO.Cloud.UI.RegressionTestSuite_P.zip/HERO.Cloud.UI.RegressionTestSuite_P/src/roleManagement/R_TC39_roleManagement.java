package roleManagement;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC39_roleManagement extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifySaveButtonFunctionalityNewRolePage() throws IOException, InterruptedException
		{
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=32;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");
			
			
			 Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Roles Management')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Roles Management')]"))).click().release().build().perform();
				
				String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Roles Management')]")).getText();
				
				System.out.println(PageTitle);
				
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
              

			  Thread.sleep(3000);
			 
			 // test.log(LogStatus.INFO, "Clicking on Add New Role button");
			  
			  driver.findElement(By.xpath("//span[contains(text(),'Add New Role')]")).click();
			  
			 System.out.println("1");
			 
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='addRoleName']")));
			 
			 driver.findElement(By.xpath("//input[@id='addRoleName']")).sendKeys("Automation4");
			 
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@id='description']")));
			 
			 driver.findElement(By.xpath("//textarea[@id='description']")).sendKeys("Automation4");
			 
			 
		
			  WebElement multiselect=driver.findElement(By.xpath("//app-role[1]/div[2]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]/div[1]"));
			  
			  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-role[1]/div[2]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]/div[1]")));
			  
	           multiselect.click();  
	           
	           System.out.println("2");
	           
	           Thread.sleep(500);
	           
	           wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'User Landing Page')]")));
	           
	           driver.findElement(By.xpath("//span[contains(.,'User Landing Page')]")).click();
	           
	           //Clicking On Blank Area    
	           
	    	   driver.findElement(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-role[1]/div[2]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]")).click();
	    	           
	           
	           
	           
	            //Clicking On Edit Checkbox
	           WebElement EditChkbox=driver.findElement(By.xpath("//app-role[1]/div[2]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-treetable[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[5]/div[1]/div[1]/p-checkbox[1]/label[1]"));
	           EditChkbox.click();
	           
	         
	           
	   
	           
	     //click on Save button on New Role Page
	   
	 driver.findElement(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-role[1]/div[2]/form[1]/div[2]/div[3]/div[1]/div[1]/button[1]/span[1]")).click();
	           
	  Thread.sleep(2000);
	 
	 
	 driver.switchTo().defaultContent();
	 
	 
     String ErrorMessage=driver.findElement(By.xpath("//div[contains(text(),'Role already Exists!')]")).getText();
	
	System.out.println("Error Message on Screen->"+ErrorMessage);
	
	
				 
			 
			
			  
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
			    
			    softassert.assertTrue(ErrorMessage.contains("Role already Exists"),"Validation for same role creation not working"); 
				
			    
			
			    
			    softassert.assertAll();
				 
				    System.out.println("TC039_roleManagement Passed");
				    
				     String status="Pass";
				     
				 //  test.log(LogStatus.PASS, "TC039_roleManagement Passed");    
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				   //Closing Child pages
						driver.findElement(By.xpath("//app-role[1]/div[2]/form[1]/div[2]/div[1]/div[2]/a[1]/em[1]")).click();
						//driver.switchTo().defaultContent();
						driver.findElement(By.xpath("//span[contains(text(),'OK')]")).click();
							     	
					     
				        }
				   
	    catch(Throwable e)
				     {
	    	
					   System.out.println("TC039_roleManagement Failed");
					   
					//  test.log(LogStatus.FAIL, "TC039_roleManagement Failed"); 

					 //Closing Child pages
//						driver.findElement(By.xpath("//app-role[1]/div[2]/form[1]/div[2]/div[1]/div[2]/a[1]/em[1]")).click();
//						driver.switchTo().defaultContent();
//						driver.findElement(By.xpath("//span[contains(text(),'OK')]")).click();
//							     		   
					   
					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
		}
	

}
