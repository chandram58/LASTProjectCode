package roleManagement;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;
import pages.HomePage;
import pages.RolesManagementPage;

public class R_TC1_roleManagement extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void NavigationtoRoleManagement() throws IOException
		{
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=1;
				
	     try{
				 
			  /*WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Roles Management')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Roles Management')]"))).click().release().build().perform();
				
				String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Roles Management')]")).getText();
				
				System.out.println(PageTitle);
				
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
			 
			 
			// driver.findElement(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1")).click();
			 
			// driver.findElement(By.xpath("//a[contains(text(),'Roles Management')]")).click();
			 
			 System.out.println("1");
				
			 
			 Thread.sleep(5000);
			 
			 
			//String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Roles Management')]")).getText();
*/
	    	 RolesManagementPage rolesManagementPageObt=new RolesManagementPage(); 
				HomePage homePageObj=new HomePage();
				 WebDriverWait wait=new WebDriverWait(driver,500);
				 xlinputfile=prop.getProperty("xlInputPath");	
					System.out.println(xlinputfile);

					xlReportPath=prop.getProperty("xlReportPath");	
					System.out.println(xlReportPath);

					homePageObj.mouseHoverAdministration();	
					homePageObj.openModule("Roles Management");
	    	 String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Roles Management')]")).getText();
				
				System.out.println(PageTitle);
           SoftAssert softAssert = new SoftAssert();
		     
		   //  test.log(LogStatus.INFO ,"Verifying page Title");
		     
	    softAssert.assertTrue(PageTitle.toLowerCase().contains("roles management"), "This is not Roles management page");
		     
		    
		     
		      softAssert.assertAll();
		      
		      System.out.println("TC001_rolesManagement Passed");
		      
		     // test.log(LogStatus.FAIL, "TC001_rolesManagement Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC001_rolesManagement Failed");
					   
					//  test.log(LogStatus.FAIL, "TC001_rolesManagement Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
		
		
		      }
	
	}
