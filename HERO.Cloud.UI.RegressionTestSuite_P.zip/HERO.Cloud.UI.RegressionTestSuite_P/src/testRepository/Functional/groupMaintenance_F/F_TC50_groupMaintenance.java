package testRepository.Functional.groupMaintenance_F;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class F_TC50_groupMaintenance extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void SameUserNotAddedtoOtherGroupValidation() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=11;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");
			
			 Thread.sleep(10000);
		
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Group Maintenance')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Group Maintenance')]"))).click().release().build().perform();

				  
				   
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Group Maintenance')]"))).click().perform();
			 
              
              

			  Thread.sleep(3000);
			 
			 // test.log(LogStatus.INFO, "Clicking on Add New Role button");
			  
			  driver.findElement(By.xpath("//span[contains(text(),'Add New Group')]")).click();
			  
			 System.out.println("1");
			 
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='addGroupName']")));
			 
			 driver.findElement(By.xpath("//input[@id='addGroupName']")).sendKeys("Automation");
			 
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@id='addDescription']")));
			 
			 driver.findElement(By.xpath("//textarea[@id='addDescription']")).sendKeys("Automation");
			 
			 
		
			  WebElement multiselect=driver.findElement(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[33]"));
			  
			  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[33]")));
			  
	           multiselect.click();  
	           
	           System.out.println("2");
	           
	           Thread.sleep(500);
	           
	           wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Peter K (AIK5247)')]")));
	           
	           driver.findElement(By.xpath("//span[contains(text(),'Peter K (AIK5247)')]")).click();
	           
	           //Clicking On Blank Area    
	           
	    	   driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div")).click();
	    	           
	           String Validationmessage=driver.findElement(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/span[1]")).getText();
	    	    
	           System.out.println(Validationmessage);
			 
			
			  
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
			    
			    softassert.assertFalse(Validationmessage.isEmpty(), "No validation message getting populated");
			    
			    softassert.assertTrue(Validationmessage.equals("The selected user is already exists in another group.."),"Validation message not matching with expected message");
				  
				 
			
			    
			    softassert.assertAll();
				 
				    System.out.println("TC010_groupMaintenance Passed");
				    
				     String status="Pass";
				     
				 //  test.log(LogStatus.PASS, "TC010_groupMaintenance Passed");    
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC010_groupMaintenance Failed");
					   
					//  test.log(LogStatus.FAIL, "TC010_groupMaintenance Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
		}
	

}
