package testRepository.Functional.groupMaintenance_F;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC045_groupMaintenance extends base
{
	
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void MandatoryFieldValidationNewGroup() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=6;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Group Maintenance')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Group Maintenance')]"))).click().release().build().perform();

				  
				   
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Group Maintenance')]"))).click().perform();
			 
              

			  Thread.sleep(2000);
			 
			  //test.log(LogStatus.INFO, "Clicking on Add New Role button");
			  
			  driver.findElement(By.xpath("//span[contains(text(),'Add New Group')]")).click();
			  
			  
			  Thread.sleep(2000);
			  
			 driver.findElement(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-group[1]/div[1]/div[3]/form[1]/div[2]/div[3]/div[1]/div[1]/button[1]/span[1]")).click();
			 
			 
	           
			 
			  String GroupNameValidationMessage=driver.findElement(By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div/div[1]/div/div")).getText();
			  System.out.println(GroupNameValidationMessage);
			  
			  String DescriptionValidationMessage=driver.findElement(By.xpath("//*[@id=\"viewAddEditSection\"]/div[2]/div/div[4]/div/div")).getText();
			  System.out.println(DescriptionValidationMessage);
			  
			  // 
			  
			  driver.findElement(By.xpath("//*[@id='addStartDate']/span/input")).sendKeys(Keys.chord(Keys.CONTROL, "a"));
			  
			  driver.findElement(By.xpath("//*[@id='addStartDate']/span/input")).sendKeys(Keys.DELETE);
			  
			  Thread.sleep(5000);
			  
			  driver.findElement(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[1]/div[1]/h3[1]")).click();
			  
			  
			  
			  String StartDateValidationmessage=driver.findElement(By.xpath("//span[contains(text(),'Start Date is required.')]")).getText();
			  
			  System.out.println(StartDateValidationmessage);
			  
			  
			  
			  Thread.sleep(3000);
			  
            driver.findElement(By.xpath("//*[@id='addEndDate']/span/input")).sendKeys(Keys.chord(Keys.CONTROL, "a"));
			  
			  driver.findElement(By.xpath("//*[@id='addEndDate']/span/input")).sendKeys(Keys.DELETE);
			  
			  driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div")).click();
			
		
			  
			  String EndDateValidationmessage=new WebDriverWait(driver,20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@title,'End date is required')]//span"))).getText();
			  
			  System.out.println(EndDateValidationmessage);
			  
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
			   softassert.assertFalse(GroupNameValidationMessage.isEmpty(), "Validation message not Populated");
			    softassert.assertTrue((GroupNameValidationMessage.toLowerCase()).equals("group name is required."), "Validation message not coming properly");
			    
			   softassert.assertFalse(DescriptionValidationMessage.isEmpty(), "Validation message not Populated");
			    softassert.assertTrue((DescriptionValidationMessage.toLowerCase()).equals("description is required."), "Validation message not coming properly");
			    
			   softassert.assertFalse(StartDateValidationmessage.isEmpty(), "Validation message not Populated");
			    softassert.assertTrue((StartDateValidationmessage.toLowerCase()).equals("start date is required."), "Validation message not coming properly");
			    
			 softassert.assertFalse(EndDateValidationmessage.isEmpty(), "Validation message not Populated");
			    softassert.assertTrue((EndDateValidationmessage.toLowerCase()).equals("End Date is req.."), "Validation message not coming properly");
			    
			    
			
			    
			    softassert.assertAll();
				 
				    System.out.println("TC006_userProfile Passed");
				    
				     String status="Pass";
				     System.out.println("TC006_userProfile Passed");
					    
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				     //Closing Child page
				 		driver.findElement(By.xpath("//span[contains(text(),'Cancel')]")).click(); 
				 		driver.switchTo().defaultContent();
				 	
				 		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'OK')]")));
				 		driver.findElement(By.xpath("//button[contains(text(),'OK')]")).click();		
								     
					     
				        }
				   
	    catch(Throwable e)
				     {
					   
					   
					//  test.log(LogStatus.FAIL, "TC006_userProfile Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						 // Assert.fail(e.getMessage());
						     
					   //Closing Child page
				 		//driver.findElement(By.xpath("//span[contains(text(),'Cancel')]")).click(); 
				 	//	driver.switchTo().defaultContent();
				 		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'OK')]")));
				 	//	driver.findElement(By.xpath("//button[contains(text(),'OK')]")).click();		
					   System.out.println("TC006_userProfile Failed");		        
				      }
          }
	
	}
