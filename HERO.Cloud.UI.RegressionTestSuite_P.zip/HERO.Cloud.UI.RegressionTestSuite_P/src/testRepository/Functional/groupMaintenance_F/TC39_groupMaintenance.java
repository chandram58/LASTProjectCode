package testRepository.Functional.groupMaintenance_F;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

public class TC39_groupMaintenance extends base{
	@Test
	public void getUsersfromDBbyGroupID() throws InterruptedException, SQLException {

			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Group Maintenance");
			  GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 
		WebElement groupNm=  grpMaintPageObj.getgroupNameforupdateintable(4);
	String GroupName=groupNm.getText();
	System.out.println(GroupName);
	
String user_UI=	grpMaintPageObj.getUserForGroup(4);
System.out.println(user_UI);

//DB validation
	String GroupName_DB=null,gorup_id=null,user_id=null,groupID=null,end_date=null,Group_desc=null;
	String Query1="select*from enc.HERO_UI_GROUP  where GROUP_NAME like '"+GroupName.trim()+"'";
	System.out.println(Query1);
	 PreparedStatement readStatement = dbcon.prepareStatement(Query1);
	  rs = readStatement.executeQuery();
	  rs.next();
	  System.out.println(Query1);
	  gorup_id=rs.getString(1);
	  System.out.println(gorup_id);
	  GroupName_DB=rs.getString(2);
	  System.out.println(GroupName_DB);
	  
	  String Query2="select*from HERO_UI_USER_GROUP_ASSIGN where GROUP_ID like '"+gorup_id.trim()+"'";
		System.out.println(Query2);
		 PreparedStatement readStatement2 = dbcon.prepareStatement(Query2);
		  rs = readStatement2.executeQuery();
		  rs.next();
		  user_id=rs.getString(2);
		  System.out.println(user_id);
		  groupID=rs.getString(3);
		  System.out.println(groupID);
	 try {  
			  SoftAssert softAssert = new SoftAssert();
		      
		      softAssert.assertEquals(gorup_id.trim().toLowerCase(), groupID.trim().toLowerCase(),"group ID is not matching with both table ");
		      softAssert.assertEquals(user_UI.trim().toLowerCase().substring(17, 24), user_id.trim().toLowerCase(),"GroupDesc not matching with DB");
		    
		      softAssert.assertAll();

				System.out.println("TC39_groupMaintenance Passed");

			}
			catch(Throwable e)
			{

				printFailure("TC39_groupMaintenance",e);
			}
	  
	}

}
