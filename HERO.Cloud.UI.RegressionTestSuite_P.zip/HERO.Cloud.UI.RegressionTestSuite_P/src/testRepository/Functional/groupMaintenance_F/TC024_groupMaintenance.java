package testRepository.Functional.groupMaintenance_F;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;
import pages.UserProfilePage;

import com.google.common.collect.Sets;
import com.relevantcodes.extentreports.LogStatus;

public class TC024_groupMaintenance extends base
{
	public String xlinputfile,xlReportPath;

	/*
	 * public String Xlsheet_InputQuery="Query_roleManagement"; public String
	 * Xlsheet_ReportModule="Role Management";
	 */

		
		

		@Test
		public void InactiveUsernotshowninNewGroupPage() throws IOException, InterruptedException
		{
		/*	
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=24;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			 Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'User Profile')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'User Profile')]"))).click().release().build().perform();

				  
				   
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'User Profile')]"))).click().perform();
		*/ //Anuja-07/20/21
			HomePage homePageObj=new HomePage();
			UserProfilePage userProflePageObj=new UserProfilePage();
			
			xlinputfile=prop.getProperty("xlInputPath");	//Anuja-07/16/21
			System.out.println(xlinputfile);

			xlReportPath=prop.getProperty("xlReportPath");	//Anuja-07/16/21
			System.out.println(xlReportPath);
			
			homePageObj.mouseHoverAdministration();	//Anuja-07/16/21
			homePageObj.openModule("User Profile");	//Anuja-07/20/21

			
			
		/*	WebElement webtable=driver.findElement(By.className("ui-table-scrollable-body-table"));
		     
		     List<WebElement> rows;
		     List<WebElement> cols = null;
		     List<String> InactiveUserListUserProfile = new ArrayList<String>();
		     Boolean flag = false;
		     
		  	System.out.println("3");
		     
		  	Thread.sleep(3000);
		  	
		     rows=webtable.findElements(By.tagName("tr"));
		     
		    System.out.println("No of rows on User Profile Table->"+ rows.size());
		
		    int InactiveUserCount=0;
			 
	for(int j=0;j<rows.size();j++) 
	   {
			cols=rows.get(j).findElements(By.tagName("td"));
			
			
			if(rows.get(j).getAttribute("class").equals("hasExpired ng-star-inserted"))
		     { 
			
			String Username=cols.get(0).getText();
			String HumanaId=cols.get(5).getText();
			String CombFormat=Username+" ("+HumanaId+")";
			
			InactiveUserListUserProfile.add(CombFormat);
			InactiveUserCount++;
			
		     }
			}
	        
	*/	//Anuja-07/20/21
			 List<String> InactiveUserListUserProfile = new ArrayList<String>();
			 InactiveUserListUserProfile=userProflePageObj.getInactiveUserNameAndUserIdasList();
			
	       System.out.println("Inactive Users list in User profile page");  
			System.out.println(InactiveUserListUserProfile);
			System.out.println("Number of Inactive Users in User profile page->"+InactiveUserListUserProfile.size()); 
			 
		/*	int ActiveUserCount=(rows.size())-InactiveUserCount;
			System.out.println("Number of Active Users in User profile page->"+ActiveUserCount);*/	//Anuja-07/20/21
			 
		/*	
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Group Maintenance')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Group Maintenance')]"))).click().release().build().perform();

				  
				   
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Group Maintenance')]"))).click().perform();
			 
              
              

			  Thread.sleep(3000);
               
			  // test.log(LogStatus.INFO, "Clicking on Add New Group button");
			  
			  driver.findElement(By.xpath("//span[contains(text(),'Add New Group')]")).click();
			  
			 System.out.println("1");
			 
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='addGroupName']")));
			 
			 driver.findElement(By.xpath("//input[@id='addGroupName']")).sendKeys("Automation");
			 
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@id='addDescription']")));
			 
			 driver.findElement(By.xpath("//textarea[@id='addDescription']")).sendKeys("Automation");
			 
			*/
			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Group Maintenance");	//Anuja-07/16/21
			GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 

			grpMaintPageObj.clickAddNewGroup();	
		
			grpMaintPageObj.inputNewGroupName("Automation");
			grpMaintPageObj.inputNewGrpDescription("Group Created by Automation");
		
	/*	//	  WebElement multiselect=driver.findElement(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]"));
			
		// wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]")));
			  
	    //       multiselect.click();  
	           
	     //      System.out.println("2");
	           
	      //     Thread.sleep(3000);
	  */    //Anuja-07/20/21
			
			List<String> UserListGroupMaintenanace = new ArrayList<String>();
			
			grpMaintPageObj.clickSelectUsers_NewGroup();
			
			UserListGroupMaintenanace=grpMaintPageObj.getUserListGrpmaintenance();
	     
	        /*  WebElement UserList;
	
	           List<String> UserListGroupMaintenanace = new ArrayList<String>();
 
              for(int k=1;k<=ActiveUserCount;k++)
              {
            	  String xpathexpr="//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem["+k+"]/li";
            	  UserList=driver.findElement(By.xpath(xpathexpr));  
            	  UserListGroupMaintenanace.add(UserList.getText());
              }
	         */ //Anuja-07/20/21
              
              Set<String> S1=new HashSet<String>(InactiveUserListUserProfile);
              Set<String> S2=new HashSet<String>(UserListGroupMaintenanace);
              System.out.println("User sets doesn't contain common user="+Sets.intersection(S1, S2).isEmpty());
        
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
			    
			  
			//softassert.assertFalse( UserListGroupMaintenanace.containsAll(InactiveUserListUserProfile), "User list in New Group page contains inactive profile");
			    softassert.assertTrue( Sets.intersection(S1, S2).isEmpty(), "User list in New Group page contains inactive profile");
			
			    
			    softassert.assertAll();
				 
				    System.out.println("TC024_groupMaintenance Passed");
				    
				     String status="Pass";
				     
				 //  test.log(LogStatus.PASS, "TC024_groupMaintenance Passed");    
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					  /* System.out.println("TC024_groupMaintenance Failed");
					   
					//  test.log(LogStatus.FAIL, "TC024_groupMaintenance Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
					*/ //Anuja-07/20/21	     
	    	printFailure("TC024_groupMaintenance",e); 
				      }
	
		}
	

}
