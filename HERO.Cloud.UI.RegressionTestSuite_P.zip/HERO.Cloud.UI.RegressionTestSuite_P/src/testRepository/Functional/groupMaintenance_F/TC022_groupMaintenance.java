package testRepository.Functional.groupMaintenance_F;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

import com.relevantcodes.extentreports.LogStatus;

public class TC022_groupMaintenance extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void CopyButtonInactiveUsers() throws IOException, InterruptedException
		{
			
			 
		/*	 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=21;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Group Maintenance')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Group Maintenance')]"))).click().release().build().perform();

				  
				   
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Group Maintenance')]"))).click().perform();
			 
              
              

			  Thread.sleep(3000);
			  
			  */ //Anuja-07/20/21
			
			HomePage homePageObj=new HomePage();
			
			xlinputfile=prop.getProperty("xlInputPath");	//Anuja-07/16/21
			System.out.println(xlinputfile);

			xlReportPath=prop.getProperty("xlReportPath");	//Anuja-07/16/21
			System.out.println(xlReportPath);

			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Group Maintenance");
			GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 

	/* WebElement webtable;
     
     Thread.sleep(3000);
     
   
     
     webtable=driver.findElement(By.className("ui-table-scrollable-body-table"));
     
     List<WebElement> rows;
     List<WebElement> cols = null;
     
     Boolean flag = false;
     
  	System.out.println("3");
     
     rows=webtable.findElements(By.tagName("tr"));
     
    System.out.println("No of rows on Group maintenence Page->"+ rows.size());
    
    WebElement Delete_ActiveUser;
    
   
    
    System.out.println(rows.get(0).getAttribute("class"));
     
 for(int j=0;j<rows.size();j++)
 {  
	 if(rows.get(j).getAttribute("class").equals("hasExpired ng-star-inserted"))
     {
		System.out.println("Verifying Copy button in Row no->"+(j+1)); 
		 
       String XpathExp="//tbody/tr["+(j+1)+"]/td[5]/div[1]/a[1]/em[1]";
       
       Delete_ActiveUser=driver.findElement(By.xpath(XpathExp));
       
       flag=Delete_ActiveUser.isDisplayed();
		
      
       
       if(flag.equals(false))
       {	   
    	break;	   
       } 
     }
   }
	*/ //Anuja-07/20/21
			Boolean flag=null;	
			flag=grpMaintPageObj.verifyCopyButtonForInActiveGroups();
			System.out.println(flag);
 
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
			    
			  
			    softassert.assertTrue(flag,"Copy button not present for all inactive users");
			  
			
			    
			    softassert.assertAll();
				 
				    System.out.println("TC021_groupMaintenance Passed");
				    
				     String status="Pass";
				     
				 //  test.log(LogStatus.PASS, "TC021_groupMaintenance Passed");    
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					 /*  System.out.println("TC021_groupMaintenance Failed");
					   
					//  test.log(LogStatus.FAIL, "TC021_groupMaintenance Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
					*/ printFailure("TC022_groupMaintenance",e); 	     
					   
				      }
	
		}
	

}
