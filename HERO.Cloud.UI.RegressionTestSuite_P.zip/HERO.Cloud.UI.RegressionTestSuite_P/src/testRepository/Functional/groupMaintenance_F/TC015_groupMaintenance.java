package testRepository.Functional.groupMaintenance_F;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

import com.relevantcodes.extentreports.LogStatus;

public class TC015_groupMaintenance extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void DeleteButtonAvaialblityafterGroupSaved() throws IOException, InterruptedException
		{
			
		/*	 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=15;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");
			
			 Thread.sleep(10000);
	
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Group Maintenance')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Group Maintenance')]"))).click().release().build().perform();

				  
				   
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Group Maintenance')]"))).click().perform();


			  Thread.sleep(3000);	*/ //Anuja-07/19/21
			
			
			HomePage homePageObj=new HomePage();
			// xlinputfile=(getPropertyValue())[0].toString();	
			xlinputfile=prop.getProperty("xlInputPath");	//Anuja-07/16/21
			System.out.println(xlinputfile);


			//xlReportPath=(getPropertyValue())[3].toString();	
			xlReportPath=prop.getProperty("xlReportPath");	//Anuja-07/16/21
			System.out.println(xlReportPath);

			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Group Maintenance");//Anuja-07/16/21
			GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 
			 
			 // test.log(LogStatus.INFO, "Clicking on edit button");
			  
			// driver.findElement(By.xpath("//tbody/tr[1]/td[5]/div[1]/a[2]/em[1]")).click(); //Anuja-07/19/21
			 
	        int userExistsFlag=0,rowIndex=0;
	        Boolean flag=null;
	           
	   while(userExistsFlag==0)
	   {
		   rowIndex=rowIndex+1;
		   grpMaintPageObj.clickEditGroup(rowIndex);
		   if(grpMaintPageObj.verifyUsersExists())
		   {
			   userExistsFlag=1;
			   flag= grpMaintPageObj.verifyDeleteButtonForSavedUsers();
			   break;
		   }
		   else
		   {
			   grpMaintPageObj.clickCancel_EditGroup();
			 
		   }
	   }
	           
//	driver.switchTo().defaultContent();
//	
//	 WebElement webtable;
//     
//     Thread.sleep(3000);
//     
//   
//     
//     webtable=driver.findElement(By.xpath("//app-group[1]/div[1]/div[4]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]"));
//     
//     List<WebElement> rows;
//     List<WebElement> cols = null;
//     
//     Boolean flag = false;
//     
//  	System.out.println("3");
//     
//     rows=webtable.findElements(By.tagName("tr"));
//     
//    System.out.println("No of rows on Add Users Table->"+ rows.size());
//     
//      
// for(int j=0;j<rows.size();j++)
// {  
//	 cols=rows.get(j).findElements(By.tagName("td"));
//     String Username=cols.get(0).getText();
//    
//	  
//     System.out.println(Username);
//     
//     
//     if((!Username.isEmpty()))
//     {	 
//    	 
//          try
//            {
//    	 
//    	 
//    	 
//             flag=cols.get(3).findElement(By.tagName("a")).isDisplayed();
//             System.out.println(flag);
//             System.out.println(cols.get(3).findElement(By.tagName("a")).getAttribute("class"));
//             break;
//  
//              }
//         catch(Exception e)
//          {
//    	 System.out.println(e.getMessage());
//    	 
//           }
//     }
//   
	
 System.out.println(flag);
 

			    try
			    {
			    SoftAssert softassert = new SoftAssert();
			    
			   
			    softassert.assertFalse(flag,"Delete Button is present for added user for already saved group.User can be deleted");
			  
			
			    
			    softassert.assertAll();
				 
				    System.out.println("TC015_groupMaintenance Passed");
				    
				     String status="Pass";
				     
				 //  test.log(LogStatus.PASS, "TC015_groupMaintenance Passed");    
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					 /*  System.out.println("TC015_groupMaintenance Failed");
					   
					//  test.log(LogStatus.FAIL, "TC015_groupMaintenance Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());*/
	    	printFailure("TC015_groupMaintenance",e); 
					   
				      }
	
		
	}
}
