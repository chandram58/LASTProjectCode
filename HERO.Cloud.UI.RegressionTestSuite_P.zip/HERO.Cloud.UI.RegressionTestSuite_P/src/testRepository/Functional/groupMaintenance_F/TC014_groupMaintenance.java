package testRepository.Functional.groupMaintenance_F;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

import com.relevantcodes.extentreports.LogStatus;

public class TC014_groupMaintenance extends base
{
	public String xlinputfile,xlReportPath;

	/*
	 * public String Xlsheet_InputQuery="Query_roleManagement"; public String
	 * Xlsheet_ReportModule="Role Management";
	 */




	@Test
	public void DeleteButtonAvailabilitywhileAddingUsers() throws IOException, InterruptedException
	{

		/*	 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);


			   xlReportPath=(getPropertyValue())[3].toString();

			   System.out.println(xlReportPath);

			   int i=14;



			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");

			 Thread.sleep(10000);

				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Group Maintenance')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Group Maintenance')]"))).click().release().build().perform();



				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Group Maintenance')]"))).click().perform();




			  Thread.sleep(3000);

			 // test.log(LogStatus.INFO, "Clicking on Add New Role button");

			  driver.findElement(By.xpath("//span[contains(text(),'Add New Group')]")).click();

			 System.out.println("1");

			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='addGroupName']")));

			 driver.findElement(By.xpath("//input[@id='addGroupName']")).sendKeys("27New");

			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@id='addDescription']")));

			 driver.findElement(By.xpath("//textarea[@id='addDescription']")).sendKeys("27New");



			  WebElement multiselect=driver.findElement(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]"));

			  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]")));

	           multiselect.click();  

	           System.out.println("2");

	           Thread.sleep(500);


	 //data specific test cases.Please check data before running script          
wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'V L (VAL2728)')]")));

	           driver.findElement(By.xpath("//span[contains(text(),'V L (VAL2728)')]")).click();
	           //Clicking On Blank Area    

	    	   driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div")).click();

		 */ //Anuja-07/19/21

		
		HomePage homePageObj=new HomePage();
		// xlinputfile=(getPropertyValue())[0].toString();	
		xlinputfile=prop.getProperty("xlInputPath");	//Anuja-07/16/21
		System.out.println(xlinputfile);


		//xlReportPath=(getPropertyValue())[3].toString();	
		xlReportPath=prop.getProperty("xlReportPath");	//Anuja-07/16/21
		System.out.println(xlReportPath);

		homePageObj.mouseHoverAdministration();	
		homePageObj.openModule("Group Maintenance");
		
		
		GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 
		grpMaintPageObj.clickAddNewGroup();	

		grpMaintPageObj.inputNewGroupName("Automation");
		grpMaintPageObj.inputNewGrpDescription("Group Created by Automation");    

		grpMaintPageObj.clickSelectUsers_NewGroup();
		//datasepecific
		grpMaintPageObj.getUserbySearch("VIP1189");
		grpMaintPageObj.clickseacheduserfromDd();
		/*	           
	driver.switchTo().defaultContent();

	 WebElement webtable;

     Thread.sleep(3000);



     webtable=driver.findElement(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]"));

     List<WebElement> rows;
     List<WebElement> cols = null;

     Boolean flag = false;

  	System.out.println("3");

     rows=webtable.findElements(By.tagName("tr"));

    System.out.println("No of rows on Add Users Table->"+ rows.size());


 for(int j=0;j<rows.size();j++)
 {  
	 cols=rows.get(j).findElements(By.tagName("td"));
     String Username=cols.get(0).getText();


     System.out.println(Username);

     if(Username.equals("V L (VAL2728)")) 
     {
    	 flag=cols.get(3).findElement(By.tagName("a")).isDisplayed();
    	  System.out.println(cols.get(3).findElement(By.tagName("a")).getAttribute("class"));

    	 break;
     }
 }
		 */ //Anuja-07/19/21	

		Boolean flag = grpMaintPageObj.deleteButtonExitsForAddedUser();
		System.out.println(flag);





		try
		{
			SoftAssert softassert = new SoftAssert();


			softassert.assertTrue(flag,"Delete Button is not  present for added user.User can not be deleted");



			softassert.assertAll();

			System.out.println("TC014_groupMaintenance Passed");

			String status="Pass";

			//  test.log(LogStatus.PASS, "TC013_groupMaintenance Passed");    

			// xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);

			//   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 



		}

		catch(Throwable e)
		{
			/*  System.out.println("TC014_groupMaintenance Failed");

					//  test.log(LogStatus.FAIL, "TC014_groupMaintenance Failed"); 


					   String status="Fail";

					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);

					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 

						  Assert.fail(e.getMessage()); */	//Anuja-07/19/2021
			printFailure("TC014_groupMaintenance",e);     

		}

	}


}
