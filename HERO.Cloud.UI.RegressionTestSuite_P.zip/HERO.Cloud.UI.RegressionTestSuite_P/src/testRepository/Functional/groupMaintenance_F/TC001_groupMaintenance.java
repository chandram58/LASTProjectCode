package testRepository.Functional.groupMaintenance_F;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

public class TC001_groupMaintenance extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void NavigationtoRoleManagementPage() throws IOException
		{
			
			 
			/* xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=1;	*/ //Anuja-07/21/21
				
	     try{
				 
			/*  WebDriverWait wait=new WebDriverWait(driver,10000);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]")));
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Group Maintenance')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Group Maintenance')]"))).click().release().build().perform();
				
				String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Group Maintenance')]")).getText();
				
				System.out.println(PageTitle);
				
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
			 
			 
			// driver.findElement(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1")).click();
			 
			// driver.findElement(By.xpath("//a[contains(text(),'Roles Management')]")).click();
			 
			 System.out.println("1");
				
			 
			 Thread.sleep(5000);
			 
			 
			//String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Roles Management')]")).getText();
			 */ //Anuja-07/21/21
	    	 
	 		HomePage homePageObj=new HomePage();

	 		xlinputfile=prop.getProperty("xlInputPath");	
	 		System.out.println(xlinputfile);

	 		xlReportPath=prop.getProperty("xlReportPath");	
	 		System.out.println(xlReportPath);

	 		homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Group Maintenance");
	 		GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 
	 		String PageTitle=grpMaintPageObj.getPageHeader_GroupMaintenance();
	 		System.out.println(PageTitle);
			
           SoftAssert softAssert = new SoftAssert();
		     
		    // test.log(LogStatus.INFO ,"Verifying page Title");
		     
	    softAssert.assertTrue(PageTitle.toLowerCase().contains("group maintenance"), "This is not Group Maintenance page");
		     
		    
		     
		      softAssert.assertAll();
		      
		      System.out.println("TC001_groupMaintenance Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC001_groupMaintenance Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					 /*  System.out.println("TC001_groupMaintenance Failed");
					   
					//  test.log(LogStatus.FAIL, "TC001_groupMaintenance Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						 */ printFailure("TC001_groupMaintenance",e);    
					   
				      }
		
		
		      }
	
	
	






}
