package testRepository.Functional.groupMaintenance_F;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

import com.relevantcodes.extentreports.LogStatus;

public class TC016_groupMaintenance extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";




	@Test
	public void UpdateEnddateGroup() throws IOException, InterruptedException
	{

		/*	 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);


			   xlReportPath=(getPropertyValue())[3].toString();

			   System.out.println(xlReportPath);

			   int i=15;



			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");

			 Thread.sleep(10000);

				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Group Maintenance')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Group Maintenance')]"))).click().release().build().perform();



				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Group Maintenance')]"))).click().perform();

		 */ //Anuja-07/20/21  

		HomePage homePageObj=new HomePage();

		xlinputfile=prop.getProperty("xlInputPath");	//Anuja-07/16/21
		System.out.println(xlinputfile);

		xlReportPath=prop.getProperty("xlReportPath");	//Anuja-07/16/21
		System.out.println(xlReportPath);

		homePageObj.mouseHoverAdministration();	
		homePageObj.openModule("Group Maintenance");//Anuja-07/16/21
		GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 


		// test.log(LogStatus.INFO, "Clicking on edit button");

		/* driver.findElement(By.xpath("//tbody/tr[1]/td[5]/div[1]/a[2]/em[1]")).click();

			  Thread.sleep(3000);*/ //Anuja-07/20/21

		grpMaintPageObj.clickEditGroup(1);

		//Updating Group    
		/*	           
	driver.switchTo().defaultContent();

	 WebElement webtable;

 webtable=driver.findElement(By.xpath("//app-group[1]/div[1]/div[4]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]"));

     List<WebElement> rows;
     List<WebElement> cols = null;
     WebElement UserEnddate,GroupEndDate,calendardate;

     String UpdateDate="12/30/9999";

  	System.out.println("3");

     rows=webtable.findElements(By.tagName("tr"));

    System.out.println("No of rows on Add Users Table->"+ rows.size());



 for(int j=0;j<rows.size();j++)
 {  
	 cols=rows.get(j).findElements(By.tagName("td"));
     String Username=cols.get(0).getText();


     System.out.println(Username);



     if((!Username.isEmpty()))
     {	 
    	 UserEnddate=cols.get(3).findElement(By.xpath("//app-group[1]/div[1]/div[4]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/p-table[1]/div[1]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[3]/div[1]/p-calendar[1]"));
    	 UserEnddate.click();
    	 calendardate=driver.findElement(By.xpath("//tbody/tr[5]/td[5]/a[1]"));
    	 calendardate.click();
    	 Thread.sleep(2000);
    	 UserEnddate=cols.get(3).findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div[2]/p-table/div/div/div/div[2]/table/tbody/tr/td[3]/div/p-calendar/span/input"));

    	// UserEnddate.sendKeys(Keys.chord(Keys.CONTROL, "a"));
    	// UserEnddate.sendKeys(Keys.DELETE);

        	  Thread.sleep(2000);
       // 	  UserEnddate.sendKeys(UpdateDate);

          }

     }
		 */
		String UpdateDate="12/30/9000";

		if(grpMaintPageObj.verifyUsersExists())
		{
			grpMaintPageObj.updateEndDateForUsers_EditGroup(UpdateDate);

		}

		/*GroupEndDate=driver.findElement(By.xpath("//p-calendar[@id='updateGroupEndDate']/span/input"));

	GroupEndDate.sendKeys(Keys.chord(Keys.CONTROL, "a"));
	GroupEndDate.sendKeys(Keys.DELETE);

   	  Thread.sleep(2000);
   	GroupEndDate.sendKeys(UpdateDate); */ //Anuja-07/20/21

		grpMaintPageObj.updateEndDateForGroup_EditGroup(UpdateDate);
base.selectDateFromDatePicker("12/30/9000");
		//Clicking on SaveButton
		//driver.findElement(By.xpath("//app-group[1]/div[1]/div[4]/form[1]/div[2]/div[3]/div[1]/div[1]/button[1]/span[1]")).click();

		grpMaintPageObj.clickSave_NewGroup();		 
		driver.switchTo().defaultContent();
		/*
 Thread.sleep(5000);

 String Message=driver.findElement(By.xpath("//div[contains(text(),'Group has been updated successfully')]")).getText(); */ //Anuja-07/20/21
		String Message=grpMaintPageObj.getSuccessMessage("update");			 

		System.out.println(Message);

		//String GroupEndDateGroupMaintenanceTable=driver.findElement(By.xpath("//tbody/tr[1]/td[4]/div[1]")).getText();

		String GroupEndDateGroupMaintenanceTable=grpMaintPageObj.getEndDateForGroup(1);


		try
		{
			SoftAssert softassert = new SoftAssert();

			softassert.assertTrue(Message.contains("Group has been updated successfully"), "Group Update message incorrect");

			softassert.assertTrue(GroupEndDateGroupMaintenanceTable.equals(UpdateDate), "Group Date not Updated");


			softassert.assertAll();

			System.out.println("TC016_groupMaintenance Passed");

			String status="Pass";

			//  test.log(LogStatus.PASS, "TC016_groupMaintenance Passed");    

			// xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);

			//   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 



		}

		catch(Throwable e)
		{
			/*System.out.println("TC016_groupMaintenance Failed");

			//  test.log(LogStatus.FAIL, "TC016_groupMaintenance Failed"); 


			String status="Fail";

			//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);

			//    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 

			Assert.fail(e.getMessage());

*/ //Anuja-07/20/21
			printFailure("TC016_groupMaintenance",e); 
		}

	}
}

