package testRepository.Functional.groupMaintenance_F;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

public class F_TC38_groupMaintenance extends base{
	@Test 
	public void getupdatefunctionlityDB() throws ParseException, InterruptedException, SQLException {
		
		
		 SimpleDateFormat Uidate = new SimpleDateFormat("dd/mm/yyyy");
		    SimpleDateFormat output = new SimpleDateFormat("yyyy-mm-dd");
	
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Group Maintenance");
		    GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 

		WebElement groupNm=  grpMaintPageObj.getgroupNameforupdateintable(4);
	String GroupName=groupNm.getText();
	System.out.println(GroupName);
	String groupdt= grpMaintPageObj.getEndDateForGroup(4);
	System.out.println(groupdt);
	java.util.Date data = Uidate.parse(groupdt);
    String newDate_UI = output.format(data);
    System.out.println(newDate_UI); 
    
System.out.println("DB");
	//DB validation
	String GroupName_DB=null,gorup_id=null,user_id=null,start_date=null,end_date=null,Group_desc=null;
	String Query1="select*from enc.HERO_UI_GROUP  where GROUP_NAME like '"+GroupName.trim()+"'";
	System.out.println(Query1);
	 PreparedStatement readStatement = dbcon.prepareStatement(Query1);
	  rs = readStatement.executeQuery();
	  rs.next();
	  System.out.println(Query1);
	 
	  GroupName_DB=rs.getString(2);
	  System.out.println(GroupName_DB);
	  end_date=rs.getString(5).substring(0, 4);
	  System.out.println("enddate:"+end_date);
//	  java.util.Date data1 = Uidate.parse(end_date);
//	    String newDate_DB = output.format(data1);
//	    System.out.println(newDate_DB); 
	  
	try {  
 SoftAssert softAssert = new SoftAssert();
      
 softAssert.assertTrue(newDate_UI.substring(0, 4).equals(end_date.substring(0, 4)), "Group Date not Updated");
  softAssert.assertAll();
	}
	catch(Throwable e)
	{

		printFailure("DB validation failed",e);
	}
      //after updating the group End Date
      
      grpMaintPageObj.clickEditGroup(1);
      String UpdateDate="12/30/9000";

		if(grpMaintPageObj.verifyUsersExists())
		{
			grpMaintPageObj.updateEndDateForUsers_EditGroup(UpdateDate);

		}
		grpMaintPageObj.updateEndDateForGroup_EditGroup(UpdateDate);
		base.selectDateFromDatePicker("12/30/9000");
		grpMaintPageObj.clickSave_NewGroup();		 
		driver.switchTo().defaultContent();
	
		//UI
		WebElement groupNm1=  grpMaintPageObj.getgroupNameforupdateintable(4);
		String Groupname=groupNm.getText();
		System.out.println(Groupname);
		String groupdt1= grpMaintPageObj.getEndDateForGroup(4);
		System.out.println(groupdt1);
		java.util.Date data2 = Uidate.parse(groupdt1);
	    String newDate_UI1 = output.format(data2);
	    System.out.println(newDate_UI1); 
	
	    //db
	    String Query2="select*from enc.HERO_UI_GROUP  where GROUP_NAME like '"+Groupname.trim()+"'";
		System.out.println(Query2);
		 PreparedStatement readStatement1 = dbcon.prepareStatement(Query2);
		  rs = readStatement1.executeQuery();
		  rs.next();
		  System.out.println(Query2);
		 
		  GroupName_DB=rs.getString(2);
		  System.out.println(GroupName_DB);
		  end_date=rs.getString(5);
		  System.out.println(end_date);
		  
		  try {  
			  SoftAssert softAssert = new SoftAssert();
		      
			  softAssert.assertEquals(end_date.trim().substring(0, 4), newDate_UI.trim().substring(0, 4),"group end is  not matching with DB");
			     
		      softAssert.assertAll();

				System.out.println("TC38_groupMaintenance Passed");

			}
			catch(Throwable e)
			{
				 System.out.println("TC38_groupMaintenance Failed");
				  Assert.fail(e.getMessage());
			}
	  
		  
	}

}
