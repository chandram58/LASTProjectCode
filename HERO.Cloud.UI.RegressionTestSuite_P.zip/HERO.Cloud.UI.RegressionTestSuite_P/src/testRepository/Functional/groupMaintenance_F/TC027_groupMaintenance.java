package testRepository.Functional.groupMaintenance_F;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

import com.relevantcodes.extentreports.LogStatus;

public class TC027_groupMaintenance extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void ThreeYearsExpiredDataValidation() throws IOException, InterruptedException, ParseException
		{
			
		/*	 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=27;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			
		
	
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Group Maintenance')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Group Maintenance')]"))).click().release().build().perform();

				  
				   
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Group Maintenance')]"))).click().perform();
			 
              */
				
			HomePage homePageObj=new HomePage();
		
			xlinputfile=prop.getProperty("xlInputPath");	//Anuja-07/16/21
			System.out.println(xlinputfile);

			xlReportPath=prop.getProperty("xlReportPath");	//Anuja-07/16/21
			System.out.println(xlReportPath);
			
			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Group Maintenance");//Anuja-07/16/21
			GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 

			/*	
				WebElement webtable=driver.findElement(By.className("ui-table-scrollable-body-table"));
			     
			     List<WebElement> rows;
			     List<WebElement> cols = null;
			     List<String> InactivegroupStartDateList = new ArrayList<String>();
			 Boolean flag = true;
			     
			  	System.out.println("3");
			     
			     rows=webtable.findElements(By.tagName("tr"));
			     
			    System.out.println("No of rows on Group Maintenance Table->"+ rows.size());
              
			*/   
			    SimpleDateFormat date1=new SimpleDateFormat("MM/dd/yyyy");
			    Date endDate = null;
			    String StartDate;
			    int inactiveGroupCount=0;
			    
			    LocalDate date;  
			    
			    
			    List<String> InactivegroupEndDateList = new ArrayList<String>();
			    InactivegroupEndDateList= grpMaintPageObj.getGroupEndDateForInActiveGrps();
				 
			/*	for(int j=0;j<rows.size();j++) 
				   {
						cols=rows.get(j).findElements(By.tagName("td"));
						
						
						if(rows.get(j).getAttribute("class").equals("hasExpired ng-star-inserted"))
					     { 
						
					     StartDate=cols.get(2).getText().trim();
					     
					     System.out.println(StartDate);
					     
					     InactivegroupStartDateList.add(StartDate);
						
						 inactiveGroupCount++;
						
					     }
						} */
				        
				
				      

				System.out.println("InActiveGroupStartDateListSize="+InactivegroupEndDateList.size());

						
						
					//	System.out.println("Number of Active Users in User profile page->"+InactivegroupStartDateList);
						
						
						//getting current date
						 Calendar calendar = Calendar.getInstance();
						System.out.println("Today's date is->"+date1.format(calendar.getTime()));
						
			          //Getting Current date - 3 Years date
			    
						
						 calendar.add(Calendar.YEAR, -3);
						 System.out.println("3 years ago  is->"+date1.format(calendar.getTime()));
						 Date Date3YearsAgo=date1.parse(date1.format(calendar.getTime()));
						 System.out.println(Date3YearsAgo);
						
						 Boolean flag = true;
						 
						 for(int j=0;j<InactivegroupEndDateList.size();j++)
						 {
							 String listdate=InactivegroupEndDateList.get(j);
							 System.out.println(listdate);
							 endDate= date1.parse(listdate);
							 System.out.println(endDate);
							if(endDate.before(Date3YearsAgo))	 
							{
								flag=false;
								System.out.println("Row no->" +(j+1)+" Start date earlier than 3 years" );
								break;
							}
						 }
						
						 System.out.println(flag);
						 

			  Thread.sleep(3000);
           
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
			    
			  
	          softassert.assertTrue( flag,"Group Maintence page inactive recods contain data earlier than 3 years  ");
			  
			
			    
			    softassert.assertAll();
				 
				    System.out.println("TC027_groupMaintenance Passed");
				    
				     String status="Pass";
				     
				 //  test.log(LogStatus.PASS, "TC027_groupMaintenance Passed");    
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					/*   System.out.println("TC027_groupMaintenance Failed");
					   
					//  test.log(LogStatus.FAIL, "TC027_groupMaintenance Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     */
	    	printFailure("TC027_groupMaintenance",e); 
					   
				      }
	
		}
	

}
