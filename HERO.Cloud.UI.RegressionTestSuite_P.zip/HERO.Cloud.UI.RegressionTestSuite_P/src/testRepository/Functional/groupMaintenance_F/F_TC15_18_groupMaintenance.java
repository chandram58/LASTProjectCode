package testRepository.Functional.groupMaintenance_F;

import java.util.Date;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

public class F_TC15_18_groupMaintenance extends base{
	@Test
	public void getExpriedGrousViewfunctionality() throws InterruptedException {
		
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		homePageObj.openModule("Group Maintenance");
		GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 
		grpMaintPageObj.clickAddNewGroup();	
		String groupName="Group"+new Date().getTime();
		System.out.println("GroupName="+groupName);
		grpMaintPageObj.inputNewGroupName(groupName);
		grpMaintPageObj.inputNewGrpDescription("Group Created by Automation");
		String UpdateDate="12/30/9000";
		grpMaintPageObj.updateEndDateForGroup_EditGroup(UpdateDate);
		grpMaintPageObj.clickonTodaybtn();
		grpMaintPageObj.clickSelectUsers_NewGroup();
		
		grpMaintPageObj.clickSave_NewGroup();
		
		grpMaintPageObj.getGroupNamebySearch(groupName);
		Thread.sleep(5000);
		WebElement group=grpMaintPageObj.getexpriedgroupaftersearch();
		 String groupexp=group.getAttribute("class");
		System.out.println(groupexp);
		grpMaintPageObj.ViewbtnforInActiveGroups().click();
	String viewpage=	grpMaintPageObj.getViewPageforexpried().getText();
	System.out.println(viewpage);
	//grpMaintPageObj.clickViewcancel();
	
	try {  
		  SoftAssert softAssert = new SoftAssert();
	      
		  softAssert.assertTrue(viewpage.contains("View Group"), "View Group is not getting for expried groups" );
		  softAssert.assertTrue(groupexp.contains("hasExpired"), "group is expried" );
		  
	      softAssert.assertAll();

			System.out.println("TC15_groupMaintenance Passed");

		}
		catch(Throwable e)
		{
			 System.out.println("TC15_groupMaintenance Failed");
			  Assert.fail(e.getMessage());
		}
		
		
	}

}
