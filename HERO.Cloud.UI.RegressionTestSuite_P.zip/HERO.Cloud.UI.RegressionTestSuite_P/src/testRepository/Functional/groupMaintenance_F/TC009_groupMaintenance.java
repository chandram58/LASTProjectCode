package testRepository.Functional.groupMaintenance_F;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

import com.relevantcodes.extentreports.LogStatus;

public class TC009_groupMaintenance extends base
{
	public String xlinputfile,xlReportPath;

	/*
	 * public String Xlsheet_InputQuery="Query_roleManagement"; public String
	 * Xlsheet_ReportModule="Role Management";
	 */



	@Test
	public void AddNewGroup() throws IOException, InterruptedException
	{
		
		HomePage homePageObj=new HomePage();
		// xlinputfile=(getPropertyValue())[0].toString();	
		xlinputfile=prop.getProperty("xlInputPath");	//Anuja-07/16/21
		System.out.println(xlinputfile);


		//xlReportPath=(getPropertyValue())[3].toString();	
		xlReportPath=prop.getProperty("xlReportPath");	//Anuja-07/16/21
		System.out.println(xlReportPath);

		int i=9;

		/*		  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");

			 Thread.sleep(10000);


				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Group Maintenance')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Group Maintenance')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Group Maintenance')]"))).click().perform();
		 */	//Anuja-07/16/21		 
		homePageObj.mouseHoverAdministration();	
		homePageObj.openModule("Group Maintenance");	//Anuja-07/16/21

		GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 

		/*		  Thread.sleep(3000);

			 // test.log(LogStatus.INFO, "Clicking on Add New Role button");

			  driver.findElement(By.xpath("//span[contains(text(),'Add New Group')]")).click();

			 System.out.println("1");

			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='addGroupName']")));

			 driver.findElement(By.xpath("//input[@id='addGroupName']")).sendKeys("Automation33");

			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@id='addDescription']")));

			 driver.findElement(By.xpath("//textarea[@id='addDescription']")).sendKeys("Automation"); */	//Anuja-07/16/2021

		grpMaintPageObj.clickAddNewGroup();	
		String groupName="Group"+new Date().getTime();
		System.out.println("GroupName="+groupName);
		grpMaintPageObj.inputNewGroupName(groupName);
		grpMaintPageObj.inputNewGrpDescription("Group Created by Automation");

		/*	WebElement multiselect=driver.findElement(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]"));

				  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[1]/div[1]/p-multiselect[1]")));

		           multiselect.click();  

		           System.out.println("2");

		           Thread.sleep(500);

		           wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem[3]/li/span")));

		           driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div/div[1]/div[1]/p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem[3]/li/span")).click();

	           //Clicking On Blank Area    

	    	   driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div/div[5]/div")).click(); */ //Anuja-07/19/21
		//grpMaintPageObj.clickSelectUsers_NewGroup();
		//grpMaintPageObj.selectFirstUserToGroup();

		//click on Save button on New Role Page

		/* driver.findElement(By.xpath("//app-group[1]/div[1]/div[3]/form[1]/div[2]/div[3]/div[1]/div[1]/button[1]/span[1]")).click();

	  Thread.sleep(2000);	*/ //Anuja-07/19/21

		grpMaintPageObj.clickSave_NewGroup();

	//	driver.switchTo().defaultContent();
Thread.sleep(1000);

		/*String Message=driver.findElement(By.xpath("//div[contains(text(),'Group has been created successfully')]")).getText();

		System.out.println(Message);	*/ //Anuja-07/19/21
		
		String Message=grpMaintPageObj.getSuccessMessage("new");

		/*
		 * WebElement webtable;
		 * 
		 * Thread.sleep(3000);
		 * 
		 * 
		 * 
		 * webtable=driver.findElement(By.className("ui-table-scrollable-body-table"));
		 * 
		 * List<WebElement> rows; List<WebElement> cols = null;
		 * 
		 * Boolean flag = false;
		 * 
		 * System.out.println("3");
		 * 
		 * rows=webtable.findElements(By.tagName("tr"));
		 * 
		 * System.out.println("No of rows on Roles Management Page->"+ rows.size());
		 * 
		 * 
		 * 
		 * 
		 * 
		 * for(i=0;i<rows.size();i++) { cols=rows.get(i).findElements(By.tagName("td"));
		 * String GroupName_UI=cols.get(0).getText();
		 * 
		 * System.out.println(GroupName_UI);
		 * 
		 * if(GroupName_UI.equals("Automation")) { flag=true;
		 * 
		 * break; } }
		 * 
		 * 
		 */ //Anuja-07/19/21

		Boolean flag = grpMaintPageObj.validateGroupCreated(groupName);


		try
		{
			SoftAssert softassert = new SoftAssert();

			softassert.assertTrue(Message.contains("Group has been created successfully"), "User not Received Success message"); 

			softassert.assertTrue(flag,"New created group not found on Group Maintenance Table");



			softassert.assertAll();

			System.out.println("TC009_groupMaintenance Passed");

			String status="Pass";

			//  test.log(LogStatus.PASS, "TC031_roleManagement Passed");    

			// xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);

			//   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 



		}

		catch(Throwable e)
		{
		/*	System.out.println("TC009_groupMaintenance Failed");

			//  test.log(LogStatus.FAIL, "TC009_groupMaintenance Failed"); 


			String status="Fail";

			//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);

			//    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 

			Assert.fail(e.getMessage());*/ //Anuja-07/19/21

			printFailure("TC009_groupMaintenance",e);
		}

	}


}
