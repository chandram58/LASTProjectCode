package testRepository.Functional.groupMaintenance_F;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

public class F_TC36_37_groupMaintenance extends base{

	@Test
	public void getgroupdetailsfromDB() throws InterruptedException, SQLException {
		
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		homePageObj.openModule("Group Maintenance");
		GroupMaintenancePage grpMaintPageObj=new GroupMaintenancePage(); 
		grpMaintPageObj.clickAddNewGroup();	
		String groupName="Group"+new Date().getTime();
		System.out.println("GroupName="+groupName);
		grpMaintPageObj.inputNewGroupName(groupName);
		grpMaintPageObj.inputNewGrpDescription("Group Created by Automation");
		grpMaintPageObj.clickSelectUsers_NewGroup();
		//datasepecific
		grpMaintPageObj.getUserbySearch("VIP1189");
		grpMaintPageObj.clickseacheduserfromDd();
		
		grpMaintPageObj.clickSave_NewGroup();
		grpMaintPageObj.getGroupNamebySearch(groupName);
		
	String gropfrmtable=	grpMaintPageObj.getgroupNamefromTablebysearch().getText();
	System.out.println(gropfrmtable);
	String descripfrmtable=grpMaintPageObj.getDescriptionfromTable().getText();
	System.out.println(descripfrmtable);
	List<String> ActivegroupStartDateList = new ArrayList<String>();
	ActivegroupStartDateList=	grpMaintPageObj.getGroupStartDateForActiveGrps();
System.out.println(ActivegroupStartDateList);

String sartdate = ActivegroupStartDateList.stream().map(Object::toString)
.collect(Collectors.joining(",")); 
System.out.println(sartdate);

		//	driver.switchTo().defaultContent();
	Thread.sleep(1000);
	//String Message=grpMaintPageObj.getSuccessMessage("new");
	
	

	//DB validation
	String GroupName_DB=null,gorup_id=null,user_id=null,start_date=null,end_date=null,Group_desc=null;
	String Query1="select*from enc.HERO_UI_GROUP  where GROUP_NAME like '"+groupName.trim()+"'";
	System.out.println(Query1);
	 PreparedStatement readStatement = dbcon.prepareStatement(Query1);
	  rs = readStatement.executeQuery();
	  rs.next();
	  System.out.println(Query1);
	  gorup_id=rs.getString(1);
	  System.out.println(gorup_id);
	  GroupName_DB=rs.getString(2);
	  System.out.println(GroupName_DB);
	  Group_desc=rs.getString(3);
	  System.out.println(Group_desc);
	  start_date=rs.getString(4);
	  System.out.println(start_date);
	  end_date=rs.getString(5);
	  System.out.println(end_date);
	  
	  Thread.sleep(3000);
	  
	  //db
	 
	  
	try {  
	  SoftAssert softAssert = new SoftAssert();
      
      softAssert.assertEquals(GroupName_DB.trim().toLowerCase(), gropfrmtable.trim().toLowerCase(),"GroupName not matching with DB");
      softAssert.assertEquals(Group_desc.trim().toLowerCase(), descripfrmtable.trim().toLowerCase(),"GroupDesc not matching with DB");
    
      softAssert.assertAll();

		System.out.println("TC36_37_groupMaintenance Passed");

	}
	catch(Throwable e)
	{

		 System.out.println("TC36_37_groupMaintenance Failed");
		  Assert.fail(e.getMessage());
	}

	}
}
