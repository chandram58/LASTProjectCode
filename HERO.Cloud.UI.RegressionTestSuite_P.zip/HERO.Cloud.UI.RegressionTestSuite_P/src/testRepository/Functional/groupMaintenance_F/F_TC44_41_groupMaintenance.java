package testRepository.Functional.groupMaintenance_F;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.GroupMaintenancePage;
import pages.HomePage;

public class F_TC44_41_groupMaintenance extends base{
	@Test
	public void getResetfunctionalityfrmfilter() throws InterruptedException {
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		homePageObj.openModule("Group Maintenance");
		GroupMaintenancePage  grpMaintPageObj=new GroupMaintenancePage();
		grpMaintPageObj.clickonFiltersection();
		String GroupName="Demo";
		grpMaintPageObj.getGroupNamefrmFilter(GroupName);
		grpMaintPageObj.getUserfrmFilter();
		String startdate="08/17/2021";
		grpMaintPageObj.selectStartDatefrmFilter(startdate);
		String EndDate="12/31/9999";
		grpMaintPageObj.selectEndDatefrmFilter(EndDate);
		String Description="Demo123";
		grpMaintPageObj.getDescriptionfrmFilter(Description);
		grpMaintPageObj.clickonFilterbtn(); 
		System.out.println(1);
		WebElement grpnamefromTabel=grpMaintPageObj.validateGroupAfterfilter();
	String groupafterfilter=grpnamefromTabel.getText();
	//System.out.println(groupafterfilter);
	WebElement groupafterreset=grpMaintPageObj.getgroupfieldfrmfilter();
	System.out.println(groupafterreset.getAttribute("class"));
	grpMaintPageObj.clickonResetbtn();
	Thread.sleep(3000);
	System.out.println("reset");
	WebElement groupafterreset1=grpMaintPageObj.getgroupfieldfrmfilter();
	System.out.println(groupafterreset1.getAttribute("class"));
	Thread.sleep(3000);
	
	try {
		 SoftAssert softAssert = new SoftAssert();
			softAssert.assertTrue(groupafterreset1.getAttribute("class").contains("ng-touched"), "reset btn is not applied" );
			softAssert.assertAll();
			System.out.println("TC043_41_groupMaintenance is passed");
	}
	catch(Exception e)
	{
		Assert.fail(e.getMessage());
		 System.out.println("TC043_41_groupMaintenance is failed");
	}
	}

}
