package testRepository.Functional.modifyTimecard_F;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class TC30_timecardManagement extends base{
	@Test
	public void geterrormessageforusername() throws InterruptedException {
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonNewTimeCard().click();
		Thread.sleep(3000);
		timecardManagementPagObj.clickonSelectUser().click();
		timecardManagementPagObj.SelectUserfromDropd("vijji");
		timecardManagementPagObj.clicknewTimeCardDate().click();
		Thread.sleep(2000);
		 timecardManagementPagObj.clickonSavebtn();
		 
	WebElement	usrmesg= timecardManagementPagObj.getuserNameErrormessage();
	String usermessage=usrmesg.getText();
	System.out.println(usermessage);
	WebElement strttim=	timecardManagementPagObj.getstartdateErrormessage();
	String srtimemessage=strttim.getText();
	System.out.println(srtimemessage);
	Thread.sleep(2000);
	timecardManagementPagObj.clickonSelectUser().click();
	timecardManagementPagObj.SelectUserfromDropd("vijji");
	timecardManagementPagObj.clicknewTimeCardDate().click();
	base.selectDateFromDatePicker("06/04/2021");
	timecardManagementPagObj.clickonStartTimeinTimeCard().click();
	 timecardManagementPagObj.getStartTimeinTimeCard().click();
	 WebElement endtime1=	timecardManagementPagObj.clickonendTimeinTimeCard();
	 endtime1.click();
	 timecardManagementPagObj.getends().click();
WebElement errms= timecardManagementPagObj.getendserrmesge();
 String errmessagend= errms.getText();
 System.out.println(errmessagend);
 
 try {
		SoftAssert softAssert = new SoftAssert();   
		 softAssert.assertTrue(usermessage.contains(" User name is required."),"not amandatory field");
		 softAssert.assertTrue(srtimemessage.contains(" Start Time is required. "),"not amandatory field");
		 softAssert.assertTrue(errmessagend.contains(" End time should be .. "),"not amandatory field");
		 softAssert.assertAll();
		  System.out.println("TC_30_timecardmanagement is passed");
				}
				
	 catch(Throwable e)
	     {
				   System.out.println("TC_30_timecardmanagement Failed");
				   Assert.fail(e.getMessage());
	     }
	 
	 
	}

}
