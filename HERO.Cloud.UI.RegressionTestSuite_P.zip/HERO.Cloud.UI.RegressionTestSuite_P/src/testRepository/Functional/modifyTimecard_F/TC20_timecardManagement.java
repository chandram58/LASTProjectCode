package testRepository.Functional.modifyTimecard_F;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class TC20_timecardManagement extends base {
	@Test
	public void updatetimecardProductivehrsFunct() throws InterruptedException {
		
		 HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(1000);
			homePageObj.openModule("Timecard Management");
			
			TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
			timecardManagementPagObj.clickonselectuserfileldinfiltr().click();
			timecardManagementPagObj.getsearchuser("Vijji");
			timecardManagementPagObj.clickonuser().click();
			Thread.sleep(3000);
			timecardManagementPagObj.clickstartdate().click();
			base.selectDateFromDatePicker("10/01/2021");
			Thread.sleep(3000);
			timecardManagementPagObj.clickenddate().click();
			base.selectDateFromDatePicker("10/01/2021");
			Thread.sleep(3000);
			timecardManagementPagObj.clickFilterbtn().click();
			Thread.sleep(2000);
			WebElement endtcrdbeforupdate=timecardManagementPagObj.getendtimefrmupdatetime();
			String entime=endtcrdbeforupdate.getText();
			System.out.println(entime);
			Thread.sleep(3000);
			timecardManagementPagObj.clickonEditbutton();
	
			String reason="Lunch";
			timecardManagementPagObj.clickonAddReasonCode().click();
			timecardManagementPagObj.clickonSecltreasoncode().click();
			timecardManagementPagObj.clickonSearchreasoncode(reason);
			timecardManagementPagObj.clickreasoncode().click();
			Thread.sleep(2000);
	
		timecardManagementPagObj.clickReasonSarttime();
		timecardManagementPagObj.getReasonSarttime();
		Thread.sleep(3000);
		timecardManagementPagObj.clickReasonEndtime();
		timecardManagementPagObj.getReasonEndtime();
		timecardManagementPagObj.getDescriptionfield("test");
		Thread.sleep(9000);
		
	
		timecardManagementPagObj.clickonSavebtn();
		Thread.sleep(5000);
		WebElement endtcrdAfterupdate=timecardManagementPagObj.getendtimefrmupdatetime();
		String entime1afterupdate=endtcrdAfterupdate.getText();
		System.out.println(entime1afterupdate);
		
		 try {
				SoftAssert softAssert = new SoftAssert();   
			
				 assertNotEquals(entime,entime1afterupdate);
				 softAssert.assertAll();
				  System.out.println("TC_20_timecardmanagement is passed");
						}
						
			 catch(Throwable e)
			     {
						   System.out.println("TC_20_timecardmanagement Failed");
						   Assert.fail(e.getMessage());
			     }
			
			
	}

}
