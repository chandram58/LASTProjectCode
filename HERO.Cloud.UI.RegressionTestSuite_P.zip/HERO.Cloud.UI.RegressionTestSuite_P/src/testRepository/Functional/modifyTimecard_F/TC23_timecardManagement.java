package testRepository.Functional.modifyTimecard_F;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class TC23_timecardManagement extends base{
	@Test
	public void getnoRecordsfound() throws InterruptedException {
		 HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(1000);
			homePageObj.openModule("Timecard Management");
			
			TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
			timecardManagementPagObj.clickonselectuserfileldinfiltr().click();
			timecardManagementPagObj.getsearchuser("Vijji");
			timecardManagementPagObj.clickonuser().click();
			Thread.sleep(3000);
			timecardManagementPagObj.clickstartdate().click();
			base.selectDateFromDatePicker("04/01/2021");
			Thread.sleep(3000);
			timecardManagementPagObj.clickenddate().click();
			base.selectDateFromDatePicker("04/01/2021");
			Thread.sleep(3000);
			timecardManagementPagObj.clickFilterbtn().click();
			Thread.sleep(2000);
	WebElement recods=timecardManagementPagObj.getNoorecordfnd();
   String records=recods.getText();
   System.out.println(records);
   try {
		SoftAssert softAssert = new SoftAssert();   
		 softAssert.assertTrue(records.contains("No records found"), "records are found");
		
		 softAssert.assertAll();
		  System.out.println("TC_23_timecardmanagement is passed");
				}
				
	 catch(Throwable e)
	     {
				   System.out.println("TC_23_timecardmanagement Failed");
				   Assert.fail(e.getMessage());
	     }
	
	}

}
