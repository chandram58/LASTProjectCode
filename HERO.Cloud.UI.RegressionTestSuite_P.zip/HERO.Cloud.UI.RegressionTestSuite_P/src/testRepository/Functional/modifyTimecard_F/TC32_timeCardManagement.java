package testRepository.Functional.modifyTimecard_F;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class TC32_timeCardManagement extends base{
	@Test
	public void getErrormesaageforDesription() throws InterruptedException {
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonNewTimeCard().click();
		Thread.sleep(3000);
		timecardManagementPagObj.clickonSelectUser().click();
		timecardManagementPagObj.SelectUserfromDropd("vijji");
		timecardManagementPagObj.clicknewTimeCardDate().click();
		base.selectDateFromDatePicker("06/04/2021");
		timecardManagementPagObj.clickonStartTimeinTimeCard().click();
		 timecardManagementPagObj.getStartTimeinTimeCard().click(); 
		 WebElement endtime1=	timecardManagementPagObj.clickonendTimeinTimeCard();
		 endtime1.click();
		 Thread.sleep(3000);
		 timecardManagementPagObj.getendTimeinTimestamp().click();
		 timecardManagementPagObj.clickonSavebtn();
	WebElement ermsg=timecardManagementPagObj.geterrmesagefordesription();
String derptiomsg=	ermsg.getText();
System.out.println(derptiomsg);
try {
	SoftAssert softAssert = new SoftAssert();   
	 softAssert.assertTrue(derptiomsg.contains("Description is required"), "desription not mandatory");
	
	 softAssert.assertAll();
	  System.out.println("TC_32_timecardmanagement is passed");
			}
			
 catch(Throwable e)
     {
			   System.out.println("TC_32_timecardmanagement Failed");
			   Assert.fail(e.getMessage());
     }
		
	}

}
