package testRepository.Functional.modifyTimecard_F;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class TC31_timecardManagement extends base{

	@Test
	public void getInlineerrormessagereasoncodes() throws InterruptedException {
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonNewTimeCard().click();
		Thread.sleep(3000);
		timecardManagementPagObj.clickonSelectUser().click();
		timecardManagementPagObj.SelectUserfromDropd("vijji");
		timecardManagementPagObj.clicknewTimeCardDate().click();
		base.selectDateFromDatePicker("06/04/2021");
		timecardManagementPagObj.clickonStartTimeinTimeCard().click();
		 timecardManagementPagObj.getStartTimeinTimeCard().click(); 
		 WebElement endtime1=	timecardManagementPagObj.clickonendTimeinTimeCard();
		 endtime1.click();
		 Thread.sleep(3000);
		 timecardManagementPagObj.getendTimeinTimestamp().click();
		 Thread.sleep(3000);
			String reason="Lunch";
			timecardManagementPagObj.clickonAddReasonCode().click();
			timecardManagementPagObj.clickonSecltreasoncode().click();
			timecardManagementPagObj.clickonSearchreasoncode(reason);
			timecardManagementPagObj.clickreasoncode().click();
			Thread.sleep(2000);
	
		timecardManagementPagObj.clickReasonSarttime();
		timecardManagementPagObj.getReasonSarttime();
		Thread.sleep(3000);
		timecardManagementPagObj.clickReasonEndtime();
		timecardManagementPagObj.getReasonEndtime();
		//add one more
		
	//	String reason1="Lunch";
		timecardManagementPagObj.clickonAddReasonCode().click();
	//	timecardManagementPagObj.clickonSecltreasoncode().click();
		//timecardManagementPagObj.clickonSearchreasoncode(reason1);
		//timecardManagementPagObj.clickreasoncode().click();
		Thread.sleep(2000);

	timecardManagementPagObj.get2ndreasoncodestarttime();
	timecardManagementPagObj.getReasonSarttime();
	Thread.sleep(3000);
	timecardManagementPagObj.get2ndreasoncodeendtime();
	timecardManagementPagObj.getReasonEndtime();
	Thread.sleep(2000);
 WebElement rsontime=timecardManagementPagObj.geterrormessageixstrecord();
 String resonmsg=rsontime.getText();
 Thread.sleep(2000);
   System.out.println(resonmsg);
   
   
   try {
		SoftAssert softAssert = new SoftAssert();   
		 softAssert.assertTrue(resonmsg.contains("Entered ti.."),"not amandatory field");
		 softAssert.assertAll();
		  System.out.println("TC_31_timecardmanagement is passed");
				}
				
	 catch(Throwable e)
	     {
				   System.out.println("TC_31_timecardmanagement Failed");
				   Assert.fail(e.getMessage());
	     }
	}
}
