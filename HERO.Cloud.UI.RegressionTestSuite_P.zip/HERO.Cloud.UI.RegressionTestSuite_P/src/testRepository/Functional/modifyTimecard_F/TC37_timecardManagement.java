package testRepository.Functional.modifyTimecard_F;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class TC37_timecardManagement extends base{
	@Test 
	public void getDBdetailsfortimecard() throws InterruptedException, SQLException {
		 HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(1000);
			homePageObj.openModule("Timecard Management");
			
			TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
			timecardManagementPagObj.clickonselectuserfileldinfiltr().click();
			timecardManagementPagObj.getsearchuser("Vijji");
			timecardManagementPagObj.clickonuser().click();
			Thread.sleep(3000);
			timecardManagementPagObj.clickstartdate().click();
			base.selectDateFromDatePicker("08/01/2021");
			Thread.sleep(3000);
			timecardManagementPagObj.clickenddate().click();
			base.selectDateFromDatePicker("08/01/2021");
			Thread.sleep(3000);
			timecardManagementPagObj.clickFilterbtn().click();
			Thread.sleep(2000);
			List<String> Userdetailsintable = new ArrayList<String>();
			Userdetailsintable=timecardManagementPagObj.getUsersfromTable();
		System.out.println(Userdetailsintable);
	 String user_UI = Userdetailsintable.stream().map(Object::toString)
                .collect(Collectors.joining(",")); 
		    System.out.println(user_UI);
		Thread.sleep(2000);	
	WebElement rsltableDa=timecardManagementPagObj.getDatesfromTable();
	String rltDates=rsltableDa.getText();
	System.out.println(rltDates);
	//DB
	String USER_ID_user=null,USER_FIRST_NAME=null,user_id_db=null,created_date_DB=null;
	
	String Query1="SELECT * from HERO_UI_USER_DETAILS  WHERE USER_FIRST_NAME like '"+user_UI.trim()+"'";
	
	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
	  rs = readStatement.executeQuery();
	  rs.next();
	  
	  USER_ID_user=rs.getString(1);
	  USER_FIRST_NAME=rs.getString(3);
	  System.out.println("userID from user table : "+ USER_ID_user);
	  System.out.println("username from usertable :"+ USER_FIRST_NAME );
	  
	  String Query2="SELECT * from HERO_UI_LOGIN_TIME_DETAILS  WHERE USER_ID like '"+USER_ID_user.trim()+"'" +"order by CREATED_DATE desc";
		
	  PreparedStatement readStatement1 = dbcon.prepareStatement(Query2);
	  rs = readStatement1.executeQuery();
	  rs.next();
	  user_id_db=rs.getString(1);
	  created_date_DB=rs.getString(5);
	  System.out.println("userID from user table : "+ user_id_db);
	  System.out.println("username from usertable :"+ created_date_DB );
	  String creDate_db=created_date_DB.substring(0,10);
	  System.out.println(creDate_db);
	  
	  try {
			 
		  SoftAssert softAssert = new SoftAssert();
     softAssert.assertTrue(USER_ID_user.toLowerCase().equals(user_UI.toLowerCase()), "user ID is not matching in db and UI" );
	  softAssert.assertTrue(rltDates.contains(creDate_db), "created date not matching with UI and DB" );
  
      softAssert.assertAll();

      System.out.println("TC_37_timecardmanagement is passed");
      }
 
catch(Throwable e)
   {
	   System.out.println("TC_37_timecardmanagement Failed");
		  Assert.fail(e.getMessage());
		     
	   
    }

}

	}


