package testRepository.Functional.modifyTimecard_F;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class TC14_timecardManagement extends base{
	@Test
	public void verifypast2yearsDates() throws InterruptedException {
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		Thread.sleep(1000);
		timecardManagementPagObj.clickonselectuserfileldinfiltr().click();
		Thread.sleep(1000);
		timecardManagementPagObj.getsearchuser("Vij");
		Thread.sleep(1000);
		timecardManagementPagObj.clickonuser().click();
		Thread.sleep(3000);
		timecardManagementPagObj.clickstartdate().click();
		WebElement pastDt=timecardManagementPagObj.getpastdateinfltsart("2019");
		String pastDte=pastDt.getAttribute("class");
		System.out.println(pastDte);
		try {
			SoftAssert softAssert = new SoftAssert();   
			 softAssert.assertTrue(pastDte.contains("disabled "), "future dates are not disabled");
			
			 softAssert.assertAll();
			  System.out.println("TC_14_timecardmanagement is passed");
					}
					
		 catch(Throwable e)
		     {
					   System.out.println("TC_14_timecardmanagement Failed");
					   Assert.fail(e.getMessage());
		     }
	}

}
