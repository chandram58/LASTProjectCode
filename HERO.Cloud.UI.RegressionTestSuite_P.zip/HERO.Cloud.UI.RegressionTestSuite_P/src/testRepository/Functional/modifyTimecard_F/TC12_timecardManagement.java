package testRepository.Functional.modifyTimecard_F;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class TC12_timecardManagement extends base{
	@Test
	public void getFuturtimefortodattimecard() throws InterruptedException {
		
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonNewTimeCard().click();
		Thread.sleep(3000);
		timecardManagementPagObj.clickonSelectUser().click();
		timecardManagementPagObj.SelectUserfromDropd("vijji");
		timecardManagementPagObj.clicknewTimeCardDate().click();
		Thread.sleep(2000);
 WebElement frDate=timecardManagementPagObj.getfuturdate();
 Thread.sleep(2000);
 String future=frDate.getAttribute("class");
 System.out.println(future);
 try {
		SoftAssert softAssert = new SoftAssert();   
		 softAssert.assertTrue(future.contains("disabled "), "future dates are not disabled");
		
		 softAssert.assertAll();
		  System.out.println("TC_12_timecardmanagement is passed");
				}
				
	 catch(Throwable e)
	     {
				   System.out.println("TC_12_timecardmanagement Failed");
				   Assert.fail(e.getMessage());
	     }
	}

}