package testRepository.Functional.maintainErrorCodes_F;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC031_maintainErrorcodes extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void NonEditableFieldsVerificationUpdateErrorcode() throws IOException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=31;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,10000);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Maintain Error Codes')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Maintain Error Codes')]"))).click().release().build().perform();
				
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]"))).click().perform();
				
				
				String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]")).getText();
				
				System.out.println("Page Title before clicking Edit Button->"+PageTitle);
				
			
                //Clicking on Edit Icon
				driver.findElement(By.xpath("//tbody/tr[1]/td[8]/span[1]/a[1]/i[1]")).click();
			    Thread.sleep(5000);
			    String PageTitle2=driver.findElement(By.xpath("//h3[contains(text(),'Update Error Code')]")).getText();
		        System.out.println("Page Title after clicking Edit Button->"+PageTitle2);
			
		        //Errorcode Field
			    WebElement Errorcode=driver.findElement(By.xpath("//input[@id='updateErrorCode']"));
			    String DisabledFlag_Errorcode=Errorcode.getAttribute("disabled");
			    
			    System.out.println("DisabledFlag for Errorcode->"+DisabledFlag_Errorcode);
			   
		        //start date Field
			    WebElement Startdate=driver.findElement(By.xpath("//*[@id='updateErrorCodeStartDate']/span/input"));
			    String DisabledFlag_Startdate=Errorcode.getAttribute("disabled");
			     System.out.println("DisabledFlag for Start date->"+DisabledFlag_Startdate); 
			 
			   //DescriptionField
			    WebElement Description=driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[7]/textarea"));
				    String DisabledFlag_Description=Errorcode.getAttribute("disabled");
				     System.out.println("DisabledFlag for Description->"+DisabledFlag_Description);   
			    
			    
           SoftAssert softAssert = new SoftAssert();
           softAssert.assertTrue(DisabledFlag_Errorcode.equals("true"), "Errorcode field is Editable");
           softAssert.assertTrue(DisabledFlag_Startdate.equals("true"), "Startdate field is Editable");
           softAssert.assertTrue(DisabledFlag_Description.equals("true"), "Description field is Editable");
       	
		      softAssert.assertAll();
		    
		    	
			   
		      
		      System.out.println("TC031_manintainErrorcodes Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC031_manintainErrorcodes Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
	    
	    	
	    	
					   System.out.println("TC031_manintainErrorcodes Failed");
					   
					//  test.log(LogStatus.FAIL, "TC031_manintainErrorcodes Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
		
		
		      }
	
	
}
