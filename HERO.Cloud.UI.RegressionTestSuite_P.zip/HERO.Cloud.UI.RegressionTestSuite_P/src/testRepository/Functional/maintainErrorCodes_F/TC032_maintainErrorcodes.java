package testRepository.Functional.maintainErrorCodes_F;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC032_maintainErrorcodes extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void EditableFieldsVerificationUpdateErrorcode() throws IOException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=32;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,10000);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Maintain Error Codes')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Maintain Error Codes')]"))).click().release().build().perform();
				
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]"))).click().perform();
				
				
				String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]")).getText();
				
				System.out.println("Page Title before clicking Edit Button->"+PageTitle);
				
				 Thread.sleep(5000);
                //Clicking on Edit Icon
				driver.findElement(By.xpath("//tbody/tr[1]/td[8]/span[1]/a[1]/i[1]")).click();
			   
			    String PageTitle2=driver.findElement(By.xpath("//h3[contains(text(),'Update Error Code')]")).getText();
		        System.out.println("Page Title after clicking Edit Button->"+PageTitle2);
			
		        //Error type Field
			    WebElement Errortype=driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[3]/div/div[1]/p-dropdown/div/label"));
			    String DisabledFlag_Errortype=Errortype.getAttribute("disabled");
			    
			    System.out.println("DisabledFlag for Errortype->"+DisabledFlag_Errortype);
			   
			    //End Date Field
			    WebElement Enddate=driver.findElement(By.xpath("//*[@id='updateErrorCodeEndDate']/span/input"));
			    String DisabledFlag_Enddate=Enddate.getAttribute("disabled");
			    System.out.println("DisabledFlag for Enddate->"+DisabledFlag_Enddate);
		     
			    //Loop Field
			    WebElement Loop=driver.findElement(By.xpath("//input[@id='loopId']"));
			    String DisabledFlag_Loop=Loop.getAttribute("disabled");
			    
			    System.out.println("DisabledFlag for Loop->"+DisabledFlag_Loop);
			    
			    
			    //Segment Field
			    WebElement Segment=driver.findElement(By.xpath("//input[@id='segmentId']"));
			    String DisabledFlag_Segment=Segment.getAttribute("disabled");
			    
			    System.out.println("DisabledFlag for Segment->"+DisabledFlag_Segment);
			    
			    //Element Field
			    
			    WebElement Element=driver.findElement(By.xpath("//input[@id='elementId']"));
			    String DisabledFlag_Element=Element.getAttribute("disabled");
			    System.out.println("DisabledFlag for Element->"+DisabledFlag_Element);
			    
			//Trading Partner
			    WebElement TradingPartner=driver.findElement(By.xpath("//label[contains(text(),'Select Trading Partner')]"));
			    String DisabledFlag_TradingPartner=Element.getAttribute("disabled");
			    System.out.println("DisabledFlag for Trading Partner->"+DisabledFlag_TradingPartner);
			    
			 //Click on Trading partner drop down  
			 //   wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[contains(text(),'Select Severity')]")));
				driver.findElement(By.xpath("//label[contains(text(),'Select Trading Partner')]")).click();
				driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[2]/div/p-dropdown/div/div[3]/div[2]/ul/p-dropdownitem/li/div/div/a")).click();
				
			
				//Trading Partner id
				WebElement TradingpartnerId=driver.findElement(By.xpath("//*[contains(@id,'partnerDetails')]/div/div[2]/span"));
			    String DisabledFlag_TradingpartnerId=TradingpartnerId.getAttribute("disabled");
			    System.out.println("DisabledFlag for Trading partner id->"+DisabledFlag_TradingpartnerId);
		
			 //Severity
			    WebElement Severity=driver.findElement(By.xpath("//label[contains(text(),'Select Severity')]"));
			    String DisabledFlag_Severity=Severity.getAttribute("disabled");
			    System.out.println("DisabledFlag for Severity->"+DisabledFlag_Severity);
			        
			    //Paste Instruction radio button
			    
			    WebElement PasteRadio=driver.findElement(By.xpath("//label[contains(text(),'Paste Instructions')]"));
			    String DisabledFlag_Pasteradio=PasteRadio.getAttribute("disabled");
			    System.out.println("DisabledFlag for Paste radio button->"+DisabledFlag_Pasteradio);
			    
			    
                 //File Upload radio button
			    
			    WebElement FileUploadradio=driver.findElement(By.xpath("//label[contains(text(),'File Upload')]"));
			    String DisabledFlag_Fileuploadradio=FileUploadradio.getAttribute("disabled");
			    System.out.println("DisabledFlag for Paste radio button->"+DisabledFlag_Fileuploadradio);
			    
			    //Paste Textbox 
			 
			     
			    WebElement PasteTextbox=driver.findElement(By.xpath(" //*[contains(@id,'ui-tabpanel')]/div[2]/div/p-editor/div/div[2]"));
			    String DisabledFlag_PasteTextbox=PasteTextbox.getAttribute("disabled");
			    System.out.println("DisabledFlag for Paste Text Box->"+DisabledFlag_PasteTextbox);
			    
			    //Click on Notes
			    driver.findElement(By.xpath("//span[contains(text(),'Notes')]")).click();
			    
			    //Notes description
			    WebElement Description=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]"));
			    String DisabledFlag_Notesdescription=Description.getAttribute("disabled");
			    System.out.println("DisabledFlag for Notes Description->"+DisabledFlag_Notesdescription);
			    
			    
			    
			    //Notes Details
			    WebElement DetailNotes=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/textarea[1]"));
			    String DisabledFlag_Notesdetail=DetailNotes.getAttribute("disabled");
			    System.out.println("DisabledFlag for Notes Detail->"+DisabledFlag_Notesdetail);
			    
			    
			       
           SoftAssert softAssert = new SoftAssert();
             softAssert.assertNull(DisabledFlag_Errortype, "Errortype field is not Editable");
             softAssert.assertNull(DisabledFlag_Enddate, "End date field is not Editable");
             softAssert.assertNull(DisabledFlag_Loop, "Loop field is not Editable");
             softAssert.assertNull(DisabledFlag_Segment, "Segment field is not Editable");
             softAssert.assertNull(DisabledFlag_Element, "Element field is not Editable");
             softAssert.assertNull(DisabledFlag_TradingPartner, "Trading Partner is not Editable");
             softAssert.assertNull(DisabledFlag_TradingpartnerId, "Trading partner id is not Editable");
             
             softAssert.assertNull(DisabledFlag_Severity, "Severity field is not Editable");
             softAssert.assertNull(DisabledFlag_Pasteradio, "Paste radio button field is Disbled");
             softAssert.assertNull(DisabledFlag_Fileuploadradio, "File Upload radio button field is Disbled");
             softAssert.assertNull(DisabledFlag_PasteTextbox, "Paste textbox field is not Editable");
             softAssert.assertNull(DisabledFlag_Notesdescription, "Notes description field is not Editable");
             softAssert.assertNull(DisabledFlag_Notesdetail, "Notes Deatail text box field is not Editable");
		      softAssert.assertAll();
		      
		    
		    	
			   
		      
		      System.out.println("TC032_manintainErrorcodes Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC032_manintainErrorcodes Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
	    	
	    
           
	    	
	    	
					   System.out.println("TC032_manintainErrorcodes Failed");
					   
					//  test.log(LogStatus.FAIL, "TC032_manintainErrorcodes Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
		
		
		      }
	
	
}
