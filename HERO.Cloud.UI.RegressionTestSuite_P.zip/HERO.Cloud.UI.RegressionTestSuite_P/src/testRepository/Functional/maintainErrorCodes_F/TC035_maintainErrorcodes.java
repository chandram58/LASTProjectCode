package testRepository.Functional.maintainErrorCodes_F;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC035_maintainErrorcodes extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void SeverityDropdownComparewithDB() throws IOException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=35;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Maintain Error Codes')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Maintain Error Codes')]"))).click().release().build().perform();
				
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]"))).click().perform();
				
				
				String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]")).getText();
				
				System.out.println("Page Tile before clicking Edit Button"+PageTitle);
				
	             //Clicking on 'Add New Error Code' button
				
				driver.findElement(By.xpath("//span[contains(text(),'Add New Error Code')]")).click();
				
				Thread.sleep(3000);
				
				String PageTitle2=driver.findElement(By.xpath("//h3[contains(text(),'New Error Code')]")).getText();
				
				System.out.println("Page Title after clicking New Error Code Button->"+PageTitle2);
				
				//Selecting Trading Partner
				driver.findElement(By.xpath("//label[contains(text(),'Select Trading Partner')]")).click();
				driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[2]/div/p-dropdown/div/div[3]/div[2]/ul/p-dropdownitem/li/div/div/a")).click();
				
				
				
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[contains(text(),'Select Severity')]")));
				driver.findElement(By.xpath("//label[contains(text(),'Select Severity')]")).click();
				
				List<WebElement> Dropdown=driver.findElements(By.xpath("//body/div/div/ul/p-dropdownitem/li"));
			
				
         List<String> SeverityList_UI=new ArrayList<String>();
				
				for(int j=0;j<Dropdown.size();j++)
				{
					String value=Dropdown.get(j).getText();
					SeverityList_UI.add(value.trim());
					
				}
				
				System.out.println("Options in Dropdown are->"+SeverityList_UI);
				
				List<String> SeverityList_DB=new ArrayList<String>();
				

			    try
		          {
					
			    	String Query1="Select Type,NAME from HERO_UI_XREF where TYPE like 'severity'";

			    	
			    	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
			    	  rs = readStatement.executeQuery();
			    	  while(rs.next())
			    	  {
			    	   String Severity_DB=rs.getString(2);
			    	  System.out.println(Severity_DB);
			    	  SeverityList_DB.add(Severity_DB.trim());
			    	  }
			    	 
		          }
			    	  
			    	  
			   catch (NullPointerException err)
			          {
				         err.getMessage();
					 	    }
					 
			  System.out.println(SeverityList_DB);
				
		
			 System.out.println("1");
				
			 
			 Thread.sleep(5000);
			 
			 
			
			 
			
           SoftAssert softAssert = new SoftAssert();
		 
  	    softAssert.assertTrue(SeverityList_UI.containsAll(SeverityList_DB) && SeverityList_DB.containsAll(SeverityList_UI), "UI List and DB list not matching");
	
		      softAssert.assertAll();
		      
		      System.out.println("TC035_manintainErrorcodes Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC035_manintainErrorcodes Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC035_manintainErrorcodes Failed");
					   
					//  test.log(LogStatus.FAIL, "TC035_manintainErrorcodes Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
		
		
		      }
	
	
}
