package testRepository.Functional.maintainErrorCodes_F;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC036_maintainErrorcodes extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void ErrorTypeDropdownComparewithDB() throws IOException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=36;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Maintain Error Codes')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Maintain Error Codes')]"))).click().release().build().perform();
				
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]"))).click().perform();
				
				
				String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]")).getText();
				
				System.out.println("Page Tile before clicking Edit Button"+PageTitle);
				
	             //Clicking on 'Add New Error Code' button
				
				driver.findElement(By.xpath("//span[contains(text(),'Add New Error Code')]")).click();
				
				Thread.sleep(3000);
				
				String PageTitle2=driver.findElement(By.xpath("//h3[contains(text(),'New Error Code')]")).getText();
				
				System.out.println("Page Title after clicking New Error Code Button->"+PageTitle2);
				
				
				 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[contains(text(),'Select Error Type')]")));
					
					driver.findElement(By.xpath("//label[contains(text(),'Select Error Type')]")).click();
					
					
					List<WebElement> Dropdown=driver.findElements(By.xpath("//body/div/div/ul/p-dropdownitem/li"));
					List<String> ErrorTypeList_UI=new ArrayList<String>();
					
					for(int j=0;j<Dropdown.size();j++)
					{
						String value=Dropdown.get(j).getText();
						ErrorTypeList_UI.add(value.trim());
						
					}
					
					System.out.println("Options in Dropdown are->"+ErrorTypeList_UI);
					
					List<String> ErrorTypeList_DB=new ArrayList<String>();
				    

			    try
		          {
					
			    	String Query1="Select Type,NAME from HERO_UI_XREF where TYPE like 'errorType'";

			    	
			    	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
			    	  rs = readStatement.executeQuery();
			    	  while(rs.next())
			    	  {
			    	   String ErrorType_DB=rs.getString(2);
			    	  System.out.println(ErrorType_DB);
			    	  ErrorTypeList_DB.add(ErrorType_DB.trim());
			    	  }
			    	 
		          }
			    	  
			    	  
			   catch (NullPointerException err)
			          {
				         err.getMessage();
					 	    }
					 
			  System.out.println(ErrorTypeList_DB);
				
		
			 System.out.println("1");
				
			 
			 Thread.sleep(5000);
			 
			 
			
			 
			
           SoftAssert softAssert = new SoftAssert();
		 
  	    softAssert.assertTrue(ErrorTypeList_UI.containsAll(ErrorTypeList_DB) && ErrorTypeList_DB.containsAll(ErrorTypeList_UI), "UI List and DB list not matching");
	
		      softAssert.assertAll();
		      
		      System.out.println("TC036_manintainErrorcodes Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC036_manintainErrorcodes Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC036_manintainErrorcodes Failed");
					   
					//  test.log(LogStatus.FAIL, "TC036_manintainErrorcodes Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
		
		
		      }
	
	
}
