package testRepository.Functional.maintainErrorCodes_F;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC053_maintainErrorcodes extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void NotesComparewithDB() throws IOException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=53;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,10000);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Maintain Error Codes')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Maintain Error Codes')]"))).click().release().build().perform();
				
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]"))).click().perform();
				
				
				String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]")).getText();
				
				System.out.println("Page Title before clicking Edit Button->"+PageTitle);
				
				//Clicking on New  Icon
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Add New Error Code')]")));
				driver.findElement(By.xpath("//span[contains(text(),'Add New Error Code')]")).click();
			    Thread.sleep(5000);
			    String PageTitle2=driver.findElement(By.xpath("//h3[contains(text(),'New Error Code')]")).getText();
		        System.out.println("Page Title after clicking Edit Button->"+PageTitle2);
				
				
				//Entering Error Code
		        String Errorcodeentered="Test2";
		        driver.findElement(By.xpath("//input[@id='errorCodeName']")).sendKeys(Errorcodeentered);
		        
		        
		        //Selecting error Type
		        driver.findElement(By.xpath("//label[contains(text(),'Select Error Type')]")).click();
		        driver.findElement(By.xpath("  //span[contains(text(),'Business Rules')]")).click();
		        
		        
			Thread.sleep(2000);
			
			//Select Trading Partner
			driver.findElement(By.xpath("//label[contains(text(),'Select Trading Partner')]")).click();
			driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[2]/div/p-dropdown/div/div[3]/div[2]/ul/p-dropdownitem/li/div/div/a")).click();
	
			
			//Select trading partner id
			driver.findElement(By.xpath("//*[contains(@id,'partnerDetails')]/div/div[2]")).click();
			driver.findElement(By.xpath("//*[contains(@id,'partnerDetails')]/div/div[4]/div[2]/ul/p-multiselectitem[19]/li/span")).click();
			driver.findElement(By.xpath("//div[@id='viewAddEditSection']")).click();
			
	
	  //Select Severity
	   driver.findElement(By.xpath("//label[contains(text(),'Select Severity')]")).click();
	   driver.findElement(By.xpath("//span[contains(text(),'Informational')]")).click();
	
	
	Thread.sleep(6000);
	
              //Going on Notes Section
			driver.findElement(By.xpath("//span[contains(text(),'Notes')]")).click();
			driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]")).sendKeys("Description");
			String ERROR_DESC_UI=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]")).getAttribute("value");
			System.out.println("Text entered in Description->"+ERROR_DESC_UI);
			
	        driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/textarea[1]")).sendKeys("Detailed Notes");
	        String ERROR_NOTE_UI=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/textarea[1]")).getAttribute("value");
			System.out.println("Text entered in Detailed Notes->"+ERROR_NOTE_UI);
			
			System.out.println(ERROR_DESC_UI.isEmpty());
			System.out.println(ERROR_NOTE_UI.isEmpty()); 
			
			
			//Click on Back To Error Code Details Link
			driver.findElement(By.xpath("//*[@id='viewAddEditSection']/a")).click(); 
				
			driver.findElement(By.xpath("//span[contains(text(),'Save')]")).click(); 
			
			driver.switchTo().defaultContent();
			
			Thread.sleep(3000);
			String Message=driver.findElement(By.xpath("//div[contains(text(),'Error code has been created successfully')]")).getText();
		
			System.out.println("Message->"+Message );
			
	  //Going to DB
			
			 String ERROR_DESC_DB = null,ERROR_NOTE_DB=null;
			  List<String> ActiveErrorcodeList_DB = new ArrayList<String>();
	    	   
			    
			  
			    try
		          {
					
			    	String Query1="Select * from HERO_UI_WORK_ERROR_NOTE where LAST_UPDATED_BY like 'CRK2305' and Cast(LAST_UPDATED_DATE as DATE) =(SELECT CAST(GETDATE() AS DATE)) ORDER BY LAST_UPDATED_DATE DESC";

			    	
			    	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
			    	  rs = readStatement.executeQuery();
			    	rs.next();
			    	 ERROR_DESC_DB=rs.getString(3);
			    	 ERROR_NOTE_DB=rs.getString(4);
			    	 
			    	  System.out.println("ERROR_DESC_DB->"+ERROR_DESC_DB);
			    	  System.out.println("ERROR_NOTE_DB->"+ERROR_NOTE_DB);
			    	 
			    	 
			    	 
		          }
			    	  
			    	  
			   catch (NullPointerException err)
			          {
				         err.getMessage();
					 	    }
					 
			
				
					
			
			 
			
           SoftAssert softAssert = new SoftAssert();
           softAssert.assertFalse(ERROR_DESC_UI.isEmpty() && ERROR_NOTE_UI.isEmpty(),"User not able to enter notes");
           softAssert.assertTrue(ERROR_DESC_UI.trim().equals(ERROR_DESC_DB.trim()) ,"Desc UI and DB value not matching");
           softAssert.assertTrue(ERROR_NOTE_UI.trim().equals(ERROR_NOTE_DB.trim()) ,"Note UI and DB value not matching");
		      softAssert.assertAll();
		      
			    
		        System.out.println("TC053_manintainErrorcodes Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC053_manintainErrorcodes Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
	    	
	    	
	    	
					   System.out.println("TC053_manintainErrorcodes Failed");
					   
					//  test.log(LogStatus.FAIL, "TC053_manintainErrorcodes Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
		
	     }
	
}
