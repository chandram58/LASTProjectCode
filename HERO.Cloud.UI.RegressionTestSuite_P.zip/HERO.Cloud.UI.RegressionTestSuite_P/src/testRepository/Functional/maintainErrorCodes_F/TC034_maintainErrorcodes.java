package testRepository.Functional.maintainErrorCodes_F;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC034_maintainErrorcodes extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void VerifyErrorcodeUIwithDB() throws IOException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=34;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,10000);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Maintain Error Codes')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Maintain Error Codes')]"))).click().release().build().perform();
				
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]"))).click().perform();
				
				
				String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Maintain Error Codes')]")).getText();
				
				System.out.println("Page Title ->"+PageTitle);
				
			    Thread.sleep(5000);
			
				WebElement webtable=driver.findElement(By.xpath("//app-error-code/div/div[2]/div/div[2]/div[2]/p-table/div/div/div/div[2]/table"));
			     
			     List<WebElement> rows1;
			     List<WebElement> cols1 = null;
			     rows1=webtable.findElements(By.tagName("tr"));
			     
				 System.out.println("No of rows on Maintain Error Code Table->"+ rows1.size());
	              
			     
			     List<String> ActiveErrorcodeList_UI = new ArrayList<String>();
				 
			     for(int j=0;j<rows1.size();j++) 
				   {
						cols1=rows1.get(j).findElements(By.tagName("td"));
						
						//System.out.println(cols1.get(0).getAttribute("rowspan"));
						if(((rows1.get(j).getAttribute("class")).equals("ng-star-inserted")) )
					     { 
						  
						        if(cols1.get(0).getAttribute("rowspan")!=null)
						          {
						            String Errorcode=cols1.get(0).getText();
					                System.out.println(Errorcode);
					                ActiveErrorcodeList_UI.add(Errorcode.trim());
					                
						}
						
				}
			}
				
			     System.out.println(ActiveErrorcodeList_UI);
			     System.out.println("******************************");
            
			     
				  String ErrorCodename_DB = null;
				  List<String> ActiveErrorcodeList_DB = new ArrayList<String>();
		    	   
				    
				  
				    try
			          {
						
				    	String Query1="Select ERROR_CODE_NAME from HERO_UI_WORK_ERROR_CODES  where END_DATE >=CAST (GETDATE() AS DATE)";

				    	
				    	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
				    	  rs = readStatement.executeQuery();
				    	  while(rs.next())
				    	  {
				    	  ErrorCodename_DB=rs.getString(1);
				    	  System.out.println(ErrorCodename_DB);
				    	  ActiveErrorcodeList_DB.add(ErrorCodename_DB.trim());
				    	  }
				    	 
			          }
				    	  
				    	  
				   catch (NullPointerException err)
				          {
					         err.getMessage();
						 	    }
						 
				  System.out.println(ActiveErrorcodeList_DB);
				   
					
						
			    

			  Thread.sleep(3000);
         
			   
			    SoftAssert softassert = new SoftAssert();
			    
		         softassert.assertTrue(ActiveErrorcodeList_UI.containsAll(ActiveErrorcodeList_DB) && ActiveErrorcodeList_DB.containsAll(ActiveErrorcodeList_UI),"Sorting not working as expected");

			    softassert.assertAll();
				 
			    
			   
			  
				 
			      System.out.println("TC034_maintainErrorCodes Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
	    	
	    	
	        System.out.println("TC034_maintainErrorCodes Failed");
					   
					  //test.log(LogStatus.FAIL, "TC034_maintainErrorCodes Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
					   
				      }
		
		
		      }
	
	
}
