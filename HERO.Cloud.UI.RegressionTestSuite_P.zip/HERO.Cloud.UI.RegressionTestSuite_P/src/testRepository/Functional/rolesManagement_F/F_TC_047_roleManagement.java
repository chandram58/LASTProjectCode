package testRepository.Functional.rolesManagement_F;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.RolesManagementPage;

public class F_TC_047_roleManagement extends base{
 @Test
 public void getnewrolefromDB() throws InterruptedException, SQLException {
	 
	 HomePage homePageObj=new HomePage();

		homePageObj.mouseHoverAdministration();	
		homePageObj.openModule("Roles Management");
		RolesManagementPage rolesManagementPageObt=new RolesManagementPage(); 
		Thread.sleep(1000);
		rolesManagementPageObt.clickAddNewRole();
		Thread.sleep(1000);
		String roleName="rolName"+new Date().getTime();
		rolesManagementPageObt.getRoleNameinAddrole(roleName);
		String Description="automation";
		rolesManagementPageObt.getDescriptioninnewrole(Description);
		rolesManagementPageObt.clickSelectScreen();
		rolesManagementPageObt.getSearchScreen("Admin Dashboard");
		rolesManagementPageObt.clickonscreenfromDpdn();
		rolesManagementPageObt.clickonEditChkbox();
		Thread.sleep(3000);
		rolesManagementPageObt.clickSave_AddNewRole();
		Thread.sleep(3000);
		//DB
		String roleName_DB=null,Description_DB=null;
		String Query1="select*from enc.HERO_UI_ROLES where ROLE_NAME like '"+roleName+"'";
    	
  	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
  	  rs = readStatement.executeQuery();
  	  rs.next();
  	roleName_DB=rs.getString(2);
  	Description_DB=rs.getString(3);
  	System.out.println(roleName_DB);
  	System.out.println(Description_DB);
  	
  	try {
  		 SoftAssert softAssert = new SoftAssert();
	       
	       softAssert.assertEquals(roleName.trim(), roleName_DB.trim(),"New Role in  UI and Db not matching");
         
	      softAssert.assertEquals(Description.trim(),Description_DB, "Regular Queue Property not matching");
	      softAssert.assertAll();
		 System.out.println("TC47_rolesManagement Passed");
		
  	}
  	 catch(Throwable e)
    {
	
  		System.out.println("TC47_rolesManagement Failed");
	   
     }

 }

}
