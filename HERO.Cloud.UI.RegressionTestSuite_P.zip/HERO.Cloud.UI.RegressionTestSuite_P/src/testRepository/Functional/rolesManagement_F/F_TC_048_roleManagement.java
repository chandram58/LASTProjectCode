package testRepository.Functional.rolesManagement_F;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.RolesManagementPage;

public class F_TC_048_roleManagement extends base{
	@Test
	public void getupdatefunctionalityDB() throws InterruptedException, SQLException {
		 HomePage homePageObj=new HomePage();

			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Roles Management");
			RolesManagementPage rolesManagementPageObt=new RolesManagementPage(); 
			Thread.sleep(1000);
	WebElement role=rolesManagementPageObt.getroleNamefromTable(2);
	String RoleName=role.getText();
	System.out.println(RoleName);
	
	rolesManagementPageObt.clickonUpdateBtn(2);
	rolesManagementPageObt.getUpdateEndate().click();
	base.selectDateFromDatePicker("12/31/9998");
	rolesManagementPageObt.clickonAcceptbtn();
	Thread.sleep(3000);
	rolesManagementPageObt.clickonSaveupdate();
	String EndDate=	rolesManagementPageObt.getEndDatefromTable(2).getText();
	System.out.println(EndDate);
	SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
	String ENDDate_UI=sdf.format(EndDate);
	System.out.println(ENDDate_UI);
	Thread.sleep(3000);
	//DB
	String RoleName_DB=null,EndDate_DB=null;
	String Query1="select*from enc.HERO_UI_ROLES where ROLE_NAME like '"+RoleName.trim()+"'";
	
	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
	  rs = readStatement.executeQuery();
	  rs.next();
	  RoleName_DB=rs.getString(2);
	EndDate_DB=rs.getString(5);
	System.out.println(RoleName_DB);
	System.out.println(EndDate_DB);
	//SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
	String ebd_date_DB=sdf.format(EndDate_DB);
	System.out.println(ebd_date_DB);
	try {
 		 SoftAssert softAssert = new SoftAssert();
	       
	       softAssert.assertEquals(RoleName.trim(), RoleName_DB.trim(),"Role in  UI and Db not matching");
	       softAssert.assertTrue(ebd_date_DB.equals(ENDDate_UI), "Edited end date and End date on main table are different");
    softAssert.assertAll();
		 System.out.println("TC48_rolesManagement Passed");
		
 	}
 	 catch(Throwable e)
   {

  		System.out.println("TC48_rolesManagement Failed");
  		System.out.println(e.getMessage());
 	   
         
	   
    }
	}

}
