package testRepository.Functional.rolesManagement_F;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.RolesManagementPage;

public class F_TC_027_roleManagement extends base{
	@Test
	public void getpastDatesfromNewrole() throws InterruptedException {
		 HomePage homePageObj=new HomePage();

			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Roles Management");
			RolesManagementPage rolesManagementPageObt=new RolesManagementPage(); 
			Thread.sleep(1000);
			rolesManagementPageObt.clickAddNewRole();
			Thread.sleep(1000);
			rolesManagementPageObt.clickonStartDate();
		WebElement pastdt=	rolesManagementPageObt.geDatesforNewRole();
		String PastDates= pastdt.getAttribute("class");
		System.out.println(PastDates);
		try {
	 		 SoftAssert softAssert = new SoftAssert();
		       
		       
		       softAssert.assertTrue(PastDates.contains("disabled"), "past Dates are not editable");
	    softAssert.assertAll();
			 System.out.println("TC27_rolesManagement Passed");
			
	 	}
	 	 catch(Throwable e)
	   {
	 		System.out.println("TC27_rolesManagement Failed");
	 		System.out.println(e.getMessage());
	    }
	}

}
