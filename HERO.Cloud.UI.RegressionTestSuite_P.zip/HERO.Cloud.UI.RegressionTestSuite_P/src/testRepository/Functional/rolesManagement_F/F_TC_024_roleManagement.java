package testRepository.Functional.rolesManagement_F;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.RolesManagementPage;

public class F_TC_024_roleManagement extends base{
	@Test
	public void getExpriedrolesFunctionality() throws InterruptedException {
		 HomePage homePageObj=new HomePage();

			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Roles Management");
			RolesManagementPage rolesManagementPageObt=new RolesManagementPage(); 
			Thread.sleep(3000);
			rolesManagementPageObt.clickoncopybtn().click();
			String expriedrole=rolesManagementPageObt.getExpiredRoles().getAttribute("class");
			System.out.println(expriedrole);
			try {
				SoftAssert softAssert = new SoftAssert();
			       
			       softAssert.assertTrue(expriedrole.contains("hasExpired"),"Role is Not expried");
		         
			}
			 catch(Throwable e)
		    {
			
				  System.out.println("role is not expried");       
			   
		     }
		String RoleName=rolesManagementPageObt.getroleNamefromCopy().getText();
		System.out.println(RoleName);
		rolesManagementPageObt.clickonsaveforcopy();
		rolesManagementPageObt.getSearchboxinmain(RoleName);
	WebElement role=	rolesManagementPageObt.getroleNamefromTable(1);
	String Roleaft=role.getAttribute("class");
	System.out.println(Roleaft);
	String rolenew=rolesManagementPageObt.getroleNamefromTable(1).getText();
	System.out.println(rolenew);
	
	try {
 		 SoftAssert softAssert = new SoftAssert();
	       
	       softAssert.assertEquals(rolenew.trim(), RoleName.trim(),"New Role   and  not matching");
        
	      softAssert.assertTrue(Roleaft.contains("inserted"), "new role is not created for expried ");
	      softAssert.assertAll();
		 System.out.println("TC24_rolesManagement Passed");
		
 	}
 	 catch(Throwable e)
   {
 		System.out.println("TC47_rolesManagement Failed");
 		System.out.println(e.getMessage());
	   
    }

		
		
	}

}
