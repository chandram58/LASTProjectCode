package testRepository.GR.transmissionLog_GR;


import java.io.File;
import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;

import com.relevantcodes.extentreports.LogStatus;







import base.base;
import utilities.*;

public class G_TC_03 extends base
{
    @Test
	public void verifyMandatoryFieldsFunctionality() throws IOException, InterruptedException
	{ 
    try{
			
			  TransmissionLogPage transmissionLogPageObj=new TransmissionLogPage(); 
		 		 HomePage homePageObj=new HomePage();


		 		homePageObj.mouseHoverReporting();	
		 	Thread.sleep(2000);
		 		homePageObj.openModule("Transmission Log");  
		 		Thread.sleep(2000);
			 
			SoftAssert softassert=new SoftAssert();  
			
			//WebDriverWait wait=new WebDriverWait(driver,10000);
			 System.out.println("0");
			
			 
	     //Clicking On Trading Partner Dropdown and Unselecting all
			 transmissionLogPageObj.clickTradingPatnerDropdownUnselectAllValues();
			
		//Clearing value from "FROM' field
	        transmissionLogPageObj.clearSubmissionFromDate();
	     
	        //Clearing value from "To' field 
	        transmissionLogPageObj.clearSubmissionToDate();   
	  
	
	  //Clicking On Claim Type Dropdown and Unselecting all		
		    transmissionLogPageObj.clickClaimTypeDropdownUnselectAllValues();
		
		//Clicking on Apply Filter Button
		    transmissionLogPageObj.clickApplyFilterButton();
		
		//Capturing validation Message Trading partner    
		    String ErrorTxt1=transmissionLogPageObj.getvalidationTxt_TradingPartner();
		      
		
		// test.log(LogStatus.INFO, "Captured Error text 1->"+ErrorTxt1);
		 
		 System.out.println("Captured Error text 1->"+ErrorTxt1);
		 
		 softassert.assertEquals(ErrorTxt1,"Please select Trading Partner","Error text not matching when all fields are blank");
		 
		
	  //Closing error pop up
		 transmissionLogPageObj.closeErrorPopup(); 
		 
		 driver.switchTo().defaultContent();
		 
       //Entering value in Trading Partner field by selecting CMS from Drop Down
		 transmissionLogPageObj.selectValueTradingPartner();
		  Thread.sleep(2000);
		  
		 //Again Clicking Apply Filter Button
		  System.out.println("Again Clicking Apply Filter Button");
		 
		//test.log(LogStatus.INFO, "Again Clicking Apply Filter Button");
		  transmissionLogPageObj.clickApplyFilterButton();
			 Thread.sleep(1000);
		  String getErrorTxt2=transmissionLogPageObj.getvalidationTxt_From();
			 System.out.println("Captured Error text 2->"+getErrorTxt2);
		    //test.log(LogStatus.INFO, "Captured Error text 2->"+getErrorTxt2);
			  softassert.assertEquals(getErrorTxt2,"Please select From Date","Error text not matching when all fields except trading partner are blank");
		 
		  //Closing error pop up
			 transmissionLogPageObj.closeErrorPopup(); 
			 
	     
	    // String getErrorTxt2=transmissionLogPageObj.getvalidationTxt_From();
		 //System.out.println("Captured Error text 2->"+getErrorTxt2);
	    //test.log(LogStatus.INFO, "Captured Error text 2->"+getErrorTxt2);
		 // softassert.assertEquals(getErrorTxt2,"Please select From Date","Error text not matching when all fields except trading partner are blank");
		 
		// wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@class,'ui-toast-close-icon pi pi-times ng-tns-c8-127 ng-star-inserted')]")));
		 
         // ((JavascriptExecutor)driver).executeScript("arguments[0].click();", CloseIconErrorPopup);
		
		
		 
		 
		/* 
		 WebElement CloseIconErrorPopup2=driver.findElement(By.xpath("//app-transmissionlog-filter/p-toast/div/p-toastitem/div/div/a"));
		 
        CloseIconErrorPopup2.click();
		 */
		 Thread.sleep(4000);
		 
		  //Selecting From Date 
		 transmissionLogPageObj.selectFromDate();
		 
		
	        //Again Clicking Apply Filter Button
	        
	        System.out.println("Again Clicking Apply Filter Button");
	        
	       // test.log(LogStatus.INFO, "Again Clicking Apply Filter Button");
			 
	        transmissionLogPageObj.clickApplyFilterButton();
			// ((JavascriptExecutor)driver).executeScript("arguments[0].click();", ApplyFilterbtn);
			 
	         //Closing error pop up
			 transmissionLogPageObj.closeErrorPopup(); 
			
			 String ErrorTxt3=transmissionLogPageObj.getvalidationTxt_To();
			 System.out.println("Captured Error text 3->"+ErrorTxt3);
		
			// test.log(LogStatus.INFO, "Captured Error text 3->"+getErrorTxt3);
			 
			 softassert.assertEquals(ErrorTxt3,"Please select To Date","Error text not matching when all fields except trading partner && FROM are blank");
			 Thread.sleep(1000);
			 transmissionLogPageObj.closeErrorPopup(); 
			 
			 
			/* 
			 WebElement CloseIconErrorPopup3=driver.findElement(By.xpath("//app-transmission/div/app-transmissionlog-filter/p-toast/div/p-toastitem/div/div/a"));
			 
		      CloseIconErrorPopup3.click();
			 */
			
			 
			 
			 //Selecting To date
			 
			
             System.out.println("Selected To Date ");
             transmissionLogPageObj.selectToDate();
			
			 
			 Thread.sleep(2000);
			 
			 transmissionLogPageObj.clickClaimTypeDropdownUnselectAllValues();
			/*
			 //Clicking On Claim Type Dropdown and Unselecting all		
				driver.findElement(By.xpath("//div[@role='checkbox']")).click();
				driver.findElement(By.xpath("//p-multiselect/div/div[4]/div[1]/div[1]/div[2]/span")).click();
				driver.findElement(By.xpath("//html//body")).click(); 
			 
			 
			 */
			 
			 
          //Again Clicking Apply Filter Button
			 
			 System.out.println("Again Clicking Apply Filter Button");
			 
		//	 test.log(LogStatus.INFO, "Again Clicking Apply Filter Button");
			 
			   transmissionLogPageObj.clickApplyFilterButton();
			 
			 Thread.sleep(2000);
			 
			 
			 driver.switchTo().defaultContent();
			 
			 String getErrorTxt4=transmissionLogPageObj.getvalidationTxt_claimType();
			 
			System.out.println("Captured Error text 4->"+getErrorTxt4);
			
			// test.log(LogStatus.INFO, "Captured Error text 4->"+getErrorTxt4);
			 
			 
			 
			 softassert.assertEquals(getErrorTxt4,"Please Select Claim Type","Error text not matching when Claim Type field is blank");
			 
			 
			 
			 
		 
		 softassert.assertAll();
          
           
           
		// test.log(LogStatus.PASS, "G_TC_03_Transmission Log Passed");  
		  System.out.println("G_TC_03_Transmission Log Passed");
		}
		  catch(Throwable e)
		  {
		//	test.log(LogStatus.FAIL, "G_TC_03_Transmission Log Failed");    
			System.out.println("G_TC_03_Transmission Log Failed");
			Assert.fail(e.getMessage());
			  
		  }
	}
  	
}
