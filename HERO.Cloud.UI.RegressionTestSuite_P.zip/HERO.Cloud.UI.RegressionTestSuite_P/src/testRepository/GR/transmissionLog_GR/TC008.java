package testRepository.GR.transmissionLog_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import base.base;

public class TC008 extends base{
	
@Test
		public void ExporttoCSV() throws IOException
		{		
	     try{
				 
		
	    	 TransmissionLogPage transmissionLogPageObj=new TransmissionLogPage(); 
	 		 HomePage homePageObj=new HomePage();
	 		 
	 		String DownloadFilepath = getPropertyFileValue("DownloadFilepath");
			 System.out.println("DownloadFilepath->"+DownloadFilepath);
	        
	      homePageObj.mouseHoverReporting();	
	 	  homePageObj.openModule("Transmission Log");
	 		
	 	  Thread.sleep(3000);
	 	  
	 	  //Select Start date in Filter and Click 'APPLY FILTER' button
	 	 transmissionLogPageObj.clearSubmissionFromDate();
	 	 
	 	transmissionLogPageObj.clickCalendarSubmissionFrom();
	 	 String SubmissionFromDate="01/01/2021";
	 	 selectDate(SubmissionFromDate);
	    transmissionLogPageObj.clickApplyFilterButton();
	 	 
	 	Thread.sleep(10000); 
	 		
	 	 //Click on Export to Excel
	 	 transmissionLogPageObj.DownloadCSV();
	 		
	 	//  test.log(LogStatus.INFO, "Getting Downloaded File Name");
	 	  File getLatestFile = base.getLatestFilefromDir(DownloadFilepath);
	 	  String fileName = getLatestFile.getName();
	 	  System.out.println("Downloaded File name->"+fileName);
  //    test.log(LogStatus.INFO, "Downloaded File name->"+fileName);
	 		    
	 		
	 		
	        SoftAssert softAssert = new SoftAssert();
		    
	      // verifying whether the file  with fileName present in the directory downloadpath or not
	        softAssert.assertTrue(isFileDownloaded(DownloadFilepath, fileName), "Download Failed");
	     //verifying whether the latest downloaded file contains "xlsx" extension or not and name of file having TransmissionsList word in it
	        softAssert.assertTrue(fileName.contains("csv") && fileName.contains("TransmissionsList"),"It is not a excel file");
			    
	           System.out.println("TC008_transmissionLog Passed");   
				   
 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC008_transmissionLog Failed");
					   
					//  test.log(LogStatus.FAIL, "TC008_transmissionLog Failed"); 
    
						  Assert.fail(e.getMessage());
						 
					}
		}
}
