package testRepository.GR.transmissionLog_GR;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import base.base;

public class R_TC_01 extends base 
{
	@Test
		public void NavigationtoTransmissionLog() throws IOException
		{
		
	     try{
				 
		
	    	 TransmissionLogPage transmissionLogPageObj=new TransmissionLogPage(); 
	 		 HomePage homePageObj=new HomePage();
	 		 homePageObj.mouseHoverReporting();	
	 	
	 		homePageObj.openModule("Transmission Log");
	 		
	 		Thread.sleep(3000);
	 		String PageURL=driver.getCurrentUrl();
	 		System.out.println(PageURL);
			
           SoftAssert softAssert = new SoftAssert();
	 // test.log(LogStatus.INFO ,"Verifying page Title");
		softAssert.assertTrue(PageURL.toLowerCase().contains("transmissionlog"), "This is not Transmission Log page");
		softAssert.assertAll();
		  
		System.out.println("TC001_transmissionLog Passed");
		//  test.log(LogStatus.FAIL, "TC001_transmissionLog Passed"); 
	
				        }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC001_transmissionLog Failed");
		  //  test.log(LogStatus.FAIL, "TC001_transmissionLog Failed");
				  Assert.fail(e.getMessage());
						 
					}
	     }
	}
