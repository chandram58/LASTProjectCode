package testRepository.GR.transmissionLog_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import base.base;

public class R_TC_09 extends base{
	@Test
		public void ResetButtonFunctionality() throws IOException
		{		
	     try{
				 
		
	    	 TransmissionLogPage transmissionLogPageObj=new TransmissionLogPage(); 
	 		 HomePage homePageObj=new HomePage();
    
	      homePageObj.mouseHoverReporting();	
	 	  homePageObj.openModule("Transmission Log");
	 		
	 	  Thread.sleep(3000);
	 		
	 	 //Getting Default Value of The Fields before clicking Reset button
	 	  String DefaultValue_TradingPartner=transmissionLogPageObj.getDefaultValueTradingPartnerBeforeReset();
	 	  String DefaultValue_From=transmissionLogPageObj.getDefaultValueFromBeforeReset();
	 	  String DefaultValue_To=transmissionLogPageObj.getDefaultValueToBeforeReset();
	 	  String DefaultValue_Claimtype=transmissionLogPageObj.getDefaultValueClaimTypeBeforeReset();
	 	  
	     //Clicking On Trading Partner Dropdown and Unselecting all
	 	  transmissionLogPageObj.clickTradingPatnerDropdownUnselectAllValues();
	 	 
	 	 
	 	 //Clearing value from "FROM' field
	 	 transmissionLogPageObj.clearSubmissionFromDate();
	 	
	 	 //Clearing value from "TO' field
	 	 transmissionLogPageObj.clearSubmissionToDate();
	 	
	 	 //Clicking On claim type  Dropdown and Unselecting all
	 	 transmissionLogPageObj.clickClaimTypeDropdownUnselectAllValues();
	 	
	 	 //Clicking on Reset button
	 	 transmissionLogPageObj.clickResetButton();
	 	
	 	 Thread.sleep(3000);
	 	
	 	//Now Getting Default Value of The Fields after clicking Reset button
	 	  String TradingPartnerAfterReset=transmissionLogPageObj.getDefaultValueTradingPartnerAfterReset();
	 	 System.out.println("TradingPartnerAfterReset->"+TradingPartnerAfterReset);
	 	  
	 	  String FromValueAfterReset=transmissionLogPageObj.getDefaultValueFromAfterReset();
	 	  System.out.println("FromValueAfterReset->"+FromValueAfterReset);
	 	  
	      String ToValueAfterReset=transmissionLogPageObj.getDefaultValueToAfterReset();
	      System.out.println("ToValueAfterReset->"+ToValueAfterReset);
	      
	      
	 	  String ClaimTypeAfterReset=transmissionLogPageObj.getDefaultValueClaimTypeAfterReset();
	 	 System.out.println("ClaimTypeAfterReset->"+ClaimTypeAfterReset);
	 	
	 		SoftAssert softassert=new SoftAssert();  	 
			softassert.assertTrue(TradingPartnerAfterReset.equals(DefaultValue_TradingPartner), "Trading partner field value not equal to default value after Reset"); 
			softassert.assertTrue(FromValueAfterReset.equals(DefaultValue_From), "From field value not equal to default value after Reset");  
			softassert.assertTrue(ToValueAfterReset.equals(DefaultValue_To), "To field value not equal to default value after Reset"); 
			softassert.assertTrue(ClaimTypeAfterReset.equals(DefaultValue_Claimtype), "Claimtype field value not equal to default value after Reset"); 
		    softassert.assertAll();
          
	 	
	    
	           System.out.println("TC009_transmissionLog Passed");   
		 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC009_transmissionLog Failed");
				//  test.log(LogStatus.FAIL, "TC009_transmissionLog Failed"); 
  
						  Assert.fail(e.getMessage());
						 
					}
		
		
		      }
		
}
