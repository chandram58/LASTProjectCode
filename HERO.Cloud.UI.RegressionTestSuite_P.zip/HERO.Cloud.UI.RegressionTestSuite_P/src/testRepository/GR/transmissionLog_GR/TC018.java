package testRepository.GR.transmissionLog_GR;

import java.io.File;
import utilities.dbConnector;
import java.io.IOException;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.userDashboardPage;
import base.base;


public class TC018 extends base{
  @Test
		public void CompareUIandDBValues() throws IOException
		{
	
		
				
	     try{
				 
		
	    	 TransmissionLogPage transmissionLogPageObj=new TransmissionLogPage(); 
	 		 HomePage homePageObj=new HomePage();
	 	      homePageObj.mouseHoverReporting();	
		 	  homePageObj.openModule("Transmission Log");
		 		
		 	  Thread.sleep(3000);
		 	  
		 	  //Select Start date in Filter and Click 'APPLY FILTER' button
		 	 transmissionLogPageObj.clearSubmissionFromDate();
		 	 
		 	transmissionLogPageObj.clickCalendarSubmissionFrom();
		 	 
		 	 String SubmissionFromDate="01/01/2021";
		 	 selectDate(SubmissionFromDate);
		 	
		 	transmissionLogPageObj.clickApplyFilterButton();
	 	    Thread.sleep(10000); 
	 		
	 	 
	 	 
	 	    //clicking sort icon in Claim then result should appear in ascending order with respective to Claim
	 	   transmissionLogPageObj.clickSorticon_ListofTransmissions_ISAID();
	 	    //Getting asc list from UI as it is appearing in ascending order in DB 
	 	   List<String> List_ISAID_STATUS_UI=transmissionLogPageObj.getList_UI();
	 	   
	 	     //Now Getting list from DB
	 	   List<String> List_ISAID_STATUS_DB=transmissionLogPageObj.getList_DB();
	 	   
	 	  System.out.println(List_ISAID_STATUS_UI); 
	 	  System.out.println(List_ISAID_STATUS_DB);
	   
	 	  Thread.sleep(3000);
	 	
	 		
	 	  //clicking sort icon in Role_Name then result should appear in ascending order with respective to Role_Name
	        SoftAssert softAssert = new SoftAssert();
		    
	        softAssert.assertTrue(List_ISAID_STATUS_UI.containsAll(List_ISAID_STATUS_DB) && List_ISAID_STATUS_DB.containsAll(List_ISAID_STATUS_UI), "UI List and DB List not matching");
		   
	        softAssert.assertAll();
	           
	        System.out.println("TC018_transmissionsLog Passed");   
		 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC018_transmissionsLog Failed");
					   
					//  test.log(LogStatus.FAIL, "TC018_transmissionsLog Failed"); 

					System.out.println(e.getMessage());	     
					 Assert.fail(e.getMessage());
						 
					}
		
		
		      }
		
}
