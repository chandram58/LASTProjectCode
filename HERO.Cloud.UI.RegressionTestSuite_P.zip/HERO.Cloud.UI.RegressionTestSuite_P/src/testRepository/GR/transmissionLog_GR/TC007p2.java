package testRepository.GR.transmissionLog_GR;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import base.base;

public class TC007p2 extends base{
	

		@Test
		public void VerifyLinkReceiveDate_999() throws IOException
		{
		
	     try{
				 
		
	    	 TransmissionLogPage transmissionLogPageObj=new TransmissionLogPage(); 
	 		 HomePage homePageObj=new HomePage();

	 		homePageObj.mouseHoverReporting();	
	 	
	 		homePageObj.openModule("Transmission Log");
	 		
	 		Thread.sleep(3000);
	 		
	 		transmissionLogPageObj.clickCalendarSubmissionFrom();
		 	 
		 	 String SubmissionFromDate="01/01/2021";
		 	 selectDate(SubmissionFromDate);
		 	
		 	transmissionLogPageObj.clickApplyFilterButton();
		 	Thread.sleep(3000);
	       //Click on ISA ID
	//	 	transmissionLogPageObj.clickLinkReceiveDate();
		 	
	 		//Verify Page Title of Opened Page
	 	//	String OpenpageTitle=transmissionLogPageObj.getPageTitleViewAcknowledgement();
	 		
            //Click on Receive Date
		 	transmissionLogPageObj.verifyLink_ListofTransmissions(); 
		      System.out.println("TC07p2_transmissionLog Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC07p2_transmissionLog Passed"); 
	  }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC07p2_transmissionLog Failed");
					   
					//  test.log(LogStatus.FAIL, "TC07p2_transmissionLog Failed"); 
  
						  Assert.fail(e.getMessage());
						 
					}
	     }

}