package testRepository.GR.transmissionLog_GR;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import base.base;

public class TC007p1 extends base{
	@Test
		public void VerifyLinkISAId() throws IOException
		{
		
	     try{
				 
		
	    	 TransmissionLogPage transmissionLogPageObj=new TransmissionLogPage(); 
	 		 HomePage homePageObj=new HomePage();

	 		homePageObj.mouseHoverReporting();	
	 	
	 		homePageObj.openModule("Transmission Log");
	 		
	 		Thread.sleep(3000);
	 		
	 		transmissionLogPageObj.clickCalendarSubmissionFrom();
		 	 
		 	 String SubmissionFromDate="01/01/2021";
		 	 selectDate(SubmissionFromDate);
		 	
		 	transmissionLogPageObj.clickApplyFilterButton();
		 	Thread.sleep(3000);
	       //Click on ISA ID
		 	transmissionLogPageObj.clickLinkISAID();
		 	Thread.sleep(3000);
	 		//Verify Page Title of Opened Page
	 		String OpenpageTitle1=transmissionLogPageObj.getPageTitleOutboundTransmissions();
	 		System.out.println("Page Title upon clicking ISSAID link->"+OpenpageTitle1);
	 	/*	Thread.sleep(3000);
	 		//Going back and Loading List of Transmissions Table
	        driver.navigate().back();
	        Thread.sleep(10000);
	        selectDate(SubmissionFromDate);
	        transmissionLogPageObj.clickApplyFilterButton();
           
	        Thread.sleep(3000);
	        //Click on Receive Date
	 		
	        transmissionLogPageObj.clickLinkReceiveDate();
	 		
	 		
	 	    //Click on Duplicate
	 		
	 		
	 		
	 		*/
	 		
	 		
	 		
	 		
			
           SoftAssert softAssert = new SoftAssert();
		     
		    // test.log(LogStatus.INFO ,"Verifying page Title");
		     
	softAssert.assertTrue(OpenpageTitle1.equalsIgnoreCase("View Batch SID"), "Link not working properly");
		     
		softAssert.assertAll();
		      
		      System.out.println("TC07p1_transmissionLog Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC07p1_transmissionLog Passed"); 
	
				        }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC07p1_transmissionLog Failed");
					   
					//  test.log(LogStatus.FAIL, "TC07p1_transmissionLog Failed"); 

						     
						  Assert.fail(e.getMessage());
						 
					}
	     }

}