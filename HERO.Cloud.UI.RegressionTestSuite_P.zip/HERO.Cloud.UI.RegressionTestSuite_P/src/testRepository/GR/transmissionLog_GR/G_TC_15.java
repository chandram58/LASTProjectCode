package testRepository.GR.transmissionLog_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class G_TC_15 extends base
{
	@Test
		public void VerifyElaspedDaysFullyRejectedScenario() throws IOException
		{
		
	     try{
				 
	    	 TransmissionLogPage transmissionLogPageObj=new TransmissionLogPage(); 
	 		 HomePage homePageObj=new HomePage();
	 	     homePageObj.mouseHoverReporting();	
		 	  homePageObj.openModule("Transmission Log");
		 		
		 	  Thread.sleep(3000);
		 	  
		 	  //Select Start date in Filter and Click 'APPLY FILTER' button
		 	 transmissionLogPageObj.clearSubmissionFromDate();
		 	 
		 	transmissionLogPageObj.clickCalendarSubmissionFrom();
		 	 
		 	 String SubmissionFromDate="01/01/2021";
		 	 selectDate(SubmissionFromDate);
		 	
		     transmissionLogPageObj.clickApplyFilterButton();
	 	     Thread.sleep(10000); 
	 
			 
			 transmissionLogPageObj.verifyElapseDaysFullyRejectedScenario();
			 
             System.out.println("TC015_transmissionLog Passed");
		    //  test.log(LogStatus.FAIL, "TC015_transmissionLog Passed"); 
				   
		    }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC015_transmissionLog Failed");
					   
					//  test.log(LogStatus.FAIL, "TC015_transmissionLog Failed"); 

						  System.out.println(e.getMessage()); 
						Assert.fail(e.getMessage());
						     
					   
				      }
			
		      }
	
}
