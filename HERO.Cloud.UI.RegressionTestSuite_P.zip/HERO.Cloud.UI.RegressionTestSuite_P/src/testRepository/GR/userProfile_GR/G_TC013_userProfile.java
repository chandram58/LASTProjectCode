package testRepository.GR.userProfile_GR;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.UserProfilePage;

public class G_TC013_userProfile extends base {
	@Test
	public void ViewandCopyUserfunctionality() throws InterruptedException {

		
		pages.HomePage homePageObj=new pages.HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(3000);
		homePageObj.openModule("User Profile");
		Thread.sleep(5000);
		UserProfilePage userProfileObj= new UserProfilePage();	
		userProfileObj.clickExpiredUserViewIcon();
	String pageTITLE=userProfileObj.getexpiredviewPageTitle().getText();
	System.out.println(pageTITLE);
	Thread.sleep(5000);
	userProfileObj.clickOnCancelviewuser();
	Thread.sleep(3000);
	userProfileObj.clickCopyIconExpiredUser();
String CopyUserpageTile=userProfileObj.getexpiredCopyPageTitle().getText();
System.out.println(CopyUserpageTile);
userProfileObj.clickonCancelCopyUser();
		
try {
	 SoftAssert softAssert = new SoftAssert();
		softAssert.assertTrue(pageTITLE.contains("View User"), "View user is not opened" );
		softAssert.assertTrue(CopyUserpageTile.contains("New User"), "Copy user is not opened" );
		System.out.println("G_TC013_userProfile passed");
}
catch(Exception e){
	
	 Assert.fail(e.getMessage());
	 System.out.println("G_TC013_userProfile failed");
}
	}

}
