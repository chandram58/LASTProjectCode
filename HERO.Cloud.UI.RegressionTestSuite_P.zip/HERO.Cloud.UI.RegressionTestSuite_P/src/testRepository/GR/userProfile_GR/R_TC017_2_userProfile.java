package testRepository.GR.userProfile_GR;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import pages.UserProfilePage;
import utilities.xlUtils;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC017_2_userProfile extends base 
{
		@Test
		public void verifyCancelButtonCloseIconOnViewUserPage() throws IOException
		{
	     try{
			Thread.sleep(5000);
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("User Profile");
			UserProfilePage userProfilePage=new UserProfilePage(); 
		
			userProfilePage.click_Usernamelink();
		    String Title1=userProfilePage.getTitle_ViewUser();
		    System.out.println("Title1->"+Title1);
		    Thread.sleep(10000);
		    userProfilePage.clickOnCancelviewuser();
		    String Title2=userProfilePage.getTitle_MainPage();
		    System.out.println("Title2->"+Title2);
		    Thread.sleep(10000);
		   
		    userProfilePage.click_Usernamelink();
		    String Title3=userProfilePage.getTitle_ViewUser();
		    System.out.println("Title3->"+Title3);
		    userProfilePage.clickCloseIcon_ViewUser();
		    String Title4=userProfilePage.getTitle_MainPage();
		    System.out.println("Title4->"+Title4);
			
		
		
		
			
			
			
			SoftAssert softassert = new SoftAssert();
			softassert.assertTrue(Title1.equalsIgnoreCase("View user") && Title3.equalsIgnoreCase("View user")  , "User Name link not working");
			softassert.assertTrue(Title2.equalsIgnoreCase("User Profile"), "Cancel Button on View User Not working");
			softassert.assertTrue(Title4.equalsIgnoreCase("User Profile"), "Close icon on view User Not working");
			softassert.assertAll();  
		      System.out.println("R_TC017_2_userProfile Passed");
		  //  test.log(LogStatus.FAIL, "R_TC017_2_userProfile Passed"); 
			 
	     } 
	    catch(Throwable e)
				     {
					   System.out.println("R_TC017_2_userProfile Failed");
				  //  test.log(LogStatus.FAIL, "R_TC017_2_userProfile Failed"); 
					   Assert.fail(e.getMessage());
					 }
	     }
}
