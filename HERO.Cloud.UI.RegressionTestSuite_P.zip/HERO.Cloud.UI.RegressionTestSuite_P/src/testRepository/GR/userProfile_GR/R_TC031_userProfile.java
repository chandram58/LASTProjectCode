package testRepository.GR.userProfile_GR;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import pages.UserProfilePage;
import utilities.xlUtils;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC031_userProfile extends base 
{
		@Test
		public void verifyFieldBorderValidations() throws IOException
		{
	     try{
			Thread.sleep(5000);
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("User Profile");
			UserProfilePage userProfilePage=new UserProfilePage(); 
		
			userProfilePage.clickonEditButton();
		    
			
			userProfilePage.clearUserEndDate_Updateuser();
			String validation1=userProfilePage.getNotNullErrorUserEnddate();
			System.out.println("validation1->"+validation1);
			
			String[] color1=userProfilePage.getErrorBorderColorUserEndDate();
			System.out.println("UserEndDateBorderColor->"+color1[0]);
			System.out.println("UserEndDateBorderColor->"+color1[1]);
			System.out.println("UserEndDateBorderColor->"+color1[2]);
			System.out.println("UserEndDateBorderColor->"+color1[3]);
			
			SoftAssert softassert = new SoftAssert();
			softassert.assertTrue(validation1.contains("End Date is required")  , "Incorrect validation error for non null User End date");
		
			softassert.assertAll();  
		      System.out.println("R_TC031_userProfile Passed");
		  //  test.log(LogStatus.FAIL, "R_TC031_userProfile Passed"); 
			 
	     } 
	    catch(Throwable e)
				     {
					   System.out.println("R_TC031_userProfile Failed");
				  //  test.log(LogStatus.FAIL, "R_TC031_userProfile Failed"); 
					   Assert.fail(e.getMessage());
					 }
	     }
}
