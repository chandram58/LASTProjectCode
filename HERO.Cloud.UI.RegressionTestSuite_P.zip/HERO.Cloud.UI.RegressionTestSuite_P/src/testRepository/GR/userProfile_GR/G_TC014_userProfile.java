package testRepository.GR.userProfile_GR;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import pages.UserProfilePage;
import utilities.xlUtils;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class G_TC014_userProfile extends base 
{
		@Test
		public void VerifyViewUserFunctionality() throws IOException
		{
	     try{
			Thread.sleep(5000);
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("User Profile");
			UserProfilePage userProfilePage=new UserProfilePage(); 
		
			userProfilePage.click_Usernamelink();
			String Title1=userProfilePage.getTitle_ViewUser(); 
			
			SoftAssert softassert = new SoftAssert();
			softassert.assertTrue(Title1.equalsIgnoreCase("View User"), "Incorrect page on clicking user profile name link");
			
			
			userProfilePage.clickOnCancelviewuser();
			
			//Click on View Icon of Inactive profile
			
			userProfilePage.clickExpiredUserViewIcon();
			String Title2=userProfilePage.getTitle_ViewUser(); 
			softassert.assertTrue(Title2.equalsIgnoreCase("View User"), "Incorrect pageup on clicking view icon of inactive profile");
			
			
			softassert.assertAll();  
		      System.out.println("G_TC014_userProfile Passed");
		  //  test.log(LogStatus.FAIL, "G_TC014_userProfile Passed"); 
			 
	     } 
	    catch(Throwable e)
				     {
					   System.out.println("G_TC014_userProfile Failed");
				  //  test.log(LogStatus.FAIL, "G_TC014_userProfile Failed"); 
					   Assert.fail(e.getMessage());
					 }
	     }
}
