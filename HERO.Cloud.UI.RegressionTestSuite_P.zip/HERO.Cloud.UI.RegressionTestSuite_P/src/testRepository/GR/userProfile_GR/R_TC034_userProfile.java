package testRepository.GR.userProfile_GR;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.UserProfilePage;

public class R_TC034_userProfile extends base{
	
	@Test
	public void applyFilterFunctionalityandreset() throws InterruptedException{
	
		
		Thread.sleep(5000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(3000);
		homePageObj.openModule("User Profile");
		UserProfilePage userProfileObj=new UserProfilePage(); 
		userProfileObj.clickonFilterSection();
		userProfileObj.clickRolesFiled();
		userProfileObj.getroleSelect();
		userProfileObj.clickOnapplyFilter();
		Thread.sleep(3000);
		List<String> roleslist = new ArrayList<String>();
		roleslist=userProfileObj.getRoleinWebTable();
		
		// String RolesafterFilter = roleslist.stream().map(Object::toString)
         //        .collect(Collectors.joining(",")); 
		    //System.out.println("rolesafterfilter--"+RolesafterFilter);
		System.out.println("d"); 
		    userProfileObj.clickRestButton();	
		    List<String> roleslist1 = new ArrayList<String>();
			roleslist1=userProfileObj.getRoleinWebTable();
			// String RolesafterReset = roleslist.stream().map(Object::toString)
	                // .collect(Collectors.joining(",")); 
			    //System.out.println("rolesafterrest---"+RolesafterReset); 
		 try {
			 Thread.sleep(5000);
			 SoftAssert softAssert = new SoftAssert();
		softAssert.assertTrue(roleslist.contains("Admin"), "Filter is not applied" );
		softAssert.assertTrue(roleslist1.contains("leader,Admin,User"), "reset is not applied" );
		//softAssert.assertAll();
		System.out.println("R_TC034_UserProfile passed");
		 }
		
	catch(Exception e)
		 {
		System.out.println("R_TC034_UserProfile failed");
		 Assert.fail(e.getMessage());
		 
		}
		 }
	
}
