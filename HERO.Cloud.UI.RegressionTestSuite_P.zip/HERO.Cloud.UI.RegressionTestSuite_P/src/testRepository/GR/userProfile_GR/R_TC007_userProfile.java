package testRepository.GR.userProfile_GR;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import pages.UserProfilePage;
import utilities.xlUtils;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC007_userProfile extends base 
{
		@Test
		public void EditEndDateHeroAkaNameUpdateUserPage() throws IOException
		{
	     try{
			Thread.sleep(5000);
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("User Profile");
			UserProfilePage userProfilePage=new UserProfilePage(); 
		
			userProfilePage.clickonEditButton();
		
			String newDate="12/31/9987";
			userProfilePage.clickUserEndDate();
			//selectDateFromDatePicker(newDate);
			selectDate(newDate);
			
			String newName="ABCD";
			userProfilePage.editHeroAkaName(newName);
			
			userProfilePage.clickAcceptBtn();
			
			
			userProfilePage.clickOnSaveBtn();
			
		
			//Click On Edit Button Again
			userProfilePage.clickonEditButton();
			String UserEndDate=userProfilePage.getUserEndDate();
			String heroAKAName=userProfilePage.getHeroAkaName();
			
			String[] parts = newDate.split("/");
			
			SoftAssert softassert = new SoftAssert();
			softassert.assertTrue(UserEndDate.contains(parts[0]) && UserEndDate.contains(parts[1])&& UserEndDate.contains(parts[2]) , "User End Date not getting Edited");
			softassert.assertTrue(heroAKAName.equals(newName), "Hero AKA Name not getting Edited");		
			softassert.assertAll();  
		      System.out.println("R_TC007_userProfile Passed");
		  //  test.log(LogStatus.FAIL, "R_TC007_userProfile Passed"); 
			 
	     } 
	    catch(Throwable e)
				     {
	    	          System.out.println(e.getMessage());
					   System.out.println("R_TC007_userProfile Failed");
				  //  test.log(LogStatus.FAIL, "R_TC007_userProfile Failed"); 
					//   Assert.fail(e.getMessage());
					 }
	     }
}
