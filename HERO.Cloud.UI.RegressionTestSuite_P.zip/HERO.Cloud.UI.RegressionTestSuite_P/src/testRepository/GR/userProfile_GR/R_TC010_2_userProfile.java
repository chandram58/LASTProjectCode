package testRepository.GR.userProfile_GR;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import pages.UserProfilePage;
import utilities.xlUtils;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC010_2_userProfile extends base 
{
		@Test
		public void updateRoleEndDate() throws IOException
		{
	     try{
			Thread.sleep(5000);
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("User Profile");
			UserProfilePage userProfilePage=new UserProfilePage(); 
		
			userProfilePage.clickonEditButton();
			
		//Updating UserEnd Date	
			userProfilePage.clickUserEndDate();
			String newuserenddate="12/31/9999";
			//selectDateFromDatePicker(newuserenddate);
			selectDate(newuserenddate);
			userProfilePage.clickDeclineBtn();
			
		     
		//Updating Role End date
			userProfilePage.clickRoleEndDate();
			String newroleenddate="12/31/9998";
			//selectDateFromDatePicker(newroleenddate);
			selectDate(newroleenddate);
			userProfilePage.clickOnSaveBtn();
			
			
		//opening page again and getting RoleEnd date Value
			Thread.sleep(3000);
			userProfilePage.clickonEditButton();
			Thread.sleep(3000);
			String RoleEndDate=userProfilePage.getRoleEndDate();
			String[] parts = newroleenddate.split("/");
			
			SoftAssert softassert=new SoftAssert();
			softassert.assertTrue(RoleEndDate.contains(parts[0]) && RoleEndDate.contains(parts[1])&& RoleEndDate.contains(parts[2]) , "Role End Date not getting Edited");
			softassert.assertAll();  
		      System.out.println("R_TC010_2_userProfile Passed");
		  //  test.log(LogStatus.Pass, "R_TC010_2_userProfile Passed"); 
			 
	     } 
	    catch(Throwable e)
				     {
					   System.out.println("R_TC010_2_userProfile Failed");
					   System.out.println(e.getMessage());
				  //  test.log(LogStatus.FAIL, "R_TC010_2_userProfile Failed"); 
					Assert.fail(e.getMessage());
					 }
	     }
}
