package testRepository.GR.userProfile_GR;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.UserProfilePage;

public class R_TC009_userProfile extends base{

	@Test
	public void ActiveUserEndDatecomparetoRoleEndDate() throws Exception {
		
		
		
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(3000);
		homePageObj.openModule("User Profile");
		UserProfilePage userProfileObj= new UserProfilePage();
		userProfileObj.clickonEditButton();
		Thread.sleep(5000);
		String pageTitle1=userProfileObj.getTitle_updatePage();
   
	System.out.println(pageTitle1);
	Thread.sleep(5000);
 userProfileObj.clickUserEndDate();
 String newDate="12/31/9997";
 selectDate(newDate);
 // userProfileObj.setuserEndDate();
  String UserEndate=userProfileObj.getUserEndDate();
  
  
  userProfileObj.clickonPOPboxforAcceptEndaDate().click();

  String RoleEndate=userProfileObj.getRoleEndDate();

 userProfileObj.clickOnSaveBtn();
 try {
	 SoftAssert softAssert = new SoftAssert();
     
	  //   test.log(LogStatus.INFO ,"verifying User role end date validation ");
	     
	     softAssert.assertTrue(UserEndate.equals(RoleEndate) , "User not able to update end date");
	     System.out.println("userEndandRoleEnddate are Same");
	     System.out.println("R_TC009_userProfile is passed");
	     
 }
 catch(Exception e) {
	 System.out.println("R_TC009_userProfile is failed");
	 System.out.println(e.getMessage());
	 Assert.fail(e.getMessage());
 }
 
  
	
	}
}
