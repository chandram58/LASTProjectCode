package testRepository.GR.userProfile_GR;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import pages.UserProfilePage;
import utilities.xlUtils;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC010_1_userProfile extends base 
{
		@Test
		public void searchRoleinSelectRole() throws IOException
		{
	     try{
			Thread.sleep(5000);
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("User Profile");
			UserProfilePage userProfilePage=new UserProfilePage(); 
		
			userProfilePage.clickonEditButton();
		     
		//Verifying SearchRole Functionality
			userProfilePage.clickSelectRoleDropdown_UpdateUser();
			String SearchTerm="Admin";
			userProfilePage.enterTxtSearchbox_SelectRoleDD_UpdateUser(SearchTerm);
			
			List<WebElement> searchResult_rows=userProfilePage.getSearchResult_SelectRoleDD_UpdateUser();
			SoftAssert softassert=new SoftAssert();
			for(int j=0;j<searchResult_rows.size();j++)
			{
			System.out.println(searchResult_rows.get(j).getText());
		    softassert.assertTrue((searchResult_rows.get(j).getText().toLowerCase()).contains(SearchTerm.toLowerCase()), "Row no->"+(j+1)+" not having Search Term");		
			}
			
			
			
				
			softassert.assertAll();  
		      System.out.println("R_TC010_1_userProfile Passed");
		  //  test.log(LogStatus.Pass, "R_TC010_1_userProfile Passed"); 
			 
	     } 
	    catch(Throwable e)
				     {
					   System.out.println("R_TC010_1_userProfile Failed");
					   System.out.println(e.getMessage());
				  //  test.log(LogStatus.FAIL, "R_TC010_1userProfile Failed"); 
					 Assert.fail(e.getMessage());
					 }
	     }
}
