package testRepository.GR.reDos_GR;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.reDosPage;
import base.base;

public class G_TC_01 extends base 
{
	@Test
		public void NavigationtoRedo() throws IOException
		{		
	     try{
				 
		
	    	 reDosPage reDosObj=new reDosPage(); 
	 		 HomePage homePageObj=new HomePage();
            Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 	
	 		homePageObj.openSearchView();
	 		
	 		Thread.sleep(4000);
	 		
	 		//Click on Upload link
	 		reDosObj.clickUploadLink_SearchView();
	 		Thread.sleep(3000);
	 		//Click on CreateNewRequest
	 		reDosObj.clickCreateNewRequest();
	 		
	 		//Select View Type
	 		Thread.sleep(2000);
	 		reDosObj.selectViewType_Claims();
	 		Thread.sleep(2000);
	 		//Click on Next Button
	 		reDosObj.clickNextButton();
	 		Thread.sleep(2000);
	 		//Select Input Columns
	 		reDosObj.selectInputColumns();
	 		Thread.sleep(2000);
	 		//Select Output Columns
	 		reDosObj.selectOutputColumns();
	 		Thread.sleep(2000);
	 		//Verifying Actions Button on page
	 		boolean flag=reDosObj.verifyActions().isDisplayed();
	 		Thread.sleep(2000);
	 		//Verifying Actions Button on page
	 		reDosObj.clickDownChevron_Actions();
	 		Thread.sleep(2000);
	 		//Clicking down chevron next to Actions Button
	 	//	reDosObj.clickDownChevron_Actions();
	 		
	 		//Verifying dropdown values
	 		String listDropdownValues_Actions=reDosObj.listDropdownValues_Actions().replace("\n", " ");
	 		System.out.println("listDropdownValues_Actions->"+listDropdownValues_Actions);
			
           SoftAssert softAssert = new SoftAssert();
	       softAssert.assertTrue(flag, "Actions buttons not displayed");
	       softAssert.assertTrue(listDropdownValues_Actions.contains("Re Do"), "Re Do option not displayed");
		   softAssert.assertAll();
		 
		   System.out.println("TC001_Redo Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC001_Redo Passed"); 
		  }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC001_Redo Failed");
					   
					//  test.log(LogStatus.FAIL, "TC001_Redo Failed"); 
                    Assert.fail(e.getMessage());
						 
					}
		
		
		      }
	
		
}
