package testRepository.GR.reDos_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.reDosPage;
import base.base;

public class R_TC_16 extends base 
{
	@Test
		public void uploadWrongFile() throws IOException
		{
	
				
	     try{
				 
		
	    	 reDosPage reDosObj=new reDosPage(); 
	 		 HomePage homePageObj=new HomePage();
             Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 	
	 		homePageObj.openSearchView();
	 		
	 		Thread.sleep(4000);
	 		
	 		//Click on Upload link
	 		reDosObj.clickUploadLink_SearchView();
	 		
	 		Thread.sleep(3000);
	 		
	 		 //Counting no of rows in FILE UPLOAD HISTORY table Before request submission
		 	   int Rowcount_beforeRedoReqSumission=reDosObj.Count_Records();
		 	   
		 	   System.out.println("Rowcount_beforeRedoReqSumission->"+Rowcount_beforeRedoReqSumission);
		 	     
		 	   
	 		//Click on CreateNewRequest
	 		reDosObj.clickCreateNewRequest();
	 		
	 		//Select View Type
	 		
	 		reDosObj.selectViewType_Claims();
	 		
	 		//Click on Next Button
	 		reDosObj.clickNextButton();
	 		
	 		//Select Input Columns
	 		reDosObj.selectInputColumns();
	 		
	 		//Select Output Columns
	 		reDosObj.selectOutputColumns();
	 		
	         //Click on Download Template button
	 		reDosObj.clickDownloadTemplate();
	 		Thread.sleep(10000);
	 		
	 		//Click on Upload button icon
	 	        reDosObj.uploadWrongFile();
	 		 
	 	  
	 	    //Click on ReDo option
	 	    reDosObj.clickReDo_Actions();
	 	     
	 	    Thread.sleep(2000);
	 	   //Counting no of rows in FILE UPLOAD HISTORY table after request submission
	 	 
	 	    String Error_FileUpload=reDosObj.captureError_WrongFileUpload();
	 	    System.out.println("Error_FileUpload->"+Error_FileUpload);
	 		
           SoftAssert softAssert = new SoftAssert();
      softAssert.assertTrue(Error_FileUpload.equalsIgnoreCase("Please upload downloaded template file to proceed"), "Incorrect error getting populated");
           
	    
	//       softAssert.assertTrue(listDropdownValues_Actions.contains("Re Do"), "Re Do option not displayed");
		   softAssert.assertAll();
		 
		   System.out.println("TC016_Redo Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC016_Redo Passed"); 
				   
		  }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC016_Redo Failed");
					   
					//  test.log(LogStatus.FAIL, "TC016_Redo Failed"); 
               Assert.fail(e.getMessage());
						 
					}
		
		
		      }
	
		
}
