package testRepository.GR.reDos_GR;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.reDosPage;
import base.base;

public class R_TC_05 extends base 
{
	@Test
		public void VerifyRequestIdLink() throws IOException
		{		
	     try{
				 
		
	    	 reDosPage reDosObj=new reDosPage(); 
	 		 HomePage homePageObj=new HomePage();
             Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 	    homePageObj.openSearchView();
	 		
	 		
	 		Thread.sleep(4000);
	 		
	 		//Click on Upload link
	 		reDosObj.clickUploadLink_SearchView();
	 		
	 		
	 		
	 		Thread.sleep(4000);
	 		
	 		reDosObj.ApplyFilter();
	 		//Click on Request id link
	 	//	reDosObj.clickRequestIdLink();
	 		
	 	    //get title of page opened
	 		String PageOpened=reDosObj.getTitlePageOnclickingRequestIdLink();
	 		 
	 	
	 		
			
           SoftAssert softAssert = new SoftAssert();
	       
	       softAssert.assertTrue(PageOpened.equalsIgnoreCase("Request Work Flow"), "Request id ink not working");
		   softAssert.assertAll();
		 
		   System.out.println("R_TC_05_Redo Passed");
		      
		    //  test.log(LogStatus.FAIL, "R_TC_05_Redo Passed"); 
		 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("R_TC_05_Redo Failed");
				  System.out.println(e.getMessage());	   
					//  test.log(LogStatus.FAIL, "R_TC_05_Redo Failed"); 
			 Assert.fail(e.getMessage());
						 
					}
		
		
		      }
	
		
}
