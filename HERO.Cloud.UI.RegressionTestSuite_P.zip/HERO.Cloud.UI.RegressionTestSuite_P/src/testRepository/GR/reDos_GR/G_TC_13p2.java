package testRepository.GR.reDos_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.reDosPage;
import base.base;

public class G_TC_13p2 extends base 
{
	@Test
		public void VerifyRequestCancel_ReqOverFlow() throws IOException
		{
	
			   		
	     try{
				 
		
	    	 reDosPage reDosObj=new reDosPage(); 
	 		 HomePage homePageObj=new HomePage();

	 		String  Downloadpath=getPropertyFileValue("DownloadFilepath");
	         System.out.println("Downloadpath->"+Downloadpath);
	 		
	 		
	 		Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 	
	 		homePageObj.openSearchView();
	 		
	 		Thread.sleep(4000);
	 		
	 		//Click on Upload link
	 		reDosObj.clickUploadLink_SearchView();
	 		
	 		//Select appropriate fields and click apply Filter
	        Thread.sleep(4000);
	 		
	 	   reDosObj.ApplyFilter();
	 	   
	 	  Thread.sleep(4000);
	 	  
	 	 
	 	  
	 	  
	 	   //click on RequestId Link
	 	  reDosObj.readStatus_uploadhistory();
	 	   
	 	 Thread.sleep(4000);
	 	   
      
	 	 
	 	
	 		
		 	  
	      
	  //    test.log(LogStatus.INFO, "Downloaded File name->"+fileName);
	 		
	 		
	 		//Click on Request id link
	 	//	reDosObj.clickRequestId
	 		 
	 	
	 		
			
        SoftAssert softAssert = new SoftAssert();
	       
	    //   softAssert.assertTrue(flag, "Input data Link not working");
		   softAssert.assertAll();
		   System.out.println("TC013p2_Redo Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC013p1_Redo Passed"); 
			}
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC013p2_Redo Failed");
					   
					//  test.log(LogStatus.FAIL, "TC013p1_Redo Failed"); 
				  Assert.fail(e.getMessage());
						 
					}
	         }
	}
