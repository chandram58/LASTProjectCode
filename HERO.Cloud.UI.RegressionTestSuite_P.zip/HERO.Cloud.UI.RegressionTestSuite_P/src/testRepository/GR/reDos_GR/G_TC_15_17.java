package testRepository.GR.reDos_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.reDosPage;
import base.base;

public class G_TC_15_17 extends base 
{
	@Test
		public void CreationofRequestRedos() throws IOException
		{
	
				
	     try{
				 
		
	    	 reDosPage reDosObj=new reDosPage(); 
	 		 HomePage homePageObj=new HomePage();
                    Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 	
	 	    homePageObj.openSearchView();
	 		
	 		Thread.sleep(4000);
	 		
	 		//Click on Upload link
	 		reDosObj.clickUploadLink_SearchView();
	 		
	 		Thread.sleep(3000);
	 		
	 		 //Counting no of rows in FILE UPLOAD HISTORY table Before request submission
		 	   int Rowcount_beforeRedoReqSumission=reDosObj.Count_Records();
		 	   
		 	   System.out.println("Rowcount_beforeRedoReqSumission->"+Rowcount_beforeRedoReqSumission);
		 	     
		 	   
	 		//Click on CreateNewRequest
	 		reDosObj.clickCreateNewRequest();
	 		
	 		//Select View Type
	 		
	 		reDosObj.selectViewType_Claims();
	 		
	 		//Click on Next Button
	 		reDosObj.clickNextButton();
	 		
	 		//Select Input Columns
	 		reDosObj.selectInputColumns();
	 		
	 		//Select Output Columns
	 		reDosObj.selectOutputColumns();
	 		
	         //Click on Download Template button
	 		reDosObj.clickDownloadTemplate();
	 		Thread.sleep(10000);
	 		
	 		//Click on Upload button icon
	 	        reDosObj.upload_file();
	 		 
	 	     
	 	     
	 	    //Click on ReDo option
	 	    reDosObj.clickReDo_Actions();
	 	   reDosObj.enterComments_Submit();
	 	     
	 	    Thread.sleep(2000);
	 	   //Counting no of rows in FILE UPLOAD HISTORY table after request submission
	 	   int Rowcount_afterRedoReqSumission=reDosObj.Count_Records();
	 	   
	 	   System.out.println("Rowcount_afterRedoReqSumission->"+Rowcount_afterRedoReqSumission);
	 	     
	 	    int Diff_count=Rowcount_afterRedoReqSumission-Rowcount_beforeRedoReqSumission;
	 		
	 		String Request_type=reDosObj.getRequestType_FileUploadHistory();
	 		System.out.println("Request_type  Submitted in File Upload History->"+Request_type);
	 		
	 		String InputFileName=reDosObj.getInputFileName_FileUplaodHistory();
	 		System.out.println("InputFileName Submitted in File Upload History->"+InputFileName);
	 		
           SoftAssert softAssert = new SoftAssert();
           softAssert.assertTrue(Diff_count==1, "Re do submission request not captured in File Upload history");
           
	     softAssert.assertTrue(Request_type.equalsIgnoreCase("Re Do"), "Request_type is not Re Do");
	     softAssert.assertTrue(InputFileName.contains("ReDo"), "Input File not having ReDo");
	     
	     
	//       softAssert.assertTrue(listDropdownValues_Actions.contains("Re Do"), "Re Do option not displayed");
		   softAssert.assertAll();
		 
		   System.out.println("TC017_Redo Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC001_Redo Passed"); 
		 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC001_Redo Failed");
					   
					//  test.log(LogStatus.FAIL, "TC001_Redo Failed"); 
              Assert.fail(e.getMessage());
						 
					}
		
		
		      }
	
		
}
