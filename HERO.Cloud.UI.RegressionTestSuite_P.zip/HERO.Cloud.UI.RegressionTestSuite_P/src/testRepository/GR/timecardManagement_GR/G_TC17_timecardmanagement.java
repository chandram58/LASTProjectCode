package testRepository.GR.timecardManagement_GR;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;
//Futur Date
public class G_TC17_timecardmanagement extends base{
	@Test
	public void FunctionalityofNewTimeCardforToday() throws Exception {
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonNewTimeCard().click();
		Thread.sleep(3000);
	WebElement endtime=	timecardManagementPagObj.clickonendTimeinTimeCard();
	String endcheckfortoday=endtime.getAttribute("class");
	System.out.println(endtime.isEnabled());
	System.out.println(endcheckfortoday);
 String productivehrs=	timecardManagementPagObj.getProductivehrsfromNewTimecard().getText();
 System.out.println(productivehrs);
 String nonproductivehrs=timecardManagementPagObj.getNonProductivehrsfromNewTimecard().getText();
 System.out.println(nonproductivehrs);
	
Thread.sleep(5000);

 timecardManagementPagObj.clicknewTimeCardDate().click();
selectDate("01/12/2022");
 timecardManagementPagObj.clickonStartTimeinTimeCard().click();
 timecardManagementPagObj.getStartTimeinTimeCard().click(); 
 WebElement endtime1=	timecardManagementPagObj.clickonendTimeinTimeCard();
 endtime1.click();
 Thread.sleep(3000);
 timecardManagementPagObj.getendTimeinTimestamp().click();;
 Thread.sleep(3000);
 String endcheckforpastday=endtime1.getAttribute("class");
 System.out.println(endcheckforpastday);
 WebElement productivehrspastday=	timecardManagementPagObj.getProductivehrsfromNewTimecard();
 System.out.println(productivehrspastday.getText());
 WebElement nonproductivehrspastday=timecardManagementPagObj.getNonProductivehrsfromNewTimecard();
 System.out.println(nonproductivehrspastday.getText());
 //String expectedendtimefortoday="ng-tns-c60-18 p-calendar p-calendar-timeonly p-calendar-disabled";
//String expectedendtimeforpastday="ng-tns-c60-18 p-calendar p-calendar-timeonly";

try {
	SoftAssert softAssert = new SoftAssert();   
		 softAssert.assertTrue(endcheckfortoday.contains("disabled"), "newtimecard for today EndTime is not disabled");
		 softAssert.assertTrue(endcheckfortoday.contains("p-calendar-timeonly"), "newtimecard for today EndTime is not enabled");
		 softAssert.assertTrue(productivehrspastday.isDisplayed(), "productivehours section not displayed");
		 softAssert.assertTrue(nonproductivehrspastday.isDisplayed(), "Nonproductivehours section not displayed");
		 
		 softAssert.assertAll();
		  System.out.println("G_TC17_timecardmanagement passed");
				}
				
	 catch(Throwable e)
	     {
				   System.out.println("G_TC17_timecardmanagement Failed");
				   Assert.fail(e.getMessage());
	     }
				
	}

}
