package testRepository.GR.timecardManagement_GR;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class R_G_TC28_18_timecardManagement extends base{
	
 @Test
 public void updateFunctionality() throws Exception {
	 HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonselectuserfileldinfiltr().click();
		timecardManagementPagObj.getsearchuser("Vijaya Pureti");
		timecardManagementPagObj.clickonuser().click();
		Thread.sleep(3000);
		timecardManagementPagObj.clickstartdate().click();
		selectDate("05/01/2022");
		Thread.sleep(3000);
		timecardManagementPagObj.clickenddate().click();
		String Currentdate=String.valueOf(getDate(0));
		System.out.println("Currentdate->"+Currentdate);
		selectDate(Currentdate);
		Thread.sleep(3000);
		timecardManagementPagObj.clickFilterbtn().click();
		Thread.sleep(2000);
		timecardManagementPagObj.clickonEditbutton();
		String reason="break";
		timecardManagementPagObj.clickonAddReasonCode().click();
		timecardManagementPagObj.clickonSecltreasoncode().click();
		timecardManagementPagObj.clickonSearchreasoncode(reason);
		timecardManagementPagObj.clickreasoncode().click();
	WebElement sectReason=	timecardManagementPagObj.clickonSecltreasoncode();
	System.out.println(sectReason.getText());
	String reasonadded=sectReason.getText();
	timecardManagementPagObj.clickReasonSarttime();
	timecardManagementPagObj.getReasonSarttime();
	timecardManagementPagObj.clickReasonEndtime();
	timecardManagementPagObj.getReasonEndtime();
	timecardManagementPagObj.getDescriptionfield("test");
	Thread.sleep(3000);
	timecardManagementPagObj.clickonSavebtn();
String message=	timecardManagementPagObj.getupdateSucess().getText();
System.out.println(message);

try {
	SoftAssert softAssert = new SoftAssert();   
	 softAssert.assertTrue(message.contains("Timecard has been updated Successfully"), "Timecard has been not updated successfully");
	
	 softAssert.assertAll();
	  System.out.println("TC_28/18_timecardmanagement is passed");
			}
			
 catch(Throwable e)
     {
			   System.out.println("TC_28/18_timecardmanagement Failed");
			   Assert.fail(e.getMessage());
     }
		
	
		
 }
}
