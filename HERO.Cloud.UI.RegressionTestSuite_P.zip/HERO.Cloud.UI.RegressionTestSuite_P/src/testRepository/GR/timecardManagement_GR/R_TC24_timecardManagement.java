package testRepository.GR.timecardManagement_GR;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class R_TC24_timecardManagement extends base{
	@Test
	public void geterrormessageforwithoutselectuserinflte() throws InterruptedException {
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickFilterbtn().click();
		Thread.sleep(3000);;
	WebElement errormessage=timecardManagementPagObj.getErrormessageforUser();
	String Message=errormessage.getText();
	System.out.println(Message);
	
	try {
		SoftAssert softAssert = new SoftAssert();   
		 softAssert.assertTrue(Message.contains("Please select users"), "Incorrect Validation Message");
		 softAssert.assertAll();
		  System.out.println("TC_24_timecardmanagement is passed");
				}
				
	catch(Throwable e)
	    {
				   System.out.println("TC_24_timecardmanagement Failed");
				   Assert.fail(e.getMessage());
	    }
	
	}
	
		
	

}
