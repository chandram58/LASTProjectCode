package testRepository.GR.timecardManagement_GR;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class R_TC22_timecardManagement extends base{
	@Test
	public void getResetFunctionalityinFiltersection() throws Exception {
		
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonselectuserfileldinfiltr().click();
		timecardManagementPagObj.getsearchuser("Vijaya Pureti");
		timecardManagementPagObj.clickonuser().click();
		Thread.sleep(3000);
		String pastDt="05/02/2022";
		timecardManagementPagObj.clickstartdate().click();
		selectDate(pastDt);
		Thread.sleep(3000);
		timecardManagementPagObj.clickenddate().click();
		selectDate(pastDt);
		Thread.sleep(3000);
		timecardManagementPagObj.clickFilterbtn().click();
	WebElement slctuser=timecardManagementPagObj.clickonselectuserfileldinfiltr();
	String userfiledvalue=slctuser.getText();
	System.out.println(userfiledvalue);
	
	Thread.sleep(3000);
	
	timecardManagementPagObj.clickonResetbutton();
	
	WebElement slctuser1=timecardManagementPagObj.clickonselectuserfileldinfiltr();
	String Defaultfield=slctuser1.getText();
	System.out.println(Defaultfield);
	
	WebElement dateinfltr=	timecardManagementPagObj.clickenddate();
	String DefaultDate=dateinfltr.getText();
	System.out.println(DefaultDate);
	
	try {
		SoftAssert softAssert = new SoftAssert();   
		 softAssert.assertTrue(Defaultfield.contains("Select Users"), "Reset button is not working ");
		 softAssert.assertAll();
		  System.out.println("TC_22_timecardmanagement is passed");
				}
				
	catch(Throwable e)
	    {
				   System.out.println("TC_22_timecardmanagement Failed");
				   Assert.fail(e.getMessage());
	    }
	
	
	}

}
