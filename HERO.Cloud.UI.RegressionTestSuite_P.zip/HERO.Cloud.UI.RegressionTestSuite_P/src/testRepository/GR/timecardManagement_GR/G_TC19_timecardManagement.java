package testRepository.GR.timecardManagement_GR;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class G_TC19_timecardManagement extends base{
	@Test
	public void getrestoredfunctionality() throws Exception {
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		Thread.sleep(2000);
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonselectuserfileldinfiltr().click();
		timecardManagementPagObj.getsearchuser("Vijaya Pureti");
		timecardManagementPagObj.clickonuser().click();
		Thread.sleep(3000);
		timecardManagementPagObj.clickstartdate().click();
		selectDate("09/09/2021");
		Thread.sleep(3000);
		timecardManagementPagObj.clickenddate().click();
		selectDate("05/20/2022");
		Thread.sleep(3000);
		timecardManagementPagObj.clickFilterbtn().click();
		
		timecardManagementPagObj.clickonDeletebtn().click();
		Thread.sleep(2000);
		timecardManagementPagObj.clickonOkbtn().click();
		
	
	String Deletemessage=timecardManagementPagObj.getdeletemessage();
	System.out.println(Deletemessage);
	Thread.sleep(3000);
	WebElement getrecorddata=timecardManagementPagObj.getresulttable();
String resulttable=	getrecorddata.getText();
System.out.println(resulttable);

try {
	SoftAssert softAssert = new SoftAssert();   
	 softAssert.assertTrue(Deletemessage.contains("Timecard has been deleted successfully"), "deletebtn is not working");
	 softAssert.assertTrue(resulttable.contains("No records found"), "restored data is not deleted");
	 softAssert.assertAll();
	  System.out.println("TC_19_timecardmanagement is passed");
			}
			
catch(Throwable e)
    {
			   System.out.println("TC_19_timecardmanagement Failed");
			   Assert.fail(e.getMessage());
    }
			
	}

}
