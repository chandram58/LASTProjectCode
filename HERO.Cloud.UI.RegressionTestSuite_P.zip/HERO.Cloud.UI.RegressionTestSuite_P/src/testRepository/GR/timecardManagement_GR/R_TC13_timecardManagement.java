package testRepository.GR.timecardManagement_GR;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class R_TC13_timecardManagement extends base{
	@Test
	public void getpastDateFunctionality() throws Exception {
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonselectuserfileldinfiltr().click();
		timecardManagementPagObj.getsearchuser("Vijaya Pureti");
		timecardManagementPagObj.clickonuser().click();
		Thread.sleep(3000);
		timecardManagementPagObj.clickstartdate().click();
		String pastDt="05/02/2022";
		
		selectDate(pastDt);
		Thread.sleep(3000);
		timecardManagementPagObj.clickenddate().click();
		selectDate(pastDt);
		Thread.sleep(3000);
		timecardManagementPagObj.clickFilterbtn().click();
		 List<String> Userdatesintable = new ArrayList<String>();
		String DatesfromTable=	timecardManagementPagObj.getDatesfromTable().getText();
		 System.out.println(DatesfromTable);
		 Userdatesintable.add(DatesfromTable);
	 List<String> Userdatesintable1 = new ArrayList<String>(Arrays.asList(pastDt));
	 try {
		 SoftAssert softAssert = new SoftAssert();   
		 softAssert.assertTrue(DatesfromTable.contains(pastDt), "past selected Dates are not displaying");
		 softAssert.assertAll();
		  System.out.println("TC_13_timecardmanagement is passed");
				}
				
	catch(Throwable e)
	    {
				   System.out.println("TC_13_timecardmanagement Failed");
				   Assert.fail(e.getMessage());
	    }
	 
	 
		
	}

}
