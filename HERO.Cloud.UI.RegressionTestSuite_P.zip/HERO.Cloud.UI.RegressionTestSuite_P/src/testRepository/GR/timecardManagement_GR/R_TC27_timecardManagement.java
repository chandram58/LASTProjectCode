package testRepository.GR.timecardManagement_GR;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class R_TC27_timecardManagement extends base{
	@Test
	public void gettimecardperOnedaye() throws Exception {
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonselectuserfileldinfiltr().click();
		timecardManagementPagObj.getsearchuser("Vijaya Pureti");
		timecardManagementPagObj.clickonuser().click();
		Thread.sleep(3000);
		String pastDt="05/02/2022";
		timecardManagementPagObj.clickstartdate().click();
		selectDate(pastDt);
		Thread.sleep(3000);
		timecardManagementPagObj.clickenddate().click();
	    selectDate(pastDt);
		Thread.sleep(3000);
		timecardManagementPagObj.clickFilterbtn().click();
		Thread.sleep(3000);
	String DatesfromTable=	timecardManagementPagObj.getDatesfromTable().getText();
	System.out.println(DatesfromTable);
		
	try {
		SoftAssert softAssert = new SoftAssert();   
		 softAssert.assertTrue(DatesfromTable.contains(pastDt), "Time card per day is not available ");
		 softAssert.assertAll();
		  System.out.println("TC_27_timecardmanagement is passed");
				}
				
	catch(Throwable e)
	    {
				   System.out.println("TC_27_timecardmanagement Failed");
				   Assert.fail(e.getMessage());
	    }
	}

}
