package testRepository.GR.timecardManagement_GR;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class R_TC21_timecardManagement extends base{
	@Test
	public void getdatesofMonth() throws Exception {
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonselectuserfileldinfiltr().click();
		timecardManagementPagObj.getsearchuser("Vijaya Pureti");
		timecardManagementPagObj.clickonuser().click();
		Thread.sleep(3000);
		String pastDt="05/02/2022";
		timecardManagementPagObj.clickstartdate().click();
		selectDate(pastDt);
		Thread.sleep(3000);
		timecardManagementPagObj.clickenddate().click();
		selectDate(pastDt);
		Thread.sleep(3000);
		timecardManagementPagObj.clickFilterbtn().click();
		List<String> Userdatesintable = new ArrayList<String>();
		Userdatesintable=timecardManagementPagObj.getDatesfromResultTable();
		 System.out.println("Userdatesintable->"+Userdatesintable);
		
		Thread.sleep(8000);
		 String dates = Userdatesintable.stream().map(Object::toString).collect(Collectors.joining(",")); 
		    System.out.println("dates->"+dates);
		//System.out.println(Userdatesintable);
		try {
			SoftAssert softAssert = new SoftAssert();   
			 softAssert.assertTrue(Userdatesintable.contains(pastDt), "dates are not available");
			 softAssert.assertAll();
			  System.out.println("TC_21_timecardmanagement is passed");
					}
					
		catch(Throwable e)
		    {
					   System.out.println("TC_21_timecardmanagement Failed");
					   Assert.fail(e.getMessage());
		    }
		
	}

}
