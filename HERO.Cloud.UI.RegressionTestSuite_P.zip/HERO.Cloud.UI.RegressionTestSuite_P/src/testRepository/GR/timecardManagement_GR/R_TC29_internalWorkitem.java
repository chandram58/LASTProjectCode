package testRepository.GR.timecardManagement_GR;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.TimeCardManagementpage;

public class R_TC29_internalWorkitem extends base{
	@Test
	public void NewTimecardFunctionality() throws Exception {
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(1000);
		homePageObj.openModule("Timecard Management");
		
		TimeCardManagementpage timecardManagementPagObj=new  TimeCardManagementpage();
		timecardManagementPagObj.clickonNewTimeCard().click();
		Thread.sleep(3000);
		timecardManagementPagObj.clickonSelectUser().click();
		timecardManagementPagObj.SelectUserfromDropd("Vijaya Pureti");
		timecardManagementPagObj.clicknewTimeCardDate().click();
		selectDate("06/04/2021");
		timecardManagementPagObj.clickonStartTimeinTimeCard().click();
		 timecardManagementPagObj.getStartTimeinTimeCard().click(); 
		 WebElement endtime1=	timecardManagementPagObj.clickonendTimeinTimeCard();
		 endtime1.click();
		 Thread.sleep(3000);
		 timecardManagementPagObj.getendTimeinTimestamp().click();
		 Thread.sleep(3000);
		 timecardManagementPagObj.clickonSavebtn();
		 
	String Message=	 timecardManagementPagObj.getNewtimecardSuccessmessage().getText();
	System.out.println(Message);
	
	try {
		SoftAssert softAssert = new SoftAssert();   
		 softAssert.assertTrue(Message.contains("Timecard has been created successfully"), "Timecard has been not created successfully");
		
		 softAssert.assertAll();
		  System.out.println("TC_29_timecardmanagement is passed");
				}
				
	 catch(Throwable e)
	     {
				   System.out.println("TC_29_timecardmanagement Failed");
				   Assert.fail(e.getMessage());
	     }
				
	
	}

}
