package testRepository.GR.partnerMaintenance_GR;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.base;
import pages.HomePage;
import pages.PartnerMaintenancePage;

public class TC_16_18_PartnerMaintenance extends base

{
	
	// TC18_verify error message for inavlid range
	
	// TC12_Verify partner  attributes in new and update partner screen
	
	@Test
	public void verifyErrorMessageInavlidRange() throws IOException
	{
		try
		{
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Partner Maintenance");
			PartnerMaintenancePage partnerMaintenancePage=new PartnerMaintenancePage();
			partnerMaintenancePage.btnEditPartner();
			
			Assert.assertTrue(partnerMaintenancePage.verifyErrorMessageInavlidRangeFun());
			
		
			 System.out.println("TC_16_18_PartnerMaintenance Passed");
		
			
		}
		catch(Throwable e)
	     {
		   System.out.println("TC_16_18_PartnerMaintenance Failed");
		   Assert.fail(e.getMessage());
		 }
	}
}