package testRepository.GR.partnerMaintenance_GR;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.PartnerMaintenancePage;

public class TC_06_11_PartnerMaintenance extends base

{
	
	// TC_02 Verify that, Ability to request updates�to a partner profile
	
	
	
	@Test
	public void verifyAbilityToRequestUpdatesPartnerProfile() throws IOException
	{
		try
		{
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Partner Maintenance");
			PartnerMaintenancePage partnerMaintenancePage=new PartnerMaintenancePage();
			// Changing Submission into Active mode
			partnerMaintenancePage.btnEditPartner();
			partnerMaintenancePage.validateEditFunctionality();
			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Partner Maintenance");
			partnerMaintenancePage.btnEditPartner();
			
		int i=partnerMaintenancePage.clickeditFinalTextCheck();
		
		if(i==1)
			Assert.assertTrue(true);
		else
			Assert.assertTrue(true);
		 System.out.println("TC_06_11_PartnerMaintenance Passed");
		}
		catch(Throwable e)
	     {
		   System.out.println("TC_06_11_PartnerMaintenance Failed");
	  //  test.log(LogStatus.FAIL, "G_TC002_userProfile Failed"); 
		   Assert.fail(e.getMessage());
		 }
	}
}
