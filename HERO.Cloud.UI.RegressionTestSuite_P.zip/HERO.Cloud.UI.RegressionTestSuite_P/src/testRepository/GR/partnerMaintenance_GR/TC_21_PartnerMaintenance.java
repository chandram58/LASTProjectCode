package testRepository.GR.partnerMaintenance_GR;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.base;
import pages.HomePage;
import pages.PartnerMaintenancePage;

public class TC_21_PartnerMaintenance extends base

{
	
	
	
	
	
	//TC_21 Verify that, Doc can be added for New Request Partner Profile
	
	
	@Test
	public void verifyDoccanbeaddedforNewRequestPartnerProfile() throws IOException
	{
		try
		{
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Partner Maintenance");
			PartnerMaintenancePage partnerMaintenancePage=new PartnerMaintenancePage();
			
			Assert.assertTrue(partnerMaintenancePage.verifyDoccanbeaddedforNewRequestPartnerProfile());
			System.out.println("TC_21_PartnerMaintenance Passed");
		}
		catch(Throwable e)
	     {
		   System.out.println("TC_21_PartnerMaintenance Failed");
	 	   Assert.fail(e.getMessage());
		 }
	}
}