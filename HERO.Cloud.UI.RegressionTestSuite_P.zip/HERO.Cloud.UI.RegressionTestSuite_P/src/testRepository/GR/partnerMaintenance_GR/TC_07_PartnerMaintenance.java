package testRepository.GR.partnerMaintenance_GR;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.base;
import pages.HomePage;
import pages.PartnerMaintenancePage;

public class TC_07_PartnerMaintenance extends base{
	
	// TC07_Verify Suspended partner available at very bottom of grid 
	@Test
	public void verifyScreenAvailabityclickNewPartner() throws IOException
	{
		try     
		{    
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Partner Maintenance");
			PartnerMaintenancePage partnerMaintenancePage=new PartnerMaintenancePage();
	        int Size = partnerMaintenancePage.totalRowsPartnerMaintenancePage();
	        String lastColumStatus = partnerMaintenancePage.getEndColumPartnerStatusText(Size);
	        String Expected="Suspended"; 
	        Assert.assertEquals(lastColumStatus.trim(),Expected.trim());
	        System.out.println("TC_07_PartnerMaintenance Passed");
		}
		
	
		catch(Throwable e)
	     {
		   System.out.println("TC_07_PartnerMaintenance Failed");
		   Assert.fail(e.getMessage());
		 }
	}

}
