package testRepository.GR.partnerMaintenance_GR;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.base;
import pages.HomePage;
import pages.PartnerMaintenancePage;

public class TC_46_47_PartnerMaintenance extends base
{
	   //  TC04_Verify partner status column as Suspend when If user clicks on Suspend toggle button available on Landing grid
	  //   TC_47 Verify that, "+" button to add more doctypes and it does not show the already existing doc type
	
	   @Test
		public void verifyPlusSymbolInNewPartnetMenu() throws IOException
		{
			try
			{
			
				HomePage homePageObj=new HomePage();
				homePageObj.mouseHoverAdministration();	
				homePageObj.openModule("Partner Maintenance");
				PartnerMaintenancePage partnerMaintenancePage=new PartnerMaintenancePage();
				
						     
				Assert.assertTrue(partnerMaintenancePage.verifyPlusSymbolInNewPartnetMenu());
				System.out.println("TC_047_PartnerMaintenance Passed");		
			}
			catch(Throwable e)
		     {
			   System.out.println("TC_047_PartnerMaintenance Failed");
		  
			   Assert.fail(e.getMessage());
			 }
		}
	}
