package testRepository.GR.partnerMaintenance_GR;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.PartnerMaintenancePage;

public class TC_09_48_PartnerMaintenance extends base

{

//	TC_09 Verify that,  Partner search screen
	
             
	@Test
	public void VerifyPartnerSearchScreen() throws IOException
	{
		try
		{
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Partner Maintenance");
			PartnerMaintenancePage partnerMaintenancePage=new PartnerMaintenancePage();
			String Searchterm="Test";
			partnerMaintenancePage.sendInputClickSearchPartner(Searchterm);
			Thread.sleep(5000);
			  List<WebElement> serachResult_rows=partnerMaintenancePage.getSearchResult();
				System.out.println("No of rows populated in Search->"+serachResult_rows.size());
					
				 SoftAssert softAssert = new SoftAssert();
					for(int j=0;j<serachResult_rows.size();j++)
					{
				      System.out.println(serachResult_rows.get(j).getText());
					  softAssert.assertTrue((serachResult_rows.get(j).getText().toLowerCase()).contains(Searchterm.toLowerCase()), "Row no->"+(j+1)+" not having searched error code");	
					}
				     softAssert.assertAll();
			
			
	 		
			
	 		 System.out.println("TC_09_48_PartnerMaintenance Passed");
			
		}
		catch(Throwable e)
	     {
		   System.out.println("TC_09_48_PartnerMaintenance Failed");
	
		   Assert.fail(e.getMessage());
		 }
	}
}



