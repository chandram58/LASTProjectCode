package testRepository.GR.partnerMaintenance_GR;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.base;
import pages.HomePage;
import pages.PartnerMaintenancePage;

public class TC_19_PartnerMaintenance extends base
{
   // TC19_verfiy with out selecting ranges click on add btn  and verify same range is selecting multiple times then user get error message

	// TC19_verifyErrorMessageDuplicateRange
	@Test
	public void verifyErrorMessageDuplicateRange() throws IOException
	{
		try
		{
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Partner Maintenance");
			PartnerMaintenancePage partnerMaintenancePage=new PartnerMaintenancePage();
			partnerMaintenancePage.btnEditPartner();
			
			Assert.assertTrue(partnerMaintenancePage.verifyErrorMessageDuplicateRangeFun());
			
		
			 System.out.println("TC_19_PartnerMaintenance Passed");
		
			
		}
		catch(Throwable e)
	     {
		   System.out.println("TC_19_PartnerMaintenance Failed");
		   Assert.fail(e.getMessage());
		 }
	}
}
