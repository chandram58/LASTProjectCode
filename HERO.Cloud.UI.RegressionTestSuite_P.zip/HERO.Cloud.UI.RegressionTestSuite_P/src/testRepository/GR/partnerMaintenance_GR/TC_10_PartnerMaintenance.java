package testRepository.GR.partnerMaintenance_GR;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.PartnerMaintenancePage;

public class TC_10_PartnerMaintenance extends base {

	//TC_10 verify new partner screen availabity after click on new partner
	@Test
	public void verifyScreenAvailabityclickNewPartner() throws IOException
	{
		try     
		{    
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Partner Maintenance");
			PartnerMaintenancePage partnerMaintenancePage=new PartnerMaintenancePage();
	
			partnerMaintenancePage.clickbtnRequestNewPartner();
			Assert.assertTrue(partnerMaintenancePage.textCheckHeadRequestNewPartner());
			 System.out.println("TC_10_PartnerMaintenance Passed");
		}
		
	
		catch(Throwable e)
	     {
		   System.out.println("TC_10_PartnerMaintenance Failed");
		   Assert.fail(e.getMessage());
		 }
	}
}
   
