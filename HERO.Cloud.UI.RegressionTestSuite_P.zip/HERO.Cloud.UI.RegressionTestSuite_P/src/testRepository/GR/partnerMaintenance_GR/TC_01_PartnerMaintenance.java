package testRepository.GR.partnerMaintenance_GR;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.PartnerMaintenancePage;


public class TC_01_PartnerMaintenance extends base {
	 
	
	//TC_01 Verify that, User can able to see the PartnerMaintenanceLandingpage
	@Test
	public void verifyUserableToSeePartnerMaintenanceLandingpage() throws IOException
	{
		try        
		{      
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(3000);
		homePageObj.openModule("Partner Maintenance");
		PartnerMaintenancePage partnerMaintenancePage=new PartnerMaintenancePage();
		Assert.assertEquals(partnerMaintenancePage.getTitle_MainPage(), "Partner Maintenance");   
		} 
		catch(Throwable e)
	     {
		   System.out.println("F_TC_01_PartnerMaintenance Failed");
	  //  test.log(LogStatus.FAIL, "G_TC002_userProfile Failed"); 
		   Assert.fail(e.getMessage());
		 }
	}
}
