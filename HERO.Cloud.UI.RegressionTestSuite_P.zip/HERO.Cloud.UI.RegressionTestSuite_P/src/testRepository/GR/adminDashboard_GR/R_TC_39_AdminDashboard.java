package testRepository.GR.adminDashboard_GR;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.AdminDashboardPage;
import pages.HomePage;
import base.base;

public class R_TC_39_AdminDashboard extends base{
	@Test
	public void agning_Hyperlink() throws InterruptedException {
		 HomePage homePageObj=new HomePage();
		 homePageObj.mouseHoverDashboard();
	 	 homePageObj.openModule("Admin Dashboard");
	 	 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
	 	try
	 	{
	 		adminDashboardpage.clickAgingTab();
	 		adminDashboardpage.clickAgingValueLink();
	 		
	 		 String breadCrumb=adminDashboardpage.getBreadcrumbSearchResultPage();
		     System.out.println("breadCrumb->"+breadCrumb);
		
		     SoftAssert softassert = new SoftAssert();
			 softassert.assertTrue(breadCrumb.contains("Home")&& breadCrumb.contains("Admin Dashboard") && breadCrumb.contains("Result for Direct Search - ACTIVITY STATE / AGING") ,"Link not navigating to proper page");
			 softassert.assertAll();
		
		System.out.println("TC39_AdminDashboard is passed");
	}
	catch(Exception e) {
		System.out.println(e);
		   System.out.println(e.getMessage());
		   System.out.println("TC39_AdminDashboard is passed");
		}
		
	
	}

}
