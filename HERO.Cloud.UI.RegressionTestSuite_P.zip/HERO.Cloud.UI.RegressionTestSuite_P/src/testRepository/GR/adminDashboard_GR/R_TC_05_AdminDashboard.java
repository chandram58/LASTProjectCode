package testRepository.GR.adminDashboard_GR;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.AdminDashboardPage;
import pages.HomePage;

public class R_TC_05_AdminDashboard  extends base{
@Test
 public void getasofDateTodayfunctionlity() throws InterruptedException {
	
	 HomePage homePageObj=new HomePage();

     homePageObj.mouseHoverDashboard();
	  homePageObj.openModule("Admin Dashboard");
	  
	 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
	 AdminDashboardPage.clickonHeropa();
	String  asofDate= adminDashboardpage.clickonAsofDatefield().getText();
	System.out.println("asofDate "+ asofDate);
Thread.sleep(2000);
	// Create object of SimpleDateFormat class and decide the format
	 DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
	 
	 //get current date time with Date()
	 Date date = new Date();
	 
	 // Now format the date
	 String date1= dateFormat.format(date);
	 
	 // Print the Date
	 System.out.println(date1);
	Thread.sleep(3000);
	 adminDashboardpage.clickonAsofDatefield().click();
	 base.selectDateFromDatePicker("03/01/2022");
	 adminDashboardpage.clickonFilterbtn();
	 Thread.sleep(3000);
	 String  selctasof= adminDashboardpage.clickonAsofDatefield().getText(); 
	 System.out.println(selctasof);
	 String ackDate= adminDashboardpage.gettodaylabelfromAcknoweldgementSection().getText();
	 System.out.println(ackDate);
String outbndDate= adminDashboardpage.gettodaylabelfromoutboundSection().getText();
  System.out.println(outbndDate);
  String workToday= adminDashboardpage.gettodaylabelfromWorkitemSection().getText();
  System.out.println(workToday);
  Thread.sleep(3000);
  try {
	  SoftAssert softAssert = new SoftAssert();   
	  softAssert.assertTrue(asofDate.contains(date1), "default date is not today");
		 softAssert.assertTrue(selctasof.contains(ackDate), "date is not updating in ack");
		 softAssert.assertTrue(selctasof.contains(outbndDate), "date is not updating in outbnd");
		 softAssert.assertTrue(selctasof.contains(workToday), "date is not updating in workitem");
		 softAssert.assertAll();
		 System.out.println("TC05_AdminDashboard is passed");
  }
  catch(Throwable e)
    {
			   
			   System.out.println("TC05_AdminDashboard is failed");
			   Assert.fail(e.getMessage());
			   
    }
	 
}
}
