package testRepository.GR.adminDashboard_GR;


import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.AdminDashboardPage;
import pages.HomePage;
import base.base;

public class R_TC_10_AdminDashboard extends base{
	@Test
	public void SelectYear_WorkItems() throws InterruptedException {
		Thread.sleep(5000);
		 HomePage homePageObj=new HomePage();
		 homePageObj.mouseHoverDashboard();
	 	 homePageObj.openModule("Admin Dashboard");
	 	 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
	 	try
		{
	 	adminDashboardpage.clickSelectYears_WorkItem();
	 	int yeartobeSelected=getYear();
	 	System.out.println("yeartobeSelected->"+yeartobeSelected);
	 	
	 	adminDashboardpage.selectValueYearsValue_WorkItem(yeartobeSelected);
	 	
	 	String selectedValue=adminDashboardpage.getselectedYearsValue_WorkItem();
	 	System.out.println("selectedValue->"+selectedValue);
	 
	
	 	 SoftAssert softassert = new SoftAssert();
	 	softassert.assertTrue(selectedValue.equalsIgnoreCase(String.valueOf(yeartobeSelected)), "Value to be selected and Value populated not matching");
	 	softassert.assertAll();
		System.out.println("TC10_AdminDashboard passed");
	}
	catch(Exception e) {
		System.out.println(e);
		   System.out.println(e.getMessage());
		   System.out.println("TC10_AdminDashboard Failed");
		   Assert.fail(e.getMessage());
		   
		}
	}

}
