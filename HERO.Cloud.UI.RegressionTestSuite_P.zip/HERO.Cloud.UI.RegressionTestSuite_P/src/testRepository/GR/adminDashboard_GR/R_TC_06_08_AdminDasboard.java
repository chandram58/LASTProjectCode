package testRepository.GR.adminDashboard_GR;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.AdminDashboardPage;
import pages.HomePage;

public class R_TC_06_08_AdminDasboard extends base{
	@Test
	public void getpastdatesfromasofDate() throws InterruptedException {
		 HomePage homePageObj=new HomePage();

	     homePageObj.mouseHoverDashboard();
		  homePageObj.openModule("Admin Dashboard");
		  
		 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
		 AdminDashboardPage.clickonHeropa();
		 Thread.sleep(3000);
		 adminDashboardpage.clickonAsofDatefield().click();
		 String asofDate="03/01/2022";
		 base.selectDateFromDatePicker(asofDate);
		 adminDashboardpage.clickonFilterbtn();
		 Thread.sleep(3000);
		 String  selctasof= adminDashboardpage.clickonAsofDatefield().getText(); 
		 System.out.println(selctasof);
		 String ackDate= adminDashboardpage.gettodaylabelfromAcknoweldgementSection().getText();
		 System.out.println(ackDate);
		 
		//futur date
	
		 adminDashboardpage.clickonAsofDatefield().click();
		Thread.sleep(3000);
	String	ftrdate= adminDashboardpage.getfuturDate().getAttribute("class");
		 
		 try {
			  SoftAssert softAssert = new SoftAssert();   
			 
			  softAssert.assertTrue(asofDate.contains(selctasof), " past date is not updating ");
				
				 softAssert.assertTrue(ftrdate.contains("disabled "), "futur date is enabled");
				 
				 softAssert.assertAll();
				 System.out.println("TC06_08_AdminDashboard is passed");
		  }
		  catch(Throwable e)
		    {
					   
					   System.out.println("TC06_08_AdminDashboard is failed");
					   Assert.fail(e.getMessage());
					   
		    }
	}

}
