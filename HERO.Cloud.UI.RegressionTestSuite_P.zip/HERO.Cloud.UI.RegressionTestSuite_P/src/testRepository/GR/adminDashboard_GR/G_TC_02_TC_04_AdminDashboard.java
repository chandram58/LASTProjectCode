package testRepository.GR.adminDashboard_GR;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.AdminDashboardPage;
import pages.HomePage;

public class G_TC_02_TC_04_AdminDashboard extends base{
	@Test
	public void getTPsFunctionality() throws InterruptedException {
		 HomePage homePageObj=new HomePage();

	      homePageObj.mouseHoverDashboard();
	 	  homePageObj.openModule("Admin Dashboard");
	 	 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
	 	adminDashboardpage.clickonTPfield().click();
	 String 	allTPs=adminDashboardpage.clickonCheckboxinSearchTP().getAttribute("class");
	 System.out.println(allTPs);
	 Thread.sleep(2000);
	 adminDashboardpage.clickonCheckboxinSearchTP().click();
	 String 	allTPDeSelect=adminDashboardpage.clickonCheckboxinSearchTP().getAttribute("aria-checked");
	 System.out.println(allTPDeSelect);
	 Thread.sleep(2000);
	
	 adminDashboardpage.clickonFilterbtn();
	 Thread.sleep(2000);
	String Message= adminDashboardpage.getErrorpupforTPs().getText();
	System.out.println(Message);
String Errormessage=Message.substring(26, 41);
	 Thread.sleep(2000);
	System.out.println(Errormessage);
	
	 try {
		  SoftAssert softAssert = new SoftAssert();   
		  softAssert.assertTrue(allTPs.contains("p-highlight"), "all partners not selected");
		  softAssert.assertTrue(allTPDeSelect.equals("false"), "partner selected");
			 softAssert.assertTrue(Errormessage.contentEquals("trading partner"), "partner error pop up is not get");
			 
			 softAssert.assertAll();
			 System.out.println("TC02_04_AdminDashboard is passed");
	  }
	  catch(Throwable e)
	    {
				   
				   System.out.println("TC02_04_AdminDashboard is failed");
				   Assert.fail(e.getMessage());
				   
	    }
	}

}
