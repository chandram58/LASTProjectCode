package testRepository.GR.adminDashboard_GR;


import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.AdminDashboardPage;
import pages.HomePage;
import base.base;

public class R_TC_11_AdminDashboard extends base{
	@Test
	public void Hyperlink_WorkItems() throws InterruptedException
	{
		Thread.sleep(5000);
		 HomePage homePageObj=new HomePage();
		 homePageObj.mouseHoverDashboard();
	 	 homePageObj.openModule("Admin Dashboard");
	 	 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
		
	 	try
	 	{
	 	adminDashboardpage.clickWorkitemValueLink();
	 	String breadCrumb=adminDashboardpage.getBreadcrumbSearchResultPage();
	 	System.out.println("breadCrumb->"+breadCrumb);
	 	
	

	SoftAssert softassert = new SoftAssert();
	softassert.assertTrue(breadCrumb.contains("Home")&& breadCrumb.contains("Admin Dashboard") && breadCrumb.contains("Result for Direct Search - WORK ITEMS") ,"Link not navigating to proper page");
    softassert.assertAll();
	System.out.println("TC11_AdminDashboard  passed");
	
}
catch(Exception e) {
	System.out.println(e);
	   System.out.println(e.getMessage());
	   System.out.println("TC11_AdminDashboard is Failed");
	   Assert.fail(e.getMessage());
	   
	}

	}

}
