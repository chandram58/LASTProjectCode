package testRepository.GR.adminDashboard_GR;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.AdminDashboardPage;
import pages.HomePage;
import base.base;

public class R_TC_52_AdminDashboard extends base{
	@Test
	public void allyears_SelectYears_workitems_excel_PDF() throws InterruptedException, IOException 
	{
		 HomePage homePageObj=new HomePage();
		 homePageObj.mouseHoverDashboard();
	 	 homePageObj.openModule("Admin Dashboard");
	 	 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
	 	 
         String  Downloadpath=getPropertyFileValue("DownloadFilepath");
         System.out.println("Downloadpath->"+Downloadpath);
		
         try{
        	 
		//All Years Selected
        // By Default All selected in WorkItems
         
         //Select WorkItem option
         adminDashboardpage.clickSectiontoExportDropdown();
         adminDashboardpage.selectWorkItems_SectiontoExportDropdown();
         
           adminDashboardpage.clickExportCSV_SectiontoExport();
			Thread.sleep(5000);
			SoftAssert softassert = new SoftAssert();
			
			File getLatestFile = base.getLatestFilefromDir(Downloadpath);
		    String fileName1 = getLatestFile.getName();
			System.out.println("fileName1->"+fileName1);	
			// verifying whether the file  with fileName present in the directory downloadpath or not
			 softassert.assertTrue(isFileDownloaded(Downloadpath, fileName1), "Download Failed");
			//verifying whether the latest downloaded file contains "xlsx" extension or not and name of file having TransmissionsList word in it
			 softassert.assertTrue(fileName1.contains("csv") && fileName1.contains("AdminDashboard"),"It is not a CSV file");
			 
			 
			 
			 Thread.sleep(3000);
			 adminDashboardpage.clickExportPDF_SectiontoExport(); 
		     Thread.sleep(5000);
		     getLatestFile = base.getLatestFilefromDir(Downloadpath);
		     String fileName2 = getLatestFile.getName();
		 	System.out.println("fileName2->"+fileName2);
		     // verifying whether the file  with fileName present in the directory Downloadpath or not
		     softassert.assertTrue(isFileDownloaded(Downloadpath, fileName2), "Download Failed");
		     //verifying whether the latest downloaded file contains "PDF" extension or not and name of file having TransmissionsList word in it
		     softassert.assertTrue(fileName2.contains("pdf") && fileName2.contains("AdminDashboard"),"It is not a PDF file");
				 
			 
		  //Select Year in workitem
		     adminDashboardpage.clickYearsDropdown_WorkItems();
		     adminDashboardpage.selectYearDropdown_WorkItems();
		     
		     adminDashboardpage.clickExportCSV_SectiontoExport();
				Thread.sleep(5000);
				
				
				getLatestFile = base.getLatestFilefromDir(Downloadpath);
			    String fileName3 = getLatestFile.getName();
				System.out.println("fileName3->"+fileName3);
				// verifying whether the file  with fileName present in the directory downloadpath or not
				 softassert.assertTrue(isFileDownloaded(Downloadpath, fileName3), "Download Failed");
				//verifying whether the latest downloaded file contains "xlsx" extension or not and name of file having TransmissionsList word in it
				 softassert.assertTrue(fileName3.contains("csv") && fileName3.contains("AdminDashboard"),"It is not a CSV file");
				 
				 
				 
				 Thread.sleep(3000);
				 adminDashboardpage.clickExportPDF_SectiontoExport(); 
			     Thread.sleep(5000);
			     getLatestFile = base.getLatestFilefromDir(Downloadpath);
			     String fileName4 = getLatestFile.getName();
			 	 System.out.println("fileName4->"+fileName4);
			     // verifying whether the file  with fileName present in the directory Downloadpath or not
			     softassert.assertTrue(isFileDownloaded(Downloadpath, fileName4), "Download Failed");
			     //verifying whether the latest downloaded file contains "PDF" extension or not and name of file having TransmissionsList word in it
			     softassert.assertTrue(fileName4.contains("pdf") && fileName4.contains("AdminDashboard"),"It is not a PDF file");
					 
				 
		     
		     
		     
		     
			 
		  softassert.assertAll();
         
		  System.out.println("R_TC05_MainatainReasoncodes Passed");
	      //test.log(LogStatus.FAIL, "R_TC05_MainatainReasoncodes Passed"); 
				    
			}
				   
	    catch(Throwable e)
			{
	             System.out.println("R_TC05_MainatainReasoncodes Failed");
					  //test.log(LogStatus.FAIL, "R_TC05_MainatainReasoncodes Failed"); 
	             Assert.fail(e.getMessage());
						     
					 }
	
		}
		
}   