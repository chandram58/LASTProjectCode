package testRepository.GR.adminDashboard_GR;
import static org.testng.Assert.assertNotEquals;




import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import base.base;

public class R_TC_13_AdminDashboard extends base{
	@Test
	public void WorkItem_year() throws InterruptedException {
		
		Thread.sleep(10000);
		WebElement years=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//p-dropdown[contains(@placeholder,'Select Year')]//child::div[1]")));
		years.click();
		
		WebElement Selectyears=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(@aria-label,'2016')]")));
		Selectyears.click();
		
WebElement workitem1=driver.findElement(By.xpath("//td[contains(text(),'277CA')]//following::td[1]"));
Thread.sleep(5000);
String actual=workitem1.getText();
//System.out.println(actual);
WebElement deseletpfilter=driver.findElement(By.xpath("//button[contains(@label,'Apply Filter')]//span[1]"));
deseletpfilter.click();
Thread.sleep(5000);
WebElement year=new WebDriverWait(driver,20).until(ExpectedConditions.elementToBeClickable(By.xpath("//p-dropdown[contains(@placeholder,'Select Year')]//child::div[1]")));
year.click();

WebElement Selectyear=new WebDriverWait(driver,20).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'2017')]//parent::li")));
Selectyear.click();
Thread.sleep(5000);
WebElement workitem2=driver.findElement(By.xpath("//td[contains(text(),'277CA')]//following::td[1]"));
Thread.sleep(5000);
String expected=workitem2.getText();
//System.out.println(expected);
try
{
	assertNotEquals(expected,actual);
	
	System.out.println("TC13_AdminDashboard is passed");
}
catch(Exception e) {
	System.out.println(e);
	   System.out.println(e.getMessage());
	   System.out.println("TC13_AdminDashboard is Failed");
	   Assert.fail(e.getMessage());
	   
	}

		
		
	}

}
