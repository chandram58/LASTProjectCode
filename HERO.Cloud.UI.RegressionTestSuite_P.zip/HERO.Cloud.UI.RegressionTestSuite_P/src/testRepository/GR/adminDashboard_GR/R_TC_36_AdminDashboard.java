package testRepository.GR.adminDashboard_GR;


import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.AdminDashboardPage;
import pages.HomePage;
import base.base;

public class R_TC_36_AdminDashboard extends base{
	@Test
	public void AgeningReport() throws InterruptedException {
		 HomePage homePageObj=new HomePage();
		 homePageObj.mouseHoverDashboard();
	 	 homePageObj.openModule("Admin Dashboard");
	 	 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
		Thread.sleep(5000);
		try
		{
				
		adminDashboardpage.clickAgingTab();
		String Tabtext=adminDashboardpage.getAgingTabText();
		System.out.println("Tabtext->"+Tabtext);
		SoftAssert softassert = new SoftAssert();
		softassert.assertTrue(Tabtext.equalsIgnoreCase("aging") ,"Tab Text not correct");
		softassert.assertAll();
	
	System.out.println("TC46_AdminDashboard is passed");
}
catch(Exception e) {
	System.out.println(e);
	   System.out.println(e.getMessage());
	   System.out.println("TC46_AdminDashboard is passed");
	}
		
	}

}

