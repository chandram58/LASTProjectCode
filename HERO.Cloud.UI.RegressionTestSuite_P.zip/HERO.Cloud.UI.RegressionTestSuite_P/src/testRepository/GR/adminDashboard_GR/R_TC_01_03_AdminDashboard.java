package testRepository.GR.adminDashboard_GR;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.AdminDashboardPage;
import pages.HomePage;

public class R_TC_01_03_AdminDashboard extends base{
	@Test
	public void getselectTPFunct() throws InterruptedException {
		 HomePage homePageObj=new HomePage();

	      homePageObj.mouseHoverDashboard();
	 	  homePageObj.openModule("Admin Dashboard");
	 	 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
	 	adminDashboardpage.clickonTPfield().click();
	 String 	allTPs=adminDashboardpage.clickonCheckboxinSearchTP().getAttribute("class");
	 System.out.println(allTPs);
	 
	 //tc01
	 
	 adminDashboardpage.clickonEmptyspace();
	 adminDashboardpage.clickonTPfield().click();
	 Thread.sleep(2000);
	 adminDashboardpage.clickonCheckboxinSearchTP().click();
	 adminDashboardpage.getTPfromDPs("1").click();
	 String TP1= adminDashboardpage.getTPfromDPs("1").getText();
	 System.out.println(TP1);
	 adminDashboardpage.getTPfromDPs("2").click();
	 String TP2= adminDashboardpage.getTPfromDPs("2").getText();
	 System.out.println(TP2);
	 adminDashboardpage.clickonEmptyspace();
	 String 	selectedTPs= adminDashboardpage.clickonTPfield().getText();
	 System.out.println(selectedTPs);
	 try {
		  SoftAssert softAssert = new SoftAssert();   
		  softAssert.assertTrue(allTPs.contains("p-highlight"), "all partners not selected");
			 softAssert.assertTrue(selectedTPs.contains(TP1), "partner not selected");
			 softAssert.assertTrue(selectedTPs.contains(TP2), "partner not selected");
			 softAssert.assertAll();
			 System.out.println("TC01_03_AdminDashboard is passed");
	  }
	  catch(Throwable e)
	    {
				   
				   System.out.println("TC01_03_AdminDashboard is failed");
				   Assert.fail(e.getMessage());
				   
	    }
	}

}
