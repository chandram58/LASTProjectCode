package testRepository.GR.adminDashboard_GR;


import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.AdminDashboardPage;
import pages.HomePage;
import base.base;

public class R_TC_33_AdminDashboard extends base{
	@Test
	public void ActivityState_Hyperlink() throws InterruptedException {
		
		Thread.sleep(5000);
		 HomePage homePageObj=new HomePage();
		 homePageObj.mouseHoverDashboard();
	 	 homePageObj.openModule("Admin Dashboard");
	 	 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
	 	try
		{
	     adminDashboardpage.clickActivityStateValueLink();
	     String breadCrumb=adminDashboardpage.getBreadcrumbSearchResultPage();
	     System.out.println("breadCrumb->"+breadCrumb);
	    
	     SoftAssert softassert = new SoftAssert();
	 	softassert.assertTrue(breadCrumb.contains("Home")&& breadCrumb.contains("Admin Dashboard") && breadCrumb.contains("Result for Direct Search - ACTIVITY STATE / AGING") ,"Link not navigating to proper page");
	     softassert.assertAll();
		
		
		System.out.println("TC43_AdminDashboard is passed");
	 }
	    catch(Exception e) {
		System.out.println(e);
		   System.out.println(e.getMessage());
		   System.out.println("TC43_AdminDashboard is Failed");
		   Assert.fail(e.getMessage());
		   
		}
		
	}

}
