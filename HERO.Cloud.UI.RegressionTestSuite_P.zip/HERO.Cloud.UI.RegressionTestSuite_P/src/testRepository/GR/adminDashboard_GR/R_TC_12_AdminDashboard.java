package testRepository.GR.adminDashboard_GR;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.AdminDashboardPage;
import pages.HomePage;

public class R_TC_12_AdminDashboard extends base{
	@Test
	public void getTodaylabelfunctionlity() throws InterruptedException {
		Thread.sleep(10000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("Admin Dashboard");
		 Thread.sleep(3000);
		AdminDashboardPage adminDashboardobj=new AdminDashboardPage();
		WebElement dateincalender=adminDashboardobj.clickonCalender();
		String SelctDate="09/02/2018";
	  base.selectDateFromDatePicker(SelctDate);
	String calednderdate=  dateincalender.getText();
	System.out.println(calednderdate);
	  adminDashboardobj.clickonFilterbtn();
	  
	 String workitemlabel= adminDashboardobj.gettodaylabelfromWorkitemSection().getText();
	 System.out.println(workitemlabel);
	String acktodaylabel= adminDashboardobj.gettodaylabelfromAcknoweldgementSection().getText();
	System.out.println(acktodaylabel);
	String outbountlabel=adminDashboardobj.gettodaylabelfromoutboundSection().getText();
	System.out.println(outbountlabel);
	
	try {
		 SoftAssert softAssert = new SoftAssert();
         softAssert.assertTrue(SelctDate.equals(workitemlabel),"workitem section today labelnot replaced with selecteddate");
         softAssert.assertTrue(SelctDate.equals(acktodaylabel),"Ack section today labelnot replaced with selecteddate");
         softAssert.assertTrue(SelctDate.equals(outbountlabel),"Outbound section today labelnot replaced with selecteddate");
         softAssert.assertAll();
         System.out.println("TC_28_admindashboard is passed");
	}
	catch(Throwable e)
    {


	   System.out.println("TC_28_admindashboard is failed");
	
		  Assert.fail(e.getMessage());	
    }	
	}

}
