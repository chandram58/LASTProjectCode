package testRepository.GR.adminDashboard_GR;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.AdminDashboardPage;
import pages.HomePage;

public class G_TC_07_AdminDashboard extends base{
	@Test
	public void getasofdatefunctionlityforhyperlink() throws InterruptedException {
		 HomePage homePageObj=new HomePage();

	     homePageObj.mouseHoverDashboard();
		  homePageObj.openModule("Admin Dashboard");
		  
		 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
		 AdminDashboardPage.clickonHeropa();
		String  asofDate= adminDashboardpage.clickonAsofDatefield().getText();
		System.out.println("asofDate "+ asofDate);
	Thread.sleep(2000);
		// Create object of SimpleDateFormat class and decide the format
		 DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
		 
		 //get current date time with Date()
		 Date date = new Date();
		 
		 // Now format the date
		 String date1= dateFormat.format(date);
		 
		 // Print the Date
		 System.out.println(date1);
	
		 Thread.sleep(3000);
			WebElement hyperlinena=	 adminDashboardpage.gethyperlinkenablingasperDate();
	String hyperlinena1=	 adminDashboardpage.gethyperlinkenablingasperDate().getAttribute("class"); 
	System.out.println(hyperlinena1);
	 try {
		  SoftAssert softAssert = new SoftAssert();   
		 
			 softAssert.assertTrue(hyperlinena.isEnabled(), "hyperlink is not enabled");
			 
			 softAssert.assertAll();
			 System.out.println("TC07_AdminDashboard is passed");
	  }
	  catch(Throwable e)
	    {
				   
				   System.out.println("TC07_AdminDashboard is failed");
				   Assert.fail(e.getMessage());
				   
	    }
		 
	}

}
