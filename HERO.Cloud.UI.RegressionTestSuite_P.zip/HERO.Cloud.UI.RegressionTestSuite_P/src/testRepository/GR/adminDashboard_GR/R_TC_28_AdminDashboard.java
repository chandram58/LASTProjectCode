package testRepository.GR.adminDashboard_GR;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.AdminDashboardPage;
import pages.HomePage;

import com.relevantcodes.extentreports.LogStatus;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import base.base;
import utilities.xlUtils;

public class R_TC_28_AdminDashboard extends base{
	
	@Test
	public void Rule_Hits_TopHits_hyperlinks() throws InterruptedException, IOException {
		
		
		Thread.sleep(5000);
		 HomePage homePageObj=new HomePage();
		 homePageObj.mouseHoverDashboard();
	 	 homePageObj.openModule("Admin Dashboard");
	 	 AdminDashboardPage  adminDashboardpage=new AdminDashboardPage();
	 	try
		{
	     adminDashboardpage.clickTopHitsValueLink();
	     String breadCrumb=adminDashboardpage.getBreadcrumbSearchResultPage();
	     System.out.println("breadCrumb->"+breadCrumb);
	    
	     SoftAssert softassert = new SoftAssert();
	 	softassert.assertTrue(breadCrumb.contains("Home")&& breadCrumb.contains("Admin Dashboard") && breadCrumb.contains("Result for Direct Search - RULE HITS") ,"Link not navigating to proper page");
	     softassert.assertAll();
	     System.out.println("TC28_AdminDashboard is passed");
		}
	
		catch(Exception e) {
			System.out.println(e);
			   System.out.println(e.getMessage());
			   System.out.println("TC28_AdminDashboard is Failed");
			   Assert.fail(e.getMessage());
			   
			}
				
		
	}
}
	


