package testRepository.GR.roleManagement_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;

import pages.HomePage;
import pages.RolesManagementPage;
import com.relevantcodes.extentreports.LogStatus;

public class R_TC_25_roleManagement extends base
{
	
		@Test
		public void VerifyCancelButtonFunctionalityUpdateRolePage() throws IOException, InterruptedException
		{
			RolesManagementPage rolesManagementPageObt=new RolesManagementPage(); 
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			homePageObj.openModule("Roles Management");
			Thread.sleep(2000);
			rolesManagementPageObt.clickEditButtonMainPage();
			Thread.sleep(2000);
			
			//getting Title of Update Role Page
			String Title1=rolesManagementPageObt.getTitle_UpdateRole();
			
			//Clicking on Cancel button on update Role Page
			rolesManagementPageObt.clickCancel_UpdateRole();
			Thread.sleep(2000);
		     
			//Getting Title of Page after clicking CanCelButton
			String Title2=rolesManagementPageObt.getTitle_MainPage();
			
			try
			 {
	        SoftAssert softassert = new SoftAssert();
	        softassert.assertTrue(Title1.equalsIgnoreCase("update role") && Title2.equalsIgnoreCase("roles management"),"Cancel button not working properly");
			softassert.assertAll();
		
			System.out.println("R_TC_25_roleManagement Passed");
           //  test.log(LogStatus.PASS, "TC047_roleManagement Passed");    
		        }
				   
	    catch(Throwable e)
	       {
	    	System.out.println("R_TC_25_roleManagement Failed");
			// test.log(LogStatus.FAIL, "R_TC_25_roleManagement Failed"); 
            Assert.fail(e.getMessage());
		    }
	    }
}
