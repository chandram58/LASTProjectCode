package testRepository.GR.roleManagement_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.RolesManagementPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class G_TC_03_roleManagement extends base
{
	
		@Test
		public void VerifySearchRoleFunctionality() throws IOException, InterruptedException
		{
	         Thread.sleep(10000);
			 HomePage homePageObj=new HomePage();
			 homePageObj.mouseHoverAdministration();	
			 Thread.sleep(3000);
			 homePageObj.openModule("Roles Management");
			 RolesManagementPage rolesManagementPage=new RolesManagementPage();	
			 String searchTerm="automation";
			 rolesManagementPage.getSearchboxinmain(searchTerm);
			 List<WebElement> serachResult_rows=rolesManagementPage.getSearchResult();
			 System.out.println("Number of rows in SearchResult->"+serachResult_rows.size());
		       
		       System.out.println(serachResult_rows.get(0).getText());
		        
		       System.out.println(serachResult_rows.get(0).getText().replace("\n", " ").toLowerCase());
		       
		   //     List<String> format_SearchResultRow=serachResult_rows.toString().replace("\n", " ").toLowerCase();
				  
				 
		    try{  
		   
				
		       SoftAssert softAssert = new SoftAssert();
		        for(int i=0;i<serachResult_rows.size();i++)
		      {
		    	  System.out.println(serachResult_rows.get(i).getText().replace("\n", " ").toLowerCase());
		    	  softAssert.assertTrue(serachResult_rows.get(i).getText().replace("\n", " ").toLowerCase().contains(searchTerm),"row no "+i+"not contains search term");   
		      }
			 
	          softAssert.assertAll();
	          System.out.println("G_TC_03_RoleManagement Passed");
		      }
		    catch(Throwable e)
			  {
		    	System.out.println("G_TC_03_RoleManagement Failed");
			//test.log(LogStatus.FAIL, "G_TC_03_RoleManagement Failed"); 

						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

