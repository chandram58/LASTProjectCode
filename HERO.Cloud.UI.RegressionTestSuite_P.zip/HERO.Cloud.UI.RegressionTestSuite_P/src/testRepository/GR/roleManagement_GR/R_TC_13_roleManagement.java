package testRepository.GR.roleManagement_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.RolesManagementPage;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC_13_roleManagement extends base
{
	@Test
		public void VerifyScreenFieldsFriendlyUI() throws IOException, InterruptedException
		{
		
			RolesManagementPage rolesManagementPageObt=new RolesManagementPage(); 
			HomePage homePageObj=new HomePage();
        	homePageObj.mouseHoverAdministration();	
        	
       	    Thread.sleep(3000);
			homePageObj.openModule("Roles Management");
			Thread.sleep(1000);
			rolesManagementPageObt.clickAddNewRole();
			 Thread.sleep(3000);
			//rolesManagementPageObt.clickSave_AddNewRole();
			rolesManagementPageObt.clickSelectScreensDropDown();
			
			rolesManagementPageObt.selectScreen("Friendly UI-Inst");
			Thread.sleep(1000);
			//rolesManagementPageObt.clickNewRoleTitle();
			Thread.sleep(1000);
			rolesManagementPageObt.clickExpandIcon_Row1();
			Thread.sleep(1000);
			List<String> Actualoptions=new ArrayList<String>();			
			 Actualoptions=	rolesManagementPageObt.getFieldsListDisplayed();
			
			
			 List<String> Expectedoptions=new ArrayList<String>(Arrays.asList("835 View", "837 View", "Balancing Dashboard Section", "Billing Provider Section", "Cancel", "Claims Section", "Complete", "Encounter Version History", "Error Section", "Escalate", "Friendly UI Business View", "History Section", "Notes Section", "Override", "Pend", "Reload", "Return To Escalate Queue", "Return To User", "Revert", "Search Business View", "Send To Contract Owner", "Service Line Section", "Stop", "Validate", "X12 View"));
					   
			 System.out.println("Expectedoptions List Size="+Expectedoptions.size()); 
			 	
			  Collections.sort(Actualoptions);
				  
			  Collections.sort(Expectedoptions);
			 System.out.println("Actual List->"+Actualoptions);
			 System.out.println("Expected List->"+Expectedoptions);
	
			
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
				
			    softassert.assertEquals(Actualoptions, Expectedoptions,"Options not matching");
			    
			    
			    softassert.assertAll();
				 
				    System.out.println("R_TC_13_roleManagement Passed");
			}
				   
	    catch(Throwable e)
				     {
				/*	   System.out.println("R_TC_13_roleManagement Failed");
					   
					//  test.log(LogStatus.FAIL, "R_TC_13_roleManagement Failed"); 

				            Assert.fail(e.getMessage());
						     
					  */  printFailure("R_TC_13_roleManagement",e);      
				      }
        	}
	}
