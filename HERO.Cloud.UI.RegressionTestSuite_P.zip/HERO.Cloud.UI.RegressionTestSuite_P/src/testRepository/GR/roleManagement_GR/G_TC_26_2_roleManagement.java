package testRepository.GR.roleManagement_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.RolesManagementPage;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class G_TC_26_2_roleManagement extends base
{
	
		@Test
		public void VerifyCopyButtonActiveInactiveUsers() throws IOException, InterruptedException
		{
			Thread.sleep(10000);
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Roles Management");
			RolesManagementPage rolesManagementPage=new RolesManagementPage();	
			Thread.sleep(2000);
			int totalRows=rolesManagementPage.getNumberofRowsUIMaintbl();   
			 
			 //Get Role Name from where Copy button is Clicked for Active user
			 String activeroleMainTbl=rolesManagementPage.getRolenameInactiveListMainTbl(1);
			 System.out.println("activeroleMainTbl->"+activeroleMainTbl);
			
			 try{
			// click Copy Button
			 rolesManagementPage.clickCopyIcon(1);
			 
			   //Getting Title,Rolename 
			 String PageTitle_active=rolesManagementPage.getTitleCopyPage();
			 System.out.println("PageTitle_active->"+PageTitle_active);
			 
		    String RolePrepoulatedCopyPage_Active=rolesManagementPage.getRoleName_UpdateRolePage();
		    System.out.println("Prepopulated Role name on Copy page->"+RolePrepoulatedCopyPage_Active);		  
				
			SoftAssert softassert = new SoftAssert();
		    softassert.assertTrue(PageTitle_active.toLowerCase().contains("new role"), "Copy page is not opening"); 
		    softassert.assertTrue(RolePrepoulatedCopyPage_Active.equals("Copy of "+activeroleMainTbl), "Incorrect copy Button is getting Clicked"); 
	
		    
		    
		    //Click on Cancel Button
		    rolesManagementPage.clickCancel_UpdateRole();
		    
		    
		    //Get Role Name from where Copy button is Clicked for inactive user
			 String inactiveroleMainTbl=rolesManagementPage.getRolenameInactiveListMainTbl(totalRows);
			 System.out.println("inactiveroleMainTbl->"+inactiveroleMainTbl);
			
			
			// click Copy Button
			 rolesManagementPage.clickCopyIcon(totalRows);
			 
			 
			   //Getting Title,Rolename 
			 String PageTitle_inactive=rolesManagementPage.getTitleCopyPage();
			 System.out.println("PageTitle_inactive->"+PageTitle_inactive);
			 
		    String RolePrepoulatedCopyPage_Inactive=rolesManagementPage.getRoleName_UpdateRolePage();
		    System.out.println("Prepopulated Role name on Copy page->"+RolePrepoulatedCopyPage_Inactive);		  
				
		
		    softassert.assertTrue(PageTitle_inactive.toLowerCase().contains("new role"), "Copy page is not opening"); 
		    softassert.assertTrue(RolePrepoulatedCopyPage_Inactive.equals(inactiveroleMainTbl), "Incorrect Copy Button is getting Clicked"); 
	
		    
		   softassert.assertAll();
		   System.out.println("G_TC_26_2_roleManagement Passed");
				 
	}
				   
	    catch(Throwable e)
		{
		System.out.println("G_TC_26_2_roleManagement Failed");
    //  test.log(LogStatus.FAIL, "G_TC_26_2_roleManagement Failed"); 
		Assert.fail(e.getMessage());
						     
		}
	}
}
