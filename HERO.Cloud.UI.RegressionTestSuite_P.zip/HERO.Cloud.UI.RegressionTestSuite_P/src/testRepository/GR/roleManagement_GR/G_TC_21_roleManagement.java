package testRepository.GR.roleManagement_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.RolesManagementPage;

import com.relevantcodes.extentreports.LogStatus;

public class G_TC_21_roleManagement extends base
{
		@Test
		public void UpdateEndDateExistingRoles() throws IOException, InterruptedException
		{
			
	  
			 RolesManagementPage rolesManagementPageObt=new RolesManagementPage(); 
				HomePage homePageObj=new HomePage();
				homePageObj.mouseHoverAdministration();	
				homePageObj.openModule("Roles Management");
				
				Thread.sleep(5000);
				rolesManagementPageObt.clickEditButtonMainPage();
				Thread.sleep(2000);
				
				String role_Edited=rolesManagementPageObt.getRoleName_UpdateRolePage();
				rolesManagementPageObt.clickRoleEndDate();
				rolesManagementPageObt.getUpdateEndate();
				Thread.sleep(6000);
				String NewEndDate="09-20-9356";
				 selectDateFromDatePicker(NewEndDate);
				 rolesManagementPageObt.clickonAcceptbtn();
				 
				 Thread.sleep(2000);
				 rolesManagementPageObt.clickonSaveupdate();
				 Thread.sleep(2000);

				 String Message=rolesManagementPageObt.getRoleUpdateSuccessMessage();
				 System.out.println("Message->"+Message);
	
				


			    try
			    {
			    SoftAssert softassert = new SoftAssert();
			    softassert.assertTrue(Message.contains("role has been updated successfully"), "User details not updated"); 
			   softassert.assertAll();
				 System.out.println("G_TC_21_roleManagement Passed");
				   //  test.log(LogStatus.PASS, "G_TC_21_roleManagement Passed");   
				
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("G_TC_21_roleManagement Failed");
					   //  test.log(LogStatus.FAIL, "G_TC_21_roleManagement Failed"); 
					Assert.fail(e.getMessage());
				     
					   
				      }
	
		      }
	
		}

