package testRepository.GR.roleManagement_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.RolesManagementPage;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class G_TC_26_1_roleManagement extends base
{
	   @Test
		public void VerifyViewButtonInactiveUsers() throws IOException, InterruptedException
		{ 
			
	     Thread.sleep(10000);
		 HomePage homePageObj=new HomePage();
		 homePageObj.mouseHoverAdministration();	
		 Thread.sleep(3000);
		 homePageObj.openModule("Roles Management");
		 RolesManagementPage rolesManagementPage=new RolesManagementPage();	
		 
		 Thread.sleep(2000);
		 int totalRows=rolesManagementPage.getNumberofRowsUIMaintbl();
		
		 //Get Role Name from where View button is Clicked
		 String InactiveroleMainTbl=rolesManagementPage.getRolenameInactiveListMainTbl(totalRows);
		 System.out.println("InactiveroleMainTbl->"+InactiveroleMainTbl);
		 
		// click View Button
		 rolesManagementPage.clickViewIconInactiveList(totalRows);
		 
		 //Getting role name 
		 String RoleNamePrepoulatedViewPage=rolesManagementPage.getRolenameViewPage();
		 System.out.println("Prepopulated Role name on View page->"+RoleNamePrepoulatedViewPage);
		 
		//Getting page Title after clicking view button
		  String Title=rolesManagementPage.getTitleViewPage();
		  System.out.println("Title->"+Title);
		  
		 //Getting Diasble chk flg
		 String disableFlag=rolesManagementPage.getDisableFlagViewPage();
		 System.out.println("disableFlag->"+disableFlag);
		 try
		 {
			 SoftAssert softassert = new SoftAssert();
			 softassert.assertTrue(Title.toLowerCase().contains("view role"), "view page is not opening"); 
			 softassert.assertTrue(RoleNamePrepoulatedViewPage.equals(InactiveroleMainTbl), "Incorrect View Button is getting Clicked"); 
			 softassert.assertTrue(disableFlag.equals("true"), "RoleNameField is not disabled"); 
			 softassert.assertAll();
				 
			 System.out.println("G_TC_26_1_roleManagement Passed");
			   
			}
				   
	    catch(Throwable e)
		   {
	    	System.out.println("G_TC_26_1_roleManagement Failed");
		//  test.log(LogStatus.FAIL, "G_TC_26_1_roleManagement Failed"); 
            Assert.fail(e.getMessage());
						     }
	            }
       }
