package testRepository.GR.roleManagement_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.RolesManagementPage;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC_29_roleManagement extends base
{
		@Test
		public void endDateGreaterThanStartDate() throws IOException, InterruptedException
		{
			
	  
			 RolesManagementPage rolesManagementPageObt=new RolesManagementPage(); 
				HomePage homePageObj=new HomePage();
				homePageObj.mouseHoverAdministration();	
				homePageObj.openModule("Roles Management");
				
				Thread.sleep(2000);
				rolesManagementPageObt.getSearchboxinmain("Testautomation");
				Thread.sleep(2000);
				rolesManagementPageObt.clickEditButtonMainPage();
				Thread.sleep(2000);
				
				String role_Edited=rolesManagementPageObt.getRoleName_UpdateRolePage();
				rolesManagementPageObt.clickTodayDate_RoleEndDate_UpdateRole();
				//Click Today link in Role End Date
				
				
				//rolesManagementPageObt.getUpdateEndate();
			/*	Thread.sleep(6000);
				String NewRoleEndDate="09-20-9356";
				 selectDateFromDatePicker(NewRoleEndDate);
				
				 rolesManagementPageObt.clickonDeclinebtn();
				 Thread.sleep(6000);
				 rolesManagementPageObt.clickPermissionEndDate();
				 String NewpermissionEndDate="12-20-9999";
				 selectDateFromDatePicker(NewpermissionEndDate);
				*/
				 String ErrorMessage=rolesManagementPageObt.getErrorMsgEndDateGreaterthanStartDate();
				 System.out.println("Message->"+ErrorMessage);
	
				


			    try
			    {
			    SoftAssert softassert = new SoftAssert();
			    softassert.assertTrue(ErrorMessage.contains("End date should be greater than Start Date"), "Incorrect Error Message"); 
			   softassert.assertAll();
				 System.out.println("R_TC_29_roleManagement Passed");
				   //  test.log(LogStatus.PASS, "R_TC_29_roleManagement Passed");   
				
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("R_TC_29_roleManagement Failed");
					   //  test.log(LogStatus.FAIL, "R_TC_29_roleManagement Failed"); 
					 Assert.fail(e.getMessage());
				     
					   
				      }
	    }
}

