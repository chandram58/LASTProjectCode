package testRepository.GR.roleManagement_GR;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;
import pages.HomePage;
import pages.QueuesAssignmentPage;
import pages.RolesManagementPage;

public class R_TC_04_roleManagement extends base
{
	@Test
		public void BreadCrumbValidationRoleManagementPage() throws IOException
		{
		
			try {

			RolesManagementPage rolesManagementPageObt=new RolesManagementPage(); 
	 		HomePage homePageObj=new HomePage();

	 	
	 		homePageObj.mouseHoverAdministration();	
	 		homePageObj.openModule("Roles Management");

			Thread.sleep(1000);
			
			String breadcrumbTitle=rolesManagementPageObt.getBreadCrumbTitle();
			
			System.out.println(breadcrumbTitle.toLowerCase());

			//String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Roles Management')]")).getText();
			 
			
           SoftAssert softAssert = new SoftAssert();
		     
		  //   test.log(LogStatus.INFO ,"Verifying page Title");
		     
	    softAssert.assertTrue(breadcrumbTitle.toLowerCase().contains("roles management") && breadcrumbTitle.toLowerCase().contains("home") && breadcrumbTitle.toLowerCase().contains("administration"), "This is not Role Management page");
		     
		    
		     
		      softAssert.assertAll();
		      
		      System.out.println("R_TC_04_roleManagement Passed");
		      
		 //     test.log(LogStatus.PASS, "TC002_roleManagement Passed"); 
			}
				   
	    catch(Throwable e)
				     {
				/*	   System.out.println("TC002_roleManagement Failed");
					   
					  test.log(LogStatus.FAIL, "TC002_roleManagement Failed"); 
					   Assert.fail(e.getMessage());
						     
					   */  
	    	printFailure("TC002_roleManagement",e);   
				      
				     }
			}
	}
