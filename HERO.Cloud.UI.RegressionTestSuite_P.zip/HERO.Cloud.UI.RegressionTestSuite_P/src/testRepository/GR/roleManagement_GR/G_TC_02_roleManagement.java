package testRepository.GR.roleManagement_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.RolesManagementPage;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class G_TC_02_roleManagement extends base
{
		@Test
		public void VerifyNewRoleCreationFunctionality() throws IOException, InterruptedException
		{
			 Thread.sleep(10000);
			 HomePage homePageObj=new HomePage();
			 homePageObj.mouseHoverAdministration();	
			 Thread.sleep(3000);
			 homePageObj.openModule("Roles Management");
			 RolesManagementPage rolesManagementPage=new RolesManagementPage();	
			 
			 try
			  {
			 rolesManagementPage.clickAddNewRole();
			 Thread.sleep(2000);
			
			 String roleEntered=getAlphaNumericString(20);
			 rolesManagementPage.getRoleNameinAddrole(roleEntered);
			 rolesManagementPage.getDescriptioninnewrole(roleEntered);
			
			 rolesManagementPage.clickSelectScreensDropDown();
			 rolesManagementPage.selectScreen("User Landing Page");
		    
			 //click on Save button on New Role Page
			 rolesManagementPage.clickSave_AddNewRole();
	      
			 String Message=rolesManagementPage.getSuccessfulRoleCreationMsg();
			 System.out.println("Message on Screen->"+Message);
			 Thread.sleep(5000);
			 //Getting active role List
			 List<String> ActiveRoleList_UI=rolesManagementPage.getListActiveRolesUIMainTbl();
			 System.out.println("ActiveRoleList_UI->"+ActiveRoleList_UI);
			
			    SoftAssert softassert = new SoftAssert();
			    softassert.assertTrue(Message.contains("role has been created successfully"),"Incorrect message"); 
			    softassert.assertTrue(ActiveRoleList_UI.contains(roleEntered.toLowerCase()),"Created Role not present in main table");
				softassert.assertAll();
				 
				    System.out.println("G_TC_02_roleManagement Passed");
				    
	}
				   
	    catch(Throwable e)
				     {
	    	
					   System.out.println("G_TC_02_roleManagement Failed");
					//  test.log(LogStatus.FAIL, "G_TC_02_roleManagement Failed"); 

				       Assert.fail(e.getMessage());
						     
					   
				      }
           }
}
