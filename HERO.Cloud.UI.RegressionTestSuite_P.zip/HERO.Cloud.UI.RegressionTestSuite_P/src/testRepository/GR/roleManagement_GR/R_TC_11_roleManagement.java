package testRepository.GR.roleManagement_GR;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.RolesManagementPage;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_11_roleManagement extends base
{
	@Test
		public void MandatoryFieldValidationNewRole() throws IOException, InterruptedException
		{
		
			 Thread.sleep(10000);
			 HomePage homePageObj=new HomePage();
			 homePageObj.mouseHoverAdministration();	
			 Thread.sleep(3000);
			 homePageObj.openModule("Roles Management");
			 RolesManagementPage rolesManagementPage=new RolesManagementPage();	
			 
			 try
			    {
			 rolesManagementPage.clickAddNewRole();
			 Thread.sleep(2000);
			 rolesManagementPage.clickSave_AddNewRole();
			 
			 String DescriptionValidationMessage=rolesManagementPage.getErrorMsg_description();
			 System.out.println(DescriptionValidationMessage);
			 
			 String RoleNameValidationMessage=rolesManagementPage.getErrorMsg_roleName();
		     System.out.println(RoleNameValidationMessage);
			  
		     String PermissionValidationMessage=rolesManagementPage.getErrorMsg_permission();
		     System.out.println(PermissionValidationMessage);
	           
		        SoftAssert softassert = new SoftAssert();
			    softassert.assertFalse(RoleNameValidationMessage.isEmpty(), "Validation message not Populated");
			    softassert.assertTrue((RoleNameValidationMessage.toLowerCase()).equals("role name is required."), "Validation message not coming properly");
			    
			    softassert.assertFalse(DescriptionValidationMessage.isEmpty(), "Validation message not Populated");
			    softassert.assertTrue((DescriptionValidationMessage.toLowerCase()).equals("description is required."), "Validation message not coming properly");
			    
			    softassert.assertFalse(PermissionValidationMessage.isEmpty(), "Validation message not Populated");
			    softassert.assertTrue((PermissionValidationMessage.toLowerCase()).equals("screen is required"), "Validation message not coming properly");
			    softassert.assertAll();
				 
				System.out.println("R_TC_11_userProfile Passed");
				    }
		
			 catch(Throwable e)
				 {
				 System.out.println("R_TC_11_userProfile Failed");
		         //test.log(LogStatus.FAIL, "R_TC_11_userProfile Failed"); 
			Assert.fail(e.getMessage());
		         }
	
	      }
	}
