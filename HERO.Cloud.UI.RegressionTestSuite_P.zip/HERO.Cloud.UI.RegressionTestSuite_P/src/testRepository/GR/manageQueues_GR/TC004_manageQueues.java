package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC004_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifySearchValidQueueFunctionality() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=4;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				 WebElement Searchwordbox= driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[1]/div/div[2]/div/div/input"));
					
				  Searchwordbox.sendKeys("XYZ");
				   
				  Thread.sleep(5000);
		
		        List<WebElement> serachResult_rows=driver.findElements(By.xpath("//app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody/tr"));
			  
		       System.out.println("No of Search Result->"+serachResult_rows.size());
		       
		       System.out.println(serachResult_rows.get(0).getText().trim());
		        
		  //     System.out.println(serachResult_rows.get(0).getText().replace("\n", " ").toLowerCase());
		       
		   //     List<String> format_SearchResultRow=serachResult_rows.toString().replace("\n", " ").toLowerCase();
				  
				 
		    try{  
		   
				
		       SoftAssert softAssert = new SoftAssert();
		       
		      for(i=0;i<serachResult_rows.size();i++)
		      {
		    	  System.out.println(serachResult_rows.get(i).getText().replace("\n", " ").toLowerCase());

		    	  softAssert.assertTrue(serachResult_rows.get(i).getText().replace("\n", " ").toLowerCase().contains("no records found"),"Records are present for search Term");   
		      }
			 
			
		            softAssert.assertAll();
			
				 
			      System.out.println("TC004_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC004_groupManagement Failed");
					   
					  //test.log(LogStatus.FAIL, "TC004_groupManagement Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

