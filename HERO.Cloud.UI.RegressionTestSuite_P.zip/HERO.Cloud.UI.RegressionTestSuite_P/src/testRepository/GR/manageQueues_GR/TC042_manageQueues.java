package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC042_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void EditableFieldonNewQueuePage() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=42;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				WebElement AddNewQueue=driver.findElement(By.xpath("//span[contains(text(),'Add New Queue')]"));
				
				AddNewQueue.click();
				
				String pageTitle=driver.findElement(By.xpath("//h3[contains(text(),'New Queue')]")).getText();
			
				System.out.println("Page opened  upon clicking Add New Queue button->"+pageTitle);
				
			 WebElement Queuename=driver.findElement(By.xpath("//input[@id='newManangeQueue']"));
			
			 WebElement Description=driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[4]/textarea"));
			
			 Queuename.sendKeys("Queue Name");	
			
			 Description.sendKeys("Queue Description");
			
			 System.out.println("Entered value for Queuename->"+Queuename.getAttribute("value"));
			
			 System.out.println("Entered value for Description->"+Description.getAttribute("value"));
			
	 try{  
		   
				
	SoftAssert softAssert = new SoftAssert();
		       
   softAssert.assertFalse((Queuename.getAttribute("value")).isEmpty(),"User not able to enter text in Queuename Field");
   
   softAssert.assertFalse((Description.getAttribute("value")).isEmpty(),"User not able to enter text in Description Field");
   
    softAssert.assertAll();

    System.out.println("TC042_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC042_manageQueues Failed");
					   
					  //test.log(LogStatus.FAIL, "TC042_manageQueues Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
	
	
	
	
	
	
	

