package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC032_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void EditSaveFunctionality() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=32;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
	
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody")));
				
			
				

				WebElement webtable=driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody"));
			     
			     List<WebElement> rows;
			     List<WebElement> cols = null;
			     List<String> AttributeList = new ArrayList<String>();
		
			    
			     WebElement EditAction;
			  	System.out.println("3");
			     
			     rows=webtable.findElements(By.tagName("tr"));
			     
			    System.out.println("No of rows on Manage Queues table->"+ rows.size());
              
			    int j;
			  
				 
				for(j=0;j<rows.size();j++) 
				   {
						cols=rows.get(j).findElements(By.tagName("td"));
						
						if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
					     { 
					       System.out.println(j);
					       
					       break;
							
					     }
				   }
				System.out.println("Active row starts from row no->"+(j+1));
				
				
			 String xpathexpEdit="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[2]/i[1]";
		   
					      
					      
		          EditAction=driver.findElement(By.xpath(xpathexpEdit));
				 
					
				  //Clicking on Edit Button
				  
		          EditAction.click();
				  
				  Thread.sleep(3000);
				  
				  String PageTitle=driver.findElement(By.xpath("//h3[contains(text(),'Update Queue')]")).getText();
				  System.out.println("Title of page opened on clicking on Edit icon->"+PageTitle);
				  
				 
				  
				  //Changing End Date 
				  
				  WebElement EndDate=driver.findElement(By.xpath("//*[@id='updateManageQueueEndDate']/span/input"));
				  
				  EndDate.click();
				  
				  //Selecting date on calendar
				  
				  driver.findElement(By.xpath("//tbody/tr[5]/td[5]/a[1]")).click();//selects 12/30/9999
				  
				  System.out.println("Updated End date is->"+EndDate.getAttribute("value")); 
				  
				  
				 //Clicking on Save button
				  
				driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[2]/div/div/button[1]")).click();
				
				driver.switchTo().defaultContent();
				
				Thread.sleep(2000);
				  
				String Message=driver.findElement(By.xpath("//div[contains(text(),'Queue has been updated successfully')]")).getText();
			
				System.out.println(Message);
			      
	 try{  
		   
				
	SoftAssert softAssert = new SoftAssert();
		       
   softAssert.assertTrue(PageTitle.contains("Update Queue") , "Upon clicking Edit button incorrect page is getting opened");
   
   softAssert.assertTrue(Message.contains("Queue has been updated successfully") , "Incorrect Message getting displayed upon clicking save button on Update Queue page");
   
    softAssert.assertAll();
			
				 
			      System.out.println("TC032_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC032_manageQueues Failed");
					   
					  //test.log(LogStatus.FAIL, "TC032_manageQueues Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
	
	
	
	
	
	
	

