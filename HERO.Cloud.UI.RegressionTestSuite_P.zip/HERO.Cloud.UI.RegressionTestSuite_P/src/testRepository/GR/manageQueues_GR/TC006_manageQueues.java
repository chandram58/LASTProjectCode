package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC006_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void SaveButtonFunctionality() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=6;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				 
				  Thread.sleep(5000);
		
		         WebElement FirstrowPriority=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]"));
		         WebElement SecondrowPriority=driver.findElement(By.xpath("//tbody/tr[2]/td[1]/div[1]/input[1]"));
		         
		         FirstrowPriority.clear();
		         FirstrowPriority.sendKeys("2");
		         
		         String FirstRowtextbeforeSave=driver.findElement(By.xpath("//tbody/tr[1]")).getText();
		         System.out.println("First row text after changing prirority to 2 and before clicking Save button->"+FirstRowtextbeforeSave);
		          
		         SecondrowPriority.clear();
		         SecondrowPriority.sendKeys("1");
		         
		         String SecondRowtextbeforeSave=driver.findElement(By.xpath("//tbody/tr[2]")).getText();
		         System.out.println("Second row text after changing prirority to 1 and before clicking Save button->"+SecondRowtextbeforeSave);
		          
		       
		       //  Now click on Save Button
				 
				driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[2]/div[2]/div[2]/span[1]/button/span")).click();
				
			
			    driver.switchTo().defaultContent();
			    
			    Thread.sleep(3000);
			 	  
			    String Message=driver.findElement(By.xpath("//div[contains(text(),'has been updated successfully!')]")).getText();
			
			     System.out.println(Message);
			     
			     driver.findElement(By.xpath("//app-admin-layout/div/app-queue/p-toast[1]/div/p-toastitem/div/div/a")).click();
			     
			     driver.switchTo().defaultContent();
			     
			     WebElement FirstrowPriority1=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]"));
		         WebElement SecondrowPriority1=driver.findElement(By.xpath("//tbody/tr[2]/td[1]/div[1]/input[1]"));
		         
			     
			     System.out.println(FirstrowPriority1.getAttribute("value"));
			     System.out.println(SecondrowPriority1.getAttribute("value"));
			     
			     String FirstRowtextafterSave=driver.findElement(By.xpath("//tbody/tr[1]")).getText();
		         System.out.println("First row text after clicking Save button->"+FirstRowtextafterSave);
		          
		         String SecondRowtextafterSave=driver.findElement(By.xpath("//tbody/tr[2]")).getText();
		         System.out.println("Second row text after clicking Save button->"+SecondRowtextafterSave);
			       
		    try{  
		   
				
		       SoftAssert softAssert = new SoftAssert();
		       
		       softAssert.assertTrue(Message.contains("has been updated successfully"), "Message not coming for save button");
		       softAssert.assertTrue((FirstrowPriority1.getAttribute("value")).equals("1")&& (SecondrowPriority1.getAttribute("value")).equals("2") , "Priority not getting rearraged after Clicking Save Button");
		       softAssert.assertTrue(FirstRowtextbeforeSave.equals(SecondRowtextafterSave)&& SecondRowtextbeforeSave.equals(FirstRowtextafterSave) , "Save Button functionality not working properly");
		            softAssert.assertAll();
			
				 
			      System.out.println("TC006_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC006_groupManagement Failed");
					   
					  //test.log(LogStatus.FAIL, "TC006_groupManagement Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

