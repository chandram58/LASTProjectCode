package testRepository.GR.manageQueues_GR;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC001_manageQueues extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void NavigationtoRoleManagementPage() throws IOException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=1;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
			 wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(text(),'Manage Queues')]")));
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();
				
				
				
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
			 
                 String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]")).getText();
				
				System.out.println(PageTitle);
				
				
			// driver.findElement(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1")).click();
			 
			// driver.findElement(By.xpath("//a[contains(text(),'Roles Management')]")).click();
			 
			 System.out.println("1");
				
			 
			 Thread.sleep(5000);
			 
			 
			//String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Roles Management')]")).getText();
			 
			
           SoftAssert softAssert = new SoftAssert();
		     
		   //  test.log(LogStatus.INFO ,"Verifying page Title");
		     
	    softAssert.assertTrue(PageTitle.toLowerCase().contains("manage queues"), "This is not Manage Queues page");
		     
		    
		     
		      softAssert.assertAll();
		      
		      System.out.println("TC001_manageQueues Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC001_manageQueues Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC001_manageQueues Failed");
					   
					 // test.log(LogStatus.FAIL, "TC001_manageQueues Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
		
		
		      }
	
	
	






}
