package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC010_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifyExporttoExcelFunctionality() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=10;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				
              WebElement DownloadExcel=driver.findElement(By.xpath("//header/div[1]/div[1]/a[1]/em[1]"));
				
				System.out.println("Clicking On Export to Excel icon");
			//    test.log(LogStatus.INFO, "Clicking On Export to Excel icon");
			 
				
		        DownloadExcel.click();
			 

			  Thread.sleep(10000);
			 
			//  test.log(LogStatus.INFO, "Getting Downloaded File Name");
	           File getLatestFile = base.getLatestFilefromDir(DownloadFilepath);
		 
			    String fileName = getLatestFile.getName();
			    
			    System.out.println("Downloaded File name->"+fileName);
			//    test.log(LogStatus.INFO, "Downloaded File name->"+fileName);
			    
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
				// verifying whether the file  with fileName present in the directory downloadpath or not
			    softassert.assertTrue(isFileDownloaded(DownloadFilepath, fileName), "Download Failed");
			    //verifying whether the latest downloaded file contains "xlsx" extension or not and name of file having TransmissionsList word in it
			    softassert.assertTrue(fileName.contains("xls") && fileName.contains("Queues"),"It is not a excel file");
			    
			    softassert.assertAll();
				 
				    System.out.println("TC010_manageQueues Passed");
				    
				//    test.log(LogStatus.FAIL, "TC010_manageQueues Failed"); 
				    
				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC010_manageQueues Failed");
					   
				//	  test.log(LogStatus.FAIL, "TC010_manageQueues Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

