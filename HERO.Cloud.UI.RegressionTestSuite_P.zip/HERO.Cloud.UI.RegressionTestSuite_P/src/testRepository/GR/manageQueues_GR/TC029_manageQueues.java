package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC029_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void QueueCreationwithCopyFunctionality() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=29;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody")));
				
			
				

				WebElement webtable=driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody"));
			     
			     List<WebElement> rows;
			     List<WebElement> cols = null;
			     List<String> AttributeList = new ArrayList<String>();
		
			    
			     WebElement CopyAction;
			  	System.out.println("3");
			     
			     rows=webtable.findElements(By.tagName("tr"));
			     
			    System.out.println("No of rows on Manage Queues table->"+ rows.size());
              
			    int j;
			  
				 
				for(j=0;j<rows.size();j++) 
				   {
						cols=rows.get(j).findElements(By.tagName("td"));
						
						if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
					     { 
					       System.out.println(j);
					       
					       break;
							
					     }
				   }
				System.out.println("Active row starts from row no->"+(j+1));
				
				
			 String xpathexpCopy="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[1]/i[1]";
		   
					      
					      
			 CopyAction=driver.findElement(By.xpath(xpathexpCopy));
				 
					
				  //Clicking on Edit Button
				  
			    CopyAction.click();
			    
			  
			    
				  
				  Thread.sleep(3000);
				  
				  String PageTitle=driver.findElement(By.xpath("//h3[contains(text(),'New Queue')]")).getText();
				  System.out.println("Title of page opened on clicking on Copy icon->"+PageTitle);
				  
				  String QueuenameEntered="Testxyz3";
				    
				    driver.findElement(By.xpath("//input[@id='updateManangeQueueName']")).clear();
				    driver.findElement(By.xpath("//input[@id='updateManangeQueueName']")).sendKeys(QueuenameEntered);
				    
				  
				  
				  
				//Clicking On save Button
					
					driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[2]/div/div/button[1]")).click();
					
					
					//Capturing Success message
					driver.switchTo().defaultContent();
					Thread.sleep(3000);
					String MessageQueuecreation=driver.findElement(By.xpath("//div[contains(text(),'Queue has been created successfully!')]")).getText();
					
					System.out.println("Validation Message for Startdate is->"+MessageQueuecreation);
					
					driver.switchTo().defaultContent();
					
					
					Thread.sleep(3000);
				
					Boolean flag=false;
					WebElement webtable1=driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody"));
					
					List<WebElement> rows1 = null;
					List<WebElement> cols1;
					
					
					rows1=webtable1.findElements(By.tagName("tr"));
					
					System.out.println("No Of rows in table->"+rows1.size());
		
					
					for(int k=0;k<rows1.size();k++)
					{
						cols1=rows1.get(k).findElements(By.tagName("td"));
						String Queuename_UI=cols1.get(2).getText();
						System.out.println(Queuename_UI);
						if(Queuename_UI.equals(QueuenameEntered))
						{
					     flag=true;	
					     break;
						}	
					}
					
					
					
				  
				
			      
	 try{  
		   
				
	SoftAssert softAssert = new SoftAssert();
		       
   softAssert.assertTrue(PageTitle.equalsIgnoreCase("New Queue") , "Upon clicking Copy icon incorrect page is getting opened");
   softAssert.assertTrue(MessageQueuecreation.contains("Queue has been created successfully") , "Incorrect Message");
   
   softAssert.assertTrue(flag , "Queue not Created");
   
    softAssert.assertAll();
			
				 
			      System.out.println("TC029_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC029_manageQueues Failed");
					   
					  //test.log(LogStatus.FAIL, "TC029_manageQueues Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
	
	
	
	
	
	
	

