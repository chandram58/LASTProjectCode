package testRepository.GR.manageQueues_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class TC014_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

	

		@Test
		public void QueueAttributeAscendingOrderValidation() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			 
			   int i=14;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,500);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			  
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				  
				   
				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				Thread.sleep(3000);
				WebElement webtable=driver.findElement(By.className("ui-table-scrollable-body-table"));
			     
			     List<WebElement> rows1;
			     List<WebElement> cols1 = null;
			     rows1=webtable.findElements(By.tagName("tr"));
			     
				 System.out.println("No of rows on Manage Queues Table->"+ rows1.size());
	              
			     
			     List<String> ActiveQueueAttributeList1 = new ArrayList<String>();
				 
			     for(int j=0;j<rows1.size();j++) 
				   {
						cols1=rows1.get(j).findElements(By.tagName("td"));
						
						
						if(rows1.get(j).getAttribute("class").equals("ng-star-inserted"))
					     { 
						
						String QueueAttribute=cols1.get(4).getText();
					    System.out.println(QueueAttribute);
					    ActiveQueueAttributeList1.add(QueueAttribute);
						
						
					     }
						}
				
              
				driver.findElement(By.xpath("//thead/tr[1]/th[5]/span[1]/p-sorticon[1]/i[1]")).click();
				
			
			     List<String> ActiveQueueAttributeList2 = new ArrayList<String>();
			  
			     
			     List<WebElement> rows2;
			     List<WebElement> cols2 = null;
			     rows2=webtable.findElements(By.tagName("tr"));
			  	System.out.println("3");
			     
			    
			    
			    int ActiveGroupCount=0;
				 
				for(int j=0;j<rows2.size();j++) 
				   {
						cols2=rows2.get(j).findElements(By.tagName("td"));
						
						
						if(rows2.get(j).getAttribute("class").equals("ng-star-inserted"))
					     { 
						
						String QueueAttribute=cols2.get(4).getText();
					    System.out.println(QueueAttribute);
					    ActiveQueueAttributeList2.add(QueueAttribute);
						ActiveGroupCount++;
						
					     }
						}
				        
				
				      
						System.out.println("Number of active Queues in Group maintenance page->"+ActiveGroupCount); 
						 System.out.println("Active Queuename list in Group maintenance page");  
							
						System.out.println(ActiveQueueAttributeList2); 
						
						Collections.sort(ActiveQueueAttributeList1, String.CASE_INSENSITIVE_ORDER);
						System.out.println(ActiveQueueAttributeList1); 
						
					
						
			    

			  Thread.sleep(3000);
           
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
			    
		         softassert.assertEquals(ActiveQueueAttributeList1, ActiveQueueAttributeList2,"Sorting in ascending order not working as expected");
 
			    softassert.assertAll();
				 
				    System.out.println("TC014_manageQueues Passed");
				    
				     String status="Pass";
				     
				 //  test.log(LogStatus.PASS, "TC014_manageQueues Passed");    
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
		
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC014_manageQueues Failed");
					   
					//  test.log(LogStatus.FAIL, "TC014_manageQueues Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
		}
	

}
