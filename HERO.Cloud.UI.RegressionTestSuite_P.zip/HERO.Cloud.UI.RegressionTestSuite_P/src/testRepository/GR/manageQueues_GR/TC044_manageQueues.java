package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC044_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void StartDateValidationNewQueuePage() throws IOException, InterruptedException, ParseException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=44;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			 SimpleDateFormat date1=new SimpleDateFormat("MM/dd/yyyy");
			 Thread.sleep(10000);
		
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				WebElement AddNewQueue=driver.findElement(By.xpath("//span[contains(text(),'Add New Queue')]"));
				
				AddNewQueue.click();
				
				String pageTitle=driver.findElement(By.xpath("//h3[contains(text(),'New Queue')]")).getText();
			
		      System.out.println("Page opened  upon clicking Add New Queue button->"+pageTitle);
		      
		      //Getting 
				
			  WebElement Startdate=driver.findElement(By.xpath("//*[@id='addQueueStartDate']/span/input"));
			  
			  String PopulatedDefaultDate=Startdate.getAttribute("value");
			  
			  System.out.println("Prepopulated Default date in Start date field->"+PopulatedDefaultDate);
			 Date PopulatedDefaultDateinDateFormat=date1.parse(PopulatedDefaultDate);
			  
			  
				//getting current date
			   
				 Calendar calendar = Calendar.getInstance();
				 String TodayDateinStringFormat=date1.format(calendar.getTime());
				 System.out.println("Today's date in string format->"+TodayDateinStringFormat);
				 
				 String TodayDateWithoutMonthYearString=TodayDateinStringFormat.substring(TodayDateinStringFormat.indexOf("/")+1, TodayDateinStringFormat.lastIndexOf("/"));
				 System.out.println("Today's date without month and Year in string format->"+TodayDateWithoutMonthYearString);
				 
				 int TodayDateWithoutMonthYearInt=Integer.parseInt(TodayDateWithoutMonthYearString);
				 System.out.println("Today's date without month and Year in int format->"+TodayDateWithoutMonthYearInt);
				 int YesterdayDateWithoutMonthYearInt=TodayDateWithoutMonthYearInt-1;
				 System.out.println("Yesterday's's date without month and Year in int format->"+YesterdayDateWithoutMonthYearInt);
				 
				 int TommorrowDateWithoutMonthYearInt=TodayDateWithoutMonthYearInt+1;
				 System.out.println("Tommorow's date without month and Year in int format->"+TommorrowDateWithoutMonthYearInt);
				 
				 
				 
				 
				Date TodayDateinDateFormat=date1.parse(date1.format(calendar.getTime()));
				 System.out.println("Today's date in date format->"+TodayDateinDateFormat);
				 
				//Clicking on Yesterday date on calendar 
				 Startdate.click();
				 driver.switchTo().defaultContent();
				 Thread.sleep(3000);
			
				 
				 
				 //Iterating through calendar
				WebElement calendartable=driver.findElement(By.xpath("/html/body/div/div[1]/div[2]/table/tbody"));
			    List<WebElement> Rows,Cols;
				
			    Rows=calendartable.findElements(By.tagName("tr"));
			    
			    System.out.println("Number of rows in calendar->"+Rows.size());
			    
			    for(int j=0;j<Rows.size();j++)
			    {
			    	Cols=Rows.get(j).findElements(By.tagName("td"));
			    	System.out.println("Number of Cols in row no "+(j+1)+" in calendar"+Cols.size());
			    	
			        for(int k=1;k<=Cols.size();k++)
			        {
			    	String xpathExp="//tr["+(j+1)+"]/td["+k+"]/span";
			    	
			    	System.out.println(Cols.get(0).findElement(By.xpath(xpathExp)).getText());
			    	
			         if((Integer.parseInt(Cols.get(0).findElement(By.xpath(xpathExp)).getText()))==YesterdayDateWithoutMonthYearInt)
			        		 {
			        	 System.out.println("Selected date is->"+Cols.get(0).findElement(By.xpath(xpathExp)).getText());
			        	 Cols.get(0).findElement(By.xpath(xpathExp)).click(); 
			        	 j=Rows.size();//To break outer loop
			        	 break;  //To break inner loop
			        		 }
			         }
			       
			    }
			    
				
			    
			    //Now After clicking getting value of Start date field
			    String PopulatedDateAfterClickingYesterdayDate=Startdate.getAttribute("value");
				  
				  System.out.println("Populated Date After Clicking YesterdayDate in Start date field->"+PopulatedDateAfterClickingYesterdayDate);
				 Date PopulatedDateAfterClickingYesterdayDateinDateFormat=date1.parse(PopulatedDateAfterClickingYesterdayDate);
			    
				 Thread.sleep(3000);
				 
				
				 
				 //Clicking on Tommorow's date on calendar 
			
				
				
			   
			    
				   for(int j=Rows.size()-1;j>=0;j--)
				    {
				    	Cols=Rows.get(j).findElements(By.tagName("td"));
				    	System.out.println("Number of Cols in row no "+(j+1)+" in calendar->"+Cols.size());
				    	
				        for(int k=Cols.size();k>0;k--)
				        {
				    	String xpathExp="//tr["+(j+1)+"]/td["+k+"]/a";
				    	
				    	System.out.println(Cols.get(k-1).findElement(By.xpath(xpathExp)).getText());
				    	
				         if((Integer.parseInt( Cols.get(k-1).findElement(By.xpath(xpathExp)).getText()))==TommorrowDateWithoutMonthYearInt)
				        		 {
				        	 System.out.println("Selected date is->"+Cols.get(0).findElement(By.xpath(xpathExp)).getText());
				        	 Cols.get(0).findElement(By.xpath(xpathExp)).click(); 
				        	 j=0;//To break outer loop
				        	         break;  //To break inner loop
				        		 }
				         }
				       
				    }
				
			    
			    //Now After clicking getting value of Start date field
			    String PopulatedDateAfterClickingTommorowDate=Startdate.getAttribute("value");
				  
				  System.out.println("Populated Date After Clicking Tomorrowdate in Start date field->"+PopulatedDateAfterClickingTommorowDate);
				 Date PopulatedDateAfterClickingTommorowDateinDateFormat=date1.parse(PopulatedDateAfterClickingTommorowDate);
			     
				 
				 
				 
				 
				 
				 
			
	 try{  
		   
				
	SoftAssert softAssert = new SoftAssert();
		       
   softAssert.assertTrue(PopulatedDefaultDateinDateFormat.equals(TodayDateinDateFormat),"Today's date is not Default date for StartDate field");
   softAssert.assertFalse(PopulatedDateAfterClickingYesterdayDateinDateFormat.before(TodayDateinDateFormat),"Past date can be selected in Start date");
   softAssert.assertTrue(PopulatedDateAfterClickingTommorowDateinDateFormat.after(TodayDateinDateFormat),"Future date can not be selected in Start date");
   
   
    softAssert.assertAll();

    System.out.println("TC044_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC044_manageQueues Failed");
					   
					  //test.log(LogStatus.FAIL, "TC044_manageQueues Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
	
	
	
	
	
	
	

