package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC013_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void QueuePropertiesDescending() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=13;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
		
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				
				
				//Clicking On Sort icon twice
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//thead/tr[1]/th[3]/span[1]/p-sorticon[1]/i[1]")));
				driver.findElement(By.xpath("//thead/tr[1]/th[4]/span[1]/p-sorticon[1]/i[1]")).click();
				driver.findElement(By.xpath("//thead/tr[1]/th[4]/span[1]/p-sorticon[1]/i[1]")).click();
				
				//Now QueueProperties is in Descending order
				

				WebElement webtable=driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody"));
			     
			     List<WebElement> rows;
			     List<WebElement> cols = null;
			     List<String> QueuePropertyList = new ArrayList<String>();
			     Boolean flag = true;
			     
			  	System.out.println("3");
			     
			     rows=webtable.findElements(By.tagName("tr"));
			     
			    System.out.println("No of rows on Manage Queues table->"+ rows.size());
              
			    
			    int ActiveQueueCount=0;
				 
				for(int j=0;j<rows.size();j++) 
				   {
						cols=rows.get(j).findElements(By.tagName("td"));
						
						if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
					     { 
					     String QueueProperties=cols.get(3).getText();
						  System.out.println(QueueProperties);
						  QueuePropertyList.add(QueueProperties);
						  ActiveQueueCount++;
					     }
						}
				 
				System.out.println("No of Elements in list->"+ActiveQueueCount);
				
				System.out.println("No of Elements in list->"+QueuePropertyList.size());
				
				System.out.println("List->"+QueuePropertyList);
				
				for(int k=1;k<QueuePropertyList.size();k++)
				{
					if((QueuePropertyList.get(k)).compareTo(QueuePropertyList.get(k-1))>0)
					{
						flag=false;
						break;		
					}
					
					
				}
				
				System.out.println(flag); 
				 
				
				Thread.sleep(5000);
			/*	
		        String st1="Copy of test queue 1 regular";
		        String st2 ="4299Regular";
		        String st3 ="CMS Contract Owner Queue 1";
		        
		        int Exp1=st1.compareTo(st2);
		        int Exp2=st3.compareTo(st2);  
			     System.out.println(Exp1);
			  
			     System.out.println(Exp2);
			 */    
			  
		    try{  
		   
				
		       SoftAssert softAssert = new SoftAssert();
		       
		     
  softAssert.assertTrue(flag , "QueueProperties is not in descending order");
		   
		            softAssert.assertAll();
			
				 
			      System.out.println("TC008_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC008_groupManagement Failed");
					   
					  //test.log(LogStatus.FAIL, "TC008_groupManagement Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

