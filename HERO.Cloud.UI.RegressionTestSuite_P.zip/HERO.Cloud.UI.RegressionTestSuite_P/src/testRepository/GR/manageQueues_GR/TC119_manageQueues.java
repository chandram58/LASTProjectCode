package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC119_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifyQueuePrioritywithDB() throws IOException, InterruptedException, SQLException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=100;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				Thread.sleep(2000);
				
				
				WebElement webtable=driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody"));
			     
			     List<WebElement> rows;
			     List<WebElement> cols = null;
			     List<String> QueueNamePriorityList_UI = new ArrayList<String>();
			     
			     WebElement CopyAction;
			  	System.out.println("3");
			     
			     rows=webtable.findElements(By.tagName("tr"));
			 
			    System.out.println("No of rows on Manage Queues table->"+ rows.size());
			    
			    int ActiveQueueCount_UI=0;
             
			    for(int j=0;j<rows.size();j++)
			    {
			    cols=rows.get(j).findElements(By.tagName("td"));
			    
			    if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
			     { 
			    String xpathexpPriority="//tbody/tr["+(j+1)+"]/td[1]/div[1]/input[1]";
			    	
			    String Priority=driver.findElement(By.xpath(xpathexpPriority)).getAttribute("value").trim();
			    System.out.println(Priority);
			    String Queuename=cols.get(2).getText().trim();
			    System.out.println(Queuename);
				QueueNamePriorityList_UI.add(Priority.trim()+' '+Queuename.trim());
				ActiveQueueCount_UI++;
			     }
			    }
			 
			    
			    
			 System.out.println("No of Active Queues on Manage Queues table->"+ ActiveQueueCount_UI);  
			  System.out.println(QueueNamePriorityList_UI);
			  
			 String QueuePriority_DB;
			 String Queuename_DB;
			 
			 
			 List<String> QueuenamePriorityList_DB = new ArrayList<String>();
			    
			  
			    try
		          {
					
			    	String Query1="SELECT PRIORITY_ID,QUEUE_NAME FROM HERO_UI_QUEUES where END_DATE>=CAST (GETDATE() AS DATE)order by PRIORITY_ID"; 

			    	
			    	  PreparedStatement readStatement1 = dbcon.prepareStatement(Query1);
			    	  rs = readStatement1.executeQuery();
			    	while(rs.next())
					 	 {
			    		QueuePriority_DB=rs.getString(1);
					 	Queuename_DB=rs.getString(2);
					 	System.out.println(Queuename_DB);
					    QueuenamePriorityList_DB.add(QueuePriority_DB+' '+Queuename_DB.trim());
					 	
					 			
					 	 }
					 			
					 System.out.println(QueuenamePriorityList_DB);		
		          }		 
					 			
					
				catch (NullPointerException err)
			          {
				         err.getMessage();
					 	    }
				 
			 
			  System.out.println(QueueNamePriorityList_UI);
			  System.out.println(QueuenamePriorityList_DB);
			  
			 
		    try{  
		   
				
		       SoftAssert softAssert = new SoftAssert();
		       
		   softAssert.assertEquals(QueueNamePriorityList_UI, QueuenamePriorityList_DB,"List having priority and Queuename Queues in UI and DB not matching");
		  softAssert.assertTrue(QueuenamePriorityList_DB.containsAll(QueueNamePriorityList_UI) && QueueNamePriorityList_UI.containsAll(QueuenamePriorityList_DB) , "List oF Queue Priority Names not matching in UI and DB");
			
		            softAssert.assertAll();
			
				 
			      System.out.println("TC100_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC100_groupManagement Failed");
					   
					  //test.log(LogStatus.FAIL, "TC100_groupManagement Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

