package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC034_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifyQueueUserListwithDB() throws IOException, InterruptedException, SQLException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=34;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
		
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				Thread.sleep(2000);
				
				 WebElement Searchwordbox= driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[1]/div/div[2]/div/div/input"));
					
				 
				 String SelectedQueue="CMS Contract queue 2";
				  Searchwordbox.sendKeys(SelectedQueue);
				   
				  Thread.sleep(5000);
		
		        List<WebElement> serachResult_rows=driver.findElements(By.xpath("//app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody/tr"));
			  
		       System.out.println("No of Search Result->"+serachResult_rows.size());
		       
		       //System.out.println(serachResult_rows.get(0).getText().trim());
				
				
		       for(int j=0;j<serachResult_rows.size();j++)
			   {
				   String xpathexp_Queuename="//tbody/tr["+(j+1)+"]/td[3]/div[1]";
				   String xpathexp_Viewusers="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[3]/i[1]";
				
			  if((driver.findElement(By.xpath(xpathexp_Queuename)).getText().equalsIgnoreCase(SelectedQueue)))
				        {
					       driver.findElement(By.xpath(xpathexp_Viewusers)).click();
					       
					        break;
					 }
				   
			   }
		   
		       Thread.sleep(3000);
				
			//Getting List of Users from user Profile Page	
				
				
				WebElement webtable=driver.findElement(By.xpath("//app-user-profile/div[2]/div/div/p-table/div/div/div/div[2]/table/tbody"));
			     
			     List<WebElement> rows_userProfile;
			     List<WebElement> cols_userProfile = null;
			     List<String> QueueUsersList_UI = new ArrayList<String>();
			     
			
			  	System.out.println("3");
			     
			  	rows_userProfile=webtable.findElements(By.tagName("tr"));
			 
			    System.out.println("No of rows on User Profile  table->"+ rows_userProfile.size());
			    
			  
             
			    for(int j=0;j<rows_userProfile.size();j++)
			    {
			    	cols_userProfile=rows_userProfile.get(j).findElements(By.tagName("td"));
			         String QueueUserID_UI=cols_userProfile.get(5).getText().trim();
			         System.out.println(QueueUserID_UI);
			         QueueUsersList_UI.add(QueueUserID_UI.trim());
				
			    }
			 
			    
			    
			
			  System.out.println(QueueUsersList_UI);
			  
			 
			  
			  
			  String QueueUserID_DB;
	        List<String> QueueUsersList_DB = new ArrayList<String>();
			    
			  
			    try
		          {
					
			    	String Query1="select a.USER_ID FROM [enc].[HERO_UI_USER_QUEUE_ASSIGN]  a join  enc.HERO_UI_QUEUES b on a.QUEUE_ID=b.QUEUE_ID where b.queue_name ='"+SelectedQueue+"'";

			    	
			    	  PreparedStatement readStatement1 = dbcon.prepareStatement(Query1);
			    	  rs = readStatement1.executeQuery();
			    	while(rs.next())
					 	 {
			    		QueueUserID_DB=rs.getString(1);
					    System.out.println(QueueUserID_DB);
					    QueueUsersList_DB.add(QueueUserID_DB.trim());
					 	
					 			
					 	 }
					 			
					 System.out.println(QueueUsersList_DB);		
		          }		 
					 			
					
				catch (NullPointerException err)
			          {
				         err.getMessage();
					 	    }
				 
			 
			  System.out.println(QueueUsersList_UI);
			  System.out.println(QueueUsersList_DB);
			  
			 
		    try{  
		   
				
		       SoftAssert softAssert = new SoftAssert();
		       
		  
		  softAssert.assertTrue(QueueUsersList_UI.containsAll(QueueUsersList_DB) && QueueUsersList_DB.containsAll(QueueUsersList_UI) , "List of User id not matching in UI and DB");
			
		            softAssert.assertAll();
			
				 
			      System.out.println("TC034_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC034_groupManagement Failed");
					   
					  //test.log(LogStatus.FAIL, "TC034_groupManagement Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}