package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC017_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifyExpiredQueueNameandCountwithDB() throws IOException, InterruptedException, SQLException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=17;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				Thread.sleep(2000);
				
				
				WebElement webtable=driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody"));
			     
			     List<WebElement> rows;
			     List<WebElement> cols = null;
			     List<String> ExpiredQueuenameList_UI = new ArrayList<String>();
			     
			     WebElement CopyAction;
			  	System.out.println("3");
			     
			     rows=webtable.findElements(By.tagName("tr"));
			 
			    System.out.println("No of rows on Manage Queues table->"+ rows.size());
			    
			    int ExpiredQueueCount_UI=0;
             
			    for(int j=0;j<rows.size();j++)
			    {
			    cols=rows.get(j).findElements(By.tagName("td"));
			       
			    if(rows.get(j).getAttribute("class").equals("hasExpired ng-star-inserted"))
			     { 
			    String ExpiredQueuename=cols.get(2).getText().trim();
				System.out.println(ExpiredQueuename);
				ExpiredQueuenameList_UI.add(ExpiredQueuename);
			    ExpiredQueueCount_UI++;
			     }	
			    }
			  
			    
			  System.out.println("No of Expired queues present on UI->"+ExpiredQueueCount_UI);  
			  System.out.println(ExpiredQueuenameList_UI);
			  
			 int ExpiredQueueCount_DB = 0;
			 String ExpiredQueuename_DB;
			 List<String> ExpiredQueuenameList_DB = new ArrayList<String>();
			    
			  
			    try
		          {
					
			    	String Query1="SELECT Count(*) as Count FROM HERO_UI_QUEUES WHERE END_DATE <CAST (GETDATE() AS DATE)";
			    	String Query2="SELECT * FROM HERO_UI_QUEUES WHERE END_DATE <CAST (GETDATE() AS DATE)";
			    	  PreparedStatement readStatement1 = dbcon.prepareStatement(Query1);
			    	  rs = readStatement1.executeQuery();
			    	  rs.next();
			    	  ExpiredQueueCount_DB=rs.getInt("Count");
			    	  
			    	  System.out.println("No of Expired queues present on DB->"+ExpiredQueueCount_DB);
			    	  
			    	  
			    	  PreparedStatement readStatement2 = dbcon.prepareStatement(Query2);
			    	  rs = readStatement2.executeQuery();
					 	
					 	
					     
					 
                while(rs.next())
					 	 {
                	ExpiredQueuename_DB=rs.getString(2);
					 	System.out.println(ExpiredQueuename_DB);
					 	ExpiredQueuenameList_DB.add(ExpiredQueuename_DB.trim());
					 	
					 			
					 	 }
					 			
					 System.out.println(ExpiredQueuenameList_DB);		
		          }		 
					 			
					
				catch (NullPointerException err)
			          {
				         err.getMessage();
					 	    }
					 
			  Collections.sort(ExpiredQueuenameList_UI);
			  Collections.sort(ExpiredQueuenameList_DB);
			  System.out.println(ExpiredQueuenameList_UI);
			  System.out.println(ExpiredQueuenameList_DB);
			  
				 
		    try{  
		   
				
		       SoftAssert softAssert = new SoftAssert();
		       
		       softAssert.assertEquals(ExpiredQueueCount_UI, ExpiredQueueCount_DB,"No of expired Queues in UI and Db not matching");
		       softAssert.assertTrue(ExpiredQueuenameList_DB.containsAll(ExpiredQueuenameList_UI) && ExpiredQueuenameList_UI.containsAll(ExpiredQueuenameList_DB) , "List of Expired Queue Names not matching in UI and DB");
			
		            softAssert.assertAll();
			
				 
			      System.out.println("TC017_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC017_groupManagement Failed");
					   
					  //test.log(LogStatus.FAIL, "TC017_groupManagement Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

