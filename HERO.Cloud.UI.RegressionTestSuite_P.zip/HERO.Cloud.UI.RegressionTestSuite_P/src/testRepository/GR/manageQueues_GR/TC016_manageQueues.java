package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC016_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void ExpiredQueuesActionVerification() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=16;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody")));
				
			
				

				WebElement webtable=driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody"));
			     
			     List<WebElement> rows;
			     List<WebElement> cols = null;
			     List<String> AttributeList = new ArrayList<String>();
			     Boolean flag1 = false;
			     Boolean flag2 = true;
			     WebElement CopyAction,ViewAction,ViewUsersAction,ViewClaimsAction;
			  	System.out.println("3");
			     
			     rows=webtable.findElements(By.tagName("tr"));
			     
			    System.out.println("No of rows on Manage Queues table->"+ rows.size());
              
			    
			  
				 
				for(int j=0;j<rows.size();j++) 
				   {
						cols=rows.get(j).findElements(By.tagName("td"));
						
						if(rows.get(j).getAttribute("class").equals("hasExpired ng-star-inserted"))
					     { 
					      String xpathexpCopy="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[1]/i[1]";
					      String xpathexpView="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[2]/i[1]";
					      String xpathexpViewUsers="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[3]/i[1]";
					      String xpathexpViewClaims="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[3]/i[1]";
					      
					      
					      
					      CopyAction=driver.findElement(By.xpath(xpathexpCopy));
					      ViewAction=driver.findElement(By.xpath(xpathexpView));
					      ViewUsersAction=driver.findElement(By.xpath(xpathexpViewUsers));
					      ViewClaimsAction=driver.findElement(By.xpath(xpathexpViewClaims));
					      
					      
						  flag1=CopyAction.getAttribute("class").contains("viewDisable") && ViewAction.getAttribute("class").contains("viewDisable"); 
						  System.out.println("flag1 for row no "+(j+1)+"->"+flag1);
						  
						  flag2=ViewUsersAction.getAttribute("class").contains("viewDisable") && ViewClaimsAction.getAttribute("class").contains("viewDisable"); 
						  System.out.println("flag2 for row no "+(j+1)+"->"+flag2);
						  
						  if(flag1.equals(true) && flag2.equals(false))
						  {
						  break;
						  }
						
					     }
						}
				
				
				System.out.println(flag1); 
				System.out.println(flag2);  
				
				Thread.sleep(5000);
		
		    try{  
		   
				
		       SoftAssert softAssert = new SoftAssert();
		       
		     
   softAssert.assertFalse(flag1 , "Copy and View action are disabled for Expired Queues");
   
   softAssert.assertTrue(flag2 , "ViewUsers and ViewClaims actions are not disbled for Expired Queues");
   
		   
		            softAssert.assertAll();
			
				 
			      System.out.println("TC016_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC016_manageQueues Failed");
					   
					  //test.log(LogStatus.FAIL, "TC016_manageQueues Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

