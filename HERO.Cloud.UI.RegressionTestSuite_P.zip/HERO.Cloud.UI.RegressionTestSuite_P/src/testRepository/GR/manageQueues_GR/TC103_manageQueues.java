package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC103_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void EscalationQueueDatetypeErrorDate() throws IOException, InterruptedException
		{
			
			
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=85;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,3000);
			 System.out.println("0");
			
			 Thread.sleep(10000);
		
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				WebElement AddNewQueue=driver.findElement(By.xpath("//span[contains(text(),'Add New Queue')]"));
				
				AddNewQueue.click();
				
				String pageTitle=driver.findElement(By.xpath("//h3[contains(text(),'New Queue')]")).getText();
			
				System.out.println("Page opened  upon clicking Add New Queue button->"+pageTitle);
			
				//Entering existing Queue name Text 
				String QueuenameEntered="Escalation1";
				driver.findElement(By.xpath("//input[@id='newManangeQueue']")).sendKeys(QueuenameEntered);
				
				
				//Entering Text in Description
			driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[4]/textarea")).sendKeys("Escalation Queue");
			 
			
			
			//Selecting type of Queue
			driver.findElement(By.xpath("//label[contains(text(),'Escalation Queue')]")).click();
			
		WebElement ContractOwnerQueue=driver.findElement(By.xpath("//label[contains(text(),'Select Contract Owner Queue')]"));
		
		ContractOwnerQueue.click();
		
		driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[1]/div[2]/div[2]/div/p-dropdown/div/div[3]/div/ul/p-dropdownitem[4]/li/span")).click();
		
		
			//Selecting Text in DateType field
			driver.findElement(By.xpath("//label[contains(text(),'Select Date Type')]")).click();
			
			driver.findElement(By.xpath("//span[contains(text(),'Error Date')]")).click();
			
			
			
			
			
			
			
			
			
			
			//Entering Text in Query field
			
			driver.findElement(By.xpath("//label[contains(text(),'Select Column')]")).click();
			
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'PARTNER ID')]")));
			driver.findElement(By.xpath("//span[contains(text(),'PARTNER ID')]")).click();
			
			driver.findElement(By.xpath("//label[contains(text(),'Select Operator')]")).click();
			
			 //span[contains(text(),'LIKE')]

			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'LIKE')]")));
			driver.findElement(By.xpath("//span[contains(text(),'LIKE')]")).click();
			
			driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[5]/div[3]/div/div[2]/div[3]/input")).sendKeys("CMS");
			
			driver.findElement(By.xpath("//span[contains(text(),'Add to Filter')]")).click();
			
			
			
			//Clicking On save Button
			
			driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[2]/div/div/button[1]")).click();
			
			
			//Capturing Success message
			driver.switchTo().defaultContent();
			Thread.sleep(3000);
			String MessagQueuecreation=driver.findElement(By.xpath("//div[contains(text(),'Queue has been created successfully!')]")).getText();
			
			System.out.println("Validation Message for Startdate is->"+MessagQueuecreation);
			
			driver.switchTo().defaultContent();
			
			WebElement webtable=driver.findElement(By.className("ui-table-scrollable-body-table"));
			
			List<WebElement> rows;
			List<WebElement> cols;
			Boolean flag=false;
			
			rows=webtable.findElements(By.tagName("tr"));
			
			System.out.println("No Of rows in table->"+rows.size());
			
			for(int j=0;j<rows.size();j++)
			{
				cols=rows.get(j).findElements(By.tagName("td"));
				String Queuename_UI=cols.get(2).getText();
				System.out.println(Queuename_UI);
				if(Queuename_UI.equals(QueuenameEntered))
				{
			     flag=true;	
			     break;
				}	
			}
			
			
			
			
			  try{  
					 
				  SoftAssert softAssert = new SoftAssert();
				
				 
		
			  softAssert.assertTrue(MessagQueuecreation.contains("Queue has been created successfully") , "Incorrect Validation Message" );
			  softAssert.assertTrue(flag, "Created Queue not found on UI Queue table" );
			 
			  
			  
    softAssert.assertAll();

    System.out.println("TC085_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC085_manageQueues Failed");
					   
					  //test.log(LogStatus.FAIL, "TC085_manageQueues Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }

		}


	
	
	
	
	
	
	
	

