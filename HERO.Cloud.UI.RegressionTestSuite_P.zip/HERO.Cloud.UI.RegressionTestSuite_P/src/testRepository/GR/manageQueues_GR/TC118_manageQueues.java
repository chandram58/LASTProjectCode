package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC118_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifyQueueDescriptionDatewithDB() throws IOException, InterruptedException, SQLException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=99;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				Thread.sleep(2000);
				
				
				WebElement webtable=driver.findElement(By.xpath("//app-admin-layout/div/app-queue/div/div[2]/div/div[1]/div/p-table/div/div/div/div[2]/table/tbody"));
			     
			     List<WebElement> rows;
			     List<WebElement> cols = null;
			   
			     
			     WebElement EditAction;
			  	System.out.println("3");
			     
			     rows=webtable.findElements(By.tagName("tr"));
			 
			    System.out.println("No of rows on Manage Queues table->"+ rows.size());
			    
			  
			    String QueueName_UI = null,QueueStartDate_UI = null,QueueEndDate_UI = null,QueueDescription_UI=null;
			    
			    int j;
             
			    for(j=0;j<rows.size();j++)
			    {
			    cols=rows.get(j).findElements(By.tagName("td"));
			       
			    if(rows.get(j).getAttribute("class").equals("ng-star-inserted"))
			     { 
			    	
			    	  System.out.println(j);
				
			    break;
			     }	
			    }
			    System.out.println("Active row starts from row no->"+(j+1));
				
				
				 String xpathexpEdit="//tbody/tr["+(j+1)+"]/td[6]/div[1]/a[2]/i[1]";
			   
						      
						      
			          EditAction=driver.findElement(By.xpath(xpathexpEdit));
					 
						
					  //Clicking on Edit Button
					  
			          EditAction.click();
					  
					  Thread.sleep(3000);
			    
					  
					  String PageTitle=driver.findElement(By.xpath("//h3[contains(text(),'Update Queue')]")).getText();
					  System.out.println("Title of page opened on clicking on Edit icon->"+PageTitle);
					  
					 
			 QueueName_UI=driver.findElement(By.xpath("//input[@id='updateManangeQueueName']")).getAttribute("value");
			
			 QueueStartDate_UI=driver.findElement(By.xpath("//*[@id='updateManageQueueStartDate']/span/input")).getAttribute("value");
			 QueueEndDate_UI=driver.findElement(By.xpath("//*[@id='updateManageQueueEndDate']/span/input")).getAttribute("value"); 
			 QueueDescription_UI=driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[4]/textarea")).getAttribute("value");   
			    
			    System.out.println("Queue Name on UI->"+QueueName_UI);
			    System.out.println("Queue Start date on UI->"+QueueStartDate_UI);
			    
			  
			    
			    System.out.println("Queue End date on UI->"+QueueEndDate_UI);
			   
			    
			    System.out.println("Queue Description on UI->"+QueueDescription_UI);
			
			  
			 
			  String QueueName_DB = null,QueueDescription_DB=null;
			  Date QueueStartdate_DB = null,QueueEnddate_DB=null;
	             
			  
			    
			  
			    try
		          {
					
			    	String Query1="SELECT QUEUE_NAME,START_DATE,END_DATE,REASON FROM HERO_UI_QUEUES WHERE QUEUE_NAME like '"+QueueName_UI+"' and END_DATE >=CAST (GETDATE() AS DATE)";

			    	
			    	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
			    	  rs = readStatement.executeQuery();
			    	  rs.next();
			    	  
			    	  QueueName_DB=rs.getString(1);
			    	  System.out.println("Selected Queue Name in DB->"+QueueName_DB);
			    	  
			    	  QueueStartdate_DB=rs.getDate(2);
			    	  System.out.println("Selected Queue Start Date in DB->"+QueueStartdate_DB);
			    	  
			    	  QueueEnddate_DB=rs.getDate(3);
			    	  System.out.println("Selected Queue End Date in DB->"+QueueEnddate_DB);
			    	  
			    	  QueueDescription_DB=rs.getString(4);
			    	  System.out.println("Selected Queue Description value  in DB->"+QueueDescription_DB);
			    	  
			    	 
		          }
			    	  
			    	  
			   catch (NullPointerException err)
			          {
				         err.getMessage();
					 	    }
					 
			   SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
			   
			   String QueueStartdate_DB_format=sdf.format(QueueStartdate_DB);
			   System.out.println("Selected Queue Start Date in DB  in desired format ->"+QueueStartdate_DB_format);
			   
			   String QueueEnddate_DB_format=sdf.format(QueueEnddate_DB);
			   System.out.println("Selected Queue End Date in DB  in desired format ->"+QueueEnddate_DB_format);
			   
			   
			   
		    try{  
		   
				
		       SoftAssert softAssert = new SoftAssert();
		       
		       softAssert.assertEquals(QueueName_UI.trim(), QueueName_DB.trim(),"Queue Name present in  UI and Db not matching");
		       softAssert.assertEquals(QueueDescription_UI.trim(), QueueDescription_DB.trim(),"Queue Name present in  UI and Db not matching");
               
		      softAssert.assertTrue(QueueStartDate_UI.equals(QueueStartdate_DB_format), "Start date not matching");
		     
		      softAssert.assertTrue(QueueEndDate_UI.equals(QueueEnddate_DB_format), "End date not matching");
		      
			    softAssert.assertAll();
			
				 
			      System.out.println("TC99_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC99groupManagement Failed");
					   
					  //test.log(LogStatus.FAIL, "TC99_groupManagement Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
