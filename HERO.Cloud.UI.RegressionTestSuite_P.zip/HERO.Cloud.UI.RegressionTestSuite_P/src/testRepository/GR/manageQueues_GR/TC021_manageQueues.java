package testRepository.GR.manageQueues_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC021_manageQueues extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void PriorityChangeDragandDropFunctionality() throws IOException, InterruptedException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=21;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,4000);
			 System.out.println("0");
			
			 Thread.sleep(10000);
			 
			// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'User Profile')]")));
			 
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[3]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Manage Queues')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Manage Queues')]"))).click().release().build().perform();

				action.moveToElement(driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]"))).click().perform();
			 
				 
				  Thread.sleep(5000);
		
		         //Dragging 2nd row into 1st row
		         WebElement source=driver.findElement(By.xpath("//*[@id='2']/img"));
		         WebElement target=driver.findElement(By.xpath("//*[@id='1']/img"));
		         
		        // action.dragAndDrop(source, target).build().perform();
		         
		         //action.clickAndHold(source).moveToElement(target).release(target).build().perform();
		          
		        String java_script1 =
		                 "var src=arguments[0],tgt=arguments[1];var dataTransfer={dropEffe" +
		                 "ct:'',effectAllowed:'all',files:[],items:{},types:[],setData:fun" +
		                 "ction(format,data){this.items[format]=data;this.types.append(for" +
		                 "mat);},getData:function(format){return this.items[format];},clea" +
		                 "rData:function(format){}};var emit=function(event,target){var ev" +
		                 "t=document.createEvent('Event');evt.initEvent(event,true,false);" +
		                 "evt.dataTransfer=dataTransfer;target.dispatchEvent(evt);};emit('" +
		                 "dragstart',src);emit('dragenter',tgt);emit('dragover',tgt);emit(" +
		                 "'drop',tgt);emit('dragend',src);";
/*
		      ((JavascriptExecutor)driver).executeScript("function createEvent(typeOfEvent) {\n" + "var event =document.createEvent(\"CustomEvent\");\n"
		                    + "event.initCustomEvent(typeOfEvent,true, true, null);\n" + "event.dataTransfer = {\n" + "data: {},\n"
		                    + "setData: function (key, value) {\n" + "this.data[key] = value;\n" + "},\n"
		                    + "getData: function (key) {\n" + "return this.data[key];\n" + "}\n" + "};\n" + "return event;\n"
		                    + "}\n" + "\n" + "function dispatchEvent(element, event,transferData) {\n"
		                    + "if (transferData !== undefined) {\n" + "event.dataTransfer = transferData;\n" + "}\n"
		                    + "if (element.dispatchEvent) {\n" + "element.dispatchEvent(event);\n"
		                    + "} else if (element.fireEvent) {\n" + "element.fireEvent(\"on\" + event.type, event);\n" + "}\n"
		                    + "}\n" + "\n" + "function simulateHTML5DragAndDrop(element, destination) {\n"
		                    + "var dragStartEvent =createEvent('dragstart');\n" + "dispatchEvent(element, dragStartEvent);\n"
		                    + "var dropEvent = createEvent('drop');\n"
		                    + "dispatchEvent(destination, dropEvent,dragStartEvent.dataTransfer);\n"
		                    + "var dragEndEvent = createEvent('dragend');\n"
		                    + "dispatchEvent(element, dragEndEvent,dropEvent.dataTransfer);\n" + "}\n" + "\n"
		                    + "var source = arguments[0];\n" + "var destination = arguments[1];\n"
		                    + "simulateHTML5DragAndDrop(source,destination);", source, target);
		         
		      */   
		        JavascriptExecutor js1 = (JavascriptExecutor) driver;
		        js1.executeScript(java_script1, source, target);
		         
		  

		         WebElement FirstrowPriority=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]"));
		         WebElement SecondrowPriority=driver.findElement(By.xpath("//tbody/tr[2]/td[1]/div[1]/input[1]"));
		         
                
		         String FirstRowtextbeforeSave=driver.findElement(By.xpath("//tbody/tr[1]")).getText();
		         System.out.println("First row text after Dragging 2nd row to 1st row and  before clicking Save button->"+FirstRowtextbeforeSave);
		         
		         System.out.println("First row Priority after Dragging 2nd row to 1st row and  before clicking Save button->"+FirstrowPriority.getAttribute("value"));
		        
		         
		         String SecondRowtextbeforeSave=driver.findElement(By.xpath("//tbody/tr[2]")).getText();
		         System.out.println("Second row text after Dragging 2nd row to 1st row and  before clicking Save button->"+SecondRowtextbeforeSave);
		         
		         System.out.println("Second row Priority after Dragging 2nd row to 1st row and  before clicking Save button->"+SecondrowPriority.getAttribute("value"));
		       
		       //  Now click on Save Button
		         System.out.println("Now click on Save Button"); 
		        
		       
				//WebElement Save=
		       //  driver.findElement(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-queue[1]/div[1]/div[2]/div[1]/div[2]/div[2]/div[2]/span[1]/button[1]/span[1]")).sendKeys(Keys.RETURN);
			//	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-queue[1]/div[1]/div[2]/div[1]/div[2]/div[2]/div[2]/span[1]/button[1]/span[1]"))); 
			
		    driver.switchTo().defaultContent();
		    
		    driver.findElement(By.xpath("//h1[contains(text(),'Manage Queues')]")).click(); 
		  //  WebElement Savebtn = driver.findElement(By.xpath("//span[contains(text(),'Save')]"));
		    WebElement Savebtn = driver.findElement(By.xpath("//app-queue/div/div[2]/div/div[2]/div[2]/div[2]/span[1]/button"));
		 
		    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-queue/div/div[2]/div/div[2]/div[2]/div[2]/span[1]/button")));
		    Savebtn.click();
		  //  String javascript = "arguments[0].click()";  
		   
		  //  ((JavascriptExecutor) driver).executeScript("arguments[0].click();", Savebtn);		    
		    // String java_script2 ="var Save=arguments[0];arguments[0].click();";

			//js.executeScript("window.document.get", Save);
			
			    driver.switchTo().defaultContent();
			  
			  //wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(text(),'has been updated successfully!')]"))); 
			    String Message=driver.findElement(By.xpath("//div[contains(text(),'has been updated successfully!')]")).getText();
			
			     System.out.println(Message);
			     
			     driver.findElement(By.xpath("//app-admin-layout/div/app-queue/p-toast[1]/div/p-toastitem/div/div/a")).click();
			     
			     driver.switchTo().defaultContent();
			     
			     WebElement FirstrowPriority1=driver.findElement(By.xpath("//tbody/tr[1]/td[1]/div[1]/input[1]"));
		         WebElement SecondrowPriority1=driver.findElement(By.xpath("//tbody/tr[2]/td[1]/div[1]/input[1]"));
		         
			     
			     System.out.println(FirstrowPriority1.getAttribute("value"));
			     System.out.println(SecondrowPriority1.getAttribute("value"));
			     
			     String FirstRowtextafterSave=driver.findElement(By.xpath("//tbody/tr[1]")).getText();
		         System.out.println("First row text after clicking Save button->"+FirstRowtextafterSave);
		         System.out.println("First row Priority after clicking Save button->"+FirstrowPriority1.getAttribute("value"));
		          
		         String SecondRowtextafterSave=driver.findElement(By.xpath("//tbody/tr[2]")).getText();
		         System.out.println("Second row text after clicking Save button->"+SecondRowtextafterSave);
		         System.out.println("Second row Priority after clicking Save button->"+SecondrowPriority1.getAttribute("value"));  
		    
		         try{  
		   
				
		       SoftAssert softAssert = new SoftAssert();
		       
		       softAssert.assertTrue(Message.contains("has been updated successfully"), "Message not coming for save button");
		       softAssert.assertTrue((FirstrowPriority1.getAttribute("value")).equals("1")&& (SecondrowPriority1.getAttribute("value")).equals("2") , "Priority not getting rearraged after Clicking Save Button");
		       softAssert.assertTrue(FirstRowtextbeforeSave.equals(SecondRowtextafterSave)&& SecondRowtextbeforeSave.equals(FirstRowtextafterSave) , "Save Button functionality not working properly");
		            softAssert.assertAll();
			
				 
			      System.out.println("TC021_manageQueues Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC021_groupManagement Failed");
					   
					  //test.log(LogStatus.FAIL, "TC021_groupManagement Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	
	
	
	
	
	

