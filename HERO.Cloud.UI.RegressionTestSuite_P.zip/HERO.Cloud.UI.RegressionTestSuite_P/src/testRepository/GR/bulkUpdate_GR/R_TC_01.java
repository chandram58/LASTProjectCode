package testRepository.GR.bulkUpdate_GR;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.bulkUpdatePage;
import pages.reDosPage;
import base.base;

public class R_TC_01 extends base 
{@Test
		public void NavigationtoBulkUpdate() throws IOException
		{
try{
				 
		
	    	 bulkUpdatePage bulkUpdateObj=new bulkUpdatePage(); 
	 		 HomePage homePageObj=new HomePage();
            Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 		homePageObj.openModule("File Upload");
	 		
	 		Thread.sleep(4000);
	 		
	 
	 		//Click on CreateNewRequest
	 		bulkUpdateObj.clickCreateNewRequest();
	 		
	 		//Select View Type
	 		
	 		bulkUpdateObj.selectViewType_Claims();
	 		
	 		//Click on Next Button
	 		bulkUpdateObj.clickNextButton();
	 		
	 		//Select Input Columns
	 		bulkUpdateObj.selectInputColumns();
	 		
	 		//Select Output Columns
	 		bulkUpdateObj.selectOutputColumns();
	 		
	 		//Verifying Actions Button on page
	 		boolean flag=bulkUpdateObj.verifyActions().isDisplayed();
	 		
	 		//Verifying Actions Button on page
	 		bulkUpdateObj.clickDownChevron_Actions();
	 		 
	 		//Clicking down chevron next to Actions Button
	 	//	reDosObj.clickDownChevron_Actions();
	 		
	 		//Verifying dropdown values
	 		String listDropdownValues_Actions=bulkUpdateObj.listDropdownValues_Actions().replace("\n", " ");
	 		
			
           SoftAssert softAssert = new SoftAssert();
	       softAssert.assertTrue(flag, "Actions buttons not displayed");
	       softAssert.assertTrue(listDropdownValues_Actions.contains("Bulk Update"), "Bulk Update option not displayed");
		   softAssert.assertAll();
		 
		   System.out.println("TC001_Bulk Update Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC001_Bulk Update Passed"); 
	  }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC001_Bulk Update Failed");
					   
					//  test.log(LogStatus.FAIL, "TC001_Bulk Update Failed"); 
               Assert.fail(e.getMessage());
						 
					}
		
		
		      }
	
		
}
