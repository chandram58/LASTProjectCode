package testRepository.GR.bulkUpdate_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.bulkUpdatePage;
import pages.reDosPage;
import base.base;

public class G_TC9_TC11_TC14_TC26 extends base 
{
	@Test
		public void CreationofRequestBulkUpdate() throws IOException
		{
	
	try{
				 
		
	    	 bulkUpdatePage bulkUpdateObj=new bulkUpdatePage(); 
	 		 HomePage homePageObj=new HomePage();
             Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 		homePageObj.openModule("File Upload");
	 		
	 		
	 		Thread.sleep(4000);
	
	 		
	 		 //Counting no of rows in FILE UPLOAD HISTORY table Before request submission
		 	   int Rowcount_beforeReqSubmission=bulkUpdateObj.Count_Records();
		 	   
		 	   System.out.println("Rowcount_before Bul Update Req Submission->"+Rowcount_beforeReqSubmission);
		 	     
		 	   
	 		//Click on CreateNewRequest
		 	  bulkUpdateObj.clickCreateNewRequest();
	 		
	 		//Select View Type
	 		
		 	 bulkUpdateObj.selectViewType_Claims();
	 		
	 		//Click on Next Button
		 	bulkUpdateObj.clickNextButton();
	 		
	 		//Select Input Columns
		 	bulkUpdateObj.selectInputColumns();
	 		
	 		//Select Output Columns
		 	bulkUpdateObj.selectOutputColumns();
	 		
	         //Click on Download Template button
		 	bulkUpdateObj.clickDownloadTemplate();
	 		Thread.sleep(10000);
	 		
	 		//Click on Upload button icon
	 		bulkUpdateObj.upload_file();
	 		 
	 	     
	 	     
	 	    //Click on Bulk Update option
	 		bulkUpdateObj.clickBulkUpdate_Actions();
	 		
	 		//Select loop,segment,element etc 
	 		bulkUpdateObj.FillDetailsBulkUpdate();
	 		
	 	// click submit
	 		bulkUpdateObj.submit_BulkUpdateReq();
	 	     
	 	    Thread.sleep(2000);
	 	   //Counting no of rows in FILE UPLOAD HISTORY table after request submission
	 	   int Rowcount_afterReqSumission=bulkUpdateObj.Count_Records();
	 	   
	 	   System.out.println("Rowcount_after Bulk Update ReqSumission->"+Rowcount_afterReqSumission);
	 	     
	 	    int Diff_count=Rowcount_afterReqSumission-Rowcount_beforeReqSubmission;
	 		
	 		String Request_type=bulkUpdateObj.getRequestType_FileUploadHistory();
	 		System.out.println("Request_type  Submitted in File Upload History->"+Request_type);
	 		
	 		String InputFileName=bulkUpdateObj.getInputFileName_FileUplaodHistory();
	 		System.out.println("InputFileName Submitted in File Upload History->"+InputFileName);
	 		
           SoftAssert softAssert = new SoftAssert();
           softAssert.assertTrue(Diff_count==1, "Bulk Update submission request not captured in File Upload history");
           
	     softAssert.assertTrue(Request_type.equalsIgnoreCase("Bulk Update"), "Request_type is not Bulk Update");
	   //  softAssert.assertTrue(InputFileName.contains("BulkUpdate"), "Input File not having BulkUpdate");
	     
	     
	//       softAssert.assertTrue(listDropdownValues_Actions.contains("Re Do"), "Re Do option not displayed");
		   softAssert.assertAll();
		 
		   System.out.println("TC011_Bulk_Update Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC011_Bulk_Update Passed"); 
		}
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC011_Bulk_Update Failed");
					   
					//  test.log(LogStatus.FAIL, "TC011_Bulk_Update Failed"); 
             Assert.fail(e.getMessage());
						 
					}
		
		 }
	
}
