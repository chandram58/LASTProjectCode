package testRepository.GR.bulkUpdate_GR;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.bulkUpdatePage;
import pages.reDosPage;
import base.base;

public class R_TC_02 extends base 
{
	@Test
		public void ApplyFilterFunctionalityBulkUpdate() throws IOException
		{
	
		try{
				 
		
	    	 bulkUpdatePage bulkUpdateObj=new bulkUpdatePage(); 
	 		 HomePage homePageObj=new HomePage();
             Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 		Thread.sleep(3000);
	 		homePageObj.openModule("File Upload");
	 		
	 		Thread.sleep(4000);
	 		
	       bulkUpdateObj.ApplyFilter();
	       
	   	Thread.sleep(4000);
	 		
	       bulkUpdateObj.VerifyRequestType();
	 
	 		
	 	
		 
		   System.out.println("TC002_Bulk Update Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC002_Bulk Update Passed"); 
		 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC002_Bulk Update Failed");
					   
					//  test.log(LogStatus.FAIL, "TC002_Bulk Update Failed"); 
                Assert.fail(e.getMessage());
						 
					}
		
		
		      }
	
		
}
