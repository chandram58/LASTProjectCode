package testRepository.GR.bulkUpdate_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.bulkUpdatePage;
import pages.reDosPage;
import base.base;

public class R_TC_16p1 extends base 
{
	@Test
		public void VerifyRequestTypeStatusDropDownValues() throws IOException
		{
	
				
	     try{
				 
		
	    	 bulkUpdatePage bulkUpdateObj=new bulkUpdatePage(); 
	 		 HomePage homePageObj=new HomePage();
             Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 		homePageObj.openModule("File Upload");
	 		
	 		Thread.sleep(4000);   
	 		//Verifying Dropdown values for fields present in Filter section
	 		
	 		List<String> RequestTypeActualValues=bulkUpdateObj.getDropdownValues_RequestType();
	 		List<String> StatusActualValues=bulkUpdateObj.getDropdownValues_Status();
	 		
	 		List <String> RequestTypeExpectedValues=Arrays.asList("Bulk Search Results","Bulk Update","Re Do","Provider Correction","Create Work Item","Override","Void","Move On","Chart Review","Kick Payments");
	 		List<String> StatusExpectedValues=Arrays.asList("Request Creation","Ready for User Upload","Submitted","Completed","Cancelled");
	 		 
	 	 
	 	    Thread.sleep(2000);
	 	
           SoftAssert softAssert = new SoftAssert();       
           softAssert.assertTrue(RequestTypeActualValues.containsAll(RequestTypeExpectedValues) && RequestTypeExpectedValues.containsAll(RequestTypeActualValues), "RequestType Expected and Actual values not matching");
           softAssert.assertTrue(StatusActualValues.containsAll(StatusExpectedValues) && StatusExpectedValues.containsAll(StatusActualValues), "Status Expected and Actual values not matching");
           softAssert.assertAll();
		 
		   System.out.println("TC016p1_Bulk_Update Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC016p1_Bulk_Update Passed"); 
		 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC016p1_Bulk_Update Failed");
					   
					//  test.log(LogStatus.FAIL, "TC016p1_Bulk_Update Failed"); 
                 Assert.fail(e.getMessage());
						 
					}
		
		
		      }
	
		
}
