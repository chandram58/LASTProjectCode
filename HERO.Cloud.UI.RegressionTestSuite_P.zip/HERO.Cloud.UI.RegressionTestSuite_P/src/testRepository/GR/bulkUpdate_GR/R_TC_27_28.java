package testRepository.GR.bulkUpdate_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.bulkUpdatePage;
import pages.reDosPage;
import base.base;

public class R_TC_27_28 extends base 
{
	@Test
		public void AllFieldMandatoryValidation() throws IOException
		{
	
				
	     try{
				 
		
	    	 bulkUpdatePage bulkUpdateObj=new bulkUpdatePage(); 
	 		 HomePage homePageObj=new HomePage();

	            Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 		homePageObj.openModule("File Upload");
	 		
	 		
	 		Thread.sleep(4000);   
	 		//Click on CreateNewRequest
		 	  bulkUpdateObj.clickCreateNewRequest();
	 		
	 		//Select View Type
	 		
		 	 bulkUpdateObj.selectViewType_Claims();
	 		
	 		//Click on Next Button
		 	bulkUpdateObj.clickNextButton();
	 		
	 		//Select Input Columns
		 	bulkUpdateObj.selectInputColumns();
	 		
	 		//Select Output Columns
		 	bulkUpdateObj.selectOutputColumns();
	 		
	         //Click on Download Template button
		 	bulkUpdateObj.clickDownloadTemplate();
	 		Thread.sleep(10000);
	 		
	 		//Click on Upload button icon
	 		bulkUpdateObj.upload_file();
	 		 
	 	   //Click on Bulk Update option
	 		bulkUpdateObj.clickBulkUpdate_Actions();
	 		
	 		
	 	   SoftAssert softAssert = new SoftAssert();
         
	 	//Find values in Segement and Element Dropdown without selecting Loop dropdown value
	 		Thread.sleep(2000);
	 		String Emptymessage_Segment=bulkUpdateObj.getSegmentEmptymessage();
	 		System.out.println("Emptymessage_Segment->"+Emptymessage_Segment);
	 		softAssert.assertTrue(Emptymessage_Segment.trim().equalsIgnoreCase("No results found"),"Segment field not empty ");
		 		
	 		
	
	 		Thread.sleep(2000);
	 		String Emptymessage_Element=bulkUpdateObj.getElementEmptymessage();
	 		System.out.println("Emptymessage_Element->"+Emptymessage_Element);
	 		  softAssert.assertTrue(Emptymessage_Element.trim().equalsIgnoreCase("No results found"),"Element field not empty ");
	 		
	 	// click submit without filling loop,Segement,Element etc
	 		Thread.sleep(3000);
	 		bulkUpdateObj.submit_BulkUpdateReq();
	 	 
	 	//Capture Error
	 		String Errortxt=bulkUpdateObj.Capture_Error();
	 		System.out.println("Errortxt->"+Errortxt);
	 	
           softAssert.assertTrue(Errortxt.equalsIgnoreCase("Please select loop details to continue"), "Incorrect Error Populated");
          
           
           softAssert.assertAll();
		 
		   System.out.println("TC027_Bulk_Update Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC027_Bulk_Update Passed"); 
		 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC027_Bulk_Update Failed");
					   
					//  test.log(LogStatus.FAIL, "TC027_Bulk_Update Failed"); 
                Assert.fail(e.getMessage());
						 
					}
		
		
		      }
	
		
}
