package testRepository.GR.bulkUpdate_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.bulkUpdatePage;
import pages.reDosPage;
import base.base;

public class R_TC_07p2 extends base 
{
	@Test
		public void VerifyRequestCancl_ReqOverFlow() throws IOException
		{
	   try{
				 
            bulkUpdatePage bulkUpdateObj=new bulkUpdatePage(); 
	 		 HomePage homePageObj=new HomePage();

	 		Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 	
	 		homePageObj.openModule("Search & View");
	 		
	 		Thread.sleep(4000);
	 		
	 		//Click on Upload link
	 		bulkUpdateObj.clickUploadLink_SearchView();
	 		
	 		//Select appropriate fields and click apply Filter
	        Thread.sleep(4000);
	 		
	        bulkUpdateObj.ApplyFilter();
	 	   
	 	  Thread.sleep(4000);
	 	  
	 	 
	 	  
	 	  
	 	   //click on RequestId Link
	 	 bulkUpdateObj.readStatus_uploadhistory();
	 	   
	 	 Thread.sleep(4000);
	 	   
      
	 	 
	 		
	 	   Thread.sleep(4000);
	 		
		 	  
	      
	  //    test.log(LogStatus.INFO, "Downloaded File name->"+fileName);
	 		
	 		
	 		//Click on Request id link
	 	//	reDosObj.clickRequestId
	 		 
	 	
	 		
			
        SoftAssert softAssert = new SoftAssert();
	       
	    //   softAssert.assertTrue(flag, "Input data Link not working");
		   softAssert.assertAll();
		   System.out.println("TC007p2_BulkUpdate Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC007p2_BulkUpdate Passed"); 
	}
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC007p2_BulkUpdate Failed");
					   
					//  test.log(LogStatus.FAIL, "TC007p2_BulkUpdate Failed"); 
				  System.out.println(e.getMessage());
				
				Assert.fail(e.getMessage());
						 
					}
		
		
		      }
	
		
}
