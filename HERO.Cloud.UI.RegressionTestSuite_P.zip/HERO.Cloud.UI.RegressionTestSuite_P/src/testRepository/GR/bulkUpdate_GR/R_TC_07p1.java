package testRepository.GR.bulkUpdate_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.bulkUpdatePage;
import pages.reDosPage;
import base.base;

public class R_TC_07p1 extends base 
{
	@Test
		public void DownloadInputFile_ReqOverflow() throws IOException
		{
	
try{
				 
		
	    	 bulkUpdatePage bulkUpdateObj=new bulkUpdatePage(); 
	 		 HomePage homePageObj=new HomePage();
             Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 		homePageObj.openModule("Search & View");
	 		
	 		 String  Downloadpath=getPropertyFileValue("DownloadFilepath");
	         System.out.println("Downloadpath->"+Downloadpath);
	         
	 		Thread.sleep(4000);
	 		
	 		//Click on Upload link
	 		bulkUpdateObj.clickUploadLink_SearchView();
	 		
	 		//Select appropriate fields and click apply Filter
	        Thread.sleep(4000);
	 		
	        bulkUpdateObj.ApplyFilter();
	 	   
	 	  Thread.sleep(4000);
	 	   //click on RequestId Link
	 	 bulkUpdateObj.clickRequestIdLink();
	 	   
	 	 Thread.sleep(4000);
	 	   
         //click on input data file link
	 	bulkUpdateObj.DownloadInputFile_RequestWorkflow();
	 	 
	 	 
	 	 
	 		
	 	   Thread.sleep(4000);
	 		//  test.log(LogStatus.INFO, "Getting Downloaded File Name");
		 	  File getLatestFile = base.getLatestFilefromDir(Downloadpath);
		 	  boolean flag=false;
		 	  String fileName = getLatestFile.getName();
		 	    
		 	  if (fileName!=null)
		 	  {
		 		 flag=true;  
		 	  }
		 	  
	        System.out.println("Downloaded File name->"+fileName);
		 	System.out.println("flag->"+flag);
	  //    test.log(LogStatus.INFO, "Downloaded File name->"+fileName);
	 		
	 		
	 		//Click on Request id link
	 	//	reDosObj.clickRequestId
	 		 
	 	
	 		
			
        SoftAssert softAssert = new SoftAssert();
	       
	       softAssert.assertTrue(flag, "Input data Link not working");
		   softAssert.assertAll();
		   System.out.println("TC07p1_BulkUpdate Passed");
		      
		    //  test.log(LogStatus.PASS, "TC013p1_Redo Passed"); 
	 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC07p1_BulkUpdate Failed");
				//  test.log(LogStatus.FAIL, "TC07p1_BulkUpdate Failed"); 
             Assert.fail(e.getMessage());
						 
					}
		
		
		      }
	
		
}
