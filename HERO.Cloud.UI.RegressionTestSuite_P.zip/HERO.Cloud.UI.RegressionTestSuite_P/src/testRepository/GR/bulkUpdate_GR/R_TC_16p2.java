package testRepository.GR.bulkUpdate_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.bulkUpdatePage;
import pages.reDosPage;
import base.base;

public class R_TC_16p2 extends base 
{
	@Test
		public void VerifyRequestedByDropDownValues() throws IOException
		{
	
				
	     try{
				 
		
	    	 bulkUpdatePage bulkUpdateObj=new bulkUpdatePage(); 
	 		 HomePage homePageObj=new HomePage();
             Thread.sleep(3000);

	 		homePageObj.mouseHoverSearchAndView();	
	 		homePageObj.openModule("File Upload");
	 		
	 		Thread.sleep(4000);   
	 		//Verifying Dropdown values for fields present in Filter section
	 		
	 		List<String> RequestedByActualValues=bulkUpdateObj.getDropdownValues_RequestedBy();
	 	
	 		
	 		//Go to user Profile to get active list of user
	 		homePageObj.mouseHoverAdministration();
	 		homePageObj.openModule("User Profile");
	 	    Thread.sleep(3000);
	 	    
	 	   List<String> ActiveUserlist=bulkUpdateObj.activeUserList_userProfile();
	 	
           SoftAssert softAssert = new SoftAssert();       
           softAssert.assertTrue(RequestedByActualValues.containsAll(ActiveUserlist) && ActiveUserlist.containsAll(RequestedByActualValues), "Incorrect set of user found in RequestedBy DropDown");
      
		   System.out.println("TC016p2_Bulk_Update Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC016p2_Bulk_Update Passed"); 
	 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC016p2_Bulk_Update Failed");
					   
					//  test.log(LogStatus.FAIL, "TC016p2_Bulk_Update Failed"); 
                  Assert.fail(e.getMessage());
						 
					}
	         }
	}
