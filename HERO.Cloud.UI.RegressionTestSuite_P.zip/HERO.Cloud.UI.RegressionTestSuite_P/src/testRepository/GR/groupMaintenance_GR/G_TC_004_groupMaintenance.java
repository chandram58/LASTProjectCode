package testRepository.GR.groupMaintenance_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.GroupMaintenancePage;
import pages.HomePage;
import pages.RolesManagementPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class G_TC_004_groupMaintenance extends base
{
		@Test
		public void VerifySearchGroupFunctionality() throws IOException, InterruptedException
		{
			 Thread.sleep(10000);
			 HomePage homePageObj=new HomePage();
			 homePageObj.mouseHoverAdministration();	
			 Thread.sleep(3000);
			 homePageObj.openModule("Group Maintenance");
			 GroupMaintenancePage groupMaintenancePage=new GroupMaintenancePage();	
			 String searchterm="123";
			 groupMaintenancePage.inputTxt_Searchbox(searchterm);
			 
			 List<WebElement> serachResult_rows=groupMaintenancePage.getSearchResult();
			 System.out.println("Number of rows in SearchResult->"+serachResult_rows.size());
		       
		    try{  
		      SoftAssert softAssert = new SoftAssert();
		      for(int i=0;i<serachResult_rows.size();i++)
		      {
		    	 softAssert.assertTrue(serachResult_rows.get(i).getText().replace("\n", " ").toLowerCase().contains(searchterm),"row no "+i+" does not contain search term");   
		      }
			softAssert.assertAll();
			System.out.println("G_TC_004_groupMaintenance Passed");
			
				 }
		catch(Throwable e)
				{
		System.out.println("G_TC_004_groupMaintenance Failed");
	    //test.log(LogStatus.FAIL, "G_TC_004_groupMaintenance Failed"); 
		Assert.fail(e.getMessage());
						     
				}
	
	      }
		}
	