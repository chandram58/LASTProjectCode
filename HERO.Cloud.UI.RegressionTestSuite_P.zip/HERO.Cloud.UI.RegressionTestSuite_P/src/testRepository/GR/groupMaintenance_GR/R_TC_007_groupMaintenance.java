package testRepository.GR.groupMaintenance_GR;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.GroupMaintenancePage;
import pages.HomePage;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_007_groupMaintenance extends base
{
	@Test
		public void MandatoryFieldValidationNewGroup() throws IOException, InterruptedException
		{
		Thread.sleep(10000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(3000);
		homePageObj.openModule("Group Maintenance");
		GroupMaintenancePage groupMaintenancePage=new GroupMaintenancePage();	
			
        Thread.sleep(2000);
        try
	    { 
        
	  //test.log(LogStatus.INFO, "Clicking on Add New Group button");
        groupMaintenancePage.clickAddNewGroup();
        Thread.sleep(2000);
        groupMaintenancePage.clickSave_NewGroup();  
		
        String GroupNameValidationMsg=groupMaintenancePage.getMandatoryValidationGpName();
        System.out.println("GroupNameValidationMsg->"+GroupNameValidationMsg);
			  
	    String DescValidationMsg=groupMaintenancePage.getMandatoryValidationDesc();
	    System.out.println("DescValidationMsg->"+DescValidationMsg);
		
	    String StartDtValidationMsg=groupMaintenancePage.getMandatoryValidationStartDt();
	    System.out.println("StartDtValidationMsg->"+StartDtValidationMsg);
		
	    String EndDtValidationMsg=groupMaintenancePage.getMandatoryValidationEndDt();
	    System.out.println("EndDtValidationMsg->"+EndDtValidationMsg);
			
        SoftAssert softassert = new SoftAssert();
        softassert.assertFalse(GroupNameValidationMsg.isEmpty(), "Validation message not Populated");
        softassert.assertTrue((GroupNameValidationMsg.toLowerCase()).contains("group name is required."), "Validation message not coming properly");
        
        softassert.assertFalse(DescValidationMsg.isEmpty(), "Validation message not Populated");
        softassert.assertTrue((DescValidationMsg.toLowerCase()).contains("description is required."), "Validation message not coming properly");
        
        softassert.assertFalse(StartDtValidationMsg.isEmpty(), "Validation message not Populated");
        softassert.assertTrue((StartDtValidationMsg.toLowerCase()).contains("start date is required."), "Validation message not coming properly");
        
        softassert.assertFalse(EndDtValidationMsg.isEmpty(), "Validation message not Populated");
        softassert.assertTrue((EndDtValidationMsg.toLowerCase()).contains("End Date is req"), "Validation message not coming properly");
			  
        softassert.assertAll();
		
        System.out.println("R_TC007_groupMaintenance Passed");
		}
	catch(Throwable e)
	  {
	//  test.log(LogStatus.FAIL, "R_TC007_groupMaintenance Failed");
		System.out.println("R_TC007_groupMaintenance Failed");		        
				      }
          }
	
	}
