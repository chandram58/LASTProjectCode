package testRepository.GR.groupMaintenance_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.GroupMaintenancePage;
import pages.HomePage;
import pages.UserProfilePage;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC_011_groupMaintenance extends base
{
		@Test
		public void ActiveUsershowninNewGroupPage() throws IOException, InterruptedException
		{
			//Going to User Profile Page
		   Thread.sleep(10000);
	        HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("User Profile");
			UserProfilePage userProfilePage=new UserProfilePage();	
			Thread.sleep(6000);
			List<String> activeUserList_UserProfile=userProfilePage.getactiveUserNameAndUserIdasList();
			Collections.sort(activeUserList_UserProfile);
			System.out.println("activeUserList_UserProfile->"+activeUserList_UserProfile);
			
			//Now going to Group Maintenance Page
			Thread.sleep(3000);
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Group Maintenance");
			GroupMaintenancePage groupMaintenancePage=new GroupMaintenancePage();
			
		
			
             // test.log(LogStatus.INFO, "Clicking on Add New Group button");
			String groupName=getAlphaNumericString(24);
			groupMaintenancePage.clickAddNewGroup();
			
			groupMaintenancePage.inputNewGroupName(groupName);
			groupMaintenancePage.inputNewGrpDescription("Automation");
			
			groupMaintenancePage.clickSelectUsers_NewGroup();
			List<String> activeUserList_GroupMaintenance=groupMaintenancePage.getUserListGrpmaintenance();
			Collections.sort(activeUserList_GroupMaintenance);
		    System.out.println("activeUserList_GroupMaintenance->"+activeUserList_GroupMaintenance);
             try
			    {
			 SoftAssert softassert = new SoftAssert();
			 softassert.assertTrue(activeUserList_UserProfile.containsAll(activeUserList_GroupMaintenance) && activeUserList_GroupMaintenance.containsAll(activeUserList_UserProfile), "Active user list in User profile and Group maintenance not matching");
			 softassert.assertAll();
				 
		     System.out.println("R_TC_011_groupMaintenance Passed");
		          }
	catch(Throwable e)
				{
			System.out.println("R_TC_011_groupMaintenance Failed");
		//  test.log(LogStatus.FAIL, "TC024_groupMaintenance Failed");
			Assert.fail(e.getMessage());
						     }
	         }
	}
