package testRepository.GR.groupMaintenance_GR;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.DateUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.GroupMaintenancePage;
import pages.HomePage;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class G_TC_025_groupMaintenance extends base
{
	@Test
		public void DateValidations() throws Exception
		{ 
		 HomePage homePageObj=new HomePage();
		 homePageObj.mouseHoverAdministration();	
		 Thread.sleep(3000);
		 homePageObj.openModule("Group Maintenance");
		 GroupMaintenancePage groupMaintenancePage=new GroupMaintenancePage();	
         Thread.sleep(3000);
			 
		// test.log(LogStatus.INFO, "Clicking on Add New Role button");
         groupMaintenancePage.clickAddNewGroup();
 		
 		String groupName=getAlphaNumericString(24);
 		groupMaintenancePage.clickAddNewGroup();
 		groupMaintenancePage.inputNewGroupName(groupName);
 		groupMaintenancePage.inputNewGrpDescription("Automation");

 		groupMaintenancePage.selectFirstUserToGroup();       
	    
 		//Trying to Enter Start date as Tomorrow date
	    String tomorrowDate = base.getDate(+1);
		System.out.println("Tomorrow date is->"+tomorrowDate); //print Tomorrow date
        
	    //Editing Group Start date as past date
		groupMaintenancePage.clearGroupStartDt();  
	    Thread.sleep(2000);
	    
	// groupMaintenancePage.inputStartDt(yesterdayDate);
      String ValidationError1=groupMaintenancePage.getMandatoryValidationStartDt();
	System.out.println("Error when No start date present->"+ValidationError1);
	    
	   
	//Second validation -
	 groupMaintenancePage.inputStartDt(tomorrowDate);
	   
	   groupMaintenancePage.clearGroupEndDt(); 
	   groupMaintenancePage.clickonTodaybtn();  
	     
	   groupMaintenancePage.clickDecline_confirmbox();
	   Thread.sleep(2000);
	     
	   String ValidationError2=groupMaintenancePage.getErrorUserEndDateLesserThanGroupEndDate();
	   System.out.println("ValidationError2->"+ValidationError2);

	   try
	   {
	    SoftAssert softassert = new SoftAssert();
	   softassert.assertTrue(ValidationError1.contains("Start Date is required"), "Past date Validation for Start date not working"); 
		softassert.assertTrue(ValidationError2.contains("User end date should be lesser than group end date"), "User end date is allowed to be greater than group end date"); 
	    softassert.assertAll();
        System.out.println("G_TC_25_groupMaintenance Passed");
				
	   }
	   catch(Throwable e)
	   {
	   System.out.println("G_TC_25_groupMaintenance Failed");
   //  test.log(LogStatus.FAIL, "G_TC_25_groupMaintenance Failed");
	   Assert.fail(e.getMessage());
			}
	
		}
	}
