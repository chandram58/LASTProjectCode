package testRepository.GR.groupMaintenance_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.GroupMaintenancePage;
import pages.HomePage;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class G_TC_010_groupMaintenance extends base
{
	@Test
   public void AddNewGroup() throws IOException, InterruptedException
		{
        Thread.sleep(10000);
        HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(3000);
		homePageObj.openModule("Group Maintenance");
		GroupMaintenancePage groupMaintenancePage=new GroupMaintenancePage();	
		Thread.sleep(3000);
        // test.log(LogStatus.INFO, "Clicking on Add New Role button");
			
		String groupName=getAlphaNumericString(24);
		groupMaintenancePage.clickAddNewGroup();
		
		groupMaintenancePage.inputNewGroupName(groupName);
		groupMaintenancePage.inputNewGrpDescription("Automation");
		groupMaintenancePage.selectFirstUserToGroup();
		//click on Save button on New Role Page
		groupMaintenancePage.clickSave_NewGroup();
		driver.switchTo().defaultContent();
		String Message=groupMaintenancePage.getSuccessMessage("new");
		System.out.println("Message->"+Message);
	
		boolean flag=groupMaintenancePage.validateGroupCreated(groupName);
		
		try
		    {
			 SoftAssert softassert = new SoftAssert();
			 softassert.assertTrue(Message.contains("Group has been created successfully"), "User not Received Success message"); 
		     softassert.assertTrue(flag,"New created group not found on Group Maintenance Table");
			 softassert.assertAll();
			 
			 System.out.println("G_TC_010_groupMaintenance Passed");
			 }
		     catch(Throwable e)
			{
	         System.out.println("G_TC_010_groupMaintenance Failed");
	  //  test.log(LogStatus.FAIL, "G_TC_010_groupMaintenance Failed"); 
             Assert.fail(e.getMessage());
						     
		    }
	    }
	}
