package testRepository.GR.groupMaintenance_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.GroupMaintenancePage;
import pages.HomePage;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC_013_groupMaintenance extends base
{
		@Test
		public void SameUserNotAddedtoOtherGroupValidation() throws IOException, InterruptedException
		{
			 HomePage homePageObj=new HomePage();
			 homePageObj.mouseHoverAdministration();	
			 Thread.sleep(3000);
			 homePageObj.openModule("Group Maintenance");
			 GroupMaintenancePage groupMaintenancePage=new GroupMaintenancePage();	
             Thread.sleep(3000);
			
             // test.log(LogStatus.INFO, "Clicking on Add New Role button");
			  
            String groupName=getAlphaNumericString(24);
     		groupMaintenancePage.clickAddNewGroup();
     		
     		groupMaintenancePage.inputNewGroupName(groupName);
     		groupMaintenancePage.inputNewGrpDescription("Automation");
			 
     		groupMaintenancePage.selectAnotherGroupUserToGroup();
			Thread.sleep(3000);  
	        String Validationmessage=groupMaintenancePage.getErrorMessageUserAlreadyExistsinOtherGp();
	    	 System.out.println("Validationmessage->"+Validationmessage);
			try
			    {
			    SoftAssert softassert = new SoftAssert();
			    softassert.assertTrue(Validationmessage.contains("The selected user already exists in another group"),"Validation message not matching with expected message");
				softassert.assertAll();
				 
				    System.out.println("R_TC_013_groupMaintenance Passed");
				//  test.log(LogStatus.PASS, "R_TC_013_groupMaintenance Passed"); 
				   
	             }
		 catch(Throwable e)
				     {
					   System.out.println("R_TC_013_groupMaintenance Failed");
					 //  test.log(LogStatus.FAIL, "R_TC_013_groupMaintenance Failed"); 

					  }
			}
}
