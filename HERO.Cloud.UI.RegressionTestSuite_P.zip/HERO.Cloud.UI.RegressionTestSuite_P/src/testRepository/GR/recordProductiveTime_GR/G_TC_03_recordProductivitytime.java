package testRepository.GR.recordProductiveTime_GR;

import java.io.IOException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.RecordProductivityTimePage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class G_TC_03_recordProductivitytime extends base
{	
	@Test
		public void ProductiveHourtrackingLogoutLogin() throws IOException
		{
          try{
				 
			 Thread.sleep(5000);
			  HomePage homePageObj=new HomePage();
			  homePageObj.mouseHoverDashboard();	
			  Thread.sleep(3000);
			  homePageObj.openModule("User Dashboard");
			  RecordProductivityTimePage rptPage=new RecordProductivityTimePage();  
			  WebElement Toggle=rptPage.getToggle();
		
			 String Productivetimeclock1Beforelogout=rptPage.getToggleActiveTime();
			 System.out.println("Procuctive time before log out->"+Productivetimeclock1Beforelogout);
			 
			//Click on Logout button
			 rptPage.clickLogout();
			 rptPage.closeApp();
			 Thread.sleep(3000);
			 launchApp();
		     Thread.sleep(10000);
			  
			  String Productivetimeclock1Afterlogin=rptPage.getToggleActiveTime();;
			 System.out.println("Procuctive time after log in->"+Productivetimeclock1Afterlogin);
		
			 Thread.sleep(60000);
			
			 String Productivetimeclock1AfterLoginandwait=rptPage.getToggleActiveTime();
			 System.out.println("Procuctive time after wait->"+Productivetimeclock1AfterLoginandwait);
			 
		
			 
			
			SoftAssert softAssert = new SoftAssert();
		     
		   //  test.log(LogStatus.INFO ,"Verifying page Title");
		     
	    softAssert.assertTrue(Productivetimeclock1Afterlogin.compareTo(Productivetimeclock1Beforelogout)>=0, "Productive Hour is not getting paused after logout");
	    softAssert.assertFalse(Productivetimeclock1Afterlogin.equals(Productivetimeclock1AfterLoginandwait), "Productive Hour not tracked after login is paused");     
	    softAssert.assertTrue(Productivetimeclock1AfterLoginandwait.compareTo(Productivetimeclock1Afterlogin)>0, "Productive Hour is paused after login");    
		
	    softAssert.assertAll();
		System.out.println("G_TC_03_recordProductivitytime Passed");
    //  test.log(LogStatus.FAIL, "G_TC_03_recordProductivitytime Passed"); 
		 }
				   
	    catch(Throwable e)
				     {
					   System.out.println("G_TC_03_recordProductivitytime Failed");
					// test.log(LogStatus.FAIL, "G_TC_03_recordProductivitytime Failed"); 

					  System.out.println(e.getMessage());
			        //  Assert.fail(e.getMessage());
				     }
               }
	}
