package testRepository.GR.recordProductiveTime_GR;

import java.io.IOException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainReasonCodesPage;
import pages.RecordProductivityTimePage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_07_recordProductivitytime extends base
{
		@Test
		public void verifyingToggleTimewithActiveHours() throws IOException
		{
	      try{
	    	  HomePage homePageObj=new HomePage();
			  homePageObj.mouseHoverDashboard();	
			  Thread.sleep(3000);
			  homePageObj.openModule("User Dashboard");
			RecordProductivityTimePage rptPage=new RecordProductivityTimePage(); 
			
			  String activeTime_Toggle=rptPage.getToggleActiveTime();
			  String[] duration = activeTime_Toggle.split(":");
			  int activeTime_Toggle_Min=Integer.parseInt(duration[0])*60+Integer.parseInt(duration[1]);
			  
			  System.out.println("activeTime_Toggle_min->"+activeTime_Toggle_Min);
			  
			
			  
			  String activeTime_ActiveHours=rptPage.getActiveHoursUserDashboard().replace("(", "").replace(")", "").replace(".", ":");
			  System.out.println("activeTime_ActiveHours->"+activeTime_ActiveHours);
			  
			  String[] parts = activeTime_ActiveHours.split(":");
			  System.out.println("parts[0]->"+parts[0]);
			  System.out.println("parts[1]->"+parts[1]);
			  
			  int activeTime_ActiveHours_Min=Integer.parseInt(parts[0])*60+Integer.parseInt(parts[1]);
			  System.out.println("activeTime_ActiveHours_Min->"+activeTime_ActiveHours_Min); 
			 
			  
			SoftAssert softassert=new SoftAssert();
			softassert.assertTrue(activeTime_Toggle_Min==activeTime_ActiveHours_Min,"Active hour not matching between toggle and Active hours on User dashboard page" );
		    softassert.assertAll();
		      
		    System.out.println("G_TC_07_recordProductivitytime Passed");
		//  test.log(LogStatus.PASS, "G_TC_07_recordProductivitytime Passed"); 
		}

	   catch(Throwable e)
	   {
	  System.out.println("G_TC_07_recordProductivitytime Failed");
     // test.log(LogStatus.FAIL, "G_TC_07_recordProductivitytime Failed"); 
      System.out.println(e.getMessage());
    //  Assert.fail(e.getMessage());
						      }
	            }
		}
