package testRepository.GR.recordProductiveTime_GR;

import java.io.IOException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainReasonCodesPage;
import pages.RecordProductivityTimePage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class G_TC_06_recordProductivitytime extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void verifyingToggleandClockPresence() throws IOException
		{
	      try{
	    	  HomePage homePageObj=new HomePage();
			  homePageObj.mouseHoverDashboard();	
			  Thread.sleep(3000);
			  homePageObj.openModule("User Dashboard");
			RecordProductivityTimePage rptPage=new RecordProductivityTimePage(); 
			
			  
			WebElement Toggle=rptPage.getToggle();
			WebElement Clock=rptPage.getClock();
		     
			
			SoftAssert softassert=new SoftAssert();
			softassert.assertTrue(Toggle.isDisplayed(), "Toggle button is not present");
			softassert.assertTrue(Clock.isDisplayed(), "Clock is not present");
		    softassert.assertAll();
		      
		    System.out.println("G_TC_06_recordProductivitytime Passed");
		//  test.log(LogStatus.PASS, "G_TC_06_recordProductivitytime Passed"); 
		}

	   catch(Throwable e)
	   {
	  System.out.println("G_TC_06_recordProductivitytime Failed");
     // test.log(LogStatus.FAIL, "G_TC_06_recordProductivitytime Failed"); 
      System.out.println(e.getMessage());
    //  Assert.fail(e.getMessage());
						      }
	            }
		}
