package testRepository.GR.recordProductiveTime_GR;

import java.io.IOException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainReasonCodesPage;
import pages.RecordProductivityTimePage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_09_recordProductivitytime extends base
{
		@Test
		public void verifyingToggleReasonCodeList() throws IOException
		{
	      try{
	    	  HomePage homePageObj=new HomePage();
			  homePageObj.mouseHoverAdministration();
			  Thread.sleep(3000);
			  homePageObj.openModule("Maintain Reason Codes");
			 MaintainReasonCodesPage mrcPage=new MaintainReasonCodesPage();
			 
			 List<String> ActiveReasonCodeList_UI= mrcPage.getActiveCodesList("Code Name");
			 System.out.println("ActiveReasonCodeList_UI->"+ActiveReasonCodeList_UI);
			 Thread.sleep(6000); 
			 
			RecordProductivityTimePage rptPage=new RecordProductivityTimePage();
			WebElement toggle=rptPage.getToggle();
			toggle.click();
			toggle.click();
			
			rptPage.clicktoggleResonDropdown();
			
			List<String> ReasonCodeList_toggle= rptPage.reasonListToggle();
			 System.out.println("ReasonCodeList_toggle->"+ReasonCodeList_toggle);
			
		    SoftAssert softassert=new SoftAssert();
			softassert.assertTrue(ReasonCodeList_toggle.containsAll(ActiveReasonCodeList_UI) && ActiveReasonCodeList_UI.containsAll(ReasonCodeList_toggle) );
		    softassert.assertAll();
		      
		    System.out.println("R_TC_09_recordProductivitytime Passed");
		//  test.log(LogStatus.PASS, "R_TC_09_recordProductivitytime Passed"); 
		}

	   catch(Throwable e)
	   {
	  System.out.println("R_TC_09_recordProductivitytime Failed");
     // test.log(LogStatus.FAIL, "R_TC_09_recordProductivitytime Failed"); 
      System.out.println(e.getMessage());
    //  Assert.fail(e.getMessage());
						      }
	            }
		}
