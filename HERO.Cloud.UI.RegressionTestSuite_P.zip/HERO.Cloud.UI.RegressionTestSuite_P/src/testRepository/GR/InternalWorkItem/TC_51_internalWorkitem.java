package testRepository.GR.InternalWorkItem;

import java.util.Iterator;
import java.util.Set;


import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class TC_51_internalWorkitem extends base{
	@Test
	public void get835Dataviewfunctionality() throws InterruptedException {
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		 InternalwrkItmpageobj.clickonDemandDraw();
		 InternalwrkItmpageobj.getClaimNumber("3052020382");
		 Thread.sleep(6000);
		 InternalwrkItmpageobj.clickonSearchbtn();
		 Thread.sleep(3000);
		 InternalwrkItmpageobj.clickonWorkitem().click();
		 InternalwrkItmpageobj.clickonOkbtn();
		 InternalwrkItmpageobj.clickon837hyperlink();
		 Thread.sleep(6000);
		//Get all the window handles in a set
		 Set <String> handles =driver.getWindowHandles();
		 Iterator<String> it = handles.iterator();
		 //iterate through your windows
		 try {
		 while (it.hasNext()) {
		 String parent = it.next();
		 String newwin = it.next();
		 driver.switchTo().window(newwin);
		 //perform actions on new window
		 //driver.close();
		 
	String 	PageTitle= InternalwrkItmpageobj.getpagetitlefor837Details().getText();
	System.out.println(PageTitle);
	 Thread.sleep(6000);
	WebElement fieldname=InternalwrkItmpageobj.getfieldsof837details();
	String fields1=fieldname.getAttribute("readOnly");
	System.out.println(fields1);
		 
	 driver.close(); //closing child window
     driver.switchTo().window(parent);
	
		SoftAssert softAssert = new SoftAssert();   
	
		
		 softAssert.assertTrue(true, "837 field are editble");
		 softAssert.assertTrue(PageTitle.contains("837"), "837 details page is not opened");
		
		 softAssert.assertAll();
		
	
		 System.out.println("TC51_internalWorkitem is passed");
}
		 }
  catch(Throwable e)
    {
			   //System.out.println("staus of work item is not updating in DB");
			   System.out.println("TC51_internalWorkitem is failed");
			   Assert.fail(e.getMessage());
			   
    }
		 
	}

}
