package testRepository.GR.InternalWorkItem;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class R_TC_35_36_internalWorkitem extends base{
	@Test
	public void getmovefrdfunctionality() throws InterruptedException, SQLException {
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		 InternalwrkItmpageobj.clickonDemandDraw();
		 InternalwrkItmpageobj.clickselectQueueDropdown_DemandDraw();
		 InternalwrkItmpageobj.selectOptionselectQueueDropdown_DemandDraw("Contract owner queue");
		 
		 InternalwrkItmpageobj.clickselectStatusDropdown_DemandDraw();
		 InternalwrkItmpageobj.selectOptionselectStatusDropdown_DemandDraw("Unassigned");
		 
		// InternalwrkItmpageobj.getClaimNumber("6250000007469");
		 InternalwrkItmpageobj.clickonSearchbtn();
		 Thread.sleep(3000);
		 InternalwrkItmpageobj.clickonWorkitem().click();
		 InternalwrkItmpageobj.clickonOkbtn();
		 String Claim=	 InternalwrkItmpageobj.getPageTitle_claim().getText();
			System.out.println(Claim);
			String CLAIM_ID=null,Queue_ID=null,User_ID=null,WORK_ITEM_VERSION_ID=null,WORK_ITEM_STATUS=null;
			String Query1="Select*from HERO_UI_WORK_ITEMS where CLAIM_ID like '"+Claim.trim()+"'";
			System.out.println(Query1);
			  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
			  rs = readStatement.executeQuery();
			  rs.next();
			  System.out.println(Query1);
			 
			  CLAIM_ID=rs.getString(4);
			  System.out.println(CLAIM_ID);
			  Queue_ID=rs.getString(7);
			  System.out.println(Queue_ID);
			  User_ID=rs.getString(8);
			  System.out.println(User_ID);
			  WORK_ITEM_VERSION_ID=rs.getString(5);
			  System.out.println(WORK_ITEM_VERSION_ID);
			  WORK_ITEM_STATUS=rs.getString(9);
			  System.out.println(WORK_ITEM_STATUS);
			  
		  int x=Integer.parseInt(WORK_ITEM_VERSION_ID);
		  System.out.println(x);
			  
			  try {
					SoftAssert softAssert = new SoftAssert();   
				
					
					 softAssert.assertTrue(WORK_ITEM_STATUS.contains("Assigned"), "workitem version is not assigned");
					 softAssert.assertTrue(User_ID.equals("User_ID"), "workitem version is not assigned");
					 softAssert.assertTrue(Queue_ID.equals("queueid10"), " Queue is not assigned");
					 softAssert.assertAll();
					System.out.println("workitem assigned to user");
				
			}
			  catch(Throwable e)
			    {
						   System.out.println("staus of work item is not updating in DB");
						   Assert.fail(e.getMessage());
			    }
			  Thread.sleep(2000);
			  InternalwrkItmpageobj.clickonMovefrd().click();  
			  InternalwrkItmpageobj.clickonOkbtn();
			  Thread.sleep(6000);
			  String Query2="Select*from enc.HERO_UI_WORK_ITEMS where CLAIM_ID like '"+CLAIM_ID.trim()+"'";
				
			  PreparedStatement readStatement1 = dbcon.prepareStatement(Query2);
			  rs = readStatement1.executeQuery();
			  rs.next();
			  
			  CLAIM_ID=rs.getString(4);
			  System.out.println(CLAIM_ID);
			  Queue_ID=rs.getString(7);
			  System.out.println(Queue_ID);
			  User_ID=rs.getString(8);
			  System.out.println(User_ID);
			  WORK_ITEM_VERSION_ID=rs.getString(5);
			  System.out.println(WORK_ITEM_VERSION_ID);
			  WORK_ITEM_STATUS=rs.getString(9);
			  System.out.println(WORK_ITEM_STATUS);
			  
		//	int   y=x+1;
			  try {
					SoftAssert softAssert = new SoftAssert();   
				
					
					 softAssert.assertTrue(WORK_ITEM_STATUS.contains("Completed"), "workitem status is not changed ");
					 softAssert.assertTrue(User_ID.contains(User_ID), "workitem assigned is not user");
					 softAssert.assertTrue(Queue_ID.contains("EPSSMOVEFORD"), " Queue is not to another queue");
					 softAssert.assertAll();
					
				
					 System.out.println("TC35_36_internalWorkitem is passed");
			}
			  catch(Throwable e)
			    {
						   //System.out.println("staus of work item is not updating in DB");
						   System.out.println("TC35_36_internalWorkitem is failed");
						   Assert.fail(e.getMessage());
						   
			    }
			  		 
	}

}
