package testRepository.GR.InternalWorkItem;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class TC56_internalWorkitem extends base{
	@Test
	public void getEnrollmentcheckhighlightedfield() throws InterruptedException {
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		 InternalwrkItmpageobj.clickonDemandDraw();
		 InternalwrkItmpageobj.getClaimNumber("3052020385");
		 InternalwrkItmpageobj.clickonSearchbtn();
		 Thread.sleep(3000);
		 InternalwrkItmpageobj.clickonWorkitem().click();
		 InternalwrkItmpageobj.clickonOkbtn();
		 
		 InternalwrkItmpageobj.clickonCfEmpNo().click();
	String cf_Emp=InternalwrkItmpageobj.getCFEmpno().getAttribute("class");
	System.out.println(cf_Emp);
	try {
		  SoftAssert softAssert = new SoftAssert();   
		 // p-inputtext p-component p-filled ng-pristine ng-valid text-highlight ng-touched
		  softAssert.assertTrue(cf_Emp.contains("text-highlight"), "CF_prov filed is not highlighted");
			 softAssert.assertAll();
			 System.out.println("TC56_internal workitem is passed");
	  }
	  catch(Throwable e)
	    {
				   
				   System.out.println("TC56_internalWorkitem is failed");
				   Assert.fail(e.getMessage());
				   
	    }
	}

}
