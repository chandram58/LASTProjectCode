package testRepository.GR.InternalWorkItem;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class G_TC44_internalWorkitem extends base{
	@Test
	public void getCancelbtnincasSce() throws InterruptedException {
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		
		 InternalwrkItmpageobj.clickonDrawnextItem();
	String Claim=	 InternalwrkItmpageobj.getPageTitle_claim().getText();
	System.out.println(Claim);
	
	
	WebElement cancel=InternalwrkItmpageobj.clickonCancelbtn();
	System.out.println(cancel.getText());
	try {
		SoftAssert softAssert = new SoftAssert();   
	
		 softAssert.assertTrue(cancel.isDisplayed(), "Cancel action btn is not displayed");
		 softAssert.assertAll();
		  System.out.println("TC_44_internalWorkitem is passed");
				}
				
	catch(Throwable e)
	    {
				   System.out.println("TC_44_internalWorkitem Failed");
				   Assert.fail(e.getMessage());
	    }
	}

}
