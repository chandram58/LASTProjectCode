package testRepository.GR.InternalWorkItem;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class G_TC11_internalWorkItem  extends base{
	@Test
	public void getActionButtonsAvailibility() throws InterruptedException {
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		 InternalwrkItmpageobj.clickonDrawnextItem();
	String Claim=	 InternalwrkItmpageobj.getPageTitle_claim().getText();
	System.out.println(Claim);
	WebElement pend=InternalwrkItmpageobj.clickonPend();
	String pendbtn=pend.getText();
	System.out.println(pendbtn);
	WebElement rtrybtn=InternalwrkItmpageobj.clickonRetry();
	String retry=rtrybtn.getText();
	System.out.println(retry);
	WebElement mvfrd=InternalwrkItmpageobj.clickonMovefrd();
	System.out.println(mvfrd.getText());
	WebElement assgnQ=InternalwrkItmpageobj.clickonAssigntoQue();
	System.out.println(assgnQ.getText());
	//WebElement cancel=InternalwrkItmpageobj.clickonCancelbtn();
	//System.out.println(cancel.getText());
	
	try {
		SoftAssert softAssert = new SoftAssert();   
		 softAssert.assertTrue(pend.isDisplayed(), "pen action btn is not displayed");
		 softAssert.assertTrue(rtrybtn.isDisplayed(), "Retry action btn is not displayed");
		 softAssert.assertTrue(mvfrd.isDisplayed(), "Moveforward action btn is not displayed");
		 softAssert.assertTrue(assgnQ.isDisplayed(), "AssigntoQueue action btn is not displayed");
		// softAssert.assertTrue(cancel.isDisplayed(), "Cancel action btn is not displayed");
		 softAssert.assertAll();
		  System.out.println("TC_11_internalWorkitem is passed");
				}
				
	catch(Throwable e)
	    {
				   System.out.println("TC_11_internalWorkitem Failed");
				   Assert.fail(e.getMessage());
	    }
	}
	

}
