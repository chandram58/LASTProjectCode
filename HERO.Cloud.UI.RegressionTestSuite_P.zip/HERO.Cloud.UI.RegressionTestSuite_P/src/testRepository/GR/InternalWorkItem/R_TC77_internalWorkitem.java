package testRepository.GR.InternalWorkItem;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class R_TC77_internalWorkitem extends base{
	@Test
	public void getErrorcodesDB() throws InterruptedException, SQLException {
		 Thread.sleep(5000);
		 Thread.sleep(2000);
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverDashboard();
			homePageObj.openModule("User Dashboard");
			 Thread.sleep(3000);
			 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
			 Thread.sleep(5000);
			 InternalwrkItmpageobj.clickonDrawnextItem();
		String CLAIM_ID=	 InternalwrkItmpageobj.getPageTitle_claim().getText();
		System.out.println(CLAIM_ID);
		Thread.sleep(8000);
		//db response
		String ERROR_CODE_ID=null,ERROR_CODE=null,Error_Code_DB=null,ERROR_DESC=null,ERROR_CODE_name=null;
		String Query1="Select WORK_ITEM_SID,CLAIM_ID,WORK_ITEM_VERSION_ID,WORK_ITEM_STATUS,ERROR_CODE,ERROR_CODE_ID from HERO_UI_WORK_ITEMS where CLAIM_ID like '"+CLAIM_ID.trim()+"'";
		System.out.println(Query1);
		  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
		  rs = readStatement.executeQuery();
		  rs.next();
		  System.out.println(Query1);
		  ERROR_CODE_ID=rs.getString(6);
		  System.out.println(ERROR_CODE_ID);
		  ERROR_CODE=rs.getString(5);
		  System.out.println(ERROR_CODE);
		  
		  Thread.sleep(3000);
		  
		  String Query2="select*from enc.HERO_UI_WORK_ERROR_CODES where ERROR_CODE_ID like '"+ERROR_CODE_ID.trim()+"'";
			
		  PreparedStatement readStatement1 = dbcon.prepareStatement(Query2);
		  rs = readStatement1.executeQuery();
		  rs.next();
		  Error_Code_DB=rs.getString(1);
		  System.out.println(Error_Code_DB);
		  ERROR_CODE_name=rs.getString(2);
		  System.out.println(ERROR_CODE_name);
		  ERROR_DESC=rs.getString(5);
		  System.out.println(ERROR_DESC);
		  String Description_Error=ERROR_DESC;
		  
		  
		  try {
			  SoftAssert softAssert = new SoftAssert();   
				
				 softAssert.assertTrue(Error_Code_DB.equals(ERROR_CODE_ID), "Error code in workitem table is not matching with error code");
				 softAssert.assertTrue(ERROR_DESC.equals(Description_Error), "error code description is not getting");
				 softAssert.assertTrue(ERROR_CODE_name.equals(ERROR_CODE), "error code name is not matching with error code table");
				 softAssert.assertAll();
				 System.out.println("TC77_internal workitem is failed");
		  }
		  catch(Throwable e)
		    {
					   
					   System.out.println("TC77_internalWorkitem is failed");
					   Assert.fail(e.getMessage());
					   
		    }
		  
	}

}
