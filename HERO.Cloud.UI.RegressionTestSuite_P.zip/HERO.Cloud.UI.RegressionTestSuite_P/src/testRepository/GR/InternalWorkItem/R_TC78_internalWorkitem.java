package testRepository.GR.InternalWorkItem;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class R_TC78_internalWorkitem extends base{
	@Test
	public void getQueuefromDB() throws InterruptedException, SQLException {
	
	 Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		 InternalwrkItmpageobj.clickonDrawnextItem();
	String CLAIM_ID=	 InternalwrkItmpageobj.getPageTitle_claim().getText();
	System.out.println(CLAIM_ID);
	Thread.sleep(8000);
	
	//DB 
	
	String Queue_ID=null,Queue_Name=null,Queue_ID_DB=null;
	
	String Query1="Select*from HERO_UI_WORK_ITEMS where CLAIM_ID like '"+CLAIM_ID.trim()+"'";
	System.out.println(Query1);
	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
	  rs = readStatement.executeQuery();
	  rs.next();
	  System.out.println(Query1);
	  Queue_ID=rs.getString(7);
	  System.out.println(Queue_ID);
	  Thread.sleep(3000);
			
	  String Query2="select*from HERO_UI_QUEUES where Queue_ID like '"+Queue_ID.trim()+"'";
		
	  PreparedStatement readStatement1 = dbcon.prepareStatement(Query2);
	  rs = readStatement1.executeQuery();
	  rs.next();
	  Queue_ID_DB=rs.getString(1).toLowerCase();
	  System.out.println(Queue_ID_DB);
	  Queue_Name=rs.getString(2);
	  System.out.println(Queue_Name);
	  
	  try {
		  SoftAssert softAssert = new SoftAssert();   
			
			 softAssert.assertTrue(Queue_ID_DB.equals(Queue_ID), "Queue_ID is not matching with Queue Table");
			 softAssert.assertAll();
			 System.out.println("TC78_internal workitem is passed");
	  }
	  catch(Throwable e)
	    {
				   
				   System.out.println("TC78_internalWorkitem is failed");
				   Assert.fail(e.getMessage());
				   
	    }
	  }
	  
	

}
