package testRepository.GR.InternalWorkItem;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class TC55_internalWorkitem extends base{
	@Test
	public void getEPSSscenarioserrorfieldshiglight() throws InterruptedException {
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		 InternalwrkItmpageobj.clickonDemandDraw();
		 InternalwrkItmpageobj.getClaimNumber("3052020384");
		 InternalwrkItmpageobj.clickonSearchbtn();
		 Thread.sleep(3000);
		 InternalwrkItmpageobj.clickonWorkitem().click();
		 InternalwrkItmpageobj.clickonOkbtn();
		 InternalwrkItmpageobj.clickonCFProvraidiobtn().click();
		String CF_prov= InternalwrkItmpageobj.getCFProvraidiobtn().getAttribute("class");
		System.out.println(CF_prov);
		Thread.sleep(1000);
		InternalwrkItmpageobj.clickonCfpayeementmpa().click();
    String cf_payee=InternalwrkItmpageobj.getCFPayeeradiobtn().getAttribute("class");
		System.out.println(cf_payee);
		Thread.sleep(1000);
		InternalwrkItmpageobj.clickonCfppvdind().click();
		String cfpp=InternalwrkItmpageobj.getCFPPVDIND().getAttribute("class"); 
		System.out.println(cfpp);
		  try {
			  SoftAssert softAssert = new SoftAssert();   
			 // p-inputtext p-component p-filled ng-pristine ng-valid text-highlight ng-touched
			  softAssert.assertTrue(CF_prov.contains("text-highlight"), "CF_prov filed is not highlighted");
				 softAssert.assertTrue(cf_payee.contains("text-highlight"), "CF_payee filed is not highlighted");
				 softAssert.assertTrue(cfpp.contains("text-highlight"), "cf_pp_vd_ind filed is not highlighted");
				 softAssert.assertAll();
				 System.out.println("TC55_internal workitem is passed");
		  }
		  catch(Throwable e)
		    {
					   
					   System.out.println("TC55_internalWorkitem is failed");
					   Assert.fail(e.getMessage());
					   
		    }
		  }	
		 
	}


