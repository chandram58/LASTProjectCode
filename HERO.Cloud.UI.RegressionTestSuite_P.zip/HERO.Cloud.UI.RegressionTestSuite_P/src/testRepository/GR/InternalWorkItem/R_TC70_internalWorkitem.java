package testRepository.GR.InternalWorkItem;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class R_TC70_internalWorkitem extends base{
	@Test
	public void getNotesSection() throws InterruptedException {
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		 InternalwrkItmpageobj.clickonDrawnextItem();
		 
		 WebElement NotesSection=InternalwrkItmpageobj.getnotesSection();
		  System.out.println(NotesSection.getText());	
			try {
				SoftAssert softAssert = new SoftAssert();   
				
				 softAssert.assertTrue(NotesSection.isDisplayed(), "Notes Section is not displayed for  cas scenarios");
				 softAssert.assertAll();
				 System.out.println("TC70_internal workitem is passed");
		 }
		 catch(Throwable e)
		   {
					   
					   System.out.println("TC70_internalWorkitem is failed");
					   Assert.fail(e.getMessage());
					   
		   }
	}

}
