package testRepository.GR.InternalWorkItem;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class TC25_internalWorkitem extends base{
	@Test
	public void getRetrypopup() throws InterruptedException {
		
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		 InternalwrkItmpageobj.clickonDrawnextItem();
	String Claim=InternalwrkItmpageobj.getPageTitle_claim().getText();
	System.out.println(Claim);
	InternalwrkItmpageobj.clickonRetry();
	
 WebElement confir=InternalwrkItmpageobj.getconfirmationpopup();
 String opuMessage=confir.getText();
 System.out.println(opuMessage);
 
 Thread.sleep(1000);
 InternalwrkItmpageobj.clikconpopuCancel();
 
 try {
		SoftAssert softAssert = new SoftAssert();   
		 
		 softAssert.assertTrue(opuMessage.toLowerCase().contains("confirmation"), "Confirmation opoup is not displayed");
		 softAssert.assertAll();
		  System.out.println("TC_25_internalWorkitem is passed");
				}
				
	catch(Throwable e)
	    {
				   System.out.println("TC_25_internalWorkitem Failed");
				   Assert.fail(e.getMessage());
	    }
	}

}
