package testRepository.GR.InternalWorkItem;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class TC41_40_internalWorkitem extends base{
	@Test
	public void getAssigntoQueueFunctionlity() throws InterruptedException, SQLException {
		
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		 InternalwrkItmpageobj.clickonDrawnextItem();
		 Thread.sleep(3000);
	String Claim=	 InternalwrkItmpageobj.getPageTitle_claim().getText();
	System.out.println(Claim);
	String CLAIM_ID=null,Queue_ID=null,User_ID=null,WORK_ITEM_VERSION_ID=null,WORK_ITEM_STATUS=null;
	String Query1="Select*from HERO_UI_WORK_ITEMS where CLAIM_ID like '"+Claim.trim()+"'";
	System.out.println(Query1);
	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
	  rs = readStatement.executeQuery();
	  rs.next();
	  System.out.println(Query1);
	 
	  CLAIM_ID=rs.getString(4);
	  System.out.println(CLAIM_ID);
	  Queue_ID=rs.getString(7);
	  System.out.println(Queue_ID);
	  User_ID=rs.getString(8);
	  System.out.println(User_ID);
	  WORK_ITEM_VERSION_ID=rs.getString(5);
	  System.out.println(WORK_ITEM_VERSION_ID);
	  WORK_ITEM_STATUS=rs.getString(9);
	  System.out.println(WORK_ITEM_STATUS);
	  
  int x=Integer.parseInt(WORK_ITEM_VERSION_ID);
  System.out.println(x);
	  
	  try {
			SoftAssert softAssert = new SoftAssert();   
		
		//	 softAssert.assertTrue(WORK_ITEM_VERSION_ID.equals(x), "workitem version is not changed");
			 softAssert.assertTrue(WORK_ITEM_STATUS.contains("Assigned"), "workitem version is not assigned");
			 softAssert.assertTrue(User_ID.equals("VIP8713"), "workitem version is not assigned");
			 softAssert.assertTrue(Queue_ID.equals("queueid10"), " Queue is not assigned");
			 softAssert.assertAll();
			System.out.println("workitem assigned to user");
		
	}
	  catch(Throwable e)
	    {
				   System.out.println("staus of work item is not updating in DB");
				   Assert.fail(e.getMessage());
	    }
	  Thread.sleep(2000);
	  InternalwrkItmpageobj.clickonAssigntoQue().click();
	  
	  InternalwrkItmpageobj.clickonComments("assignbtn");
	  
	  InternalwrkItmpageobj.clickonConfirmBtn();
	  Thread.sleep(9000);
	  String Query2="Select*from enc.HERO_UI_WORK_ITEMS where CLAIM_ID like '"+CLAIM_ID.trim()+"'";
		
	  PreparedStatement readStatement1 = dbcon.prepareStatement(Query2);
	  rs = readStatement1.executeQuery();
	  rs.next();
	  
	  CLAIM_ID=rs.getString(4);
	  System.out.println(CLAIM_ID);
	  Queue_ID=rs.getString(7);
	  System.out.println(Queue_ID);
	  User_ID=rs.getString(8);
	  System.out.println(User_ID);
	  WORK_ITEM_VERSION_ID=rs.getString(5);
	  System.out.println(WORK_ITEM_VERSION_ID);
	  WORK_ITEM_STATUS=rs.getString(9);
	  System.out.println(WORK_ITEM_STATUS);
	  
	int   y=x+1;
	  try {
			SoftAssert softAssert = new SoftAssert();   
		
			// softAssert.assertTrue(WORK_ITEM_VERSION_ID.equals(y), "workitem version is not changed");
			 softAssert.assertTrue(WORK_ITEM_STATUS.contains("Unassigned"), "workitem status is not changed ");
			 softAssert.assertTrue(User_ID.contains(null), "workitem assigned is not user");
			 softAssert.assertTrue(Queue_ID.contains("QueueId2"), " Queue is not to another queue");
			 softAssert.assertAll();
			
		
			 System.out.println("TC41_internalWorkitem is passed");
	}
	  catch(Throwable e)
	    {
				   //System.out.println("staus of work item is not updating in DB");
				   System.out.println("TC41_internalWorkitem is failed");
				   Assert.fail(e.getMessage());
				   
	    }
	  
	  
	}

}
