package testRepository.GR.InternalWorkItem;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class R_TC72_internalWorkitem extends base{
	@Test
	public void gethistorySectionforCasscenar() throws InterruptedException {
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		 InternalwrkItmpageobj.clickonDrawnextItem();
		 
	WebElement historySection=InternalwrkItmpageobj.gethistorysection();
  System.out.println(historySection.getText());	
	try {
		SoftAssert softAssert = new SoftAssert();   
		
		 softAssert.assertTrue(historySection.isDisplayed(), "history section is not displayed for  cas scenarios");
		 softAssert.assertAll();
		 System.out.println("TC72_internal workitem is passed");
 }
 catch(Throwable e)
   {
			   
			   System.out.println("TC72_internalWorkitem is failed");
			   Assert.fail(e.getMessage());
			   
   }
	
	
	}

}
