package testRepository.GR.InternalWorkItem;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.InternalWorkItempage;

public class R_TC_45_46_internalWorkitem extends base{
	@Test
	public void getCancelBtnFunctionality() throws InterruptedException, SQLException {
		Thread.sleep(2000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("User Dashboard");
		 Thread.sleep(3000);
		 InternalWorkItempage InternalwrkItmpageobj=new InternalWorkItempage();
		 Thread.sleep(5000);
		 InternalwrkItmpageobj.clickonDrawnextItem();
	String CLAIM_ID=	 InternalwrkItmpageobj.getPageTitle_claim().getText();
	System.out.println(CLAIM_ID);
	Thread.sleep(8000);
	//db response
	//int wI_version=2;
	String WORK_ITEM_SID=null,CLAIM_ID_DB=null,WORK_ITEM_VERSION_ID=null,WORK_ITEM_STATUS=null,QUEUE_ID=null,USER_ID=null,WI_STATUS_DESC=null;
	
	String Query1="Select*from HERO_UI_WORK_ITEMS where CLAIM_ID like '"+CLAIM_ID.trim()+"'";
	System.out.println(Query1);
	  PreparedStatement readStatement = dbcon.prepareStatement(Query1);
	  rs = readStatement.executeQuery();
	  rs.next();
	  System.out.println(Query1);
	  
	  WORK_ITEM_SID=rs.getString(1);
	  System.out.println(WORK_ITEM_SID);
	  CLAIM_ID_DB=rs.getString(2);
	  WORK_ITEM_VERSION_ID=rs.getString(5);
	  System.out.println(WORK_ITEM_VERSION_ID);
	  WORK_ITEM_STATUS=rs.getString(9);
	  System.out.println(WORK_ITEM_STATUS);
	  WI_STATUS_DESC=rs.getString(10);
	  System.out.println(WI_STATUS_DESC);
	  USER_ID=rs.getString(8);
	  
	  int x=Integer.parseInt(WORK_ITEM_VERSION_ID);
	  
	  try {
			SoftAssert softAssert = new SoftAssert();   
		
			 softAssert.assertTrue(WORK_ITEM_VERSION_ID.equals(x), "workitem version is not changed");
			 softAssert.assertTrue(WORK_ITEM_STATUS.contains("Assigned"), "workitem version is not assigned");
			 softAssert.assertTrue(USER_ID.contains(USER_ID), "workitem version is not assigned");
			 softAssert.assertAll();
			 System.out.println(WORK_ITEM_SID);
			 System.out.println(WORK_ITEM_VERSION_ID);
			
			
		
	}
	  catch(Throwable e)
	    {
				   System.out.println("staus of work item is not updating in DB");
				   Assert.fail(e.getMessage());
	    }
	  Thread.sleep(2000);
	  InternalwrkItmpageobj.clickonCancelbtn().click();
	  InternalwrkItmpageobj.getalert();
	  
	  InternalwrkItmpageobj.clickonComments("Cancel");
	  Thread.sleep(2000);
	  InternalwrkItmpageobj.clickonConfirmBtn();
	  Thread.sleep(5000);
	  String Query2="Select*from enc.HERO_UI_WORK_ITEMS where CLAIM_ID like '"+CLAIM_ID.trim()+"'";
		
	  PreparedStatement readStatement1 = dbcon.prepareStatement(Query2);
	  rs = readStatement1.executeQuery();
	  rs.next();
	  
	  WORK_ITEM_SID=rs.getString(1);
	  CLAIM_ID_DB=rs.getString(2);
	  WORK_ITEM_VERSION_ID=rs.getString(5);
	  System.out.println(WORK_ITEM_VERSION_ID);
	  WORK_ITEM_STATUS=rs.getString(9);
	  System.out.println(WORK_ITEM_STATUS);
	  WI_STATUS_DESC=rs.getString(10);
	  System.out.println(WI_STATUS_DESC);
	  USER_ID=rs.getString(8);
	  
	int   y=x-1;
	  try {
			SoftAssert softAssert = new SoftAssert();   
		
			 softAssert.assertTrue(WORK_ITEM_VERSION_ID.equals(y), "workitem version is not changed");
			 softAssert.assertTrue(WORK_ITEM_STATUS.contains("unAssigned"), "workitem status is not changed ");
			 softAssert.assertTrue(USER_ID.contains("null"), "workitem assigned is not user");
			 softAssert.assertAll();
			
		
			 System.out.println("TC45_internalWorkitem is passed");
	}
	  catch(Throwable e)
	    {
				   System.out.println("staus of work item is not updating in DB");
				   System.out.println("TC45_internalWorkitem is failed");
				   Assert.fail(e.getMessage());
				   
	    }
	  
	  
}
}