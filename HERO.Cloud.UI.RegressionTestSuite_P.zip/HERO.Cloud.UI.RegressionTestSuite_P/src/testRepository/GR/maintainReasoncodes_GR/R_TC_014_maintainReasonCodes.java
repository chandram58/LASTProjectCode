package testRepository.GR.maintainReasoncodes_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainReasonCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_014_maintainReasonCodes extends base
{
	
		@Test
		public void MaxMinutesperInstanceMaxDailyValidation() throws IOException, InterruptedException
		{
		
			 Thread.sleep(5000);
			 
			//Open Maintain Reason Codes Module
				
				HomePage homePageObj=new HomePage();
				homePageObj.mouseHoverAdministration();	
				Thread.sleep(3000);
				homePageObj.openModule("Maintain Reason Codes");
				MaintainReasonCodesPage maintainReasonCodesPage=new MaintainReasonCodesPage(); 
				String PageTitle=maintainReasonCodesPage.getPageTitle();
				System.out.println("PageTitle->"+PageTitle);
				
				try{  
					  
				
			    //Clicking on Add New Time Tracking Reason Code button
				
				maintainReasonCodesPage.clickAddNewTimeTrackingReasonCodeButton();
				Thread.sleep(2000);
				String PageTitleOpenedPage=maintainReasonCodesPage.getPageTitle_newReasonCode();
				System.out.println("Page Title of opened page->"+PageTitleOpenedPage);
				Thread.sleep(3000);
		   
		   
		        maintainReasonCodesPage.inputMaxMinPerInstance("2");
		        maintainReasonCodesPage.inputMaxDailyMin("1");
		
		        String Validationerror=maintainReasonCodesPage.getError2ForMaxMinPerInstance();
		        System.out.println("Validationerror->"+Validationerror);
		        
		        SoftAssert softAssert = new SoftAssert();
		        softAssert.assertTrue(Validationerror.contains("Max Minutes per instance can not be more than max daily minutes"),"Incorrect Message");
		        softAssert.assertAll();
                System.out.println("R_TC14_maintainReasoncodes Passed");
			
				}
				   
				catch(Throwable e)
				{
					System.out.println("R_TC14_maintainReasoncodes Failed");
				  //test.log(LogStatus.FAIL, "R_TC14_maintainReasoncodes Failed");
					Assert.fail(e.getMessage());
						     
			      }
	
	      }


}