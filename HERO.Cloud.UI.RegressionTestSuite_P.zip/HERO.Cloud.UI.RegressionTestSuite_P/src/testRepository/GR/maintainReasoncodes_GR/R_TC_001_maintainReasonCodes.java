package testRepository.GR.maintainReasoncodes_GR;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainReasonCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_001_maintainReasonCodes extends base
{
	
	
		@Test
		public void NavigationtoMaintainReasonCodes() throws IOException, InterruptedException
		{
			
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Maintain Reason Codes");
			MaintainReasonCodesPage maintainReasonCodesPage=new MaintainReasonCodesPage();  
			String Pagetitle=maintainReasonCodesPage.getPageTitle();
            System.out.println("Pagetitle->"+Pagetitle);
			 try
			    {
		   
			
			
			SoftAssert softassert = new SoftAssert();
			softassert.assertTrue(Pagetitle.equalsIgnoreCase("Maintain Reason Codes"),"Incorrect page");
			softassert.assertAll();
		    System.out.println("R_TC01_MainatainReasoncodes Passed");
	      //test.log(LogStatus.FAIL, "R_TC01_MainatainReasoncodes Passed"); 
				    
			}
				   
	    catch(Throwable e)
			{
	             System.out.println("R_TC01_MainatainReasoncodes Failed");
					  //test.log(LogStatus.FAIL, "R_TC01_MainatainReasoncodes Failed"); 
	             Assert.fail(e.getMessage());
						     
					 }
	
		}
		
}