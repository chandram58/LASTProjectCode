package testRepository.GR.maintainReasoncodes_GR;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;
import pages.HomePage;
import pages.MaintainReasonCodesPage;

public class R_TC_010_maintainReasonCodes extends base
{
	@Test
	public void StartandEndDateValidationNewReasonCodePage() throws IOException, InterruptedException, ParseException
	{
		MaintainReasonCodesPage maintainReasonCodesPageObj=new MaintainReasonCodesPage(); 
		HomePage homePageObj=new HomePage();


		homePageObj.mouseHoverAdministration();	
		homePageObj.openModule("Maintain Reason Codes");

		maintainReasonCodesPageObj.clickAddNewTimeTrackingReasonCodeButton();
		Thread.sleep(1000);
		//maintainReasonCodesPageObj.clickStartDate_NewReasonCode();

		SimpleDateFormat date1=new SimpleDateFormat("MM/dd/yyyy");
		String PopulatedDefaultDate_startDate=maintainReasonCodesPageObj.getStartDate_newReasonCode();
		System.out.println("Prepopulated Default date in Start date field->"+PopulatedDefaultDate_startDate);
		Date PopulatedDefaultDateinDateFormat_startDate=date1.parse(PopulatedDefaultDate_startDate);

		//getting current date

		Calendar calendar = Calendar.getInstance();
		String TodayDateinStringFormat=date1.format(calendar.getTime());
		System.out.println("Today's date in string format->"+TodayDateinStringFormat);
		Date TodayDateinDateFormat=date1.parse(TodayDateinStringFormat);
		System.out.println("Today's date in date format->"+TodayDateinDateFormat);


		//selecting yesterday date
		calendar.add(calendar.DATE, -1);
		String yesterdayDate=date1.format(calendar.getTime());
		System.out.println("YesterdayDate="+yesterdayDate);
		
		try{  
			
		maintainReasonCodesPageObj.clickStartDate_NewReasonCode();
		selectDateFromDatePicker(yesterdayDate);
		//Now After clicking getting value of Start date field
		String PopulatedDateAfterClickingYesterdayDate=maintainReasonCodesPageObj.getStartDate_newReasonCode();
		System.out.println("Populated Date After Clicking YesterdayDate in Start date field->"+PopulatedDateAfterClickingYesterdayDate);
		Date PopulatedDateAfterClickingYesterdayDateinDateFormat_StartDate=date1.parse(PopulatedDateAfterClickingYesterdayDate);
		Thread.sleep(1000);
		
		//selecting future date
		calendar = Calendar.getInstance();
		calendar.add(calendar.DATE, 1);
		String tomorrowDate=date1.format(calendar.getTime());
		System.out.println("TomorrowDate="+tomorrowDate);
		
		maintainReasonCodesPageObj.clickStartDate_NewReasonCode();
		selectDateFromDatePicker(tomorrowDate);
		//Now After clicking getting value of Start date field
		String PopulatedDateAfterClickingTommorowDate=maintainReasonCodesPageObj.getStartDate_newReasonCode();
		System.out.println("Populated Date After Clicking YesterdayDate in Start date field->"+PopulatedDateAfterClickingTommorowDate);
		Date PopulatedDateAfterClickingTommorowDateinDateFormat_StartDate=date1.parse(PopulatedDateAfterClickingTommorowDate);
		Thread.sleep(1000);
		
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertTrue(PopulatedDefaultDateinDateFormat_startDate.equals(TodayDateinDateFormat),"Today's date is not Default date for StartDate field");
		softAssert.assertFalse(PopulatedDateAfterClickingYesterdayDateinDateFormat_StartDate.before(TodayDateinDateFormat),"Past date can be selected in Start date");
		softAssert.assertTrue(PopulatedDateAfterClickingTommorowDateinDateFormat_StartDate.after(TodayDateinDateFormat),"Future date can not be selected in Start date");
		
		
	 // Now Validating End date End date
		String PopulatedDefaultDate_EndDate=maintainReasonCodesPageObj.getEndDate_newReasonCode();
		System.out.println("Prepopulated Default date in End date field->"+PopulatedDefaultDate_EndDate);
		
		
		maintainReasonCodesPageObj.clickEndDate_NewReasonCode();
		
		selectDateFromDatePicker("today");
		String PopulateddateafterclickingTodayCalendarbutton=maintainReasonCodesPageObj.getEndDate_newReasonCode();				
		System.out.println("Populated date after clicking Today button in Calendar for End date field->"+PopulateddateafterclickingTodayCalendarbutton); 
		Date PopulateddateafterclickingTodayCalendarbuttoninDateFormat_EndDate=date1.parse(PopulateddateafterclickingTodayCalendarbutton);

		Thread.sleep(1000);
		maintainReasonCodesPageObj.clickEndDate_NewReasonCode();
		selectDateFromDatePicker(yesterdayDate);

		String PopulatedDateAfterClickingYesterdayDate_EndDate=maintainReasonCodesPageObj.getEndDate_newReasonCode();		
		System.out.println("Populated Date After Clicking Yesterday Date in End date field->"+PopulatedDateAfterClickingYesterdayDate);
		Date PopulatedDateAfterClickingYesterdayDateinDateFormat_EndDate=date1.parse(PopulatedDateAfterClickingYesterdayDate);

		softAssert.assertTrue(PopulatedDefaultDate_EndDate.equals("12/31/9999"),"12/31/9999 date is not Default date for Enddate field");
		softAssert.assertTrue(PopulateddateafterclickingTodayCalendarbuttoninDateFormat_EndDate.equals(TodayDateinDateFormat),"Today date can be selected in End date");
		softAssert.assertFalse(PopulatedDateAfterClickingYesterdayDateinDateFormat_EndDate.before(TodayDateinDateFormat),"Past date can be selected in End date");


		softAssert.assertAll();
		System.out.println("R_TC_10_maintainReasoncodes Passed");
		}

	    catch(Throwable e)
	    {
		 System.out.println("R_TC_10_maintainReasoncodes Failed");
		 //test.log(LogStatus.FAIL, "R_TC_10_maintainReasoncodes Failed"); 
		 Assert.fail(e.getMessage());
               }
		}
}
