package testRepository.GR.maintainReasoncodes_GR;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainReasonCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_005_maintainReasonCodes extends base
{
	
	
		@Test
		public void VerifyExporttoCSVandPDFFunctionality() throws IOException, InterruptedException
		{
			String Downloadpath=getPropertyFileValue("DownloadFilepath");
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Maintain Reason Codes");
			

			 try
			    {
		    //Clicking on 'Export to Excel' and 'Export to PDF' button
			
			Thread.sleep(3000);
			MaintainReasonCodesPage maintainReasonCodesPage=new MaintainReasonCodesPage(); 
			maintainReasonCodesPage.clickDownToExcelbtn();
			Thread.sleep(5000);
			SoftAssert softassert = new SoftAssert();
			
			File getLatestFile = base.getLatestFilefromDir(Downloadpath);
		    String fileName1 = getLatestFile.getName();
			System.out.println("Downloaded File name->"+fileName1);	
			// verifying whether the file  with fileName present in the directory downloadpath or not
			 softassert.assertTrue(isFileDownloaded(Downloadpath, fileName1), "Download Failed");
			//verifying whether the latest downloaded file contains "xlsx" extension or not and name of file having TransmissionsList word in it
			 softassert.assertTrue(fileName1.contains("csv") && fileName1.contains("ReasonCode"),"It is not a CSV file");
			 
			 
			 
			 Thread.sleep(3000);
		     maintainReasonCodesPage.clickDownToPDFbtn(); 
		     Thread.sleep(5000);
		     getLatestFile = base.getLatestFilefromDir(Downloadpath);
		     String fileName2 = getLatestFile.getName();
		     System.out.println("Downloaded File name->"+fileName2);	
		     // verifying whether the file  with fileName present in the directory Downloadpath or not
		     softassert.assertTrue(isFileDownloaded(Downloadpath, fileName2), "Download Failed");
		     //verifying whether the latest downloaded file contains "PDF" extension or not and name of file having TransmissionsList word in it
		     softassert.assertTrue(fileName2.contains("pdf") && fileName2.contains("ReasonCode"),"It is not a PDF file");
				 
			 
			 
		  softassert.assertAll();
		  System.out.println("R_TC05_MainatainReasoncodes Passed");
	      //test.log(LogStatus.FAIL, "R_TC05_MainatainReasoncodes Passed"); 
				    
			}
				   
	    catch(Throwable e)
			{
	             System.out.println("R_TC05_MainatainReasoncodes Failed");
					  //test.log(LogStatus.FAIL, "R_TC05_MainatainReasoncodes Failed"); 
	             Assert.fail(e.getMessage());
						     
					 }
	
		}
		
}