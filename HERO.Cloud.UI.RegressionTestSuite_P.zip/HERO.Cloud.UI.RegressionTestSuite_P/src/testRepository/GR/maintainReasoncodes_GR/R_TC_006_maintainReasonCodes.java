package testRepository.GR.maintainReasoncodes_GR;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainReasonCodesPage;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC_006_maintainReasonCodes extends base
{
		@Test
		public void RecordCountValidation() throws IOException, InterruptedException, SQLException
		{
			
	     Thread.sleep(10000);
	     HomePage homePageObj=new HomePage();
	     homePageObj.mouseHoverAdministration();	
		 Thread.sleep(3000);
		 homePageObj.openModule("Maintain Reason Codes");
		 MaintainReasonCodesPage maintainReasonCodesPage=new MaintainReasonCodesPage();  
		 String Pagetitle=maintainReasonCodesPage.getPageTitle();
         System.out.println("Pagetitle->"+Pagetitle);	 
          
         List<WebElement> rows=maintainReasonCodesPage.getNumberofRows_UIMainPage();
		 System.out.println("No of rows on Maintain Reason Codes Table->"+ rows.size());
		  
		 String RecordCount_UI=maintainReasonCodesPage.getRecordCount_UIMaintable();
	             
		 //Verifying in DB
		  int Count_DB = maintainReasonCodesPage.getRecordCount_DB();
				    
				  Thread.sleep(3000);
           
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
			    
		         softassert.assertEquals(rows.size(), Integer.parseInt(RecordCount_UI),"Record Count present on UI and Message not matching");
		         softassert.assertEquals(rows.size(),Count_DB ,"Record Count present on UI and DB not matching");
 
			    softassert.assertAll();
				System.out.println("R_TC_06_maintainReasoncodes Passed");
				 
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("R_TC_06_maintainReasoncodes Failed");
					  //  test.log(LogStatus.FAIL, "R_TC_06_maintainReasoncodes Failed"); 
                   Assert.fail(e.getMessage());
						     
					   
				      }
	
		}
	

}
