package testRepository.GR.maintainReasoncodes_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainReasonCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class G_TC_007_maintainReasoncodes extends base
{
	@Test
	public void SearchFunctionalityMainatainReasoncode() throws IOException, InterruptedException
		{
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(3000);
		homePageObj.openModule("Maintain Reason Codes");
		MaintainReasonCodesPage maintainReasonCodesPage=new MaintainReasonCodesPage();  
		String Pagetitle=maintainReasonCodesPage.getPageTitle();
        System.out.println("Pagetitle->"+Pagetitle);
			try{
				 
			 
				String ErrorCodeforSearch="break";
				List<WebElement> serachResult_rows=maintainReasonCodesPage.getSearchResult_rows(ErrorCodeforSearch);
				System.out.println("No of rows populated in Search->"+serachResult_rows.size());
				
			 SoftAssert softAssert = new SoftAssert();
				for(int j=0;j<serachResult_rows.size();j++)
				{
				System.out.println(serachResult_rows.get(j).getText());
			    softAssert.assertTrue((serachResult_rows.get(j).getText().toLowerCase()).contains(ErrorCodeforSearch.toLowerCase()), "Row no->"+(j+1)+" not having searched error code");	
				}
		    softAssert.assertAll();
		      
		    System.out.println("G_TC07_maintainReasoncodes Passed");
		   //  test.log(LogStatus.FAIL, "G_TC007_maintainReasoncodes Passed"); 
				   
		  }
				   
	    catch(Throwable e)
				{
	    	    System.out.println("G_TC07_maintainReasoncodes Failed");
			  //  test.log(LogStatus.FAIL, "TC007_manintainReasoncodes Failed");  
	    	    Assert.fail(e.getMessage());
				      }
		
		
		      }
	
	
}
