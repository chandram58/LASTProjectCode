package testRepository.GR.maintainReasoncodes_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainReasonCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class G_TC25_R_TC27_maintainReasoncodes extends base
{
	
		@Test
		public void SaveFunctionalityUpdateReasonCode() throws IOException, InterruptedException
		{
			
			    Thread.sleep(10000);
		
			    HomePage homePageObj=new HomePage();
				homePageObj.mouseHoverAdministration();	
				Thread.sleep(3000);
				homePageObj.openModule("Maintain Reason Codes");
				MaintainReasonCodesPage maintainReasonCodesPage=new MaintainReasonCodesPage();  
				String Pagetitle=maintainReasonCodesPage.getPageTitle();
	            System.out.println("Pagetitle->"+Pagetitle);
				
	            System.out.println("Page title before clicking Edit button ->"+Pagetitle);		
			 
		        String Selectedreasoncode="Break";
		        Thread.sleep(5000);
		        List<WebElement> searchResult_rows1=maintainReasonCodesPage.getSearchResult_rows(Selectedreasoncode);
			    System.out.println("No of rows in search result->"+searchResult_rows1.size());
			     
			    maintainReasonCodesPage.search_Click(searchResult_rows1,Selectedreasoncode);
		
		       String PageTitle2=maintainReasonCodesPage.getPageTitle_editReasonCode();
		   System.out.println("Page Title after clicking Edit button ->"+PageTitle2);
		   
		   Thread.sleep(3000);
		 
		   //Update End date
		   String NewEndDate="12/30/9999";
		   maintainReasonCodesPage.clickEndDate_UpdateReasonCode();
		   selectDateFromDatePicker(NewEndDate);
		   
	       //Clicking on Save
		   maintainReasonCodesPage.clickSave();
		   
	       //Capturing success message
		   driver.switchTo().defaultContent();
		   Thread.sleep(3000);
		   String Message=maintainReasonCodesPage.getSuccessMessage("update");
		 
		   //Validating whether End date is getting validated in main table or not
		   
		   driver.switchTo().defaultContent();
		   Thread.sleep(10000);
		    
		        List<WebElement> searchResult_rows2=maintainReasonCodesPage.getSearchResult_rows(Selectedreasoncode);
			    System.out.println("No of rows in search result->"+searchResult_rows2.size());
			   
		      
			    String Enddate_UI=maintainReasonCodesPage.getEndDate_Searchresult(searchResult_rows2,Selectedreasoncode);
		   
	try{  
				   
					
    SoftAssert softAssert = new SoftAssert();
    softAssert.assertTrue(Message.contains("Reason code has been updated successfully"), "Incorrect message");
    softAssert.assertTrue(Enddate_UI.contains(NewEndDate), "Main table date value not getting updated");
    softAssert.assertAll();
      System.out.println("G_TC25_R_TC27_maintainReasoncodes Passed");
                          }
				   
	    catch(Throwable e)
				     {
					   System.out.println("G_TC25_R_TC27_maintainReasoncodes Failed");
					 //test.log(LogStatus.FAIL, "G_TC25_R_TC27_maintainReasoncodes Failed"); 
					  Assert.fail(e.getMessage());
						     
					   }
	
	      }
}