package testRepository.GR.maintainReasoncodes_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainReasonCodesPage;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC_004_maintainReasonCodes extends base
{
		@Test
		public void AscendingDescendingOrderValidation() throws IOException, InterruptedException
		{
			Thread.sleep(10000);
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Maintain Reason Codes");
			MaintainReasonCodesPage maintainReasonCodesPage=new MaintainReasonCodesPage();  
			String Pagetitle=maintainReasonCodesPage.getPageTitle();
	        System.out.println("Pagetitle->"+Pagetitle); 
			
	        
	        List<String> ActiveErrorcodeList1=maintainReasonCodesPage.getUIactivereasoncodelist();
		   //Clicking on Sort icon reason code list in ascending order 
	        maintainReasonCodesPage.clickSortCodeName();	
	        List<String> ActiveErrorcodeList2=maintainReasonCodesPage.getUIactivereasoncodelist();
	        
	        //Clicking on Sort icon again reason code list in descending order
	        maintainReasonCodesPage.clickSortCodeName();	
	        List<String> ActiveErrorcodeList3=maintainReasonCodesPage.getUIactivereasoncodelist();
	        
	        System.out.println("Active Groupname list in Group maintenance page");
	        
	        try
		    {
	        //Sorting List1 in ascending order without considering Case
            Collections.sort(ActiveErrorcodeList1, String.CASE_INSENSITIVE_ORDER);
		    System.out.println("ActiveErrorcodeList1_asc->"+ActiveErrorcodeList1); 
		   
		    SoftAssert softassert = new SoftAssert();
		    softassert.assertEquals(ActiveErrorcodeList1, ActiveErrorcodeList2,"Ascending order Sorting not working as expected");		

		    //Sorting List1 in descending order without considering Case
		    Collections.sort(ActiveErrorcodeList1, Collections.reverseOrder(String.CASE_INSENSITIVE_ORDER));
			System.out.println("ActiveErrorcodeList1_desc->"+ActiveErrorcodeList1); 
		    
			 softassert.assertEquals(ActiveErrorcodeList1, ActiveErrorcodeList3,"Descending order Sorting not working as expected");		
		     Thread.sleep(3000);
           
			    
			    softassert.assertAll();
				System.out.println("R_TC_04_maintainReasoncodes Passed");
				}
				 catch(Throwable e)
				 {
			    System.out.println("R_TC_04_maintainReasoncodes Failed");
			    //  test.log(LogStatus.FAIL, "R_TC_04_maintainReasoncodes Failed"); 

			    Assert.fail(e.getMessage());
			   }
         }

}
