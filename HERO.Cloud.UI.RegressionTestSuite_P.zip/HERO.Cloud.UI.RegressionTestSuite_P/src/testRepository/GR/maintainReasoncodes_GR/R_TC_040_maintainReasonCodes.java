package testRepository.GR.maintainReasoncodes_GR;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.MaintainReasonCodesPage;

public class R_TC_040_maintainReasonCodes extends base{
	
	@Test
	public void activeandInActiveReasonCodesCopyBtnFunctionality() throws InterruptedException {
	
		MaintainReasonCodesPage maintainReasonCodesPageObj=new MaintainReasonCodesPage(); 
		HomePage homePageObj=new HomePage();

		homePageObj.mouseHoverAdministration();	
		homePageObj.openModule("Maintain Reason Codes");
		maintainReasonCodesPageObj.clickOnCopyBtnActiveReason();
		
	    String PageTitle=maintainReasonCodesPageObj.getPageTitleforCopy();
	    System.out.println("PageTitle on Clicking Active ReasonCode->"+PageTitle);
	    maintainReasonCodesPageObj.enterPageTitleforCopy();
	    String reasonCodeNameActive=maintainReasonCodesPageObj.getReasoncodenameCopy();
	    System.out.println("reasonCodeNameActive->"+reasonCodeNameActive);
	    maintainReasonCodesPageObj.clickSave();
 
	    Thread.sleep(3000);
	    maintainReasonCodesPageObj.clickOnCopypBtnInactiveReason();
	    maintainReasonCodesPageObj.enterPageTitleforCopy();
	    String reasonCodeNameInActive=maintainReasonCodesPageObj.getReasoncodenameCopy();
	    System.out.println("reasonCodeNameInActive->"+reasonCodeNameInActive);
	    maintainReasonCodesPageObj.clickSave();
	    
	    Thread.sleep(10000);
	    List<String> Reasoncodelist = new ArrayList<String>();
	    Reasoncodelist= maintainReasonCodesPageObj.getUIactivereasoncodelist();
  
  try {
		 SoftAssert softAssert = new SoftAssert();
			softAssert.assertTrue(Reasoncodelist.contains(reasonCodeNameInActive), "usingcopybtn new code is not created for inacative reason code" );
			softAssert.assertTrue(Reasoncodelist.contains(reasonCodeNameActive), "usingcopybtn new code is not created for active reason code" );
			//softAssert.assertAll();
			System.out.println("TC40_maintainreasoncodes is passed");
	}
	catch(Exception e) {
		System.out.println("TC40_maintainreasoncodes  is failed");
		Assert.fail(e.getMessage());
		 
	}
  
	}

}
