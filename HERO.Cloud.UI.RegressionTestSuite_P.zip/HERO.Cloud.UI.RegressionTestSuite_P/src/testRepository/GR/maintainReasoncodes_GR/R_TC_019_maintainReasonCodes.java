package testRepository.GR.maintainReasoncodes_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainReasonCodesPage;
import pages.QueuesAssignmentPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_019_maintainReasonCodes extends base
{
	

		@Test
		public void CreationofNewReasonCodeValidation() throws IOException, InterruptedException
		{
			
			//Open Maintain Reason Codes Module
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Maintain Reason Codes");
			
		    //Clicking on Add New Time Tracking Reason Code button
			MaintainReasonCodesPage maintainReasonCodesPage=new MaintainReasonCodesPage(); 
			maintainReasonCodesPage.clickAddNewTimeTrackingReasonCodeButton();
			 Thread.sleep(2000);
			
			 maintainReasonCodesPage.getPageTitle();
			 //Generating Random Character
			 Random r = new Random();
			 char c = (char)(r.nextInt(26) + 'a');
			 String ReasoncodeEntered="Break"+c;
			 System.out.println("ReasoncodeEntered->"+ReasoncodeEntered);
			 maintainReasonCodesPage.inputReasonCodeName(ReasoncodeEntered);
			 
			 maintainReasonCodesPage.inputDescription("Test");
			 //Click on Save Button
			 maintainReasonCodesPage.clickSave();
			 Thread.sleep(2000);
			 
			 maintainReasonCodesPage.getErrorMsg("Reason code has been created successfully");
			 
			 Thread.sleep(2000);
			 List<String> MainTablelist=maintainReasonCodesPage.getUIactivereasoncodelist();
	
			
	 try
	 {  
		   
				
	SoftAssert softAssert = new SoftAssert();
		       
  // softAssert.assertTrue(Message.contains("Reason code has been created successfully"),"Incorrect message");
   softAssert.assertTrue(MainTablelist.contains(ReasoncodeEntered),"Newly Created Reason code not found on main reason Codes table");
    softAssert.assertAll();

    System.out.println("R_TC_19_maintainReasoncodes Passed");
    //test.log(LogStatus.PASS, "R_TC_19_maintainReasoncodes Passed"); 
				 }
				   
	    catch(Throwable e)
				     {
					   System.out.println("R_TC_19_maintainReasoncodes Failed");
					  //test.log(LogStatus.FAIL, "R_TC_19_maintainReasoncodes Failed"); 
					   
                       Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}