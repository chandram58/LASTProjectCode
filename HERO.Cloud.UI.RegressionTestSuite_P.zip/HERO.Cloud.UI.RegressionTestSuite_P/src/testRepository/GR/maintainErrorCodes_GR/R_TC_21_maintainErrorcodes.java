package testRepository.GR.maintainErrorCodes_GR;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_21_maintainErrorcodes extends base
{
		@Test
		public void NonEditableFieldsVerificationUpdateErrorcode() throws IOException
		{
		 try{
			 Thread.sleep(5000);
			 HomePage homePageObj=new HomePage();
			 homePageObj.mouseHoverAdministration();	
			 Thread.sleep(3000);
			 homePageObj.openModule("Maintain Error Codes");
			 
			 MaintainErrorCodesPage maintainErrorCodesPage=new MaintainErrorCodesPage(); 
			//Clicking on Edit Icon
			 maintainErrorCodesPage.clickEditbtn();	
			 String PageTitle1=maintainErrorCodesPage.getUpdatePageTitle();
			 System.out.println("Page Title after clicking Edit Button->"+PageTitle1);	
			
			 String DisabledFlag_Errorcode=maintainErrorCodesPage.getDisabledFlag("Errorcode");
			 String DisabledFlag_Startdate=maintainErrorCodesPage.getDisabledFlag("Startdate");
			 String DisabledFlag_Description=maintainErrorCodesPage.getDisabledFlag("Description");
			 
			 String DisabledFlag_Errortype=maintainErrorCodesPage.getDisabledFlag("Errortype");
			 String DisabledFlag_Enddate=maintainErrorCodesPage.getDisabledFlag("Enddate");
			 String DisabledFlag_Loop=maintainErrorCodesPage.getDisabledFlag("Loop");
			 String DisabledFlag_Segment=maintainErrorCodesPage.getDisabledFlag("Segment"); 
			 String DisabledFlag_Element=maintainErrorCodesPage.getDisabledFlag("Element");
			 String DisabledFlag_TradingPartner=maintainErrorCodesPage.getDisabledFlag("TradingPartnerDropdown");
			
			 
				//Selecting Trading Partner
	               maintainErrorCodesPage.clickonTPDP();
	               maintainErrorCodesPage.clickandSelectTradingPatnerDropdown();
	         
			/* 
			 //   wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[contains(text(),'Select Severity')]")));
				driver.findElement(By.xpath("//label[contains(text(),'Select Trading Partner')]")).click();
				driver.findElement(By.xpath("//*[@id='viewAddEditSection']/div[2]/div[1]/div[2]/div/p-dropdown/div/div[3]/div[2]/ul/p-dropdownitem/li/div/div/a")).click();
			*/	
		      String DisabledFlag_TradingpartnerId=maintainErrorCodesPage.getDisabledFlag("TradingpartnerId");
		      String DisabledFlag_Severity=maintainErrorCodesPage.getDisabledFlag("Severity");
		      String DisabledFlag_Pasteradio=maintainErrorCodesPage.getDisabledFlag("PasteRadio");
		      String DisabledFlag_Fileuploadradio=maintainErrorCodesPage.getDisabledFlag("FileUploadradio");
		      String DisabledFlag_PasteTextbox=maintainErrorCodesPage.getDisabledFlag("PasteTextbox");
				   
		       //Click on Notes
		      driver.findElement(By.xpath("//span[contains(text(),'Notes')]")).click();
			
				   
			String DisabledFlag_Notesdescription=maintainErrorCodesPage.getDisabledFlag("NotesDescription");
			String DisabledFlag_Notesdetail=maintainErrorCodesPage.getDisabledFlag("NotesDetail");
			  
			    
           SoftAssert softAssert = new SoftAssert();
           softAssert.assertTrue(DisabledFlag_Errorcode.equals("true"), "Errorcode field is Editable");
           softAssert.assertTrue(DisabledFlag_Startdate.equals("true"), "Startdate field is Editable");
           
           softAssert.assertNull(DisabledFlag_Description, "Description field is not Editable");
           
           softAssert.assertNull(DisabledFlag_Errortype, "Errortype field is not Editable");
           softAssert.assertNull(DisabledFlag_Enddate, "End date field is not Editable");
           softAssert.assertNull(DisabledFlag_Loop, "Loop field is not Editable");
           softAssert.assertNull(DisabledFlag_Segment, "Segment field is not Editable");
           softAssert.assertNull(DisabledFlag_Element, "Element field is not Editable");
           softAssert.assertNull(DisabledFlag_TradingPartner, "Trading Partner is not Editable");
           softAssert.assertNull(DisabledFlag_TradingpartnerId, "Trading partner id is not Editable");
           
           softAssert.assertNull(DisabledFlag_Severity, "Severity field is not Editable");
           softAssert.assertNull(DisabledFlag_Pasteradio, "Paste radio button field is Disbled");
           softAssert.assertNull(DisabledFlag_Fileuploadradio, "File Upload radio button field is Disbled");
           softAssert.assertNull(DisabledFlag_PasteTextbox, "Paste textbox field is not Editable");
           softAssert.assertNull(DisabledFlag_Notesdescription, "Notes description field is not Editable");
           softAssert.assertNull(DisabledFlag_Notesdetail, "Notes Deatail text box field is not Editable");
       	
		      softAssert.assertAll();
		    
	    
		      System.out.println("R_TC_21_manintainErrorcodes Passed");
		  //  test.log(LogStatus.FAIL, "R_TC_21_manintainErrorcodes Passed"); 
		
		    }
				   
	    catch(Throwable e)
		   {
	            System.out.println("R_TC_21_manintainErrorcodes Failed");
	        //  test.log(LogStatus.FAIL, "R_TC_21_manintainErrorcodes Failed"); 
	            Assert.fail(e.getMessage());
						     
					    }
		         }
	       }