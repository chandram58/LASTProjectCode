package testRepository.GR.maintainErrorCodes_GR;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_28_maintainErrorcodes extends base
{
		@Test
		public void countNumberofRecordsMainPage() throws IOException
		{
		 try{
			 Thread.sleep(5000);
			 HomePage homePageObj=new HomePage();
			 homePageObj.mouseHoverAdministration();	
			 Thread.sleep(3000);
			 homePageObj.openModule("Maintain Error Codes");
			 
			 MaintainErrorCodesPage maintainErrorCodesPage=new MaintainErrorCodesPage(); 
			
			 //Getting Total no of Records from Text 
			 
			 String Text=maintainErrorCodesPage.getTextBelowMainTbl();
			 System.out.println("Text->"+Text);
			 String[] parts=Text.split("-");
			 String[] CountRecords=parts[1].split("/");
			 int totalCount=Integer.valueOf(CountRecords[1]);
			 System.out.println("totalCount->"+totalCount);
			 
			 //Now Getting no of rows in Main Table
			
			 int recordCountPage=maintainErrorCodesPage.getRecordCountUIMainPage();
			 System.out.println("recordCountPage->"+recordCountPage);
			 
			 SoftAssert softassert=new SoftAssert();
			 softassert.assertTrue((totalCount>=100), "Total record count less than 100");
			 softassert.assertTrue(recordCountPage==100, "Record count on page less than 100");
			 softassert.assertAll();
		    
	    
		      System.out.println("R_TC_21_manintainErrorcodes Passed");
		  //  test.log(LogStatus.FAIL, "R_TC_21_manintainErrorcodes Passed"); 
		
		    }
				   
	    catch(Throwable e)
		   {
	            System.out.println("R_TC_21_manintainErrorcodes Failed");
	        //  test.log(LogStatus.FAIL, "R_TC_21_manintainErrorcodes Failed"); 
	            Assert.fail(e.getMessage());
						     
					    }
		         }
	       }