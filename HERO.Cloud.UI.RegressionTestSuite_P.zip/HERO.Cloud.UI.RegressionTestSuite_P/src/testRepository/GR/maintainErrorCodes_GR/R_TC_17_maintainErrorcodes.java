package testRepository.GR.maintainErrorCodes_GR;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_17_maintainErrorcodes extends base
{
	@Test
		public void ErrorTypeDropdownComparewithDB() throws IOException
		{
		
	     try{
	    	 Thread.sleep(10000);
		     HomePage homePageObj=new HomePage();
		     homePageObj.mouseHoverAdministration();	
			 Thread.sleep(3000);
			 homePageObj.openModule("Maintain Error Codes");
			 MaintainErrorCodesPage maintainErrorCodesPage=new MaintainErrorCodesPage();  
			 String Pagetitle=maintainErrorCodesPage.getModulePageTitle();
	        System.out.println("Page Title->"+Pagetitle);
				
	         //Clicking on 'Add New Error Code' button
	        
	        maintainErrorCodesPage.clickonAddNewErrorCode();
	        String PageTitle2=maintainErrorCodesPage.getNewPageTitle();
			System.out.println("Page Title after clicking New Error Code Button->"+PageTitle2);	 
		
			maintainErrorCodesPage.clickErrorTypeDropdown();
			List<String> ErrorTypeList_UI=maintainErrorCodesPage.getErrorTypeList_UI();
		    System.out.println("ErrorTypeList_UI->"+ErrorTypeList_UI );
					
	         List<String> ErrorTypeList_DB=maintainErrorCodesPage.getErrorTypeList_DB();
			 System.out.println("ErrorTypeList_DB->"+ErrorTypeList_DB);
				
	         Thread.sleep(5000);
			 
			 SoftAssert softAssert = new SoftAssert();
			 softAssert.assertTrue(ErrorTypeList_UI.containsAll(ErrorTypeList_DB) && ErrorTypeList_DB.containsAll(ErrorTypeList_UI), "UI List and DB list not matching");
			 softAssert.assertAll();
		     System.out.println("R_TC_17_maintainErrorcodes Passed");
		   //  test.log(LogStatus.PASS, "R_TC_17_maintainErrorcodes Passed"); 
	     }
				   catch(Throwable e)
				     {
					   System.out.println("R_TC_17_maintainErrorcodes Failed");
					  //  test.log(LogStatus.FAIL, "R_TC_17_maintainErrorcodes Failed"); 
					   Assert.fail(e.getMessage());
						   }
		   }
	}
