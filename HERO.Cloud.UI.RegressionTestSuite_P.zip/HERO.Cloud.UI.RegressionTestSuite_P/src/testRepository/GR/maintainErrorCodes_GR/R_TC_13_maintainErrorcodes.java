package testRepository.GR.maintainErrorCodes_GR;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import pages.MaintainReasonCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_13_maintainErrorcodes extends base
{


		@Test
		public void VerifyErrorcodeUIwithDB() throws IOException
		{
			try{
		     Thread.sleep(10000);
		     HomePage homePageObj=new HomePage();
		     homePageObj.mouseHoverAdministration();	
			 Thread.sleep(3000);
			 homePageObj.openModule("Maintain Error Codes");
			 MaintainErrorCodesPage maintainErrorCodesPage=new MaintainErrorCodesPage();  
			 String Pagetitle=maintainErrorCodesPage.getModulePageTitle();
	         System.out.println("Pagetitle->"+Pagetitle);	 
			 Thread.sleep(5000);
			 
			 List<String> ActiveErrorcodeList_UI= maintainErrorCodesPage.getActiveErrorCodeList_UI();
			 System.out.println("ActiveErrorcodeList_UI->"+ActiveErrorcodeList_UI);
			 System.out.println("******************************");
             List<String> ActiveErrorcodeList_DB = maintainErrorCodesPage.ActiveErrorcodeList_DB();
			 System.out.println("ActiveErrorcodeList_DB->"+ActiveErrorcodeList_DB);
				   
	         Thread.sleep(3000);
	         SoftAssert softassert = new SoftAssert();
			 softassert.assertTrue(ActiveErrorcodeList_UI.containsAll(ActiveErrorcodeList_DB) && ActiveErrorcodeList_DB.containsAll(ActiveErrorcodeList_UI),"UI and DB list  not matching ");
			 softassert.assertAll();
			 System.out.println("R_TC_13_maintainErrorcodes Passed");
			
		    }
				   
	    catch(Throwable e)
				     {
	    	System.out.println("R_TC_13_maintainErrorcodes Failed");
	        //test.log(LogStatus.FAIL, "R_TC_13_maintainErrorcodes Failed");
	    	Assert.fail(e.getMessage());
					  }
			}
		}
