package testRepository.GR.maintainErrorCodes_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class G_TC_23_maintainErrorcodes extends base
{
		@Test
		public void NewErrorcodeCreationFunctionality() throws IOException
		{
			try{
			     Thread.sleep(10000);
			     HomePage homePageObj=new HomePage();
			     homePageObj.mouseHoverAdministration();	
				 Thread.sleep(3000);
				 homePageObj.openModule("Maintain Error Codes");
				 MaintainErrorCodesPage maintainErrorCodesPage=new MaintainErrorCodesPage();  
				 String Pagetitle1=maintainErrorCodesPage.getModulePageTitle();
		         System.out.println("Pagetitle->"+Pagetitle1);
		         Thread.sleep(3000);
				
				//Clicking on Add New error Code
		         maintainErrorCodesPage.clickonAddNewErrorCode();
		         String Pagetitle2= maintainErrorCodesPage.getNewPageTitle();
		         System.out.println("Page Title after clicking New Error Code Button->"+Pagetitle2);
		       
		         //Entering Error Code Name
		         String errorCodeName=getAlphaNumericString(20);
		         maintainErrorCodesPage.enterNewErrorCode(errorCodeName);
		         
		         //Selecting Error Type
		        maintainErrorCodesPage.selectErrorType("Business Rules");
		         
		         
		         
				//Selecting Trading Partner
		         maintainErrorCodesPage.clickonTPDP();
		         maintainErrorCodesPage.clickandSelectTradingPatnerDropdown();
		      
				//Select Severity
		         maintainErrorCodesPage.clickonSeverityDP();
		         maintainErrorCodesPage.selectSeverityfrmDP("Warning");
		         
		         maintainErrorCodesPage.clickLinkBacktoErrorcodedetails();
		         
		        // Click on Save
		         maintainErrorCodesPage.clickonSaveBTn();
		         String message=maintainErrorCodesPage.getErrorCodeCreatedMessage();
		         
		         
		         
		         
				
			//	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[contains(text(),'Select Severity')]")));
			//	driver.findElement(By.xpath("//label[contains(text(),'Select Severity')]")).click();
				
				
			/*
				
			     List<WebElement> Radiobuttons=driver.findElements(By.xpath("//p-tabview[1]/div[1]/div[1]/p-tabpanel[1]/div[1]/div[1]/div[1]"));
			   
			     List<String> RadioButtonList=new ArrayList<String>();
			     System.out.println(Radiobuttons.get(0).getText());
				  String[] value=Radiobuttons.get(0).getText().split("\n");
				
				for(int j=0;j<value.length;j++)
				{
			      System.out.println(value[j]);
				    RadioButtonList.add(value[j].trim());
				}
				
				System.out.println("Actual Radio Buttons are->"+RadioButtonList);
				
				String[] expectedradio={"Paste Instructions","File Upload"};
				
				
				List<String> ExpectedRadiButtonList=new ArrayList<String>();
				for(int k=0;k<expectedradio.length;k++)
				{
					System.out.println(expectedradio[k]);
					ExpectedRadiButtonList.add(expectedradio[k]);
					
				}
				
				System.out.println("Expected Radio buttons are->"+ExpectedRadiButtonList);
			
			// driver.findElement(By.xpath("//body/app-root[1]/div[1]/app-admin-layout[1]/div[1]/app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1")).click();
			 
			// driver.findElement(By.xpath("//a[contains(text(),'Roles Management')]")).click();
			 
			 System.out.println("1");
				
			 
			
			 
			//String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Roles Management')]")).getText();
			 */
			
           SoftAssert softAssert = new SoftAssert();
           softAssert.assertTrue(message.equalsIgnoreCase("Error code has been created successfully"), "Error code not created");
	
		      softAssert.assertAll();
		      
		 System.out.println("TC029_manintainErrorcodes Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC029_manintainErrorcodes Passed"); 
		
				        }
				   
	    catch(Throwable e)
				     {
	    
					   System.out.println("TC029_manintainErrorcodes Failed");
			  //  test.log(LogStatus.FAIL, "TC029_manintainErrorcodes Failed"); 
                          Assert.fail(e.getMessage());
						     
					   
				      }
			
			
		
		
		      }
	
	
}
