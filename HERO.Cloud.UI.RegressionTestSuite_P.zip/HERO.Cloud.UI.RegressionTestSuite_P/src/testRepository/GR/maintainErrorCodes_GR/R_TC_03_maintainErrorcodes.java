package testRepository.GR.maintainErrorCodes_GR;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_03_maintainErrorcodes extends base
{
	@Test
		public void SortingFunctionality() throws IOException
		{
		
	     try{
	    	 Thread.sleep(10000);
		     HomePage homePageObj=new HomePage();
		     homePageObj.mouseHoverAdministration();	
			 Thread.sleep(3000);
			 homePageObj.openModule("Maintain Error Codes");
			 MaintainErrorCodesPage maintainErrorCodesPage=new MaintainErrorCodesPage();  
			 String Pagetitle=maintainErrorCodesPage.getModulePageTitle();
	         System.out.println("Pagetitle->"+Pagetitle);	 
			 Thread.sleep(5000);
			
			//Clicking on Sort icon
		     maintainErrorCodesPage.clickSortIcon();
		     Thread.sleep(3000);
             List<String> ActiveErrorcodeList1 =maintainErrorCodesPage.getActiveErrorCodeList_UI(); 
			 System.out.println("ActiveErrorcodeList1->"+ActiveErrorcodeList1);
		     System.out.println("******************************");
            
		     //Clicking on Sort icon
		     maintainErrorCodesPage.clickSortIcon();
		     Thread.sleep(3000);
		     List<String> ActiveErrorcodeList2=maintainErrorCodesPage.getActiveErrorCodeList_UI();
		     System.out.println("ActiveErrorcodeList2->"+ActiveErrorcodeList2); 
		     //, String.CASE_INSENSITIVE_ORDER
		     
		     Collections.reverse(ActiveErrorcodeList2);
		     System.out.println("ActiveErrorcodeList2 after reversing->"+ActiveErrorcodeList2); 
						
			  Thread.sleep(3000);
              SoftAssert softassert = new SoftAssert();
			  softassert.assertTrue(ActiveErrorcodeList2.equals(ActiveErrorcodeList1),"Sorting not working as expected");
              softassert.assertAll();
				 
			  System.out.println("R_TC_03_maintainErrorcodes Passed");
		}
				   
	    catch(Throwable e)
				     {
	    	
	    	
	        System.out.println("R_TC_03_maintainErrorcodes Failed");
		//test.log(LogStatus.FAIL, "R_TC_03_maintainErrorcodes Failed"); 
         Assert.fail(e.getMessage());
						     
				}
		   }
	}
