package testRepository.GR.maintainErrorCodes_GR;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.MaintainErrorCodesPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class G_TC_11_maintainErrorcodes extends base
{

	
		

		@Test
		public void EditFunctionalityMainatainErrorcodePage() throws IOException
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;

			
	     try{
	    	 HomePage homePageObj=new HomePage();
			 homePageObj.mouseHoverAdministration();	
			 Thread.sleep(3000);
			 homePageObj.openModule("Maintain Error Codes");
			 MaintainErrorCodesPage maintainErrorCodesPage=new MaintainErrorCodesPage(); 	 
			 String PageTitle1=maintainErrorCodesPage.getModulePageTitle();
			 System.out.println("Page Title before clicking Edit Button->"+PageTitle1);
				
		  //Clicking on Edit Icon
				
			 maintainErrorCodesPage.clickEditbtn();	
			 String PageTitle2=maintainErrorCodesPage.getUpdatePageTitle();
			  System.out.println("Page Title after clicking Edit Button->"+PageTitle2);
			   
			// Updating description and Save
			  
			  maintainErrorCodesPage.editDescription();
			  maintainErrorCodesPage.clickonSaveBTn();
			  
			 System.out.println("1");
				
			 
			 Thread.sleep(5000);
			 
			 String PageTitle3=maintainErrorCodesPage.getModulePageTitle();
			 System.out.println("Page Title after editing error code and clicking on save Button->"+PageTitle3);
			 
			
           SoftAssert softAssert = new SoftAssert();
		     
		   //  test.log(LogStatus.INFO ,"Verifying page Title");
		     
	        softAssert.assertTrue(PageTitle1.equalsIgnoreCase("Maintain Error Codes"), "This is not Maintain Error Code page");
	        softAssert.assertTrue(PageTitle2.equalsIgnoreCase("Update Error Code"), "Incorrect page opening after clicking edit button");    
	        softAssert.assertTrue(PageTitle3.equalsIgnoreCase("Maintain Error Codes"), "User not returned to Module main page after editing and Saving error code");     
		    softAssert.assertAll();
		      
		    System.out.println("G_TC_11_maintainErrorcodes Passed");
		  //  test.log(LogStatus.PASS, "G_TC_11_maintainErrorcodes Passed"); 
				   
		     }
				   
	    catch(Throwable e)
				     {
					   System.out.println("G_TC_11_maintainErrorcodes Failed");
				  //  test.log(LogStatus.FAIL, "G_TC_11_maintainErrorcodes Failed"); 
					   Assert.fail(e.getMessage());
						     
					 }
		  }
		
}
