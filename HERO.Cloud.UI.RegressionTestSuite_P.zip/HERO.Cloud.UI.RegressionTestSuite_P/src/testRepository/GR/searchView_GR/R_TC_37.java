package testRepository.GR.searchView_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.searchViewPage;
import base.base;

public class R_TC_37 extends base{
	@Test
		public void VerifyBreadcrumb_DirectSearchResult() throws IOException
		{	
	     try{
				 
		
	    	 searchViewPage searchViewPageObj=new searchViewPage(); 
	 		 HomePage homePageObj=new HomePage();
	 	    homePageObj.mouseHoverSearchAndView();	
	      Thread.sleep(1000);
	      homePageObj.openSearchView();
	 	 //searchViewPageObj.waitForPageLoad();
	 	  
	 	  
	 	  Thread.sleep(10000);
	 	
	 	 searchViewPageObj.clickSelectDropdown();
	 	Thread.sleep(3000);
		String Claimid="HP2022897635395";
	 	 searchViewPageObj.enterValueTextbox(Claimid);
	 	Thread.sleep(3000);
	 	 searchViewPageObj.clickSearchIcon_Direct();
	 	  
	 	 Thread.sleep(3000);
	 	 searchViewPageObj.clickClaimstab();
 
	 	String UrlonClick_HomeLink=searchViewPageObj.clickHomeLinkSearchResult();
	 	
	 	System.out.println("UrlonClick_HomeLink->"+UrlonClick_HomeLink);
	 	
	 	driver.navigate().back();
	 	
	 	Thread.sleep(3000);
	 	String UrlonClick_SearchLink=searchViewPageObj.clickSearchLinkSearchResult();
		System.out.println("UrlonClick_SearchLink->"+UrlonClick_SearchLink);
	 	
	 	
	    SoftAssert softAssert = new SoftAssert();
	    
	    softAssert.assertTrue(UrlonClick_HomeLink.contains("user") && UrlonClick_HomeLink.contains("landing"),"Home link not working properly");
	    softAssert.assertTrue(UrlonClick_SearchLink.contains("searchAndView"),"Search link not working properly");
	    
	    softAssert.assertAll();
	    
	    System.out.println("TC037_searchView Passed");   
		 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC037_searchView Failed");
					   
	         //  test.log(LogStatus.FAIL, "TC037_searchView Failed"); 
			Assert.fail(e.getMessage());
						 
					}
		}
	}
