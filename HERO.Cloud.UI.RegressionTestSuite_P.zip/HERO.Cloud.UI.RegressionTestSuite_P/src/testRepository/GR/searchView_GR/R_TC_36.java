package testRepository.GR.searchView_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.searchViewPage;
import base.base;

public class R_TC_36 extends base{
	@Test
		public void ExporttoPDF_GuidedSearch() throws IOException
		{
	
		
				
	     try{
				 
		
	    	 searchViewPage searchViewPageObj=new searchViewPage(); 
	 		 HomePage homePageObj=new HomePage();
	 		 String  Downloadpath=getPropertyFileValue("DownloadFilepath");
	         System.out.println("Downloadpath->"+Downloadpath);
	        
	        
	      homePageObj.mouseHoverSearchAndView();	
	      homePageObj.openSearchView();
	 	 //searchViewPageObj.waitForPageLoad();	
	 	  Thread.sleep(20000);
	 	
	 	 searchViewPageObj.selectGuidedRadioButton();
	 	Thread.sleep(2000);
	 	 searchViewPageObj.clickSelectCombination();
	 	Thread.sleep(2000);
	 	 searchViewPageObj.selectGuidedSearchOption();
	 	 Thread.sleep(2000);
	 	searchViewPageObj.clickSearchIcon_Guided(); 
	 	 Thread.sleep(3000);
	 	
 
	 	
	 		
	 	 //Click on Export to Excel
	 	searchViewPageObj.DownloadPDF();
	 		
	 	//  test.log(LogStatus.INFO, "Getting Downloaded File Name");
	 	  File getLatestFile = base.getLatestFilefromDir(Downloadpath);
	 	  String fileName = getLatestFile.getName();
	 	  System.out.println("Downloaded File name->"+fileName);
  //    test.log(LogStatus.INFO, "Downloaded File name->"+fileName);
	 		    
	 		
	 	 Thread.sleep(3000);
	       SoftAssert softAssert = new SoftAssert();
	        Thread.sleep(3000);  
	      // verifying whether the file  with fileName present in the directory downloadpath or not
	        softAssert.assertTrue(isFileDownloaded(Downloadpath, fileName), "Download Failed");
	     //verifying whether the latest downloaded file contains "pdf" extension or not and name of file having Search_Results word in it
	        softAssert.assertTrue(fileName.contains("pdf") && fileName.contains("Search_Results"),"It is not a excel file");
	        softAssert.assertAll();     
	           System.out.println("R_TC_36_searchView Passed");   
		 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("R_TC_36_searchView Failed");
					   
					//  test.log(LogStatus.FAIL, "R_TC_36_searchView Failed"); 
               Assert.fail(e.getMessage());
						 
					}
		 }
	}
