package testRepository.GR.searchView_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.searchViewPage;
import base.base;

public class G_TC_45 extends base{
    @Test
		public void CreateNewCombination_GuidedSearch() throws IOException
		{
           try{
				 
		
	    	 searchViewPage searchViewPageObj=new searchViewPage(); 
	 		 HomePage homePageObj=new HomePage();

	      homePageObj.mouseHoverSearchAndView();	
	      Thread.sleep(3000);
	      homePageObj.openSearchView();
	 	 //searchViewPageObj.waitForPageLoad();	
	 	  Thread.sleep(10000);
	 	
	 	 searchViewPageObj.selectGuidedRadioButton();
	 	 searchViewPageObj.clickSelectCombination();
	 
	 	Thread.sleep(3000);
	 	searchViewPageObj.AddNewCombination_Verify();
	 
	 		
	 		
	        SoftAssert softAssert = new SoftAssert();
		    
	      // verifying whether the file  with fileName present in the directory downloadpath or not
	   
	           System.out.println("G_TC_45_searchView Passed");   
			 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("G_TC_45_searchView Failed");
					   
			//  test.log(LogStatus.FAIL, "G_TC_45_searchView Failed"); 
                 Assert.fail(e.getMessage());
						 
					}
		
		
		      }



	
}
