package testRepository.GR.searchView_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.searchViewPage;
import base.base;

public class R_TC_40 extends base{
@Test
		public void AddColumn_GuidedSearchResult() throws IOException
		{
	
		
				
	     try{
				 
		
	    	 searchViewPage searchViewPageObj=new searchViewPage(); 
	 		HomePage homePageObj=new HomePage();
           homePageObj.mouseHoverSearchAndView();	
	      Thread.sleep(2000);
	      homePageObj.openSearchView();
	 	  //searchViewPageObj.waitForPageLoad();
	 	 
	 	  Thread.sleep(20000);
	 	 searchViewPageObj.selectGuidedRadioButton();
	 	 Thread.sleep(2000);
	 	 searchViewPageObj.clickSelectCombination();
	 	 Thread.sleep(2000);
	 	 searchViewPageObj.selectGuidedSearchOption();
	 	 Thread.sleep(2000);
	 	 searchViewPageObj.clickSearchIcon_Guided(); 
	 	 Thread.sleep(3000);
	 	
	 	 searchViewPageObj.clickAddColumn();
	 	 Thread.sleep(5000);
	 	 String ResultHeaders=searchViewPageObj.getSearchResultHeader();
	 	
	 	
	    SoftAssert softAssert = new SoftAssert();
	    
	    softAssert.assertTrue(ResultHeaders.contains("Service Begin Date"), "Added column not reflected in Search Result Headers");
	   
	    
	    softAssert.assertAll();
	    
	    System.out.println("TC040_searchView Passed");   
	 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC040_searchView Failed");
					   
	         //  test.log(LogStatus.FAIL, "TC040_searchView Failed"); 
			  Assert.fail(e.getMessage());
						 
					}
		
		
		      }



	
}
