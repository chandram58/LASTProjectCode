package testRepository.GR.searchView_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.searchViewPage;
import base.base;

public class R_TC_41 extends base{
	@Test
		public void VerifyValidation_GuidedSearch() throws IOException
		{
	
		
				
	     try{
				 
		
	    	 searchViewPage searchViewPageObj=new searchViewPage(); 
	 		 HomePage homePageObj=new HomePage();

	        
	      homePageObj.mouseHoverSearchAndView();	
	      homePageObj.openSearchView();
	 	 //searchViewPageObj.waitForPageLoad();
	 	 
	 	  Thread.sleep(20000);
	 	
	 	 searchViewPageObj.selectGuidedRadioButton();
	 	Thread.sleep(2000);
	 	 searchViewPageObj.clickSearchIcon_Guided();
	 	 Thread.sleep(2000);
	 	
	 	
 
	 	String Validationerror=searchViewPageObj.getEmptyValidationErrortxt();
	 	
	 	System.out.println("Validationerror->"+Validationerror);
	 	
	 
	 	
	    SoftAssert softAssert = new SoftAssert();
	    
	    softAssert.assertTrue(Validationerror.equalsIgnoreCase("Please select a Combination"),"Incorrect error message");
	  
	    softAssert.assertAll();
	    
	    System.out.println("TC041_searchView Passed");   
		 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC041_searchView Failed");
					   
	         //  test.log(LogStatus.FAIL, "TC041_searchView Failed"); 
	            Assert.fail(e.getMessage());
						 
					}
	      }
}
