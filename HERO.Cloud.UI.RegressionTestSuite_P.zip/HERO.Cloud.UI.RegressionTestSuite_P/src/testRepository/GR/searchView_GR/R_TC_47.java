package testRepository.GR.searchView_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.searchViewPage;
import base.base;

public class R_TC_47 extends base{
	@Test
		public void DeleteFunctionality_MyCombination() throws IOException
		{
	try{
				 
		
	    	 searchViewPage searchViewPageObj=new searchViewPage(); 
	 		 HomePage homePageObj=new HomePage();
           homePageObj.mouseHoverSearchAndView();	
           homePageObj.openSearchView();
	 	  searchViewPageObj.waitForPageLoad();
	 	 
	 	  Thread.sleep(20000);
	 	 
	 	 searchViewPageObj.selectGuidedRadioButton();
	 	 searchViewPageObj.clickSelectCombination();
	 	 searchViewPageObj.selectGuidedSearchOption();
	 	 Thread.sleep(2000);
	 	searchViewPageObj.clickSearchIcon_Guided(); 
		 Thread.sleep(3000);
			
		int combinationCount_beforeDelete=searchViewPageObj.getCountCombination_MyCombinations();
		 System.out.println("combinationCount_beforeDelete->"+combinationCount_beforeDelete);	
	 	
		 SoftAssert softAssert = new SoftAssert();
		 if(combinationCount_beforeDelete>0)
		 	{
			 
			 //Click on Trash Icon for 1st combination
			 searchViewPageObj.clickTrashiconAndConfirm();
			 int combinationCount_AfterDelete=searchViewPageObj.getCountCombination_MyCombinations();
			 System.out.println("combinationCount_AfterDelete->"+combinationCount_AfterDelete);	
			 
			 softAssert.assertTrue(combinationCount_AfterDelete==combinationCount_beforeDelete-1, "Delete functionality for My Combination not working");
			 softAssert.assertAll();
		 	}
		 else
		 {
			 System.out.println("No Combination to Delete");
		 }
	 	
	   
	    
	    // softAssert.assertTrue(DefaultSearchType.equals("Service Begin Date"), "Added column not reflected in Search Result Headers");
	   
	    
	    softAssert.assertAll();
	    
	    System.out.println("TC047_searchView Passed");   
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
				     
				        }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC047_searchView Failed");
					   
	         //  test.log(LogStatus.FAIL, "TC047_searchView Failed"); 
				  String status="Fail";
				       
			   //	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						 
					}
		
		
		      }



	
}
