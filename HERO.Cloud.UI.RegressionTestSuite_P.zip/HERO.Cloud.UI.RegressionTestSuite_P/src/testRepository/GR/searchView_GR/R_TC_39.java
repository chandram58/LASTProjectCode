package testRepository.GR.searchView_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.searchViewPage;
import base.base;

public class R_TC_39 extends base{
	@Test
		public void VerifyBreadcrumb_GuidedSearchResultEditCombination() throws IOException
		{	
	     try{
				 
		
	    	 searchViewPage searchViewPageObj=new searchViewPage(); 
	 		 HomePage homePageObj=new HomePage();
            homePageObj.mouseHoverSearchAndView();	
	      Thread.sleep(2000);
	      homePageObj.openSearchView();
	 	 //searchViewPageObj.waitForPageLoad();
	 	 
	 	  Thread.sleep(20000);
	 	
	 	 
	 	
	 	  	 searchViewPageObj.selectGuidedRadioButton();
		 	 Thread.sleep(2000);
		 	 searchViewPageObj.clickSelectCombination();
		 	 Thread.sleep(2000);
		 	 searchViewPageObj.selectGuidedSearchOption();
		 	 Thread.sleep(2000);
		 	 searchViewPageObj.clickEditCombination();
		 	 Thread.sleep(2000);
	 	
	 	
 
	 	String UrlonClick_HomeLink=searchViewPageObj.clickHomeLinkSearchResult();
		Thread.sleep(3000);
	 	System.out.println("UrlonClick_HomeLink->"+UrlonClick_HomeLink);
	 	
	 	driver.navigate().back();
	 	
	 	Thread.sleep(3000);
	 	String UrlonClick_SearchLink=searchViewPageObj.clickSearchLinkEditCombination();
		System.out.println("UrlonClick_SearchLink->"+UrlonClick_SearchLink);
	 	
	 	
	    SoftAssert softAssert = new SoftAssert();
	    
	    softAssert.assertTrue(UrlonClick_HomeLink.contains("user") && UrlonClick_HomeLink.contains("landing"),"Home link not working properly");
	    softAssert.assertTrue(UrlonClick_SearchLink.contains("searchAndView"),"Search link not working properly");
	    
	    softAssert.assertAll();
	    
	    System.out.println("TC039_searchView Passed");   
		}
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC039_searchView Failed");
					   
	         //  test.log(LogStatus.FAIL, "TC039_searchView Failed"); 
		       Assert.fail(e.getMessage());
						 
					}
		
		
		      }



	
}
