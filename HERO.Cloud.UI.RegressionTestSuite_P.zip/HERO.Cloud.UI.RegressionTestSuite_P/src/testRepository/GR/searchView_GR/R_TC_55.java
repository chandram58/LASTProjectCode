package testRepository.GR.searchView_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.searchViewPage;
import base.base;

public class R_TC_55 extends base{
	@Test
		public void MaxCombination_GuidedSearchResult() throws IOException
		{
	try{
		searchViewPage searchViewPageObj=new searchViewPage(); 
	 	HomePage homePageObj=new HomePage();
      
	 	homePageObj.mouseHoverSearchAndView();
	 	  Thread.sleep(2000);
	 	 homePageObj.openSearchView();
	 	 //searchViewPageObj.waitForPageLoad();
	 	 
	 	  Thread.sleep(20000);
	 	 searchViewPageObj.selectGuidedRadioButton();
	 	 searchViewPageObj.clickSelectCombination();
	 	 searchViewPageObj.selectGuidedSearchOption();
	 	 Thread.sleep(2000);
	 	searchViewPageObj.clickSearchIcon_Guided(); 
	 	 Thread.sleep(3000);
	 	 SoftAssert softAssert = new SoftAssert();
	 	int combinationCount=searchViewPageObj.getCountCombination_MyCombinations();
	 	
	 	if(combinationCount>=10)
	 	{
	 		searchViewPageObj.clickAddToMyCombination();
	 		
	 		String ErrorTxt=searchViewPageObj.getMaxCombinationsError();
	 		System.out.println("ErrorTxt->"+ErrorTxt);
	 		softAssert.assertTrue(ErrorTxt.equalsIgnoreCase("Cannot have more than 10 combinations."));
	 		
	 	}
	 	else 
	 	{
	 	 System.out.println("Combination count is less than 10");	
	 	}
	 
	 	
	softAssert.assertAll();
	
	System.out.println("TC055_searchView Passed");   
				   
		      String status="Pass";
		   }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC055_searchView Failed");
					   
	         //  test.log(LogStatus.FAIL, "TC055_searchView Failed"); 
				  String status="Fail";
	          Assert.fail(e.getMessage());
						 
					}
		
		
		      }



	
}
