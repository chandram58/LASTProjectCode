package testRepository.GR.searchView_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.searchViewPage;
import base.base;

public class R_TC_34 extends base{
	@Test
		public void ExporttoCSV_DirectSearch() throws IOException
		{		
	     try{
	    	 searchViewPage searchViewPageObj=new searchViewPage(); 
	 		 HomePage homePageObj=new HomePage();
	 		 
	 		 String  Downloadpath=getPropertyFileValue("DownloadFilepath");
	         System.out.println("Downloadpath->"+Downloadpath);
			
		  homePageObj.mouseHoverSearchAndView();	
	 	  homePageObj.openSearchView();
	 	// searchViewPageObj.waitForPageLoad();
	 		
	 	  Thread.sleep(10000);
	 	
	 	 searchViewPageObj.clickSelectDropdown();
	 	 Thread.sleep(2000);
	 	String Claimid="HP2022897635395";
	 	 searchViewPageObj.enterValueTextbox(Claimid);
	 	 Thread.sleep(2000);
	 	 searchViewPageObj.clickSearchIcon_Direct();
	 	  
	 	 Thread.sleep(3000);
	 	 searchViewPageObj.clickClaimstab();
 
	 	 
	 	 Thread.sleep(3000);
	 	 //Click on Export to Excel
	 	searchViewPageObj.DownloadCSV();
	 		
	 	//  test.log(LogStatus.INFO, "Getting Downloaded File Name");
	 	  File getLatestFile = base.getLatestFilefromDir(Downloadpath);
	 	  String fileName = getLatestFile.getName();
	 	  System.out.println("Downloaded File name->"+fileName);
  //    test.log(LogStatus.INFO, "Downloaded File name->"+fileName);
	 		    
	 		
	 		
	        SoftAssert softAssert = new SoftAssert();
		    
	      // verifying whether the file  with fileName present in the directory downloadpath or not
	        softAssert.assertTrue(isFileDownloaded(Downloadpath, fileName), "Download Failed");
	     //verifying whether the latest downloaded file contains "csv" extension or not and name of file having Search_Results word in it
	        softAssert.assertTrue(fileName.contains("csv") && fileName.contains("Search_Results"),"It is not a csv file");
	        softAssert.assertAll();     
	           System.out.println("TC034_searchView Passed");   
	}
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC034_searchView Failed");
					   
					//  test.log(LogStatus.FAIL, "TC034_searchView Failed"); 
                  Assert.fail(e.getMessage());
						 
					}
          }
	}
