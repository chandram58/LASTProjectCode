package testRepository.GR.QueueAssignment_GR;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.QueuesAssignmentPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC12_2_queuesAssignment extends base
{
	@Test
		public void SortingFunctionality() throws IOException, InterruptedException
		{
			Thread.sleep(5000);
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Queues Assignment");
			
			QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
			String PageTitle=queueAssignmentPageObj.getPageHeader_QueueAssignment();
			System.out.println(PageTitle);
			
			try
			{
			queueAssignmentPageObj.selectUserOrGroupFromDropdown("User");
			String SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
			System.out.println("Searchbox text Populated->"+SerachboxText);
			queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
	 		queueAssignmentPageObj.selectUserOrGroupFromSearchDropdown("Rajeev Khera");
	 		String selectedUser=queueAssignmentPageObj.getValueFromSearchBox();
	 		System.out.println("Selected User -> "+selectedUser);
	 		Thread.sleep(2000);
	 		
	 		
			 
		
			
		  
			 Thread.sleep(5000);
			 
			  //clicking sort icon in Claim then result should appear in ascending order with respective to Claim
			 queueAssignmentPageObj.clickSortQueueName_Queues();
		 	  
		 	 List<String> List_ClaimNumber_asc=queueAssignmentPageObj.ascendingOrderList_Claim();
		 	 //clicking sort icon again in Claim then result should appear in descending order with respective to Claim 
		 	queueAssignmentPageObj.clickSortQueueName_Queues();
		 	 
		 	 List<String> List_ClaimNumber_desc=queueAssignmentPageObj.descendingOrderList_Claim();
		 	 
		 	 
		 	 
		 	 
		 	 
		 		
		 	  //clicking sort icon in Role_Name then result should appear in ascending order with respective to Role_Name
		        SoftAssert softAssert = new SoftAssert();
			    
		        softAssert.assertEquals(List_ClaimNumber_asc.get(0), List_ClaimNumber_desc.get(List_ClaimNumber_desc.size()-1), "1st row  of ascending order and last row of descending order of Active Roles not matching");
			     
	            softAssert.assertAll();
		           System.out.println("R_TC12_4_queueAssignment Passed");   
		 }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC023_queuesAssignment  Failed");
					   
					//  test.log(LogStatus.FAIL, "TC23_modifyTimecard  Failed"); 
					   Assert.fail(e.getMessage());
						     
					   
			  }
		
		  }
	
}