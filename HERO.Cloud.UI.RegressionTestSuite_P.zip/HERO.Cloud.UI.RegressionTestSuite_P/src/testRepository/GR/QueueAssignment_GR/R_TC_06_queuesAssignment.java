package testRepository.GR.QueueAssignment_GR;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;
import pages.HomePage;
import pages.QueuesAssignmentPage;

public class R_TC_06_queuesAssignment extends base
{
	@Test
		public void VerifyGroupQueueList() throws IOException, InterruptedException
		{
			
		
			QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
	 		HomePage homePageObj=new HomePage();
            homePageObj.mouseHoverAdministration();	
	 		Thread.sleep(3000);
	 		homePageObj.openModule("Queues Assignment");
	 		String PageTitle=queueAssignmentPageObj.getPageHeader_QueueAssignment();
	 		System.out.println(PageTitle);
	 		queueAssignmentPageObj.selectUserOrGroupFromDropdown("Group");
	 		
	 		String SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
	 		System.out.println("Searchbox text Populated->"+SerachboxText);
			
	 		
	 		queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
	 		Thread.sleep(1000);
	 		queueAssignmentPageObj.selectUserOrGroupFromSearchDropdown("CMS Aging");
	 		String selectedGroup=queueAssignmentPageObj.getValueFromSearchBox();
	 		System.out.println("Selected Group -> "+selectedGroup);
	 		Thread.sleep(2000);
				
	 		String SectionTitle=queueAssignmentPageObj.getSectionHeader_ListOfQueues();
	 		System.out.println("Section Title -> "+SectionTitle);
	 		
	 		String PopulatedUser=queueAssignmentPageObj.getUserName_ListOfQueues();
	 		System.out.println("Populated Users -> "+PopulatedUser);
	 		
	 		Boolean flag1=queueAssignmentPageObj.verifyListofQueuesSection();
	 		Boolean flag2=queueAssignmentPageObj.verifyQueuesSection();
	 		Boolean flag3=queueAssignmentPageObj.verifyPrimaryQueuesSection();
	 		Boolean flag4=queueAssignmentPageObj.verifySecondaryQueuesSection();
						
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
				
			    softassert.assertTrue(SectionTitle.contains("List Of Queues"), "Incorrect text being populated");
			    softassert.assertTrue(SectionTitle.contains(selectedGroup), "Incorrect Group being populated"); 
			    softassert.assertTrue(flag1, "List of Queues Section is not present");
			    softassert.assertTrue(flag2, "Queue Section is not present");
			    softassert.assertTrue(flag3, "Primary Queues Section is not present");
			    softassert.assertTrue(flag4, "Secondary Queues Section is not present");			    
			   
			    softassert.assertAll();
				 
				    System.out.println("TC006_queuesAssignment Passed");
				    
				    //test.log(LogStatus.FAIL, "TC006_queuesAssignment Failed"); 
			}
				   
	    catch(Throwable e)
				     {
				   System.out.println("TC006_queuesAssignment Failed");
					   
					//  test.log(LogStatus.FAIL, "TC006_queuesAssignment Failed"); 
				      Assert.fail(e.getMessage());
						     
				 
				      }
	
	      }


}
