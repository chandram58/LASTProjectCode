package testRepository.GR.QueueAssignment_GR;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.QueuesAssignmentPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_52_queuesAssignment extends base
{
	@Test
		public void VerifyUserwithoutAstriskFunctionality() throws IOException, InterruptedException
		{
			
			Thread.sleep(5000);
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();
			Thread.sleep(5000);
	 	 	
			homePageObj.openModule("Queues Assignment");
			
			QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
			String PageTitle=queueAssignmentPageObj.getPageHeader_QueueAssignment();
			System.out.println(PageTitle);
			
			try{
			
				
		  //Select Users from drop down and Queue from Primary and secondary section and Save It
		 			
			queueAssignmentPageObj.selectUserOrGroupFromDropdown("User");
			
			String SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
			System.out.println("Searchbox text Populated->"+SerachboxText);
			queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
	 		queueAssignmentPageObj.selectUserOrGroupFromSearchDropdown("Hanimi Golamari");
	 		String selectedUser=queueAssignmentPageObj.getValueFromSearchBox();
	 		System.out.println("Selected User -> "+selectedUser);
	 		Thread.sleep(5000);
	 		
	 		queueAssignmentPageObj.removeQueuefrmPrimary();
	 		queueAssignmentPageObj.removeQueuefrmsecondary();
	 		queueAssignmentPageObj.clickSaveButton();
	        
	 	     Thread.sleep(5000);
	 		//click on Group link  and remove Queue from Primary and secondary Section and Save it
	 		WebElement Group=queueAssignmentPageObj.getAssociatedGroup_Users();
	 		Group.click();
         
	 		
	 		queueAssignmentPageObj.removeQueuefrmPrimary();
	 		queueAssignmentPageObj.removeQueuefrmsecondary();
	 		Thread.sleep(5000);
	 		queueAssignmentPageObj.clickSaveButton();
	 		
	 		//Now assign a Queue and save  in any of section while group drop down is selected
	 		Thread.sleep(5000);
	 		queueAssignmentPageObj.DragandDropofQueueforPrimaryQueue();
	 		queueAssignmentPageObj.selectPriority_primaryQueue();
	 		queueAssignmentPageObj.clickSaveButton();
	 		
	 		//Select users link and Verify Astrix in user name
	 		
	 		
	 		WebElement Users=queueAssignmentPageObj.getAssociatedUsers_Group();
	 	
	 		 Thread.sleep(2000);
	 		 
	 		
	 		

			SoftAssert softassert = new SoftAssert();
		    softassert.assertFalse(Users.getText().contains("*"),"Associated user  having Astrix mark when no assignment of queue from user assignment");
		    softassert.assertAll();	
				 
				    System.out.println("R_TC_52_queueAssignment Passed");
				    //test.log(LogStatus.FAIL, "R_TC_52_queueAssignment Failed"); 
	}
				   
	    catch(Throwable e)
				     {
					   System.out.println("R_TC_52_queueAssignment Failed");
					   
					//  test.log(LogStatus.FAIL, "R_TC_52_queueAssignment Failed"); 
					   Assert.fail(e.getMessage());
			  
				      }
	
	      }


}