package testRepository.GR.QueueAssignment_GR;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;
import pages.HomePage;
import pages.QueuesAssignmentPage;

public class R_TC_07_queuesAssignment extends base
{
	@Test
		public void VerifyUserQueueList() throws IOException, InterruptedException
		{
			
		
			Thread.sleep(5000);
			
			
	 		HomePage homePageObj=new HomePage();


	 		homePageObj.mouseHoverAdministration();	
	 		Thread.sleep(3000);
	 		homePageObj.openModule("Queues Assignment");
	 		QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
	 		String PageTitle=queueAssignmentPageObj.getPageHeader_QueueAssignment();
	 		System.out.println(PageTitle);
	 		queueAssignmentPageObj.selectUserOrGroupFromDropdown("User");
	 		
	 		String SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
	 		System.out.println("Searchbox text Populated->"+SerachboxText);
			
		
	 		queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
	 		queueAssignmentPageObj.selectUserOrGroupFromSearchDropdown("Chandra Kumar");
	 		String selectedUser=queueAssignmentPageObj.getValueFromSearchBox();
	 		System.out.println("Selected User -> "+selectedUser);
	 		Thread.sleep(2000);
	 		
	 		
		
	 		String SectionTitle=queueAssignmentPageObj.getSectionHeader_ListOfQueues();
	 		System.out.println("SectionTitle -> "+SectionTitle);
	 		
	 		String PopulatedUser=queueAssignmentPageObj.getUserName_ListOfQueues();
	 		System.out.println("Populated User -> "+PopulatedUser);
	 		
	 		Boolean flag1=queueAssignmentPageObj.verifyListofQueuesSection();
	 		Boolean flag2=queueAssignmentPageObj.verifyQueuesSection();
	 		Boolean flag3=queueAssignmentPageObj.verifyPrimaryQueuesSection();
	 		Boolean flag4=queueAssignmentPageObj.verifySecondaryQueuesSection();
						
			    try
			    {
			    SoftAssert softassert = new SoftAssert();
				
			    softassert.assertTrue(SectionTitle.contains("List Of Queues"), "Incorrect text being populated");
			    softassert.assertTrue(PopulatedUser.equalsIgnoreCase(selectedUser), "Incorrect User being populated"); 
			    softassert.assertTrue(flag1, "List of Queues Section is not present");
			    softassert.assertTrue(flag2, "Queue Section is not present");
			    softassert.assertTrue(flag3, "Primary Queues Section is not present");
			    softassert.assertTrue(flag4, "Secondary Queues Section is not present");
			    
			    
			   
			    softassert.assertAll();
				 
				    System.out.println("TC007_queuesAssignment Passed");
				    //test.log(LogStatus.FAIL, "TC006_userProfile Failed"); 
		}
				   
	    catch(Throwable e)
				     {
				   System.out.println("TC007_queueAssignment Failed");
		//  test.log(LogStatus.FAIL, "TC007_queueAssignment Failed"); 
				   Assert.fail(e.getMessage());		 
	    }
	}
}
