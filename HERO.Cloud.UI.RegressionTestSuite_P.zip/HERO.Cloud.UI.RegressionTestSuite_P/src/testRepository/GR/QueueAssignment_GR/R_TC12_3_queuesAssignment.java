package testRepository.GR.QueueAssignment_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.QueuesAssignmentPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC12_3_queuesAssignment extends base
{
	@Test
		public void VerifySearchwithUserOrGrouporQueue() throws IOException, InterruptedException
		{
             Thread.sleep(5000);
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();	
			Thread.sleep(3000);
			homePageObj.openModule("Queues Assignment");
			
			QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
			String PageTitle=queueAssignmentPageObj.getPageHeader_QueueAssignment();
			System.out.println(PageTitle);
			
			
			//Validating Search User Result
			queueAssignmentPageObj.selectUserOrGroupFromDropdown("User");
			try
			{
			String SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
			System.out.println("Searchbox text Populated->"+SerachboxText);
			queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
	       
			String searchTermUser="ba";
		    List<WebElement> SearchResult=queueAssignmentPageObj.getSearchUserResult(searchTermUser);
		    System.out.println("No Of Search result -> "+SearchResult.size());
				
		    SoftAssert softassert = new SoftAssert();
		   for(int k=0;k<SearchResult.size();k++)
		    {
		    	 System.out.println("Row "+(k+1)+"->"+SearchResult.get(k).getText());
		    	 
		    	 softassert.assertTrue(SearchResult.get(k).getText().toLowerCase().contains(searchTermUser), "Row no-"+(k+1)+" not having search term");
		    	
		    }
		    	
		    	
		    	
			    softassert.assertAll();
			    
			    
			 
			  //Validating Search Group result
			    
				queueAssignmentPageObj.selectUserOrGroupFromDropdown("Group");
				
				
				SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
				System.out.println("Searchbox text Populated->"+SerachboxText);
				queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
		       
				String searchTermGroup="aut";
			   SearchResult=queueAssignmentPageObj.getSearchUserResult(searchTermGroup);
			    System.out.println("No Of Search result -> "+SearchResult.size());
					
			   
			   for(int k=0;k<SearchResult.size();k++)
			    {
			    	 System.out.println("Row "+(k+1)+"->"+SearchResult.get(k).getText());
			    	 
			    	 softassert.assertTrue(SearchResult.get(k).getText().toLowerCase().contains(searchTermGroup), "Row no-"+(k+1)+" not having search term");
			    	
			    }
			    	
			    softassert.assertAll();
				    
		//Validating queue Search Result
			    
			   String searchTermQueue="Regular";
			   List<WebElement> Queuelist=queueAssignmentPageObj.getSearchResultQueuewithGroup(searchTermQueue);
			     
			    for(int k=0;k<Queuelist.size();k++)
			    {
			      if(Queuelist.get(k).getAttribute("class").equals("ui-multiselect-item ui-corner-all ui-state-highlight"))
			      {
			    	  System.out.println("Row "+(k+1)+"->"+Queuelist.get(k).findElement(By.tagName("label")).getAttribute("title"));
			    	 
			    	 softassert.assertTrue(Queuelist.get(k).findElement(By.tagName("label")).getAttribute("title").toLowerCase().contains(searchTermQueue), "Row no-"+(k+1)+" not having search term");
			      }
			    }
			    	
			    	softassert.assertAll();
				System.out.println("R_TC12_3_queueAssignment Passed");
		}
				   
	    catch(Throwable e)
				     {
					   System.out.println("R_TC12_3_queueAssignment Failed");
				            Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }
}
	