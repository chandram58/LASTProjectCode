package testRepository.GR.QueueAssignment_GR;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.QueuesAssignmentPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_78_queuesAssignment extends base
{
	@Test
		public void UserlistSeperatedbycomma() throws IOException, InterruptedException
		{
			
			Thread.sleep(5000);
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();
			Thread.sleep(5000);
	 	 	
			homePageObj.openModule("Queues Assignment");
			
			QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
			String PageTitle=queueAssignmentPageObj.getPageHeader_QueueAssignment();
			System.out.println(PageTitle);
			
			try{
			
				
		  //Select Group from drop down and Queue from Primary and secondary section and Save It
		 			
			queueAssignmentPageObj.selectUserOrGroupFromDropdown("Group");
			
			String SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
			System.out.println("Searchbox text Populated->"+SerachboxText);
			queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
	 		queueAssignmentPageObj.selectUserOrGroupFromSearchDropdown("HERO UAT Testers");
	 		String selectedGroup=queueAssignmentPageObj.getValueFromSearchBox();
	 		System.out.println("Selected Group -> "+selectedGroup);
	 		Thread.sleep(5000);
	 		
	 		
	 		 //Select User from drop down and Queue from Primary and secondary section and Save It
 			
			WebElement UserList=queueAssignmentPageObj.getAssociatedUsers_Group();
			System.out.println("UserList->"+UserList.getText());
			
			
	

			SoftAssert softassert = new SoftAssert();
		   
		    softassert.assertTrue(UserList.getText().contains(",")," User not seperated by comma");
		    softassert.assertAll();	
	/*			
		    Users.click();
		    Thread.sleep(3000);
			
				
		    String SectionTitle=queueAssignmentPageObj.getSectionTitle();
		    String PopulatedGroup=queueAssignmentPageObj.getPopulatedgroup();
		    String PrimaryQueuesectionContent=queueAssignmentPageObj.getPrimaryQueuesectionContent();
			String SecondaryQueuesectionContent=queueAssignmentPageObj.getSecondaryQueuesectionContent();
				
				
				
		      softassert.assertTrue(SectionTitle.contains("List Of Queues"), "Incorrect text being populated");
			  softassert.assertTrue(PopulatedGroup.equalsIgnoreCase(selectedGroup), "Incorrect Group being populated"); 
			  softassert.assertFalse(PrimaryQueuesectionContent.contains("No records found") && SecondaryQueuesectionContent.contains("No records found") , "Primary Queue Section and Secondary Queue section are empty");

			   
			    softassert.assertAll();
			    
			    */
				System.out.println("R_TC_78_queueAssignment Passed");
		//test.log(LogStatus.PASS, "R_TC_78_queueAssignment Passed"); 
			}
				   
	    catch(Throwable e)
				     {
					   System.out.println("R_TC_78_queueAssignment Failed");
				//  test.log(LogStatus.FAIL, "R_TC_78_queueAssignment Failed"); 
					   Assert.fail(e.getMessage());
						   
				      }
	
	      }


}