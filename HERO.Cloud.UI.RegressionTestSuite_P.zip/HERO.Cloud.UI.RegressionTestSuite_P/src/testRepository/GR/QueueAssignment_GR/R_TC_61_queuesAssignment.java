package testRepository.GR.QueueAssignment_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.QueuesAssignmentPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_61_queuesAssignment extends base
{
	@Test
		public void ChangeQueueAssignmentIndividualToGroup() throws IOException, InterruptedException
		{
			
			Thread.sleep(5000);
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();
			Thread.sleep(5000);
	 	 	
			homePageObj.openModule("Queues Assignment");
			
			QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
			String PageTitle=queueAssignmentPageObj.getPageHeader_QueueAssignment();
			System.out.println(PageTitle);
			
			try{
			
				
		  //Select Group from drop down and Queue from Primary and secondary section and Save It
		 			
			queueAssignmentPageObj.selectUserOrGroupFromDropdown("Group");
			
			String SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
			System.out.println("Searchbox text Populated->"+SerachboxText);
			queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
	 		queueAssignmentPageObj.selectUserOrGroupFromSearchDropdown("5XE0iRwwfjzyV4WwHxYKxxnI");
	 		String selectedGroup=queueAssignmentPageObj.getValueFromSearchBox();
	 		System.out.println("Selected Group -> "+selectedGroup);
	 		Thread.sleep(5000);
	 		
	 		//click on User link  and remove Queue from Primary and secondary Section and Save it
	 		WebElement Users=queueAssignmentPageObj.getAssociatedUsers_Group();
	 		Users.click();
	 		
	 		
	 		queueAssignmentPageObj.removeQueuefrmPrimary();
	 		queueAssignmentPageObj.removeQueuefrmsecondary();
	 		queueAssignmentPageObj.clickSaveButton();
	 		
	 	    String Queuelist_userAssignment_primary=queueAssignmentPageObj.getPrimaryQueuesectionContent();
	 		System.out.println("Queuelist_userAssignment Primary Section->"+Queuelist_userAssignment_primary);
	 		
	 		String Queuelist_userAssignment_secondary=queueAssignmentPageObj.getSecondaryQueuesectionContent();
		 	System.out.println("Queuelist_userAssignment Seconadry Section->"+Queuelist_userAssignment_secondary);
		 		
	        
	 	     Thread.sleep(5000);
	 		//click on Group link  and add Queue and save it.
	 		WebElement Group=queueAssignmentPageObj.getAssociatedGroup_Users();
	 		Group.click();
         
	 		queueAssignmentPageObj.DragandDropofQueueforPrimaryQueue();
	 		queueAssignmentPageObj.selectPriority_primaryQueue();
	 
	 		Thread.sleep(5000);
	 		queueAssignmentPageObj.clickSaveButton();
	 		
	 		String Queuelist_groupAssignment_primary=queueAssignmentPageObj.getPrimaryQueuesectionContent();
		     System.out.println("Queuelist_groupAssignment_primary->"+Queuelist_groupAssignment_primary);
		        
		    String Queuelist_groupAssignment_secondary=queueAssignmentPageObj.getPrimaryQueuesectionContent();
		      System.out.println("Queuelist_groupAssignment_secondary->"+Queuelist_groupAssignment_secondary);
		        
	 		 
	 		
	 		

			SoftAssert softassert = new SoftAssert();
		    softassert.assertFalse(Queuelist_groupAssignment_primary.contains("No records found"),"No queues in group assignment primary section");
		    softassert.assertFalse(Queuelist_groupAssignment_secondary.contains("No records found"),"No queues in group assignment primary section");
		    softassert.assertTrue(Queuelist_userAssignment_primary.contains("No records found"),"Queues present in User assignment primary section");
		    softassert.assertTrue(Queuelist_userAssignment_secondary.contains("No records found"),"Queues present in User assignment Secondary section");
		    softassert.assertAll();	
	/*			
		    Users.click();
		    Thread.sleep(3000);
			
				
		    String SectionTitle=queueAssignmentPageObj.getSectionTitle();
		    String PopulatedGroup=queueAssignmentPageObj.getPopulatedgroup();
		    String PrimaryQueuesectionContent=queueAssignmentPageObj.getPrimaryQueuesectionContent();
			String SecondaryQueuesectionContent=queueAssignmentPageObj.getSecondaryQueuesectionContent();
				
				
				
		      softassert.assertTrue(SectionTitle.contains("List Of Queues"), "Incorrect text being populated");
			  softassert.assertTrue(PopulatedGroup.equalsIgnoreCase(selectedGroup), "Incorrect Group being populated"); 
			  softassert.assertFalse(PrimaryQueuesectionContent.contains("No records found") && SecondaryQueuesectionContent.contains("No records found") , "Primary Queue Section and Secondary Queue section are empty");

			   
			    softassert.assertAll();
			    
			    */
				System.out.println("R_TC_61_queueAssignment Passed");
				    
				    //test.log(LogStatus.FAIL, "R_TC_61_queueAssignment Failed"); 
			}
				   
	    catch(Throwable e)
				     {
					   System.out.println("R_TC_61_queueAssignment Failed");
					   
					//  test.log(LogStatus.FAIL, "R_TC_61_queueAssignment Failed"); 
					   Assert.fail(e.getMessage());
						      }
	
	      }


}