package testRepository.GR.QueueAssignment_GR;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.QueuesAssignmentPage;
import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class R_TC_13_queuesAssignment extends base
{
	@Test
		public void UserAssignedQueueNotPresentInGroupAssignedQueue() throws IOException, InterruptedException
		{
			
			Thread.sleep(5000);
			
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();
			Thread.sleep(5000);
	 	 	
			homePageObj.openModule("Queues Assignment");
			
			QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
			String PageTitle=queueAssignmentPageObj.getPageHeader_QueueAssignment();
			System.out.println(PageTitle);
			
			try{
			
				
		  //Select Group from drop down and Queue from Primary and secondary section and Save It
		 			
			queueAssignmentPageObj.selectUserOrGroupFromDropdown("Group");
			
			String SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
			System.out.println("Searchbox text Populated->"+SerachboxText);
			queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
	 		queueAssignmentPageObj.selectUserOrGroupFromSearchDropdown("CMS Aging");
	 		String selectedGroup=queueAssignmentPageObj.getValueFromSearchBox();
	 		System.out.println("Selected Group -> "+selectedGroup);
	 		Thread.sleep(5000);
	 		
	 		queueAssignmentPageObj.removeQueuefrmPrimary();
	 		queueAssignmentPageObj.removeQueuefrmsecondary();
	 		queueAssignmentPageObj.clickSaveButton();
	        
	 	     Thread.sleep(5000);
	 		//click on User link  and remove Queue from Primary and secondary Section and Save it
	 		WebElement Users=queueAssignmentPageObj.getAssociatedUsers_Group();
	 		Users.click();
         
	 		
	 		queueAssignmentPageObj.removeQueuefrmPrimary();
	 		queueAssignmentPageObj.removeQueuefrmsecondary();
	 		Thread.sleep(5000);
	 		queueAssignmentPageObj.clickSaveButton();
	 		
	 		//Now assign a Queue and save  in any of section while user drop down is selected
	 		Thread.sleep(5000);
	 		queueAssignmentPageObj.DragandDropofQueueforPrimaryQueue();
	 		queueAssignmentPageObj.selectPriority_primaryQueue();
	 		queueAssignmentPageObj.clickSaveButton();
	 		
	 		//Capture Queue list
	 		String PrimaryQueuesection_User=queueAssignmentPageObj.getPrimaryQueuesectionContent();
	 		System.out.println("PrimaryQueuesection_User->"+PrimaryQueuesection_User);
	 		
	 		
	 		
	 		
	 		//Select Group link and Verify Astrix in user name
	 		
	 		
	 		WebElement Group=queueAssignmentPageObj.getAssociatedGroup_Users();
	 		Group.click();
	 		 Thread.sleep(2000);
	 		 
	 		String PrimaryQueuesection_Group=queueAssignmentPageObj.getPrimaryQueuesectionContent();
	 		System.out.println("PrimaryQueuesection_Group->"+PrimaryQueuesection_Group);
	 		
	 		

			SoftAssert softassert = new SoftAssert();
		    softassert.assertFalse(PrimaryQueuesection_Group.equalsIgnoreCase(PrimaryQueuesection_User)," Queues assigned to Users via the User  Assignment is not displayed under Group Assignment");
		    softassert.assertAll();	
	/*			
		    Users.click();
		    Thread.sleep(3000);
			
				
		    String SectionTitle=queueAssignmentPageObj.getSectionTitle();
		    String PopulatedGroup=queueAssignmentPageObj.getPopulatedgroup();
		    String PrimaryQueuesectionContent=queueAssignmentPageObj.getPrimaryQueuesectionContent();
			String SecondaryQueuesectionContent=queueAssignmentPageObj.getSecondaryQueuesectionContent();
				
				
				
		      softassert.assertTrue(SectionTitle.contains("List Of Queues"), "Incorrect text being populated");
			  softassert.assertTrue(PopulatedGroup.equalsIgnoreCase(selectedGroup), "Incorrect Group being populated"); 
			  softassert.assertFalse(PrimaryQueuesectionContent.contains("No records found") && SecondaryQueuesectionContent.contains("No records found") , "Primary Queue Section and Secondary Queue section are empty");

			   
			    softassert.assertAll();
			    
			    */
				System.out.println("R_TC_13_queueAssignment Passed");
				    
				    //test.log(LogStatus.FAIL, "R_TC_13_queueAssignment Passed"); 
			 }
				   
	    catch(Throwable e)
				     {
					   System.out.println("R_TC_13_queueAssignment Failed");
					   
					//  test.log(LogStatus.FAIL, "R_TC_13_queueAssignment Failed"); 
                      Assert.fail(e.getMessage());
						     }
	             }


}