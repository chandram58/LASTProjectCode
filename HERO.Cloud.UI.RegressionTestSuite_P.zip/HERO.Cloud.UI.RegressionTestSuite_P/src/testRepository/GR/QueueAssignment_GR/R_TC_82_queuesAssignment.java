package testRepository.GR.QueueAssignment_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.QueuesAssignmentPage;
import base.base;

import com.relevantcodes.extentreports.LogStatus;

public class R_TC_82_queuesAssignment extends base
{
	@Test
		public void ActiveUsershowninQueueAssignmentPage() throws IOException, InterruptedException
		{
			
            Thread.sleep(5000);
		//Navigating to User Profile Page and getting Active list of users	
			HomePage homePageObj=new HomePage();
			homePageObj.mouseHoverAdministration();
			Thread.sleep(5000);
	 	 	try{
			homePageObj.openModule("User Profile");
			Thread.sleep(5000);
			QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
			List<String> ActiveUserListUserProfile=queueAssignmentPageObj.getActiveUserList_UserProfile();
			
			Collections.sort(ActiveUserListUserProfile);
			System.out.println("Sorted ActiveUserListUserProfile->"+ActiveUserListUserProfile);
			
			
			
			//Navigating to Queue assignment User assignment page  
			homePageObj.mouseHoverAdministration();
			Thread.sleep(5000);
	 	 	
			homePageObj.openModule("Queues Assignment");
			String PageTitle2=queueAssignmentPageObj.getPageHeader_QueueAssignment();
			System.out.println(PageTitle2);
			
			
			
				
		  //Select user from drop down and click on select user box to display user list 
		 			
			queueAssignmentPageObj.selectUserOrGroupFromDropdown("User");
			queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
			ArrayList<String> UserListQueueAssignment=queueAssignmentPageObj.getSearchResultsList();
			
			
			Collections.sort(UserListQueueAssignment);
			System.out.println("Sorted UserListQueueAssignment->"+UserListQueueAssignment);
			  Thread.sleep(3000);

			
			    SoftAssert softassert = new SoftAssert();
			    softassert.assertEquals(ActiveUserListUserProfile,UserListQueueAssignment, "Active user list in User profile and Queue assignment not matching");
			    softassert.assertAll();
				 
				System.out.println("R_TC_82_QueueAssignment Passed");
			}
				   
	    catch(Throwable e)
				     {
					   System.out.println("R_TC_82_QueueAssignment Failed");
					   
					//  test.log(LogStatus.FAIL, "R_TC_82_QueueAssignment Failed"); 
					   Assert.fail(e.getMessage());  
				      }
	          }
	
}
