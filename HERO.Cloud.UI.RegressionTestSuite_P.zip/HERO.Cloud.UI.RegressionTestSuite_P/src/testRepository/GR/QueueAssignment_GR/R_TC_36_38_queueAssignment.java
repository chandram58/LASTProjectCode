package testRepository.GR.QueueAssignment_GR;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.QueuesAssignmentPage;

public class R_TC_36_38_queueAssignment extends base{
	@Test
	public void changeQueueHierachyfromPrimarytoSecondaryViceVersa_User() throws InterruptedException {
Thread.sleep(5000);
		
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();
		Thread.sleep(5000);
 	 	
		homePageObj.openModule("Queues Assignment");
		
		QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
		String PageTitle=queueAssignmentPageObj.getPageHeader_QueueAssignment();
		System.out.println(PageTitle);
		queueAssignmentPageObj.selectUserOrGroupFromDropdown("Group");
		
		String SearchboxText=queueAssignmentPageObj.getValueFromSearchBox();
		System.out.println("Searchbox text Populated->"+SearchboxText);
		queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
 		queueAssignmentPageObj.selectUserOrGroupFromSearchDropdown("CMS Aging");
 		String selectedGroup=queueAssignmentPageObj.getValueFromSearchBox();
 		System.out.println("Selected Group -> "+selectedGroup);
 		Thread.sleep(2000);
 		
 		try{
 		String primaryQueue=queueAssignmentPageObj.getprimaryTable();
 	 	System.out.println("primaryQueue before removing queues->"+primaryQueue);
 	    
 	 	
 	 	queueAssignmentPageObj.moveQueuefrmPrimarytoSecondary();
 	 	queueAssignmentPageObj.selectPriority_secondaryQueue();
 	 	queueAssignmentPageObj.clickonSave();
 	 	String primaryQueue1=queueAssignmentPageObj.getprimaryTable();
 	 	System.out.println("primaryQueue after moving queues to secondary->"+primaryQueue1);
 	 	
 	 	
 	 	Thread.sleep(5000);
 	 	
 	 	
 	 	
 	 	String secondaryQ=queueAssignmentPageObj.getSecondaryTable();
 	 	System.out.println("SecondaryQueue before removing queues->"+secondaryQ);
 	 	
 	 	queueAssignmentPageObj.moveQueuefrmSecondarytoPrimary();
 	 	queueAssignmentPageObj.selectPriority_primaryQueue();
 	 	queueAssignmentPageObj.clickonSave();
 	 	
 	 	String secondaryQ1=queueAssignmentPageObj.getSecondaryTable();
 	 	System.out.println("secondaryQ after removing queues to secondary->"+secondaryQ1);
	
 	 
 	 		
 	 		 SoftAssert softassert = new SoftAssert();
 				Thread.sleep(3000);
 			   softassert.assertTrue(primaryQueue1.contains("No records found"), "Queues is not removed for primary section");
 			   softassert.assertTrue(secondaryQ1.contains("No records found"), "Queues is not removed for Secondary  section");
 			    softassert.assertAll();
 				 
 			    System.out.println("TC15_queuesAssignment Passed");
 	 	}
 		 catch(Throwable e)
 	    {
 			 System.out.println("TC15_queuesAssignment Failed");
 			  Assert.fail(e.getMessage());
 	     } 
	}
	

}
