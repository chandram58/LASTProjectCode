package testRepository.GR.QueueAssignment_GR;



import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.QueuesAssignmentPage;

public class R_TC_29_30_queueAssignment extends base{
	@Test
	public void getprimaryandsecondaryQueue_group() throws InterruptedException {
		Thread.sleep(5000);
		
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverAdministration();	
		Thread.sleep(3000);
		homePageObj.openModule("Queues Assignment");
		
		QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
		String PageTitle=queueAssignmentPageObj.getPageHeader_QueueAssignment();
		System.out.println(PageTitle);
		queueAssignmentPageObj.selectUserOrGroupFromDropdown("Group");
		
		String SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
		System.out.println("Searchbox text Populated->"+SerachboxText);
		queueAssignmentPageObj.clickSelectUsersOrGroupsSearch();
 		queueAssignmentPageObj.selectUserOrGroupFromSearchDropdown("CMS Aging");
 		String selectedGroup=queueAssignmentPageObj.getValueFromSearchBox();
 		System.out.println("Selected Group -> "+selectedGroup);
 		Thread.sleep(2000);
 		
 		
 		
	
 	String queue1=	queueAssignmentPageObj.getqueueptable();
 	System.out.println("Queue to be added in Primary Queue Table->"+queue1);
 	String queue2=queueAssignmentPageObj.getqueueStable();
 	System.out.println("Queue to be added in Secondary Queue Table->"+queue2);
 	
 	queueAssignmentPageObj.DragandDropofQueueforPrimaryQueue();
 	
 	queueAssignmentPageObj.selectPriority_primaryQueue();
 	queueAssignmentPageObj.clickonSave();
 	
 	
 	Thread.sleep(10000);
 	String primaryQueue=queueAssignmentPageObj.getprimaryTable();
 	System.out.println("Queue List in Primary table after Queue being added->"+primaryQueue);
 	
 	queueAssignmentPageObj.DragandDropofQueueforSecondaryQueue();
 	
 	queueAssignmentPageObj.selectPriority_secondaryQueue();
 	queueAssignmentPageObj.clickonSave();
 	
 	
 	Thread.sleep(10000);
 	String secondaryQ=queueAssignmentPageObj.getSecondaryTable();
 	System.out.println("Queue List in Secontary Queue table after Queue being added->"+secondaryQ);
 	
 	try {
 		
 		 SoftAssert softassert = new SoftAssert();
			Thread.sleep(3000);
		    softassert.assertTrue(primaryQueue.contains(queue1), "Queues is not dragged for primary section");
		   softassert.assertTrue(secondaryQ.contains(queue2), "Queues is not dragged for secondary section");
		    softassert.assertAll();
			 
		    System.out.println("R_TC_29_queuesAssignment Passed");
 	}
	 catch(Throwable e)
    {
		 System.out.println("R_TC_29_queuesAssignment Failed");
		  Assert.fail(e.getMessage());
     } 
 	
	}

}
