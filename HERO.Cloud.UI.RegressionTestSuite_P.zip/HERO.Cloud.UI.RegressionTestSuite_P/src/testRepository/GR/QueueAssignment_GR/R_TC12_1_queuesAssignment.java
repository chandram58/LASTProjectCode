package testRepository.GR.QueueAssignment_GR;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;
import pages.HomePage;
import pages.QueuesAssignmentPage;

public class R_TC12_1_queuesAssignment extends base
{
	@Test
		public void VerifySearchPlaceholderText() throws IOException, InterruptedException
		{
			
			
			QueuesAssignmentPage queueAssignmentPageObj=new QueuesAssignmentPage(); 
	 		HomePage homePageObj=new HomePage();


	 		homePageObj.mouseHoverAdministration();
	 	    Thread.sleep(3000);
	 		homePageObj.openModule("Queues Assignment");
	 		String PageTitle=queueAssignmentPageObj.getPageHeader_QueueAssignment();
	 		System.out.println(PageTitle);
	 		
	 		try{
	 			SoftAssert softassert = new SoftAssert();
	 			String SerachboxText;
	 			
	 	     //Verifying Search Placeholder Text User Drop down Selected
				queueAssignmentPageObj.selectUserOrGroupFromDropdown("User");
				SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
		 		System.out.println("Searchbox text Populated->"+SerachboxText);
		        softassert.assertTrue(SerachboxText.contains("Select User"), "Incorrect text being populated in Select User Placeholder");
				softassert.assertAll();
					
	 			
	 		   Thread.sleep(4000);
	 		
	 		  //Verifying Search Placeholder Text Group Drop down Selected
	 		  queueAssignmentPageObj.selectUserOrGroupFromDropdown("Group");
	 		
	 		
	 		SerachboxText=queueAssignmentPageObj.getValueFromSearchBox();
	 		System.out.println("Searchbox text Populated->"+SerachboxText);
	 		
			
		    softassert.assertTrue(SerachboxText.contains("Select Groups"), "Incorrect text being populated in Select Group Placeholder");
			softassert.assertAll();
		
			System.out.println("TC004_userProfile Passed");
			//test.log(LogStatus.FAIL, "TC004_userProfile Failed"); 
		 }
		
	    catch(Throwable e)
				     {
					  System.out.println("TC004_QueueAssignment Failed");
					   
					//  test.log(LogStatus.FAIL, "TC004_userProfile Failed"); 
                   //  Assert.fail(e.getMessage());
							     
					   
				      }
	
	      }


}
	
		