package testRepository.GR.userDashboard_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.userDashboardPage;
import base.base;

public class TC_12 extends base {
@Test
	public void verifyPendedSection() throws IOException
	{
	
	try{
		 
			
    	 userDashboardPage userDashboardPageObj=new userDashboardPage(); 
 		 HomePage homePageObj=new HomePage();
          homePageObj.mouseHoverDashboard();
 	  homePageObj.openModule("User Dashboard");
 		
 	  Thread.sleep(3000);
 		
 	  
 	
 	 String PendedItemsHeader=userDashboardPageObj.getPendedItemsSection_header().getText();
 	 System.out.println("PendedItemsHeader->"+PendedItemsHeader);
 
 	 String PendedItems_BodyHeader=userDashboardPageObj.getPendedItemsSection_Bodyheader().getText();
 	 System.out.println("PendedItems_BodyHeader->"+PendedItems_BodyHeader);
 	 
     boolean flag=userDashboardPageObj.getPendedItemsSection_content().isDisplayed();
	 System.out.println("flag->"+flag);
 	 
 	 
     SoftAssert softAssert = new SoftAssert();
     
     softAssert.assertTrue(PendedItemsHeader.equalsIgnoreCase("PENDED ITEMS"), "PendeItemSection_Header not displayed correctly");
     softAssert.assertTrue(PendedItems_BodyHeader.contains("Claim #  Date Pended  Status  Days Pended  Queue Name  Error Codes  Date Created"), "PendeItemSection_Header not displayed correctly");   
     softAssert.assertTrue(flag, "PendeItemSection_content not displayed correctly");
     
     System.out.println("TC012_userDashboard Passed");   
    		     
	 }
			   
    catch(Throwable e)
			     {
	System.out.println("TC012_userDashboard Failed");
	//  test.log(LogStatus.FAIL, "TC002_userDashboard Failed"); 
  	     
    Assert.fail(e.getMessage());
					 
				}
	
	
	      }
	
}
