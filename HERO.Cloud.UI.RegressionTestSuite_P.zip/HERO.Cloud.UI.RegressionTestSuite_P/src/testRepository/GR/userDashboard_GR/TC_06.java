package testRepository.GR.userDashboard_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.userDashboardPage;
import base.base;

public class TC_06 extends base {
	@Test
	public void VerifyResourceProductivityRpt() throws IOException
	{
	
	try{
		 
			
    	 userDashboardPage userDashboardPageObj=new userDashboardPage(); 
 		 HomePage homePageObj=new HomePage();
       homePageObj.mouseHoverDashboard();
 	  homePageObj.openModule("User Dashboard");
 		
 	  Thread.sleep(3000);
 		
 	 //Click on ResourceProductivityReport Link
 	 userDashboardPageObj.clickResoureProductivityreport();
 	 
 	 Thread.sleep(3000);
 	 
 	String rptTitle=userDashboardPageObj.getResourceProductivityRptTitle();
 	 
        SoftAssert softAssert = new SoftAssert();
	    
      
        softAssert.assertTrue(rptTitle.equalsIgnoreCase("Resource Productivity Report"), "Report Title Not Matching");
     
           System.out.println("TC006_userDashboard Passed");   
			   
	  }
			   
    catch(Throwable e)
			     {
			  System.out.println("TC006_userDashboard Failed");
		//  test.log(LogStatus.FAIL, "TC006_userDashboard Failed
			  Assert.fail(e.getMessage());
					 
				}
	
	
	      }
	
}
