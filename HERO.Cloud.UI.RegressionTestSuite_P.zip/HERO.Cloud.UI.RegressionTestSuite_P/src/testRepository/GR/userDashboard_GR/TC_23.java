package testRepository.GR.userDashboard_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.userDashboardPage;
import base.base;

public class TC_23 extends base{
   @Test
		public void SortingClaim_Mainpage() throws IOException
		{		
	     try{
		    userDashboardPage userDashboardPageObj=new userDashboardPage(); 
	 		 HomePage homePageObj=new HomePage();
	 	 homePageObj.mouseHoverDashboard();	
	 	  homePageObj.openModule("User Dashboard");
	 	  
	 	  userDashboardPageObj.clickDemanadDraw(); 
	 		
	 	  Thread.sleep(3000);
	 	  userDashboardPageObj.clickSearchButtonWorkItemDemandDraw();
	 
	
	 	Thread.sleep(10000); 
	 		
	 	 
	 	 
	 	  //clicking sort icon in Claim then result should appear in ascending order with respective to Claim
	 	  userDashboardPageObj.clickSorticon_workItems_DemandDrawPage();
	 	  
	 	 List<String> List_WI_asc=userDashboardPageObj.ascendingOrderList_Workitems_DemandDraw();
	 	 //clicking sort icon again in Claim then result should appear in descending order with respective to Claim 
	 	userDashboardPageObj.clickSorticon_workItems_DemandDrawPage();
	 	 
	 	 List<String> List_WI_desc=userDashboardPageObj.descendingOrderList_Workitems_DemandDraw();
	 	 
	 	 
	 	 
	 	 
	 	 
	 		
	 	  //clicking sort icon in Role_Name then result should appear in ascending order with respective to Role_Name
	        SoftAssert softAssert = new SoftAssert();
		    
	        softAssert.assertEquals(List_WI_asc.get(0), List_WI_desc.get(List_WI_desc.size()-1), "1st row  of ascending order and last row of descending order of Active Roles not matching");
		   
	        softAssert.assertAll();
	           
	        System.out.println("TC023_userDashboard Passed");   
		 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC023_userDashboard Failed");
					   
			//  test.log(LogStatus.FAIL, "TC013_userDashboard Failed"); 
                 Assert.fail(e.getMessage());
						 
					}
		
		
		      }
		
}
