package testRepository.GR.userDashboard_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.userDashboardPage;
import base.base;

public class TC_22 extends base{
	@Test
		public void SearchResetFunctionality() throws IOException
		{
		
	     try{
				 
		
	    	 userDashboardPage userDashboardPageObj=new userDashboardPage(); 
	 		 HomePage homePageObj=new HomePage();
	 	
	      homePageObj.mouseHoverDashboard();	
	 	  homePageObj.openModule("User Dashboard");
	 	  
	 	 userDashboardPageObj.clickDemanadDraw(); 
	 	
	 	 //Getting default value of fields on page
	 	String ClaimNumber_beforereset=userDashboardPageObj.getValueClaimNumber_WorkitemsDemandDrawPage();
	 	System.out.println("ClaimNumber_beforereset->"+ClaimNumber_beforereset);
	 	String Queuename_beforereset=userDashboardPageObj.getValueQueueName_WorkitemsDemandDrawPage();
	 	System.out.println("Queuename_beforereset->"+Queuename_beforereset);
	 	String Status_beforereset=userDashboardPageObj.getValueStatus_WorkitemsDemandDrawPage();
	 	System.out.println("Status_beforereset->"+Status_beforereset);
	 	String DateCreated_beforereset=userDashboardPageObj.getValueDateCreated_WorkitemsDemandDrawPage();
		System.out.println("DateCreated_beforereset->"+DateCreated_beforereset);
	 	
	 	
	 	//Changing one of the field
	 	userDashboardPageObj.selectDateCreated__WorkitemsDemandDrawPage();
	 	
	 	  Thread.sleep(3000);
	 	 userDashboardPageObj.clickSearchButtonWorkItemDemandDraw();
	 	 
	 	boolean flag=userDashboardPageObj.getSearchResultSection_WorkitemsDemandDrawPage().isDisplayed();
	 	System.out.println("flag->"+flag);
	 	 
	 	 
	 	 Thread.sleep(3000);
	 	 
	 	boolean resultFlag=userDashboardPageObj.getSearchResultSection_WorkitemsDemandDrawPage().isDisplayed();
	 	 
	 	 
	 	
	 	//Now Clicking on Reset button
	 	userDashboardPageObj.clickReset_WorkitemsDemandDrawPage();
	 	
	 	
	 	String ClaimNumber_afterreset=userDashboardPageObj.getValueClaimNumber_WorkitemsDemandDrawPage();
	 	System.out.println("ClaimNumber_afterreset->"+ClaimNumber_afterreset);
	 	
	 	String Queuename_afterreset=userDashboardPageObj.getValueQueueName_WorkitemsDemandDrawPage();
	 	System.out.println("Queuename_afterreset->"+Queuename_afterreset);
	 	
	 	String Status_afterreset=userDashboardPageObj.getValueStatus_WorkitemsDemandDrawPage();
		System.out.println("Status_afterreset->"+Status_afterreset);
		
	 	String DateCreated_afterreset=userDashboardPageObj.getValueDateCreated_WorkitemsDemandDrawPage();
	 	System.out.println("DateCreated_afterreset->"+DateCreated_afterreset);
	 
	 		
	        SoftAssert softAssert = new SoftAssert();
	        softAssert.assertTrue(flag, "Search Result not getting populated");
	        softAssert.assertTrue(ClaimNumber_afterreset.equals(ClaimNumber_beforereset), "Rest button not working for Claim Number field");
	        softAssert.assertTrue(Queuename_afterreset.equals(Queuename_beforereset), "Rest button not working for Claim Number field");
	        softAssert.assertTrue(Status_afterreset.equals(Status_beforereset), "Rest button not working for Claim Number field");
	        softAssert.assertTrue(DateCreated_afterreset.equals(DateCreated_beforereset), "Rest button not working for Claim Number field");
	        
	           System.out.println("TC022_userDashboard Passed");   
		}
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC022_userDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC022_userDashboard Failed"); 
                         Assert.fail(e.getMessage());
						 
					}
		
		
		      }
		
}
