package testRepository.GR.userDashboard_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.userDashboardPage;
import base.base;

public class TC_02_03 extends base {
	@Test
	public void verifyPerformanceTbl() throws IOException
	{
	
	try{
		 
			
    	 userDashboardPage userDashboardPageObj=new userDashboardPage(); 
 		 HomePage homePageObj=new HomePage();
        homePageObj.mouseHoverDashboard();
 	    homePageObj.openModule("User Dashboard");
 		
 	  Thread.sleep(3000);
 		
 	 //Click on ResourceProductivityReport Link
 	 boolean flag1=userDashboardPageObj.getMyPerformanceTable().isDisplayed();
 	 System.out.println("flag1->"+flag1);
 	 boolean flag2=userDashboardPageObj.gettodaysHoursSection().isDisplayed();
 	 System.out.println("flag2->"+flag2);
 	 boolean flag3=userDashboardPageObj.gettodaysProductivitySection().isDisplayed();
 	 System.out.println("flag3->"+flag3);
 	 boolean flag4=userDashboardPageObj.gettodaysWorkItemsSection().isDisplayed();
 	 System.out.println("flag4->"+flag4);
 	 Thread.sleep(3000);
 	 
 	
 	 
     SoftAssert softAssert = new SoftAssert();
	    
     softAssert.assertTrue(flag1 && flag2 && flag3 && flag4, "My Performance Section not displayed correctly");
     
     System.out.println("TC002_userDashboard Passed");   
    	     
	 }
			   
    catch(Throwable e)
			     {
	System.out.println("TC002_userDashboard Failed");
	//  test.log(LogStatus.FAIL, "TC002_userDashboard Failed"); 
        Assert.fail(e.getMessage());
					 
				}
	
	
	      }
	
}
