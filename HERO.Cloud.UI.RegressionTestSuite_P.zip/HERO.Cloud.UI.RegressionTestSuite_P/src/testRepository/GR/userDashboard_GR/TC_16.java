package testRepository.GR.userDashboard_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.userDashboardPage;
import base.base;

public class TC_16 extends base{
	@Test
		public void VerifySectionToExportDropdownValues() throws IOException
		{	
	     try{
			userDashboardPage userDashboardPageObj=new userDashboardPage(); 
	 		 HomePage homePageObj=new HomePage();
           homePageObj.mouseHoverDashboard();	
	 	  homePageObj.openModule("User Dashboard");
	 		
	 	  Thread.sleep(3000);
	 		
	 	 //Click on options 
	 	 List<WebElement> options=userDashboardPageObj.getoptionsSectionstoExport();
	 	 
	 	
	 	 List<String> actualOptions=new ArrayList<String>();
	 	
	 	for(int i=0;i<options.size();i++)
	 	{
	 		System.out.println(options.get(i).getText());
	 		actualOptions.add(options.get(i).getText());
	 		
	 	}
	 	
	 		
	 	 List<String> expectedOptions= Arrays.asList("Today's work items","Today's productivity","Today's hours","Pended items");
	 		
	 		
	        SoftAssert softAssert = new SoftAssert();
		    
	// verifying whether the file  with fileName present in the directory downloadpath or not
	 softAssert.assertTrue(actualOptions.containsAll(expectedOptions) && expectedOptions.containsAll(actualOptions) , "Expected and Actual Options not matching");
	     
	           System.out.println("TC016_userDashboard Passed");   
	 }
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC016_userDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC016_userDashboard Failed"); 
               Assert.fail(e.getMessage());
						 
					}
		
		
		      }
		
}
