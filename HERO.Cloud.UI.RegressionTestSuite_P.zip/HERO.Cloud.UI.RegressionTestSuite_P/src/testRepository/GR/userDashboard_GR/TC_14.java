package testRepository.GR.userDashboard_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.userDashboardPage;
import base.base;

public class TC_14 extends base {

	@Test
	public void VerifyClaimLink() throws IOException
	{
	
	try{
		 
			
    	 userDashboardPage userDashboardPageObj=new userDashboardPage(); 
 		 HomePage homePageObj=new HomePage();
     homePageObj.mouseHoverDashboard();
 	  homePageObj.openModule("User Dashboard");
 		
 	  Thread.sleep(3000);
 		
 	 //Click on Claim Link
 	 userDashboardPageObj.clickClaimLink();
 	 
 	 Thread.sleep(3000);
 	 
 	String OpenedPageContent=userDashboardPageObj.getOpenPageHeader();
 	 
        SoftAssert softAssert = new SoftAssert();
	    
      
        softAssert.assertTrue(OpenedPageContent.toLowerCase().contains("business view"), "Incorrect page opened upon clicking Cliam# link");
     
           System.out.println("TC014_userDashboard Passed");   
	}
			   
    catch(Throwable e)
			     {
			  System.out.println("TC014_userDashboard Failed");
				   
				//  test.log(LogStatus.FAIL, "TC014_userDashboard Failed"); 
              Assert.fail(e.getMessage());
					 
				}
	
	
	      }
	
}
