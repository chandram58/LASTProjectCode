package testRepository.GR.userDashboard_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.userDashboardPage;
import base.base;

public class TC_27p1 extends base{
	@Test
		public void WorkItemDemandDrawAssignedFunctionality() throws IOException
		{
	
		
				
	     try{
				 
		
	    	 userDashboardPage userDashboardPageObj=new userDashboardPage(); 
	 		 HomePage homePageObj=new HomePage();
	      homePageObj.mouseHoverDashboard();	
	 	  homePageObj.openModule("User Dashboard");
	 	  
	 	 userDashboardPageObj.clickDemanadDraw(); 
	
	 	//Changing status as Assigned
	 	userDashboardPageObj.SelectStatusAssigned();
	 	
	 	  Thread.sleep(3000);
	 	 userDashboardPageObj.clickSearchButtonWorkItemDemandDraw();
	 	 
	 	boolean flag=userDashboardPageObj.getSearchResultSection_WorkitemsDemandDrawPage().isDisplayed();
	 	System.out.println("flag->"+flag);
	 	 
	 	 
	 	 Thread.sleep(3000);
	 	 
	 
	  
	 	//clicking on 1st result link
	 	userDashboardPageObj.click_WorkItemSearchResultlink();
	 	
	 	String errortxt1=userDashboardPageObj.captureError_AssignedDemandDraw();
	 	
	 	
	 		
	        SoftAssert softAssert = new SoftAssert();
	        softAssert.assertTrue(flag, "Search Result not getting populated");
	        softAssert.assertTrue(errortxt1.equalsIgnoreCase("Unable to demand draw this work item"),"Incorrect error");
	     
	        
	           System.out.println("TC027_userDashboard Passed");   
	}
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC027_userDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC027_userDashboard Failed"); 
              Assert.fail(e.getMessage());
						 
					}
		
		
		      }
		
}
