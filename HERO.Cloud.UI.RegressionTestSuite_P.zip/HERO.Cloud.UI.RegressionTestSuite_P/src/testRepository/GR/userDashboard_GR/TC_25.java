package testRepository.GR.userDashboard_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.userDashboardPage;
import base.base;

public class TC_25 extends base{
	@Test
		public void ExporttoExcel() throws IOException
		{
		try{
				 
		 userDashboardPage userDashboardPageObj=new userDashboardPage(); 
		 HomePage homePageObj=new HomePage();
	 	
	        
	 	 String DownloadFilepath = getPropertyFileValue(DOWNLOADFILEPATH);
		  System.out.println("DownloadFilepath->"+DownloadFilepath);
	        
	        
	      homePageObj.mouseHoverDashboard();	
	 	  homePageObj.openModule("User Dashboard");
	 	  
	 	 userDashboardPageObj.clickDemanadDraw(); 
	 		
	 	  Thread.sleep(3000);
	 	 userDashboardPageObj.clickSearchButtonWorkItemDemandDraw();
	 
	
	 	Thread.sleep(10000); 
	 	 //Click on Export to Excel
	 	 userDashboardPageObj.DownloadExcel_WorkItemDemandDraw();
	 		
	 	//  test.log(LogStatus.INFO, "Getting Downloaded File Name");
	 	  File getLatestFile = base.getLatestFilefromDir(DownloadFilepath);
	 	  String fileName = getLatestFile.getName();
	 	  System.out.println("Downloaded File name->"+fileName);
  //    test.log(LogStatus.INFO, "Downloaded File name->"+fileName);
	 		    
	 		
	 		
	        SoftAssert softAssert = new SoftAssert();
		    
	      // verifying whether the file  with fileName present in the directory downloadpath or not
	        softAssert.assertTrue(isFileDownloaded(DownloadFilepath, fileName), "Download Failed");
	     //verifying whether the latest downloaded file contains "xlsx" extension or not and name of file having TransmissionsList word in it
	        softAssert.assertTrue(fileName.contains("xls") && fileName.contains("UserDashboard"),"It is not a excel file");
			    
	           System.out.println("TC025_userDashboard Passed");   
	}
				   
	    catch(Throwable e)
				     {
				  System.out.println("TC025_userDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC025_userDashboard Failed"); 
                  Assert.fail(e.getMessage());
						 
					}
        }
		
}
