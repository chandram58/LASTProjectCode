package testRepository.GR.userDashboard_GR;

import java.io.File;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pages.HomePage;
import pages.TransmissionLogPage;
import pages.userDashboardPage;
import base.base;

public class TC_01 extends base {

	@Test
	public void verifyNavigationtoUserDashboard() throws IOException
	{
	
	try{
		 
			
    	 userDashboardPage userDashboardPageObj=new userDashboardPage(); 
 		 HomePage homePageObj=new HomePage();
      homePageObj.mouseHoverDashboard();
 	  homePageObj.openModule("User Dashboard");
 		
 	  Thread.sleep(3000);
 		
 	 String PageURL=driver.getCurrentUrl();
		System.out.println(PageURL);
		
 	 
 	
 	 
     SoftAssert softAssert = new SoftAssert();
	    
     softAssert.assertTrue(PageURL.toLowerCase().contains("user")&& PageURL.toLowerCase().contains("landing"), "User landing page is not getting Displayed");
     System.out.println("TC001_userDashboard Passed");   
  }
			   
    catch(Throwable e)
			     {
	System.out.println("TC001_userDashboard Failed");
	//  test.log(LogStatus.FAIL, "TC001_userDashboard Failed"); 
     Assert.fail(e.getMessage());
					 
				}
	
	
	      }
	
}
