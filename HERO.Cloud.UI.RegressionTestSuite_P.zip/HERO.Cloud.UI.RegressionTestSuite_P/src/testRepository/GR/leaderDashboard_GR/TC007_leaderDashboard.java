package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC007_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void TotalCurrentProductivitySectionDashboardPage() throws IOException
		{
			driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=4;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
			 
			    Thread.sleep(5000);
			    WebElement TotalCurrentProductivitySection=driver.findElement(By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[3]/div/header"));
			    boolean Flag=TotalCurrentProductivitySection.isDisplayed();
				
	            System.out.println("Total Current Productivity Section displayed->"+Flag);
				SoftAssert softAssert = new SoftAssert();
		     
		     
	    softAssert.assertTrue(Flag, "Total Current Productivity Section not  displayed");
		     
		    
		 softAssert.assertAll();
		      
		      System.out.println("TC007_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC007_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
		    
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC007_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC007_leaderDashboard Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
					
				      }
			
		      }
	
}
