package testRepository.GR.leaderDashboard_GR;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.leaderDashboardPage;

public class TC17_leaderDashboard_1 extends base{

	@Test
	public void getErrormessageforassignedWorkitem() throws InterruptedException {
		Thread.sleep(5000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("Leader Dashboard");
		 Thread.sleep(3000);
		 leaderDashboardPage leaderDashboardPageobj=new leaderDashboardPage();
		 leaderDashboardPageobj.clickOnQueueInventory();
		 leaderDashboardPageobj.clickOnSelectQueue();
		 leaderDashboardPageobj.clickOnApplyfilter();
		 leaderDashboardPageobj.clickonAssignBtn();
		 leaderDashboardPageobj.getSerachUser("Durga");
		 leaderDashboardPageobj.clickuserfrmdpaftersearch();
		 leaderDashboardPageobj.clickAissign_reassignbtn();
	String message=	 leaderDashboardPageobj.getErrrorMessageforWorkItem().getText();
	
	System.out.println(message);
	
	try {
		 SoftAssert softAssert = new SoftAssert();
         softAssert.assertTrue(message.contains("Please select atleast one Work item or a Queue"),"workitem errormessage not getting");
         softAssert.assertAll();
         System.out.println("TC17_leaderdashboard is passed");
	}
	catch(Throwable e)
    {


	   System.out.println("TC17_leaderdashboard is failed");
	
		  Assert.fail(e.getMessage());	
    }		 
	}
}
