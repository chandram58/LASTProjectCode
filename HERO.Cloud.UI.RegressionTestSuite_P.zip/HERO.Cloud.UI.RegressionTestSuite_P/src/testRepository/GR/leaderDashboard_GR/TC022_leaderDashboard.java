package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC022_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void FutureDateValidationQueueInventoryReport() throws IOException
		{
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=60;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
		  
			
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
			 
			  
			    
			    //Getting Default Report date for the section
			    String DefaultReportDate=driver.findElement(By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[2]/div[1]/div[1]")).getText();
				  System.out.println("Default Report Date for the section->"+DefaultReportDate);
			    
			    
			   
				//getting current date
				    SimpleDateFormat date1=new SimpleDateFormat("MM/dd/yyyy"); 
					 Calendar calendar = Calendar.getInstance();
					 int currentmonth = calendar.get(Calendar.MONTH)+1;//+1 since month is indexed from 0
					 int currentYear= calendar.get(Calendar.YEAR);
					 System.out.println("Current month in int Format->"+currentmonth+" Current Year->"+currentYear);
					 
					 
					 calendar.add(Calendar.DATE, +1);
				     Date todate1 = calendar.getTime();
				     int SelectedDate=calendar.get(Calendar.DATE);
				     int SelectedDateMonth=calendar.get(Calendar.MONTH)+1;//+1 since month is indexed from 0
					 int SelectedDateYear=calendar.get(Calendar.YEAR);
					 
					 System.out.println("Selected Future date in int Format->"+SelectedDate+"Selected Future date month in int Format->"+SelectedDateMonth+" Selected Future date Year->"+SelectedDateYear); 
				     String fromdate = date1.format(todate1);
					 
					
					 
					 String SelectedFutureDateWithoutMonthYearString=fromdate.substring(fromdate.indexOf("/")+1, fromdate.lastIndexOf("/"));
					 System.out.println("Selected Future Date without month and Year in string format->"+SelectedDate);
					 
					 int SelectedFutureDateWithoutMonthYearInt=Integer.parseInt(SelectedFutureDateWithoutMonthYearString);
					 System.out.println("Selected Furure Date without month and Year in int format->"+SelectedFutureDateWithoutMonthYearInt);
					 
					 
				 
				Date TodayDateinDateFormat=date1.parse(date1.format(calendar.getTime()));
				 System.out.println("Today's date in date format->"+TodayDateinDateFormat);
				 
			  
			    //Clicking on Calendar on Queue Inventory Report
				
				 driver.findElement(By.xpath("//a[contains(text(),'Queue Inventory Report')]")).click();
			
				
				//Clicking on date created Start date date picker
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-inventoryreport/div[2]/div/div/div/form/fieldset[2]/p-calendar/span/button/span[1]")));
				driver.findElement(By.xpath("//app-inventoryreport/div[2]/div/div/div/form/fieldset[2]/p-calendar/span/button/span[1]")).click();
			    Thread.sleep(5000); 
			    
			  
			    
			    //Now Selecting Active Dates in a List
			    
			    List<WebElement> ActiveDates= driver.findElements(By.xpath("//p-calendar/span/div/div[1]/div[2]/table/tbody/tr/td/a")); 
			    List<String> ActiveDatelist=new ArrayList<String>();
			    System.out.println("Dates enabled for Selection");
			   
			   
			   for(int k=0;k<ActiveDates.size();k++)
			   {
				   System.out.println(ActiveDates.get(k).getText());
				   ActiveDatelist.add(ActiveDates.get(k).getText().trim());
			   }
			 
			   System.out.println("*********");
			    System.out.println("Selected Future date->"+SelectedFutureDateWithoutMonthYearInt);

				
				
				SoftAssert softAssert = new SoftAssert();
     
	    softAssert.assertFalse(ActiveDatelist.contains(SelectedFutureDateWithoutMonthYearInt), "Future Dates are enabled for Selection ");
		     
		    
		 softAssert.assertAll();
		      
		      System.out.println("TC022_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.PASS, "TC022_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
		      //closing child page
				driver.findElement(By.xpath("//app-leaderdashboard/div[2]/p-sidebar/div/div[1]/button/span")).click();		     
					     	
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC022_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC022_leaderDashboard Failed"); 

					   //closing child page
					//	driver.findElement(By.xpath("//app-leaderdashboard[1]/div[2]/p-sidebar[1]/div[1]/a[1]/span[1]")).click();		     
							         
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
						
				      }
			
		      }
	
}
