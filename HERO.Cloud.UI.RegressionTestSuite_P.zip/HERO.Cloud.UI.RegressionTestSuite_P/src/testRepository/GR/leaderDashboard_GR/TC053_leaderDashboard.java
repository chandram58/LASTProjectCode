package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC053_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void ApplyFilterSelectLeaderValidationProductivityReport() throws IOException
		{
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=18;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
			 
			    Thread.sleep(5000);
			    WebElement ResoureceProductivityReportLink=driver.findElement(By.xpath("//a[contains(text(),'Resource Productivity Report')]"));
			    ResoureceProductivityReportLink.click();
			    
			    Thread.sleep(5000);
				
	           String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Resource Productivity Report')]")).getText();
		      System.out.println("Page Title->"+PageTitle);
		    
		      String SelectedLeaderFieldDefaultValue= driver.findElement(By.xpath("//app-resourcepoductivityreport/div[2]/div/div/div/form/fieldset[1]/p-multiselect/div")).getText();  
		      System.out.println("Selected Leader Field Default Value->"+SelectedLeaderFieldDefaultValue); 
		      
		     
		      //Click on Apply Filter Button
		      driver.findElement(By.xpath("//button[contains(text(),'Apply Filter')]")).click(); 
		      
		     driver.switchTo().defaultContent();
		     String ErrorMessage=driver.findElement(By.xpath("//div[contains(text(),'Please select Leader from dropdown')]")).getText();
		     System.out.println("Error Message->"+ErrorMessage); 
		     
		      
		 
		      SoftAssert softAssert = new SoftAssert();
			  softAssert.assertTrue(ErrorMessage.equalsIgnoreCase("Please select Leader from dropdown") , "Incorrect Error Message");
		      softAssert.assertAll();
		      
		      System.out.println("TC053_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.PASS, "TC053_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     

				//Closing child window
				 driver.findElement(By.xpath("//app-leaderdashboard[1]/div[3]/p-sidebar[1]/div[1]/div[1]/button[1]/span[1]")).click();
			   
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC053_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC053_leaderDashboard Failed"); 

					 //Closing child window
				 driver.findElement(By.xpath("//app-leaderdashboard[1]/div[3]/p-sidebar[1]/div[1]/a[1]")).click();
					   	   
					   
					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						
						  

							
					   
				      }
			
		      }
	
}
