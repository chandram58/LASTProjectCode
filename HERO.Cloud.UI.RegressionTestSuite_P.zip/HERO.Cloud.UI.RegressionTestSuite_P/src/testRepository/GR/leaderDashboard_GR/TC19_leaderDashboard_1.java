package testRepository.GR.leaderDashboard_GR;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.base;
import pages.HomePage;
import pages.leaderDashboardPage;

public class TC19_leaderDashboard_1 extends base{
	
	@Test
	public void assignworkitemSuccessmessage() throws InterruptedException {
		Thread.sleep(10000);
		HomePage homePageObj=new HomePage();
		homePageObj.mouseHoverDashboard();
		homePageObj.openModule("Leader Dashboard");
		 Thread.sleep(3000);
		 leaderDashboardPage leaderDashboardPageobj=new leaderDashboardPage();
		 leaderDashboardPageobj.clickOnQueueInventory();
		 leaderDashboardPageobj.clickOnSelectQueue();
		 leaderDashboardPageobj.clickOnApplyfilter();
		 leaderDashboardPageobj.getSelect1stQueueTable();
		 leaderDashboardPageobj.clickonAssignBtn();
		 leaderDashboardPageobj.getSerachUser("Durga");
		 leaderDashboardPageobj.clickuserfrmdpaftersearch();
		 leaderDashboardPageobj.clickAissign_reassignbtn();
		
		
		 leaderDashboardPageobj.clcikOnPopBtnOK();
		 Thread.sleep(10000);
	String message=leaderDashboardPageobj.getSuccessMessageforWorkItem().getText();
	System.out.println(message);
	try {
		 SoftAssert softAssert = new SoftAssert();
        softAssert.assertTrue(message.contains("Work Items Have Been Assigned Successfully"),"workitem errormessage not getting");
        softAssert.assertAll();
        System.out.println("TC19_leaderdashboard is passed");
	}
	catch(Throwable e)
   {


	   System.out.println("TC19_leaderdashboard is failed");
	
		  Assert.fail(e.getMessage());	
   }		 
	}
		
	
	

}
