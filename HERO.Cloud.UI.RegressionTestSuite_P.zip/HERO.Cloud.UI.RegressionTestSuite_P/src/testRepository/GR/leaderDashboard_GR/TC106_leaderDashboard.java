package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC106_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void SelectDirectorValidationPendedItemsScreen() throws IOException
		{
			
			driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=40;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,10000);
			 System.out.println("0");
			
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
				
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
				
				
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
			 
			 
		
			 System.out.println("1");
				
			 
			 Thread.sleep(5000);
			
			WebElement PenededItemssection=driver.findElement(By.xpath("//strong[contains(text(),'PENDED ITEMS')]"));
			System.out.println("Peneded Items section dispalyed on Leader Dashboard page->"+PenededItemssection.isDisplayed());
			
			//Click on links in Pended Items table
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tbody/tr[5]/td[2]/a[1]")));
			driver.findElement(By.xpath("//tbody/tr[5]/td[2]/a[1]")).click();
			Thread.sleep(3000);
			String PageTitle2=driver.findElement(By.xpath("//h1[contains(text(),'Pended Items')]")).getText();
			System.out.println("Page Opened upon clicking on links in Pended Items table->"+PageTitle2);
			
			//Click on Reset Button
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Reset')]")));
			driver.findElement(By.xpath("//span[contains(text(),'Reset')]")).click();
			
			//Click on Apply Filter Button
			driver.findElement(By.xpath("//span[contains(text(),'Apply Filter')]")).click();
			
			  driver.switchTo().defaultContent();
			    String ValidationError=driver.findElement(By.xpath("//div[contains(text(),'Director - Required')]")).getText();
			    System.out.println("validation Error Message->"+ValidationError);
			    
			    Thread.sleep(3000);
			
		    SoftAssert softAssert = new SoftAssert();
		     
		    // test.log(LogStatus.INFO ,"Verifying page Title");
		     
	    softAssert.assertTrue(PenededItemssection.isDisplayed(), "Peneded Items section is not displayed");
	    softAssert.assertTrue(PageTitle2.equalsIgnoreCase("Pended Items"), "Peneded Items page not Opened upon clicking on links in Pended Items table");   
	    softAssert.assertTrue(ValidationError.equalsIgnoreCase("Director - Required"),"Incorrect Error Message");
	    softAssert.assertAll();
		      
		      System.out.println("TC040_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC040_groupMaintenance Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
		      //Closing child screens
		      driver.findElement(By.xpath("//app-leaderdashboard/div[5]/p-sidebar/div/div[1]/button/span")).click(); 
			   			
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC040_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC040_leaderDashboard Failed"); 

					   //Closing child screens
					     // driver.findElement(By.xpath("//app-leaderdashboard[1]/div[5]/p-sidebar[1]/div[1]/a[1]/span[1]")).click(); 
						   					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
			
		      }
	
}
