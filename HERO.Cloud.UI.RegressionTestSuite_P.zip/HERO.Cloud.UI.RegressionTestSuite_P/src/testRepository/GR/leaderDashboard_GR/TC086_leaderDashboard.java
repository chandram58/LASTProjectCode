package testRepository.GR.leaderDashboard_GR;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC086_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void ExporttoPDFSuccessReport() throws IOException
		{
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   int i=27;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
			
		  
			 Thread.sleep(5000);
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
			 
			    Thread.sleep(5000);
			    WebElement SuccessReportLink=driver.findElement(By.xpath("//a[contains(text(),'Success Report')]"));
			    SuccessReportLink.click();
				
			    Thread.sleep(5000);
	           String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Success Report')]")).getText();
		      System.out.println("Page Title->"+PageTitle);
		    
				Thread.sleep(3000);
				
				   driver.findElement(By.xpath("//span[contains(text(),'Select Leader')]")).click();
				      driver.findElement(By.xpath("//app-successreport/div[2]/div/div[1]/form/fieldset[1]/p-multiselect/div/div[4]/div[1]/div[1]/div[2]")).click(); 
				      driver.findElement(By.xpath("//h1[contains(text(),'Success Report')]")).click();
				      //Click on Apply Filter Button
				      driver.findElement(By.xpath("//span[contains(text(),'Apply Filter')]")).click(); 
				      
				      
				      Thread.sleep(5000);
				      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//header/div[1]/a[2]/i[1]")));     
				
				 WebElement DownloadPDF=driver.findElement(By.xpath("//header/div[1]/a[2]/i[1]"));
					
					System.out.println("Clicking On Export to PDF icon");
				//    test.log(LogStatus.INFO, "Clicking On Export to PDF icon");
				 
					
					DownloadPDF.click();
				 

				  Thread.sleep(10000);
				 
				//  test.log(LogStatus.INFO, "Getting Downloaded File Name");
		           File getLatestFile = base.getLatestFilefromDir(DownloadFilepath);
			 
				    String fileName = getLatestFile.getName();
				    
				    System.out.println("Downloaded File name->"+fileName);
				//    test.log(LogStatus.INFO, "Downloaded File name->"+fileName);
				    
	                System.out.println("1");
				
			 
			 Thread.sleep(5000);
			 
			 
			//String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Roles Management')]")).getText();
			 
			
           SoftAssert softassert = new SoftAssert();
		     
		   //  test.log(LogStatus.INFO ,"Verifying page Title");
		     
        // verifying whether the file  with fileName present in the directory downloadpath or not
		    softassert.assertTrue(isFileDownloaded(DownloadFilepath, fileName), "Download Failed");
		    //verifying whether the latest downloaded file contains "xlsx" extension or not and name of file having TransmissionsList word in it
		    softassert.assertTrue(fileName.contains("pdf") && fileName.contains("SuccessReport"),"It is not a PDF file");
		    
		     
		    
		     
		      softassert.assertAll();
		      
		      System.out.println("TC027_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC027_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
		    //Closing child window
				 driver.findElement(By.xpath("//app-leaderdashboard[1]/div[4]/p-sidebar[1]/div[1]/a[1]/span[1]")).click();	
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC027_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC027_leaderDashboard Failed"); 

				
					 //Closing child window
						 driver.findElement(By.xpath("//app-leaderdashboard[1]/div[4]/p-sidebar[1]/div[1]/a[1]/span[1]")).click();   
					   
					   
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
		
		
		      }
	
	
}
