package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC014_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void ResetFunctionalityInventoryNewClosedWorksection() throws IOException
		{
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=45;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			// wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
		  
			
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
			 
			    Thread.sleep(5000);
			    
			    //Getting Default Report date for the section
			    String DefaultReportDate=driver.findElement(By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[2]/div[1]/div/div[1]")).getText();
				  System.out.println("Default Report Date for the section->"+DefaultReportDate);
			    
			    
			   
				//getting current date
			    SimpleDateFormat date1=new SimpleDateFormat("MM/dd/yyyy"); 
				 Calendar calendar = Calendar.getInstance();
				 String TodayDateinStringFormat=date1.format(calendar.getTime());
				 System.out.println("Today's date in string format->"+TodayDateinStringFormat);
				 
				 String TodayDateWithoutMonthYearString=TodayDateinStringFormat.substring(TodayDateinStringFormat.indexOf("/")+1, TodayDateinStringFormat.lastIndexOf("/"));
				 System.out.println("Today's date without month and Year in string format->"+TodayDateWithoutMonthYearString);
				 
				 int TodayDateWithoutMonthYearInt=Integer.parseInt(TodayDateWithoutMonthYearString);
				 System.out.println("Today's date without month and Year in int format->"+TodayDateWithoutMonthYearInt);
				 int YesterdayDateWithoutMonthYearInt=TodayDateWithoutMonthYearInt-1;
				 System.out.println("Yesterday's's date without month and Year in int format->"+YesterdayDateWithoutMonthYearInt);
				 
				 int TommorrowDateWithoutMonthYearInt=TodayDateWithoutMonthYearInt+1;
				 System.out.println("Tommorow's date without month and Year in int format->"+TommorrowDateWithoutMonthYearInt);
				 
				 
				 
				 
				Date TodayDateinDateFormat=date1.parse(date1.format(calendar.getTime()));
				 System.out.println("Today's date in date format->"+TodayDateinDateFormat);
				 
			  
			    //Clicking on Calendar
				driver.findElement(By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[2]/div[1]/header/span/p-calendar/span/button/span[1]")).click();
			    Thread.sleep(5000); 
			    
			    //Clicking Yesterday date in Calendar
				
				 //Iterating through calendar
				WebElement calendartable=driver.findElement(By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[2]/div[1]/header/span/p-calendar/span/div/div[1]/div/div[2]/table/tbody"));
			    List<WebElement> Rows,Cols;
				
			    Rows=calendartable.findElements(By.tagName("tr"));
			    
			    System.out.println("Number of rows in calendar->"+Rows.size());
			    
				  for(int j=0;j<Rows.size();j++)
				    {
				    	Cols=Rows.get(j).findElements(By.tagName("td"));
				    	System.out.println("Number of Cols in row no "+(j+1)+" in calendar"+Cols.size());
				    	
				        for(int k=1;k<=Cols.size();k++)
				        {
				        	Thread.sleep(5000);
				    	String xpathExp="//p-calendar//span//div//div[1]//div//div[2]//table/tbody//tr["+(j+1)+"]/td["+k+"]" ;                   
				    	
				    	System.out.println(Cols.get(0).findElement(By.xpath(xpathExp)).getText());
				    	
				         if((Integer.parseInt(Cols.get(0).findElement(By.xpath(xpathExp)).getText()))==YesterdayDateWithoutMonthYearInt)
				        		 {
				        	 System.out.println("Selected date is->"+Cols.get(0).findElement(By.xpath(xpathExp)).getText());
				        	 Cols.get(0).findElement(By.xpath(xpathExp)).click(); 
				        	 j=Rows.size();//To break outer loop
				        	 break;  //To break inner loop
				        		 }
				         }
				       
				    }
				    
				 driver.findElement(By.xpath("//header")).click();
				 //Getting Report date from section
				  
				  String SelectedReportDate=driver.findElement(By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[2]/div[1]/div[1]")).getText();
				  System.out.println("Selected Report Date for the section->"+SelectedReportDate);
				  
				  Thread.sleep(3000);
				 //Click on Reset Button
			    driver.findElement(By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[2]/div[1]/header/span/em")).click();
			    
			    //Getting Report date value after Reset
			    String ReportDateAfterReset=driver.findElement(By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[2]/div[1]/div/div[1]")).getText();
				  System.out.println(" Report Date after Reset for the section->"+ReportDateAfterReset);
			    
				SoftAssert softAssert = new SoftAssert();
     
	    softAssert.assertTrue(ReportDateAfterReset.trim().equals(DefaultReportDate.trim()), "Report date after reset and default report date not matching");
		     
		    
		 softAssert.assertAll();
		      
		      System.out.println("TC014_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.PASS, "TC014_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC014_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC014_leaderDashboard Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
			
		      }
	
}
