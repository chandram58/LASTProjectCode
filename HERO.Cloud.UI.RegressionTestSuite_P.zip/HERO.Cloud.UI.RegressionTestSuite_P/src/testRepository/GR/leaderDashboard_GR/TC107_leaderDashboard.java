package testRepository.GR.leaderDashboard_GR;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC107_leaderDashboard extends base
{
	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		
		

		@Test
		public void VerifySortingFunctionalityPendedItems() throws IOException, InterruptedException
		{
			
			driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   
			   int i=63;
				
	
				 
			  WebDriverWait wait=new WebDriverWait(driver,10000);
			 System.out.println("0");
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
			
			 Thread.sleep(10000);
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
				
				
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
				
				
			 
				 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tbody/tr[5]/td[2]/a[1]")));
				driver.findElement(By.xpath("//tbody/tr[5]/td[2]/a[1]")).click();
				
				Thread.sleep(3000);
				
				String Pagetitle=driver.findElement(By.xpath("//h1[contains(text(),'Pended Items')]")).getText();
			    System.out.println("Page Title of current page->"+Pagetitle);
			    
				
			    driver.findElement(By.xpath("//span[contains(text(),'Apply Filter')]")).click();
				
				 Thread.sleep(5000);
				
				
				List<WebElement> rows_Workitems_asc,cols_Workitems_asc;
				List<WebElement> rows_Workitems_desc,cols_Workitems_desc;
				
				
				   //clicking sort icon in wokitems column then result should appear in ascending order with respective to workitems column
				
				 driver.findElement(By.xpath("//thead/tr[1]/th[2]/p-sorticon[1]/i[1]")).click(); 
				 WebElement  webtable_Workitems_asc=driver.findElement(By.xpath("//app-penddeditems/div/div[2]/div[2]/div/p-table/div/div/div/div[2]/table/tbody"));
				 rows_Workitems_asc=webtable_Workitems_asc.findElements(By.tagName("tr"));
				 cols_Workitems_asc=rows_Workitems_asc.get(0).findElements(By.tagName("td"));
				 
				 System.out.println(rows_Workitems_asc.size());
				 
			      System.out.println( cols_Workitems_asc.size()); 
						 
						 
						 //Getting WorkItems list
						 
			 List<String> rows_WorkitemList_asc = new ArrayList<String>();
		   				
				
				 for(int j=0;j<rows_Workitems_asc.size();j++)
				 {
				    rows_WorkitemList_asc.add(rows_Workitems_asc.get(j).getText()); 
									  
				 }
				 
				
				 
				 System.out.println(rows_WorkitemList_asc.size());
				 System.out.println(rows_WorkitemList_asc.get(0));
				 
				 System.out.println("****************");
				 
				 
		 
				 Thread.sleep(5000);
				//clicking sort icon in Role_Name then result should appear in descending order with respective to Role_Name
				 
				driver.findElement(By.xpath("//thead/tr[1]/th[2]/p-sorticon[1]/i[1]")).click(); 
				
				 Thread.sleep(5000);
				 
				WebElement  webtable_Workitem_desc=driver.findElement(By.xpath("//app-penddeditems/div/div[2]/div[2]/div/p-table/div/div/div/div[2]/table/tbody"));
				
				rows_Workitems_desc=webtable_Workitem_desc.findElements(By.tagName("tr"));
				
				
				cols_Workitems_desc=rows_Workitems_desc.get(rows_Workitems_desc.size()-1).findElements(By.tagName("td"));
				
				//Getting Workitems in descending order list
				
				 List<String> rows_WorkitemsList_desc = new ArrayList<String>();
				 
			 
				
				 for(int j=0;j<rows_Workitems_desc.size();j++)
				 {
				
			      //System.out.println(rows_Rolename_asc.get(j).getText().replace("\n", " "));
					 rows_WorkitemsList_desc.add(rows_Workitems_desc.get(j).getText()); 
									 
				 }
				
				
				 System.out.println(rows_Workitems_desc.size());
				 System.out.println(rows_Workitems_desc.get(rows_Workitems_desc.size()-1).getText());
				 
				 System.out.println("***");
				 
					 
		    try{  
		   
				
		       SoftAssert softAssert = new SoftAssert();
		       
		       softAssert.assertEquals(rows_Workitems_asc.get(0), rows_Workitems_desc.get(rows_Workitems_desc.size()-1), "1st row  of ascending order and last row of descending order of Active Roles not matching");
		     
		            softAssert.assertAll();
			
				 
			      System.out.println("TC063_leaderDashboard Passed");
				

				     String status="Pass";
		           
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				     //Closing child screens
				      driver.findElement(By.xpath("//app-leaderdashboard/div[5]/p-sidebar/div/div[1]/button/span")).click(); 
					   				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC063_leaderDashboard  Failed");
					   
					  //test.log(LogStatus.FAIL, "TC063_leaderDashboard  Failed"); 

					   //Closing child screens
					    //  driver.findElement(By.xpath("//app-leaderdashboard[1]/div[5]/p-sidebar[1]/div[1]/a[1]/span[1]")).click(); 
						   					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					 //    xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
	
	      }


}
	