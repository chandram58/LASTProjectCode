package testRepository.GR.leaderDashboard_GR;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC095_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void SelectQueueNameValidationClaimStatusReport() throws IOException, InterruptedException
		{
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   int i=32;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
			
		  
			 Thread.sleep(5000);
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
			 
			    Thread.sleep(5000);
			    WebElement SuccessReportLink=driver.findElement(By.xpath("//a[contains(text(),'Success Report')]"));
			    SuccessReportLink.click();
				
			    Thread.sleep(5000);
	           String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Success Report')]")).getText();
		      System.out.println("Page Title->"+PageTitle);
		    
				Thread.sleep(3000);
				
				   driver.findElement(By.xpath("//span[contains(text(),'Select Leader')]")).click();
				      driver.findElement(By.xpath("//app-successreport/div[2]/div/div[1]/form/fieldset[1]/p-multiselect/div/div[4]/div[1]/div[1]/div[2]")).click(); 
				      driver.findElement(By.xpath("//h1[contains(text(),'Success Report')]")).click();
				      //Click on Apply Filter Button
				      driver.findElement(By.xpath("//span[contains(text(),'Apply Filter')]")).click(); 
				      
				      
				      Thread.sleep(5000);
				      
				      wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//th[contains(text(),'Over All %')]")));
				      
				      WebElement OverAllPercentage=driver.findElement(By.xpath("//th[contains(text(),'Over All %')]"));
				      System.out.println("OverAllPercentage field displayed in Success Report->"+OverAllPercentage.isDisplayed());
				      
			  //Clicking on Value link present in Overall Percentage field
				          
				      driver.findElement(By.xpath("//tbody/tr[1]/td[3]/button[1]")).click();
				      
				      Thread.sleep(3000);
				      wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h1[contains(text(),'Claims Current Status')]")));
				 
				      String PageTitle2=driver.findElement(By.xpath("//h1[contains(text(),'Claims Current Status')]")).getText();
				      System.out.println("Page Title upon clicking value link in overall percentage field in success report->"+PageTitle2);   
			          
				    //Click on Apply Filter button
				
				    driver.findElement(By.xpath("//app-claimscurrentstatus/div[2]/div/div/form/fieldset[4]/button[1]")).click();      
				      
				    Thread.sleep(3000);
				    
				    driver.switchTo().defaultContent();
				    String ValidationError=driver.findElement(By.xpath("//div[contains(text(),'Please select Queue Name')]")).getText();
				    System.out.println("validation Error Message->"+ValidationError);
				    
				    Thread.sleep(3000);
				      
				    
           SoftAssert softassert = new SoftAssert();
		     
           softassert.assertTrue(OverAllPercentage.isDisplayed(),"OverAllPercentage field not displayed in Success Report");
           softassert.assertTrue(PageTitle2.equalsIgnoreCase("Claims Current Status"),"Incorrect page opened upon clicking value link in overall percentage field in success report");
           softassert.assertTrue(ValidationError.equalsIgnoreCase("Please select Queue Name"),"Incorrect Error Message");
		       
           softassert.assertAll();
		      
		      System.out.println("TC032_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC032_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				//Closing child screens
		      driver.findElement(By.xpath("//app-successreport[1]/div[3]/p-sidebar[1]/div[1]/a[1]/span[1]")).click(); 
			   Thread.sleep(2000);
		       driver.findElement(By.xpath("//app-leaderdashboard[1]/div[4]/p-sidebar[1]/div[1]/a[1]/span[1]")).click();   
				      
			   
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC032_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC032_leaderDashboard Failed"); 

					 //Closing child screens
					   driver.findElement(By.xpath("//app-successreport[1]/div[3]/p-sidebar[1]/div[1]/a[1]/span[1]")).click(); 
					   Thread.sleep(2000);
					   driver.findElement(By.xpath("//app-leaderdashboard[1]/div[4]/p-sidebar[1]/div[1]/a[1]/span[1]")).click();   
							      		   
					   
					   
					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
		
		
		      }
	
	
}
