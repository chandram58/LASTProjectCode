package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC082_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void ApplyFilterSelectLeaderValidationSuccessReport() throws IOException
		{
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=18;
				
	     try{
				 
	    	 WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
		  
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
			 
			    Thread.sleep(5000);
			    WebElement SuccessReportLink=driver.findElement(By.xpath("//a[contains(text(),'Success Report')]"));
			    SuccessReportLink.click();
				
			    Thread.sleep(5000);
	           String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Success Report')]")).getText();
		      System.out.println("Page Title->"+PageTitle);
		    
		    
		     
		      //Click on Apply Filter Button
		      driver.findElement(By.xpath("//span[contains(text(),'Apply Filter')]")).click(); 
		      
		     driver.switchTo().defaultContent();
		     String ErrorMessage=driver.findElement(By.xpath("//div[contains(text(),'Please select Leader from dropdown')]")).getText();
		     System.out.println("Error Message->"+ErrorMessage); 
		     
		      
		 
		      SoftAssert softAssert = new SoftAssert();
			  softAssert.assertTrue(ErrorMessage.equalsIgnoreCase("Please select Leader from dropdown") , "Incorrect Error Message");
		      softAssert.assertAll();
		      
		      System.out.println("TC082_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.PASS, "TC082_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
		    //Closing child window
		driver.findElement(By.xpath("//app-leaderdashboard/div[4]/p-sidebar/div/div[1]/button/span")).click();		
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC082_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC082_leaderDashboard Failed"); 

					 //Closing child window
						// driver.findElement(By.xpath("//app-leaderdashboard[1]/div[4]/p-sidebar[1]/div[1]/a[1]/span[1]")).click();  
					   
						 
						 String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
			
		      }
	
}
