package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC011_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void QueueInventoryReportHyperlink() throws IOException
		{
			driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=7;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,10000);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
			 
			    Thread.sleep(10000);
			    
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-leaderdashboard/div[1]/div[1]/div/div[1]/header/a")));
			   
			    
			 
			    
			    wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Queue Inventory Report')]")));
			    driver.findElement(By.xpath("//a[contains(text(),'Queue Inventory Report')]")).click(); 
			    Thread.sleep(3000);
			
			   
			    String Pagetitle=driver.findElement(By.xpath("//h1[contains(text(),'Queue Inventory Report')]")).getText();
			    System.out.println("Page Title->"+Pagetitle);
			  
			    
			    SoftAssert softassert=new SoftAssert();    
		     
			    softassert.assertTrue(Pagetitle.contains("Queue Inventory Report"), "On Clicking link Queue Inventory Report not opening");
		     
			    softassert.assertAll();
		      
		      System.out.println("TC011_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.PASS, "TC011_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
		    //closing child page
				driver.findElement(By.xpath("//app-leaderdashboard[1]/div[2]/p-sidebar[1]/div[1]/a[1]/span[1]")).click();		
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC011_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC011_leaderDashboard Failed"); 
                     System.out.println(e.getMessage());
                     
                     //closing child page
				//		driver.findElement(By.xpath("//app-leaderdashboard[1]/div[2]/p-sidebar[1]/div[1]/a[1]/span[1]")).click();		     
					   
					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						 // Assert.fail(e.getMessage());
					
					  
				      }
			
		      }
	
}
