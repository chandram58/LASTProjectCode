package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC047_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void ResetFunctionalityQueueInventoryReport() throws IOException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=47;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,10000);
			 System.out.println("0");
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
		        Thread.sleep(5000);
			 
		        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Queue Inventory Report')]")));
			    WebElement QueueInventoryLink=driver.findElement(By.xpath("//a[contains(text(),'Queue Inventory Report')]"));
			    QueueInventoryLink.click();
			    Thread.sleep(3000);
			    
	           String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Queue Inventory Report')]")).getText();
		      System.out.println("Page Title->"+PageTitle);
		    
		      //Getting Default value of Select Queues field
		      
		      String DefaultSelectQueueField=driver.findElement(By.xpath("//div[contains(text(),'Select Queues')]")).getText();
		      System.out.println("Default value of Select Queue Field->"+DefaultSelectQueueField);
		      
		      //Click on Select all option for the field
		      driver.findElement(By.xpath("//div[contains(text(),'Select Queues')]")).click();
		      Thread.sleep(2000);
		      driver.findElement(By.xpath("//app-inventoryreport/div[2]/div/div/div/form/fieldset[1]/p-multiselect/div/div[4]/div[1]/div[1]/div[2]")).click();
		      driver.findElement(By.xpath("//h1[contains(text(),'Queue Inventory Report')]")).click();
		      Thread.sleep(3000);
		     // Getting value of the field after selection
		      String SelectedValueSelectQueueField=driver.findElement(By.xpath("//app-inventoryreport/div[2]/div/div/div/form/fieldset[1]/p-multiselect/div/div[2]")).getText();
		      System.out.println("Selected value of Select Queue Field->"+SelectedValueSelectQueueField);
		      
		      //Click on Reset Button
		      driver.findElement(By.xpath(" //span[contains(text(),'Reset')]")).click();
		      
		   
             //Getting value after reset for  Select Queues field
		      
		      String SelectQueueFieldValueAfterReset=driver.findElement(By.xpath("//div[contains(text(),'Select Queues')]")).getText();
		      System.out.println("Select Queue Field value after Reset->"+SelectQueueFieldValueAfterReset);
		      
		    
		      SoftAssert softAssert = new SoftAssert();
			  softAssert.assertTrue(PageTitle.equalsIgnoreCase("Queue Inventory Report"), "Queue Inventory Report not Displayed");
			  softAssert.assertTrue(SelectQueueFieldValueAfterReset.equals(DefaultSelectQueueField),"Reset Button not working properly");
		      softAssert.assertAll();
		      
		      System.out.println("TC047_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.PASS, "TC046_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC047_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC047_leaderDashboard Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
			
		      }
	
}
