package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC015_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void DatePickerFunctionalityInventoryNewClosedWorksection() throws IOException
		{
			
			driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=45;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			// wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
			 
			    Thread.sleep(5000);
			    
			    //Getting Default Report date for the section
			    String DefaultReportDate=driver.findElement(By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[2]/div[1]/div[1]")).getText();
				  System.out.println("Default Report Date for the section->"+DefaultReportDate);
			    
			    
			   
				//getting current date
				    SimpleDateFormat date1=new SimpleDateFormat("MM/dd/yyyy"); 
					 Calendar calendar = Calendar.getInstance();
					 
					 
					 int currentmonth = calendar.get(Calendar.MONTH)+1;//+1 since Month is indexed from 0
					 System.out.println("Current month in int Format->"+(calendar.get(Calendar.MONTH)+1));
					 
					 int currentYear= calendar.get(Calendar.YEAR);
					 System.out.println("Current month in int Format->"+currentmonth+ " Current Year->"+currentYear);
					 
					 
					 calendar.add(Calendar.YEAR, -7);
				     Date todate1 = calendar.getTime();
				     int SelectedDate=calendar.get(Calendar.DATE);
				     int SelectedDateMonth=calendar.get(Calendar.MONTH);
					 int SelectedDateYear=calendar.get(Calendar.YEAR);
					 
					 System.out.println("Selected date in int Format->"+SelectedDate+"Selected date month in int Format->"+SelectedDateMonth+" Selected date Year->"+SelectedDateYear); 
				     String fromdate = date1.format(todate1);
					 
					
					 
					 String SelectedDateWithoutMonthYearString=fromdate.substring(fromdate.indexOf("/")+1, fromdate.lastIndexOf("/"));
					 System.out.println("Selected date 7 year ago  without month and Year in string format->"+SelectedDate);
					 
					 int SelectedDateWithoutMonthYearInt=Integer.parseInt(SelectedDateWithoutMonthYearString);
					 System.out.println("Selected date 7 year ago without month and Year in int format->"+SelectedDateWithoutMonthYearInt);
					 
					 
			
			  
			    //Clicking on Calendar
				driver.findElement(By.xpath("//app-leaderdashboard/div[1]/div[1]/div/section[2]/div[1]/header/span/p-calendar/span/button/span[1]")).click();
			   
			    
			    //Clicking on Year DropDown
			    driver.findElement(By.xpath("//p-calendar[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/select[2]")).click();
			    driver.findElement(By.xpath("//p-calendar[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/select[2]/option[1]")).click();  //Selecting Year 7 year ago
			    
			    
			    //Now Selecting Active Dates in a List
			    
			    List<WebElement> ActiveDates=  driver.findElements(By.xpath("//p-calendar/span/div/div[1]/div/div[2]/table/tbody/tr/td/span")); 
			    
			 
			    System.out.println("Earliest Date enabled for selection is->"+ActiveDates.get(0).getText());
			    
			    System.out.println(ActiveDates);

				
				
				SoftAssert softAssert = new SoftAssert();
     
	    softAssert.assertTrue((SelectedDateWithoutMonthYearInt)==(Integer.parseInt(ActiveDates.get(0).getText())), "Dates previous to 7 years are enabled ");
		     
		    
		 softAssert.assertAll();
		      
		      System.out.println("TC015_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.PASS, "TC015_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC015_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC015_leaderDashboard Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
			
		      }
	
}
