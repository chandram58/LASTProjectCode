package testRepository.GR.leaderDashboard_GR;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC042_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void ExporttoPDFQueueInventoryReport() throws IOException
		{
			
			driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
               System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
				
			   int i=50;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,10000);
			 System.out.println("0");
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
		        Thread.sleep(5000);
			 
		        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Queue Inventory Report')]")));
			    WebElement QueueInventoryLink=driver.findElement(By.xpath("//a[contains(text(),'Queue Inventory Report')]"));
			    QueueInventoryLink.click();
			    Thread.sleep(3000);
			    
	           String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Queue Inventory Report')]")).getText();
		      System.out.println("Page Title->"+PageTitle);
		    
		      
		    
		      //Click on Apply Filter Button
		      driver.findElement(By.xpath("//span[contains(text(),'Apply Filter')]")).click();
		      
		      Thread.sleep(3000);
		      //Look for WorkItems table
		      WebElement WorkItemsSection=  driver.findElement(By.xpath("//strong[contains(text(),'WORK ITEMS')]"));
		      System.out.println("WorkItems Section Displayed->"+WorkItemsSection.isDisplayed());
		      
		  	
				 WebElement DownloadPDF=driver.findElement(By.xpath("//header/div[1]/a[3]/i[1]"));
					
					System.out.println("Clicking On Export to PDF icon");
				//    test.log(LogStatus.INFO, "Clicking On Export to PDF icon")
					DownloadPDF.click();
				 

				  Thread.sleep(10000);
				 
				//  test.log(LogStatus.INFO, "Getting Downloaded File Name");
		           File getLatestFile = base.getLatestFilefromDir(DownloadFilepath);
			 
				    String fileName = getLatestFile.getName();
				    
				    System.out.println("Downloaded File name->"+fileName);
				//    test.log(LogStatus.INFO, "Downloaded File name->"+fileName);
				    
	                System.out.println("1");
				
			 
			        Thread.sleep(5000);
			
		      
		      SoftAssert softAssert = new SoftAssert();
			  softAssert.assertTrue(PageTitle.equalsIgnoreCase("Queue Inventory Report"), "Queue Inventory Report not Displayed");
			  softAssert.assertTrue(WorkItemsSection.isDisplayed(), "On clicking Apply Filter Button Work Items section not getting displayed ");
		     
			  // verifying whether the file  with fileName present in the directory downloadpath or not
			  softAssert.assertTrue(isFileDownloaded(DownloadFilepath, fileName), "Download Failed");
			    //verifying whether the latest downloaded file contains "xlsx" extension or not and name of file having TransmissionsList word in it
			  softAssert.assertTrue(fileName.contains("pdf") && fileName.contains("QueueInventoryReport"),"It is not a PDF file");
			   
			  softAssert.assertAll();
		      
		      System.out.println("TC042_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.PASS, "TC042_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
		      //closing child page
				driver.findElement(By.xpath("//app-leaderdashboard/div[2]/p-sidebar/div/div[1]/button/span")).click();		     
					     	
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC042_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC042_leaderDashboard Failed"); 

					   //closing child page
					//	driver.findElement(By.xpath("//app-leaderdashboard/div[2]/p-sidebar/div/div[1]/button/span")).click();	   
					   
					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
						 	     
								     		   
				      }
			
		      }
	
}
