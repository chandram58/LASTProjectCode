package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC036_leaderDashboard_WorkItemsTablePendedItemsScreenpage extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void WorkItemsTablePendedItemsScreen() throws IOException
		{
			
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=36;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 //wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
				
				
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
			 
			 
		
			 System.out.println("1");
				
			 
			 Thread.sleep(5000);
			
			WebElement PenededItemssection=driver.findElement(By.xpath("//strong[contains(text(),'PENDED ITEMS')]"));
			System.out.println("Peneded Items section dispalyed on Leader Dashboard page->"+PenededItemssection.isDisplayed());
			
			//Click on links in Pended Items table
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tbody/tr[5]/td[2]/a[1]")));
			driver.findElement(By.xpath("//tbody/tr[5]/td[2]/a[1]")).click();
			
			String PageTitle2=driver.findElement(By.xpath("//h1[contains(text(),'Pended Items')]")).getText();
			System.out.println("Page Opened upon clicking on links in Pended Items table->"+PageTitle2);
			
			Thread.sleep(5000);	
			//Click on Apply Filter Button
		    driver.findElement(By.xpath("//span[contains(text(),'Apply Filter')]")).click(); 
		    Thread.sleep(3000);	
			WebElement WorkItemsTable=driver.findElement(By.xpath("//strong[contains(text(),'WORK ITEMS')]"));
			
		    System.out.println("WorkItems table Displayed->"+WorkItemsTable.isDisplayed());
		    
			
			 
			
           SoftAssert softAssert = new SoftAssert();
		     
		    // test.log(LogStatus.INFO ,"Verifying page Title");
		     
	    softAssert.assertTrue(PenededItemssection.isDisplayed(), "Peneded Items section is not displayed");
	    softAssert.assertTrue(PageTitle2.equalsIgnoreCase("Pended Items"), "Peneded Items page not Opened upon clicking on links in Pended Items table");     
	     softAssert.assertTrue(WorkItemsTable.isDisplayed(), "Work items table is not displayed on pended items page");    
		 softAssert.assertAll();
		      
		      System.out.println("TC036_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC036_groupMaintenance Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC036_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC036_leaderDashboard Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
			
		      }
	
}
