package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC045_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void ResourceProductivityReportLinkDashboardPage() throws IOException
		{
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=6;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			
		  
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
			 
			    
			    WebElement QueueInventoryLink=driver.findElement(By.xpath("//a[contains(text(),'Resource Productivity Report')]"));
			    QueueInventoryLink.click();
				
	           String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Resource Productivity Report')]")).getText();
		      System.out.println("Page Title->"+PageTitle);
		    
		      
		      SoftAssert softAssert = new SoftAssert();
			  softAssert.assertTrue(PageTitle.equalsIgnoreCase("Resource Productivity Report"), "Resource Productivity Report not Displayed");
		      softAssert.assertAll();
		      
		      System.out.println("TC013_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.PASS, "TC013_leaderDashboard Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				//Closing child window
		      driver.findElement(By.xpath("//app-leaderdashboard[1]/div[3]/p-sidebar[1]/div[1]/div[1]/button[1]/span[1]")).click();
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC013_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC013_leaderDashboard Failed"); 

						//Closing child window
					 //     driver.findElement(By.xpath("//app-leaderdashboard/div[2]/p-sidebar/div/div[1]/button/span")).click();   
					   
					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					
				      }
			
		      }
	
}
