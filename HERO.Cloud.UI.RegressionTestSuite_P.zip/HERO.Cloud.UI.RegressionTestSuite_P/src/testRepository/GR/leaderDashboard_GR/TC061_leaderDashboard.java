package testRepository.GR.leaderDashboard_GR;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC061_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void CloseIconFunctionalityResourceProductivityReport() throws IOException
		{
			driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   int i=21;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,1000);
			 System.out.println("0");
			
			
		  
			 Thread.sleep(5000);
			 
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
			    action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
		        System.out.println("1");
				
			 
			    Thread.sleep(5000);
			    WebElement ResoureceProductivityReportLink=driver.findElement(By.xpath("//a[contains(text(),'Resource Productivity Report')]"));
			    ResoureceProductivityReportLink.click();
			    
			    Thread.sleep(5000);
				
	           String PageTitle=driver.findElement(By.xpath("//h1[contains(text(),'Resource Productivity Report')]")).getText();
		      System.out.println("Page Title before clicking close button->"+PageTitle);
				Thread.sleep(3000);
				 SoftAssert softassert = new SoftAssert();
			    softassert.assertTrue(PageTitle.equalsIgnoreCase("Resource Productivity Report"), "Resource Productivity Report link not working");
				
			//Clicking on Close Button
			  boolean flag=true;
			driver.findElement(By.xpath("//app-leaderdashboard[1]/div[3]/p-sidebar[1]/div[1]/div[1]/button[1]/span[1]")).click();
			try
			{
		 driver.findElement(By.xpath("//h1[contains(text(),'Resource Productivity Report')]"));
		  System.out.println("Resource Productivity report not getting closed even after clicking close button");
		  flag=false;
			}
			catch(Exception e)
			{
			System.out.println("Resource Productivity report is closed");	
			}
			    
			
			softassert.assertTrue(flag, "Close button not working");
			 softassert.assertAll();
		      System.out.println("TC021_manintainErrorcodes Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC021_manintainErrorcodes Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC021_manintainErrorcodes Failed");
					   
					//  test.log(LogStatus.FAIL, "TC021_manintainErrorcodes Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
		
		
		      }
	
	
}
