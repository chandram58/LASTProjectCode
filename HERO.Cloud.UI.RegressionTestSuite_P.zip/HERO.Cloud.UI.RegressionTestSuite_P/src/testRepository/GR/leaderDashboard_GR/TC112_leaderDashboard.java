package testRepository.GR.leaderDashboard_GR;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC112_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void SelectSectiontoExportLeaderDashboardScreen() throws IOException
		{
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
			   
			   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   int i=42;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
				
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
				
				
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
			 
			 Thread.sleep(5000);
		
			 System.out.println("1");
			 
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select Sections to Export')]")));
			 driver.findElement(By.xpath("//div[contains(text(),'Select Sections to Export')]")).click();
			 
			 List<WebElement> SelectSectionstoImport=driver.findElements(By.xpath("//p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem/li/span"));
			 
			 System.out.println("No of Options in section select Sections to Import->"+SelectSectionstoImport.size());
			 
			 driver.findElement(By.xpath("//header/div[1]/p-multiselect[1]/div[1]/div[4]/div[1]/div[1]/div[2]")).click();
			 
			 String SectionsSelected= driver.findElement(By.xpath("//div[contains(text(),'Sections Selected')]")).getText();
			 System.out.println(SectionsSelected);
			 
			 String NoofSectionsSelected=SectionsSelected.substring(0,SectionsSelected.indexOf("Sections Selected"));
			 System.out.println("Sections Selected->"+NoofSectionsSelected);
			 
			 Thread.sleep(5000);
			
			
			
		    SoftAssert softAssert = new SoftAssert();
		     
		    // test.log(LogStatus.INFO ,"Verifying page Title");
		     
	    softAssert.assertTrue(Integer.parseInt(NoofSectionsSelected.trim())>=1, "User not able to select multiple selections");
	  
	    softAssert.assertAll();
		      
		      System.out.println("TC042_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC042_groupMaintenance Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC042_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC042_leaderDashboard Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
			
		      }
	
}
