package testRepository.GR.leaderDashboard_GR;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilities.xlUtils;

import com.relevantcodes.extentreports.LogStatus;

import base.base;

public class TC113_leaderDashboard extends base
{

	public String xlinputfile,xlReportPath;

	public String Xlsheet_InputQuery="Query_roleManagement";
	public String Xlsheet_ReportModule="Role Management";

		

		@Test
		public void ExporttoExcelLeaderDashboardScreen() throws IOException
		{
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			 xlinputfile=(getPropertyValue())[0].toString();
			   System.out.println(xlinputfile);
			
   xlReportPath=(getPropertyValue())[3].toString();
			   
			   System.out.println(xlReportPath);
			   
			   String[] Value = base.getPropertyValue();
				
				String DownloadFilepath=Value[2];
		    	
				System.out.println(DownloadFilepath);
			   
			   int i=43;
				
	     try{
				 
			  WebDriverWait wait=new WebDriverWait(driver,100);
			 System.out.println("0");
			
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[2]/a[1]")));
				
			
		  
			 Thread.sleep(5000);
			 
			
				Actions action = new Actions(driver);
				action.moveToElement(driver.findElement(By.xpath("//app-navigation-bar[1]/div[1]/ul[1]/li[1]/a[1]"))).perform();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(text(),'Leader Dashboard')]")));
				action.moveToElement(driver.findElement(By.xpath("//a[contains(text(),'Leader Dashboard')]"))).click().release().build().perform();
				
				
				action.moveToElement(driver.findElement(By.xpath("//html//body"))).click().perform();
			 
			 Thread.sleep(5000);
		
			 System.out.println("1");
			 
			 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'Select Sections to Export')]")));
			 driver.findElement(By.xpath("//div[contains(text(),'Select Sections to Export')]")).click();
			 
			 List<WebElement> SelectSectionstoImport=driver.findElements(By.xpath("//p-multiselect/div/div[4]/div[2]/ul/p-multiselectitem/li/span"));
		     //Click on Select All options
			 driver.findElement(By.xpath("//header/div[1]/p-multiselect[1]/div[1]/div[4]/div[1]/div[1]/div[2]")).click();
			 driver.findElement(By.xpath("//html//body")).click();
			 
			 
			 Thread.sleep(5000);
			
			 WebElement DownloadExcel=driver.findElement(By.xpath("//header/div[1]/div[1]/ul[1]/li[1]/a[1]/em[1]"));
				
				System.out.println("Clicking On Export to Excel icon");
			//    test.log(LogStatus.INFO, "Clicking On Export to Excel icon");
			    DownloadExcel.click();
			 

			  Thread.sleep(10000);
			 
			//  test.log(LogStatus.INFO, "Getting Downloaded File Name");
	           File getLatestFile = base.getLatestFilefromDir(DownloadFilepath);
		 
			    String fileName = getLatestFile.getName();
			    
			    System.out.println("Downloaded File name->"+fileName);
			//    test.log(LogStatus.INFO, "Downloaded File name->"+fileName);
			    
             System.out.println("1");
			
		 
		 Thread.sleep(5000);
			
		    SoftAssert softAssert = new SoftAssert();
		     
		    // test.log(LogStatus.INFO ,"Verifying page Title");
		     
		    // verifying whether the file  with fileName present in the directory downloadpath or not
		    softAssert.assertTrue(isFileDownloaded(DownloadFilepath, fileName), "Download Failed");
		    //verifying whether the latest downloaded file contains "xlsx" extension or not and name of file having TransmissionsList word in it
		    softAssert.assertTrue(fileName.contains("xls") && fileName.contains("LeaderDashboard"),"It is not a excel file");
		    
	         softAssert.assertAll();
		      
		      System.out.println("TC043_leaderDashboard Passed");
		      
		    //  test.log(LogStatus.FAIL, "TC043_groupMaintenance Passed"); 
				   
		      String status="Pass";
		       
		     // xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
			   
			//     xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,""); 
				     
				
					     
				        }
				   
	    catch(Throwable e)
				     {
					   System.out.println("TC043_leaderDashboard Failed");
					   
					//  test.log(LogStatus.FAIL, "TC043_leaderDashboard Failed"); 

					  
					   String status="Fail";
				       
					//	xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 3,status);
						   
					  //   xlUtils.setCellData(xlReportPath, Xlsheet_ReportModule, i, 4,"Validation Error"); 
						     
						  Assert.fail(e.getMessage());
						     
					   
				      }
			
		      }
	
}
