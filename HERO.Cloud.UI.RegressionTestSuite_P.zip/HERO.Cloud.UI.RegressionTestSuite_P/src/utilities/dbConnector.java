package utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class dbConnector 
{
	
	public static Connection dbcon;
    String resultValue = "";
    public ResultSet rs;
    public static Properties prop; 
    public static String rootFolderPath;
    public static FileInputStream fis;
    public String uid,pwd,dburl;
 //public String uid = "heroqa";
   
 //public String pwd = "hero@Qa123";
   
    
  //public String dburl="jdbc:sqlserver://hqri2-hero-data-east2-int-hyperscale.database.windows.net:1433;database=hero-hqri2-sql-hyper-intdb-001;user=heroqa;password=hero@Qa123;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;;";
    

    
    
@BeforeSuite
 public void setUpDBConnection() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException
 {
	//Logger.getRootLogger().setLevel(Level.OFF);
	 prop=new Properties();
		
  	 rootFolderPath = new File("").getAbsolutePath();
       System.out.println(rootFolderPath);
  	
  	fis=new FileInputStream(rootFolderPath+"\\src\\Resources\\properties\\config.properties");	

       prop.load(fis);
    
  	 
		  uid=prop.getProperty("uid");
		  System.out.println("uid->"+uid);
		  pwd=prop.getProperty("pwd");
		  System.out.println("pwd->"+pwd);
		dburl=prop.getProperty("dburl");
		 System.out.println("dburl->"+dburl);
	
	System.out.println("Setting Up Database Connection");
     
	                 try 
	                     {
		                  Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver").newInstance();
	                     }
		
	                   catch (ClassNotFoundException e)
	                   {
		                  e.getMessage();
	                        }

	                   
	   
	try
		{
	   dbcon=DriverManager.getConnection(dburl, uid, pwd);
		
		System.out.println("Connected to Database");
		        
		    if(dbcon!=null) {
		    	System.out.println("Connected to the database...");
            }
		    else 
		    {
		    	System.out.println("Database connection failed to Environment");
            }
		}
		 
		 
		 catch (SQLException ex) 
		 {
             ex.getMessage();
          }
		
	 
 }

@AfterSuite
 public void closeDBConnection() {
     if (dbcon != null) {
               try {
            	   System.out.println("Closing Database Connection...");
                   dbcon.close();
               } 
               catch (SQLException ex) 
               {
                   ex.getMessage();
               }
           }
      }	

}



