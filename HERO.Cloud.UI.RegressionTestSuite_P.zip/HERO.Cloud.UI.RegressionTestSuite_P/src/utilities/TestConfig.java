package utilities;
public class TestConfig
{
	
	
	public static String server="pobox.humana.com";
	public static String from = "ckumar12@humana.com";
	public static String password = "apr#2020";
	public static String[] to ={"ckumar12@humana.com"};
	public static String subject = "HERO WEB Automation Report";
	
	public static String messageBody ="TestMessage";
	public static String attachmentPath="c:\\screenshot\\2017_10_3_14_49_9.jpg";
	public static String attachmentName="error.jpg";
	
}
