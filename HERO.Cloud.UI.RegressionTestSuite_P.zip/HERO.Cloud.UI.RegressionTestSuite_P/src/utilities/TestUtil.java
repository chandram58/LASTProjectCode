package utilities;

import java.io.File;
import java.io.IOException;

import java.util.Date;


import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import base.base;

public class TestUtil extends base {

	public static String screenshotPath;
	public static String screenshotName;
	private static String fileSeperator = System.getProperty("file.separator");
	
	
	public static void captureScreenshot(String testName) throws IOException, InterruptedException {

		try {
			File file = new File("Screenshots" + fileSeperator + "Results");
			if (!file.exists()) {
				System.out.println("File created " + file);
				file.mkdir();
			}
		
		
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		Date d = new Date();
		screenshotName = testName+"_"+d.toString().replace(":", "_").replace(" ", "_") + ".jpg";
		
		File targetFile = new File(System.getProperty("user.dir") +"Screenshots" + fileSeperator + "Results" + fileSeperator + testName, screenshotName);
		FileUtils.copyFile(scrFile, targetFile);

		FileUtils.copyFile(scrFile,
				new File(System.getProperty("user.dir") + "\\target\\test-reports\\htmlTestReport\\" + screenshotName));
		}
		catch (Exception e) {
			System.out.println("An exception occured while taking screenshot " + e.getCause());
			
		}
		
		
	}
		

	public String getTestClassName(String testName) {
		String[] reqTestClassname = testName.split("\\.");
		int i = reqTestClassname.length - 1;
		System.out.println("Required Test Name : " + reqTestClassname[i]);
		return reqTestClassname[i];
	}
	
	
}
