package utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class xlUtils 
{
 public static FileInputStream fi;
 public static FileOutputStream fo;
 /*public static HSSFWorkbook wb;
 
 public static HSSFSheet ws;
 public static HSSFRow row;
 public static HSSFCell cell;
 */
 public static XSSFWorkbook wb;
 public static XSSFSheet ws;
 public static XSSFRow row;
 public static XSSFCell cell;
 public static CellStyle style;
 
 
 public static int getRowCount(String xlfile,String Xlsheet) throws IOException
 {
	int rowcount;
	fi=new FileInputStream(xlfile);
	wb=new XSSFWorkbook(fi);
	ws=wb.getSheet(Xlsheet);
	rowcount=ws.getLastRowNum();
	wb.close();
	fi.close();
	return rowcount;
	  
 }
 
 public static int getCellCount(String xlfile,String Xlsheet,int rownum) throws IOException
 {
	int cellcount;
	fi=new FileInputStream(xlfile);
	wb=new XSSFWorkbook(fi);
	ws=wb.getSheet(Xlsheet);
	row=ws.getRow(rownum);
	cellcount=row.getLastCellNum();
	wb.close();
	fi.close();
	return cellcount;
	  
 }
 
 public static String getCellData(String xlfile,String Xlsheet,int rownum,int colnum) throws IOException
 {
	 fi=new FileInputStream(xlfile);
	 wb=new XSSFWorkbook(fi);
	 ws=wb.getSheet(Xlsheet);
	 row=ws.getRow(rownum);
	 String data;
	 try{
	 cell=row.getCell(colnum);
	 data=cell.getStringCellValue();
	 }
	 catch(Exception e)
	 {       
		System.out.println(e.getMessage());
		data="";
	 }
	 wb.close();
	 fi.close();
	return data;
	 
 }
 
 public static void setCellData(String xlfile,String Xlsheet,int rownum,int colnum,String data) throws IOException
 {
	 fi=new FileInputStream(xlfile);
	 
	 wb=new XSSFWorkbook(fi);
	 ws=wb.getSheet(Xlsheet);
	 row=ws.getRow(rownum);
	 
	
	
	 cell=row.createCell(colnum);
	 cell.setCellValue(data);
	 fo=new FileOutputStream(xlfile);
	 wb.write(fo);
	
	
	wb.close();
	fi.close();
	fo.close();
	 
 }
 
 
 
 
 
}
